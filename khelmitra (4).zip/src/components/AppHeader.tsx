import { Bell, Wallet, Gift, Settings, Coins, Smartphone, Headphones, UserPlus, ShieldCheck } from 'lucide-react';
import { useState, useEffect } from 'react';
import { UserProfile, ActiveSheetType } from '../types';
import KhelMitraLogo from './KhelMitraLogo';
import { demoPointsService } from '../services/demoPointsService';
import { notificationService } from '../services/notificationService';

interface AppHeaderProps {
  user: UserProfile;
  onOpenSheet: (sheet: ActiveSheetType) => void;
}

export default function AppHeader({ user, onOpenSheet }: AppHeaderProps) {
  const [virtualCoins, setVirtualCoins] = useState(demoPointsService.getPoints());
  const [unreadNotifs, setUnreadNotifs] = useState(notificationService.getUnreadCount());

  useEffect(() => {
    const unsubCoins = demoPointsService.subscribe(setVirtualCoins);
    const unsubNotifs = notificationService.subscribe((items) => {
      setUnreadNotifs(items.filter((n) => !n.read).length);
    });
    return () => {
      unsubCoins();
      unsubNotifs();
    };
  }, []);
  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 bg-[#070b14]/95 backdrop-blur-md px-4 py-3 border-b border-slate-800/80 shadow-lg shadow-black/50"
    >
      <div className="flex items-center justify-between gap-2">
        {/* KhelMitra Modern Cricket Logo */}
        <KhelMitraLogo
          variant="header"
          size="md"
          showSubtitle={true}
          onClick={() => onOpenSheet('none')}
        />

        {/* Right Header Utilities: Daily Missions, Wallet, Notifications & Profile Avatar */}
        <div className="flex items-center gap-1.5">
          {/* Daily Missions Quick Button */}
          <button
            id="header-daily-missions-button"
            onClick={() => onOpenSheet('daily-missions')}
            className="relative w-8 h-8 rounded-xl bg-slate-900/90 border border-amber-500/40 hover:border-amber-400 flex items-center justify-center text-amber-400 active:scale-95 transition-all shadow-sm"
            aria-label="Daily Missions"
            title="Daily Missions & Rewards"
          >
            <Gift className="w-4 h-4" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-500"></span>
          </button>

          {/* Wallet Balance Chip */}
          <button
            id="wallet-quick-button"
            onClick={() => onOpenSheet('wallet')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900/90 border border-amber-500/30 hover:border-amber-400/60 active:scale-95 transition-all text-left shadow-sm"
          >
            <div className="w-5 h-5 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
              <Wallet className="w-3.5 h-3.5" />
            </div>
            <div className="flex flex-col pr-0.5">
              <span className="text-[9px] text-slate-400 leading-none font-medium">Wallet</span>
              <span className="text-xs font-bold text-amber-300 leading-tight">
                ₹{user.totalCash.toLocaleString()}
              </span>
            </div>
          </button>

          {/* Notifications Button */}
          <button
            id="notifications-button"
            onClick={() => onOpenSheet('notifications')}
            className="relative w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
            aria-label="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifs > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] px-1 rounded-full bg-red-500 text-white text-[9px] font-black flex items-center justify-center border border-[#070b14] shadow-sm">
                {unreadNotifs > 9 ? '9+' : unreadNotifs}
              </span>
            )}
          </button>

          {/* Virtual Coins Balance Chip */}
          <button
            id="header-virtual-coins-button"
            onClick={() => onOpenSheet('game-history')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500/15 border border-amber-500/40 hover:border-amber-400 active:scale-95 transition-all text-left shadow-sm"
            title="Virtual Coins Balance • Tap for Game History"
          >
            <span className="text-xs">🪙</span>
            <div className="flex flex-col pr-0.5">
              <span className="text-[9px] text-amber-400 leading-none font-bold uppercase">Coins</span>
              <span className="text-xs font-black text-amber-300 font-mono leading-tight">
                {virtualCoins.toLocaleString()}
              </span>
            </div>
          </button>

          {/* Invite Friends Quick Button */}
          <button
            id="header-invite-button"
            onClick={() => onOpenSheet('invite-friends')}
            className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-500/30 hover:border-amber-400 flex items-center justify-center text-amber-400 active:scale-95 transition-all"
            aria-label="Invite Friends"
            title="Invite Friends & Earn Free Coins"
          >
            <UserPlus className="w-4 h-4" />
          </button>

          {/* Customer Care Button */}
          <button
            id="header-support-button"
            onClick={() => onOpenSheet('customer-care')}
            className="w-8 h-8 rounded-xl bg-blue-500/15 border border-blue-500/30 hover:border-blue-400 flex items-center justify-center text-blue-400 active:scale-95 transition-all"
            aria-label="Customer Care"
            title="Customer Care, Help & 24/7 Support"
          >
            <Headphones className="w-4 h-4" />
          </button>

          {/* Android APK Download Quick Button */}
          <button
            id="header-apk-download-button"
            onClick={() => onOpenSheet('apk-download')}
            className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 hover:border-emerald-400 active:scale-95 transition-all text-emerald-400 shadow-sm"
            title="Download Android APK / Project"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="text-[10px] font-black uppercase tracking-wider font-mono">APK</span>
          </button>

          {/* Settings Button */}
          <button
            id="header-settings-button"
            onClick={() => onOpenSheet('settings')}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
            aria-label="Settings"
            title="Gaming Settings & Preferences"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>

          {/* Master Owner Control Panel Button */}
          <button
            id="header-owner-panel-button"
            onClick={() => onOpenSheet('master-owner')}
            className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-500/40 hover:border-amber-400 flex items-center justify-center text-amber-400 active:scale-95 transition-all shadow-sm"
            aria-label="Master Owner Control Panel"
            title="Master Owner Control Panel"
          >
            <ShieldCheck className="w-4 h-4" />
          </button>

          {/* Profile Avatar Button */}
          <button
            id="header-profile-button"
            onClick={() => onOpenSheet('profile')}
            className="relative flex items-center p-0.5 rounded-xl border border-slate-700 hover:border-amber-500/80 active:scale-95 transition-all"
            title="User Profile"
          >
            <img
              src={user.avatarUrl}
              alt={user.name}
              className="w-8 h-8 rounded-[10px] object-cover"
              referrerPolicy="no-referrer"
            />
            <span className="absolute -bottom-1 -right-1 px-1 py-0.2 bg-amber-500 text-[8px] font-black text-slate-950 rounded font-mono">
              L{user.level}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
