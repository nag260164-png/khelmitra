import { 
  X, Radio, Trophy, Users, Gamepad2, User, Wallet, Bell, 
  ChevronRight, Shield, Award, CheckCircle2, ArrowUpRight, 
  Flame, Zap, Sparkles, RefreshCw, Star, Info, Plus
} from 'lucide-react';
import { ActiveSheetType, UserProfile, UserTeam } from '../types';
import { LIVE_MATCHES, FANTASY_CONTESTS, GAMES_LIST } from '../data/mockData';
import { useState } from 'react';
import LiveCricketHub from './cricket/LiveCricketHub';
import FantasyTeamCreator from './fantasy/FantasyTeamCreator';
import MyFantasyTeamsHub from './fantasy/MyFantasyTeamsHub';
import FantasyRulesPage from './fantasy/FantasyRulesPage';
import GamesDashboard from './games/GamesDashboard';
import DailyMissionsSheet from './missions/DailyMissionsSheet';
import CallBreakGame from './games/CallBreakGame';
import TeenPattiGame from './games/TeenPattiGame';
import LudoGame from './games/LudoGame';
import RummyGame from './games/RummyGame';
import GameHistoryModal from './games/GameHistoryModal';
import GameSettingsModal from './games/GameSettingsModal';
import LeaderboardModal from './games/LeaderboardModal';
import RewardsModal from './games/RewardsModal';
import AndroidApkModal from './AndroidApkModal';
import CustomerCareModal from './support/CustomerCareModal';
import InviteFriendsModal from './referral/InviteFriendsModal';
import NotificationCenterModal from './notifications/NotificationCenterModal';
import MasterOwnerControlPanel from './admin/MasterOwnerControlPanel';
import ProductDetailSheet from './reselling/ProductDetailSheet';
import ResellerOrderModal from './reselling/ResellerOrderModal';
import ResellerDashboardView from './reselling/ResellerDashboardView';
import SupplierPortalView from './reselling/SupplierPortalView';
import { resellingService } from '../services/resellingService';
import { ResellerProduct } from '../types';

interface ActionModalSheetProps {
  sheetType: ActiveSheetType;
  user: UserProfile;
  onClose: () => void;
  onSwitchSheet: (type: ActiveSheetType) => void;
}

export default function ActionModalSheet({ sheetType, user, onClose, onSwitchSheet }: ActionModalSheetProps) {
  const [selectedMatchIdx, setSelectedMatchIdx] = useState(0);
  const [joinedContests, setJoinedContests] = useState<string[]>([]);
  const [activeGamePlaying, setActiveGamePlaying] = useState<string | null>(null);
  const [spinResult, setSpinResult] = useState<string | null>(null);
  const [editingTeam, setEditingTeam] = useState<UserTeam | null>(null);
  const [walletNotice, setWalletNotice] = useState<string | null>(null);

  const showWalletNotice = (msg: string) => {
    setWalletNotice(msg);
    setTimeout(() => setWalletNotice(null), 3000);
  };

  if (sheetType === 'none') return null;

  // Dedicated Full Sheet for Live Cricket
  if (sheetType === 'live-cricket') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[94vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <LiveCricketHub onClose={onClose} />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for Fantasy Team Creation & Editing
  if (sheetType === 'create-team') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <FantasyTeamCreator
            editingTeam={editingTeam}
            onClose={() => {
              setEditingTeam(null);
              onSwitchSheet('my-teams');
            }}
            onSaved={(_savedTeam) => {
              setEditingTeam(null);
              onSwitchSheet('my-teams');
            }}
            onOpenRulesPage={() => onSwitchSheet('fantasy-rules')}
          />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for Fantasy Cricket Rules & Demo Points System
  if (sheetType === 'fantasy-rules') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <FantasyRulesPage
            onClose={onClose}
            onNavigateToCreateTeam={() => onSwitchSheet('create-team')}
          />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for KhelMitra Games Arena
  if (sheetType === 'games') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <GamesDashboard
            onClose={onClose}
            onNavigateToFantasy={() => onSwitchSheet('create-team')}
            onOpenDailyMissions={() => onSwitchSheet('daily-missions')}
          />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for Daily Missions & Rewards
  if (sheetType === 'daily-missions') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <DailyMissionsSheet
            onClose={onClose}
            onNavigateToSheet={onSwitchSheet}
          />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for Call Break Game
  if (sheetType === 'call-break') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <CallBreakGame onBack={onClose} />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for Teen Patti Game
  if (sheetType === 'teen-patti') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <TeenPattiGame onBack={onClose} />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for Ludo Game
  if (sheetType === 'ludo') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <LudoGame onBack={onClose} />
        </div>
      </div>
    );
  }

  // Dedicated Full Sheet for Rummy Game
  if (sheetType === 'rummy') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <RummyGame onBack={onClose} />
        </div>
      </div>
    );
  }

  // Dedicated Modal for Game History
  if (sheetType === 'game-history') {
    return <GameHistoryModal onClose={onClose} />;
  }

  // Dedicated Modal for Game Settings
  if (sheetType === 'settings') {
    return (
      <GameSettingsModal 
        onClose={onClose} 
        onOpenApkCenter={() => onSwitchSheet('apk-download')} 
        onOpenCustomerCare={() => onSwitchSheet('customer-care')}
        onOpenInviteFriends={() => onSwitchSheet('invite-friends')}
        onOpenMasterOwner={() => onSwitchSheet('master-owner')}
      />
    );
  }

  // Dedicated Modal for Leaderboard
  if (sheetType === 'leaderboard') {
    return <LeaderboardModal onClose={onClose} onSelectGame={(g) => onSwitchSheet(g as ActiveSheetType)} />;
  }

  // Dedicated Modal for Rewards & Lucky Wheel
  if (sheetType === 'rewards') {
    return <RewardsModal onClose={onClose} />;
  }

  // Dedicated Modal for Android APK Build & Download
  if (sheetType === 'apk-download') {
    return <AndroidApkModal onClose={onClose} />;
  }

  // Dedicated Modal for Customer Care, Support & FAQs
  if (sheetType === 'customer-care') {
    return <CustomerCareModal onClose={onClose} />;
  }

  // Dedicated Modal for Invite Friends & Referral Rewards
  if (sheetType === 'invite-friends') {
    return <InviteFriendsModal onClose={onClose} />;
  }

  // Dedicated Modal for Notification Center
  if (sheetType === 'notifications') {
    return (
      <NotificationCenterModal 
        onClose={onClose} 
        onSwitchSheet={onSwitchSheet} 
      />
    );
  }

  // Dedicated Modal for Master Owner Control Panel
  if (sheetType === 'master-owner') {
    return <MasterOwnerControlPanel onClose={onClose} />;
  }

  // Dedicated Sheet for Reseller Product Detail & Live Margin Calculator
  if (sheetType === 'product-detail') {
    const product = resellingService.getActiveProduct() || resellingService.getProducts()[0];
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <ProductDetailSheet
            product={product}
            onClose={onClose}
            onPlaceOrder={(p, size, margin) => {
              resellingService.setActiveProduct(p);
              onSwitchSheet('cart-checkout');
            }}
          />
        </div>
      </div>
    );
  }

  // Dedicated Sheet for Reseller Order Modal (Customer delivery address & margin collection)
  if (sheetType === 'cart-checkout') {
    const product = resellingService.getActiveProduct() || resellingService.getProducts()[0];
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <ResellerOrderModal
            product={product}
            initialSize={product.sizes[0] || 'Free Size'}
            initialMargin={250}
            onClose={onClose}
            onOrderSuccess={(_order) => {
              onSwitchSheet('reseller-dashboard');
            }}
          />
        </div>
      </div>
    );
  }

  // Dedicated Sheet for Reseller Dashboard & Order Tracking
  if (sheetType === 'reseller-dashboard' || sheetType === 'order-tracking') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <ResellerDashboardView
            onClose={onClose}
            initialTab={sheetType === 'order-tracking' ? 'orders' : 'payout'}
            onExploreProducts={() => {
              onClose();
            }}
          />
        </div>
      </div>
    );
  }

  // Dedicated Sheet for Wholesale Supplier Portal
  if (sheetType === 'supplier-portal') {
    return (
      <div 
        id="action-modal-overlay" 
        className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
        onClick={onClose}
      >
        <div 
          id="action-modal-sheet-content"
          className="w-full max-w-md h-[95vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          <SupplierPortalView onClose={onClose} />
        </div>
      </div>
    );
  }

  const currentMatch = LIVE_MATCHES[selectedMatchIdx] || LIVE_MATCHES[0];

  const handleJoinContest = (contestId: string) => {
    if (!joinedContests.includes(contestId)) {
      setJoinedContests([...joinedContests, contestId]);
    }
  };

  const handlePlaySpin = () => {
    const rewards = ['₹100 Bonus Cash', 'Free Mega Contest Pass', '500 Khel Coins', '2X Booster'];
    const randomReward = rewards[Math.floor(Math.random() * rewards.length)];
    setSpinResult(randomReward);
  };

  return (
    <div 
      id="action-modal-overlay" 
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="action-modal-sheet-content"
        className="w-full max-w-md max-h-[85vh] bg-[#0c101a] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Android Sheet Top Drag Handle & Title */}
        <div className="pt-3 pb-2 px-5 border-b border-slate-800/80 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2">
            {sheetType === 'fantasy-cricket' && <Trophy className="w-5 h-5 text-amber-400" />}
            {sheetType === 'my-teams' && <Users className="w-5 h-5 text-blue-400" />}
            {sheetType === 'profile' && <User className="w-5 h-5 text-emerald-400" />}
            {sheetType === 'wallet' && <Wallet className="w-5 h-5 text-amber-400" />}

            <h3 className="text-base font-bold text-white tracking-wide">
              {sheetType === 'fantasy-cricket' && 'Fantasy Cricket Contests'}
              {sheetType === 'my-teams' && 'My Cricket Teams'}
              {sheetType === 'profile' && 'KhelMitra Profile'}
              {sheetType === 'wallet' && 'Khel Wallet & Cash'}
            </h3>
          </div>

          <button
            id="close-action-sheet-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 no-scrollbar">

          {/* ================= FANTASY CRICKET SHEET ================= */}
          {sheetType === 'fantasy-cricket' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-slate-900 to-amber-500/10 border border-amber-500/30 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-amber-300">Free Demo Fantasy Contests</span>
                    <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-black">
                      FREE PLAY
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    100% Free Demo points • No real money or betting
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    id="fantasy-sheet-rules-btn"
                    onClick={() => onSwitchSheet('fantasy-rules')}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 border border-amber-500/30 text-xs font-bold flex items-center gap-1 active:scale-95 transition-all"
                  >
                    <Award className="w-3.5 h-3.5" />
                    <span>Rules</span>
                  </button>

                  <button 
                    id="create-team-from-contest-btn"
                    onClick={() => {
                      setEditingTeam(null);
                      onSwitchSheet('create-team');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 text-xs font-black flex items-center gap-1 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Draft 11</span>
                  </button>
                </div>
              </div>

              {FANTASY_CONTESTS.map((contest) => {
                const isJoined = joinedContests.includes(contest.id);
                return (
                  <div 
                    key={contest.id}
                    className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 space-y-2.5"
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">{contest.title}</h4>
                          {contest.guaranteed && (
                            <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded font-bold">
                              Guaranteed
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-slate-400">{contest.matchName}</span>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">Demo Prize Pool</span>
                        <span className="text-base font-sports font-bold text-amber-400">{contest.prizePool}</span>
                      </div>
                    </div>

                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div 
                        style={{ width: `${Math.round((contest.filledSpots / contest.totalSpots) * 100)}%` }}
                        className="bg-amber-500 h-full"
                      ></div>
                    </div>

                    <div className="flex justify-between items-center pt-1 text-xs">
                      <div>
                        <span className="text-slate-400">Entry: </span>
                        <strong className="text-emerald-400 font-bold text-xs">FREE PASS</strong>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            setEditingTeam(null);
                            onSwitchSheet('create-team');
                          }}
                          className="px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-800 text-slate-200 hover:text-white text-xs font-bold"
                        >
                          Draft 11
                        </button>

                        <button
                          onClick={() => handleJoinContest(contest.id)}
                          className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all ${
                            isJoined 
                              ? 'bg-emerald-600 text-white' 
                              : 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:from-amber-400 hover:to-orange-400'
                          }`}
                        >
                          {isJoined ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Joined (T1)</span>
                            </>
                          ) : (
                            <>
                              <Trophy className="w-3.5 h-3.5" />
                              <span>Join Contest</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ================= MY TEAMS SHEET ================= */}
          {sheetType === 'my-teams' && (
            <MyFantasyTeamsHub
              onOpenCreateTeam={(team) => {
                setEditingTeam(team || null);
                onSwitchSheet('create-team');
              }}
              onOpenRulesPage={() => onSwitchSheet('fantasy-rules')}
              onClose={onClose}
            />
          )}

          {/* ================= PROFILE SHEET ================= */}
          {sheetType === 'profile' && (
            <div className="space-y-4">
              {/* Profile Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-[#0d1625] to-slate-950 border border-slate-800 text-center relative overflow-hidden">
                <div className="w-16 h-16 rounded-2xl mx-auto mb-2 overflow-hidden border-2 border-amber-500/80 shadow-md">
                  <img src={user.avatarUrl} alt={user.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <h4 className="text-base font-bold text-white">{user.name}</h4>
                <span className="text-xs text-slate-400">@{user.username}</span>

                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 mt-2 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold">
                  <Award className="w-3.5 h-3.5" />
                  <span>{user.tier} • Level {user.level}</span>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">Matches</span>
                  <span className="text-base font-bold text-white">{user.matchesPlayed}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">Win Rate</span>
                  <span className="text-base font-bold text-emerald-400">{user.winRate}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">Khel Coins</span>
                  <span className="text-base font-bold text-amber-400">{user.coins.toLocaleString()}</span>
                </div>
              </div>

              {/* Wallet Summary */}
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                    <Wallet className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">Total Balance</span>
                    <span className="text-lg font-bold text-white">₹{user.totalCash.toLocaleString()}</span>
                  </div>
                </div>
                <button
                  onClick={() => onSwitchSheet('wallet')}
                  className="py-1.5 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                >
                  Manage Wallet
                </button>
              </div>

              {/* Fast links */}
              <div className="space-y-1.5 text-xs">
                <button
                  id="profile-invite-friends-btn"
                  onClick={() => onSwitchSheet('invite-friends')}
                  className="w-full p-3 rounded-xl bg-slate-900/80 hover:bg-slate-900 border border-amber-500/30 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 font-bold">🎁 Invite Friends & Earn</span>
                  </div>
                  <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-500/30">
                    +1,000 Coins
                  </span>
                </button>

                <button
                  id="profile-customer-care-btn"
                  onClick={() => onSwitchSheet('customer-care')}
                  className="w-full p-3 rounded-xl bg-slate-900/80 hover:bg-slate-900 border border-blue-500/30 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-blue-300 font-bold">🎧 Customer Care & WhatsApp</span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    24/7 Live
                  </span>
                </button>

                <button
                  id="profile-apk-center-btn"
                  onClick={() => onSwitchSheet('apk-download')}
                  className="w-full p-3 rounded-xl bg-slate-900/80 hover:bg-slate-900 border border-emerald-500/30 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-emerald-300 font-bold">📱 Android APK Center</span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    Download
                  </span>
                </button>

                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between text-slate-300">
                  <span>KYC Verification</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between text-slate-300">
                  <span>Responsible Sports Gaming</span>
                  <span className="text-slate-500">&gt;</span>
                </div>
              </div>
            </div>
          )}

          {/* ================= WALLET SHEET ================= */}
          {sheetType === 'wallet' && (
            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30">
                <span className="text-xs text-slate-400 block">Withdrawable Balance</span>
                <span className="text-3xl font-sports font-bold text-amber-400">₹{user.totalCash.toLocaleString()}</span>
                <div className="mt-2 text-xs text-slate-400 flex justify-between border-t border-slate-800 pt-2">
                  <span>Bonus Cash: ₹{user.bonusCash}</span>
                  <span>Coins: {user.coins}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button 
                  onClick={() => showWalletNotice('Add Cash: Instant UPI, NetBanking, and Card deposit gateways supported.')}
                  className="py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs active:scale-95 transition-all shadow-md shadow-emerald-600/20"
                >
                  + Add Cash
                </button>
                <button 
                  onClick={() => showWalletNotice('Withdrawal: Instant payout processed to linked bank UPI handle.')}
                  className="py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs active:scale-95 transition-all"
                >
                  Withdraw Cash
                </button>
              </div>

              {walletNotice && (
                <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/50 text-xs text-amber-300 text-center animate-in fade-in">
                  {walletNotice}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Bottom Close Bar */}
        <div className="p-3 bg-slate-950 border-t border-slate-800/80">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold active:scale-95 transition-all"
          >
            Back to KhelMitra Home
          </button>
        </div>
      </div>
    </div>
  );
}
