interface KhelMitraLogoProps {
  variant?: 'header' | 'icon' | 'badge' | 'full';
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  className?: string;
  onClick?: () => void;
}

export default function KhelMitraLogo({
  variant = 'header',
  size = 'md',
  showSubtitle = true,
  className = '',
  onClick,
}: KhelMitraLogoProps) {
  // Cricket Ball App Icon SVG
  const CricketBallEmblem = ({ emblemSize = 40 }: { emblemSize?: number }) => (
    <div
      className="relative flex items-center justify-center shrink-0"
      style={{ width: emblemSize, height: emblemSize }}
    >
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full drop-shadow-[0_4px_10px_rgba(220,38,38,0.35)]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Cricket Ball 3D Gradient */}
          <radialGradient
            id="cricketBallLeather"
            cx="36%"
            cy="32%"
            r="65%"
            fx="30%"
            fy="28%"
          >
            <stop offset="0%" stopColor="#ff4d4d" />
            <stop offset="35%" stopColor="#dc2626" />
            <stop offset="75%" stopColor="#991b1b" />
            <stop offset="100%" stopColor="#450a0a" />
          </radialGradient>

          {/* Golden Seam Metallic Gradient */}
          <linearGradient id="goldenSeam" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fef08a" />
            <stop offset="40%" stopColor="#f59e0b" />
            <stop offset="80%" stopColor="#d97706" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>

          {/* Android App Icon Squircle Gradient */}
          <linearGradient id="squircleBg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="50%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#020617" />
          </linearGradient>

          {/* Metallic Gold Ring */}
          <linearGradient id="goldBorder" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fbbf24" />
            <stop offset="50%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#b45309" />
          </linearGradient>
        </defs>

        {/* Outer subtle shield / velocity flare */}
        <circle cx="50" cy="50" r="48" fill="url(#cricketBallLeather)" stroke="#ef4444" strokeWidth="1.5" strokeOpacity="0.4" />

        {/* Glossy top-left light sheen on leather */}
        <ellipse cx="40" cy="28" rx="26" ry="14" fill="#ffffff" fillOpacity="0.16" transform="rotate(-25 40 28)" />

        {/* Cricket Ball Central Raised Seam Ribbon */}
        <path
          d="M18 78 C 30 52, 70 48, 82 22"
          stroke="#450a0a"
          strokeWidth="6.5"
          strokeLinecap="round"
        />
        <path
          d="M18 78 C 30 52, 70 48, 82 22"
          stroke="url(#goldenSeam)"
          strokeWidth="4"
          strokeLinecap="round"
        />

        {/* Cricket Hand-Stitched V Seams */}
        <path
          d="M26 73 L22 68 M31 65 L27 60 M36 57 L32 52 M43 51 L40 45 M50 46 L48 40 M57 42 L55 36 M65 37 L64 30 M72 31 L72 24 M78 24 L79 17"
          stroke="#ffffff"
          strokeWidth="2"
          strokeLinecap="round"
          strokeOpacity="0.9"
        />
        <path
          d="M26 73 L30 76 M31 65 L36 67 M36 57 L42 59 M43 51 L48 52 M50 46 L55 46 M57 42 L62 41 M65 37 L69 35 M72 31 L75 28 M78 24 L81 20"
          stroke="#ffffff"
          strokeWidth="2"
          strokeLinecap="round"
          strokeOpacity="0.9"
        />

        {/* Dynamic Cricket Velocity Wing (Sports Gaming Power) */}
        <path
          d="M50 82 C 68 82, 85 68, 88 48"
          stroke="#f59e0b"
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray="2 4"
        />

        {/* Center Victory Spark / Sports Star */}
        <path
          d="M50 44 L52 48 L56 50 L52 52 L50 56 L48 52 L44 50 L48 48 Z"
          fill="#fbbf24"
          className="drop-shadow-[0_0_4px_rgba(251,191,36,0.8)]"
        />
      </svg>
    </div>
  );

  // Android Launcher Icon Variant (Squircle App Icon)
  if (variant === 'icon') {
    const iconDim = size === 'lg' ? 'w-20 h-20' : size === 'md' ? 'w-14 h-14' : 'w-10 h-10';
    return (
      <div
        id="khelmitra-android-icon"
        onClick={onClick}
        className={`relative ${iconDim} rounded-[22%] p-[2px] bg-gradient-to-br from-amber-400 via-red-600 to-amber-600 shadow-xl shadow-red-950/60 flex items-center justify-center cursor-pointer select-none ${className}`}
      >
        <div className="w-full h-full rounded-[20%] bg-[#080d1a] flex items-center justify-center p-1.5 overflow-hidden">
          <CricketBallEmblem emblemSize={size === 'lg' ? 64 : size === 'md' ? 44 : 32} />
        </div>
      </div>
    );
  }

  // Header Brand Logo
  return (
    <div
      id="khelmitra-brand-header"
      onClick={onClick}
      className={`flex items-center gap-2.5 cursor-pointer select-none group ${className}`}
      title="KhelMitra Sports Gaming"
    >
      {/* Android-Optimized Cricket Ball App Icon */}
      <div className="relative flex items-center justify-center">
        <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 via-orange-500 to-red-600 p-[1.5px] shadow-lg shadow-red-900/30 group-hover:scale-105 transition-transform">
          <div className="w-full h-full bg-[#0a0f1d] rounded-[14px] flex items-center justify-center p-0.5">
            <CricketBallEmblem emblemSize={32} />
          </div>
        </div>
        {/* Subtle Live Active Indicator */}
        <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-[#080b11] shadow-sm"></span>
      </div>

      {/* Modern KhelMitra Typography */}
      <div className="flex flex-col">
        <div className="flex items-baseline gap-1">
          <span className="text-[26px] font-sports tracking-wider font-extrabold leading-none text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-200 drop-shadow-[0_1px_3px_rgba(245,158,11,0.3)]">
            KHEL
          </span>
          <span className="text-[26px] font-sports tracking-wider font-extrabold leading-none text-white drop-shadow-[0_1px_2px_rgba(255,255,255,0.2)]">
            MITRA
          </span>
        </div>
        {showSubtitle && (
          <div className="flex items-center gap-1.5 -mt-0.5">
            <span className="text-[8.5px] uppercase font-black tracking-widest text-amber-400/90 font-mono">
              SPORTS GAMING
            </span>
            <span className="w-1 h-1 rounded-full bg-red-500"></span>
            <span className="text-[8.5px] font-bold text-slate-400 font-mono">
              CRICKET & FANTASY
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
