import { useState, useEffect } from 'react';
import { 
  Search, Filter, Sparkles, TrendingUp, Share2, 
  ShoppingCart, Star, Truck, ShieldCheck, ChevronRight, 
  Building2, DollarSign, Package, AlertCircle, RefreshCw 
} from 'lucide-react';
import { ResellerCategory, ResellerProduct, ResellerEarnings } from '../../types';
import { resellingService } from '../../services/resellingService';
import { RESELLER_CATEGORIES } from '../../data/resellingData';
import { audioEffectsService } from '../../services/audioEffectsService';

interface ResellingMarketplaceViewProps {
  onOpenProductDetail: (product: ResellerProduct) => void;
  onOpenDashboard: () => void;
  onOpenSupplierPortal: () => void;
  onPlaceQuickOrder: (product: ResellerProduct) => void;
}

export default function ResellingMarketplaceView({
  onOpenProductDetail,
  onOpenDashboard,
  onOpenSupplierPortal,
  onPlaceQuickOrder
}: ResellingMarketplaceViewProps) {
  const [products, setProducts] = useState<ResellerProduct[]>(resellingService.getFilteredProducts());
  const [earnings, setEarnings] = useState<ResellerEarnings>(resellingService.getEarnings());
  const [selectedCat, setSelectedCat] = useState<ResellerCategory | 'All'>(resellingService.getSelectedCategory());
  const [searchQuery, setSearchQuery] = useState(resellingService.getSearchQuery());
  const [sharedProductId, setSharedProductId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = resellingService.subscribe(() => {
      setProducts([...resellingService.getFilteredProducts()]);
      setEarnings({ ...resellingService.getEarnings() });
      setSelectedCat(resellingService.getSelectedCategory());
      setSearchQuery(resellingService.getSearchQuery());
    });
    return unsub;
  }, []);

  const handleCategorySelect = (cat: ResellerCategory | 'All') => {
    audioEffectsService.playClick();
    setSelectedCat(cat);
    resellingService.setSelectedCategory(cat);
  };

  const handleSearchChange = (q: string) => {
    setSearchQuery(q);
    resellingService.setSearchQuery(q);
  };

  const handleQuickWhatsAppShare = (e: React.MouseEvent, product: ResellerProduct) => {
    e.stopPropagation();
    audioEffectsService.playClick();
    resellingService.shareProductOnWhatsApp(product, 250);
    setSharedProductId(product.id);
    setTimeout(() => setSharedProductId(null), 2500);
  };

  return (
    <div id="reselling-marketplace-view" className="space-y-4 pb-28">
      {/* 1. RESELLER GREETING & EARNINGS SNAPSHOT BANNER */}
      <div className="px-4">
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-pink-950/70 via-slate-900 to-amber-950/50 border border-pink-500/30 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-pink-500 to-rose-600 text-white flex items-center justify-center font-black text-sm shadow-md">
                🛍️
              </div>
              <div>
                <h2 className="text-xs font-black text-white">KhelMitra Reseller Marketplace</h2>
                <p className="text-[10px] text-pink-300 font-medium">
                  Zero Investment • Factory Wholesale • Free COD
                </p>
              </div>
            </div>

            <button
              onClick={onOpenDashboard}
              className="px-2.5 py-1.5 rounded-xl bg-slate-900 border border-pink-500/40 text-right hover:border-pink-400 active:scale-95 transition-all"
            >
              <span className="text-[9px] text-slate-400 block uppercase">Your Profit</span>
              <span className="text-xs font-black text-emerald-400">₹{earnings.totalMarginEarned}</span>
            </button>
          </div>

          {/* Quick Action Navigation Buttons */}
          <div className="grid grid-cols-3 gap-1.5 mt-3 pt-2.5 border-t border-slate-800/80 text-[10px] font-bold">
            <button
              onClick={onOpenDashboard}
              className="p-1.5 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 hover:text-white flex items-center justify-center gap-1 active:scale-95 transition-all"
            >
              <DollarSign className="w-3 h-3 text-emerald-400" />
              <span>Earnings</span>
            </button>

            <button
              onClick={onOpenDashboard}
              className="p-1.5 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 hover:text-white flex items-center justify-center gap-1 active:scale-95 transition-all"
            >
              <Package className="w-3 h-3 text-pink-400" />
              <span>Orders ({earnings.totalOrdersCount})</span>
            </button>

            <button
              onClick={onOpenSupplierPortal}
              className="p-1.5 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300 hover:text-white flex items-center justify-center gap-1 active:scale-95 transition-all"
            >
              <Building2 className="w-3 h-3 text-amber-400" />
              <span>Suppliers</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. LIVE SEARCH BAR */}
      <div className="px-4">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search Kurtis, Sarees, Dresses, Beauty Kits, Decor..."
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-pink-500/60 shadow-inner"
          />
          {searchQuery && (
            <button
              onClick={() => handleSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs font-bold"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* 3. SIX WHOLESALE CATEGORIES CAROUSEL */}
      <div className="space-y-2">
        <div className="px-4 flex items-center justify-between">
          <h3 className="text-xs font-black text-white uppercase tracking-wider">Explore Wholesale Categories</h3>
          <span className="text-[10px] text-pink-400 font-bold">6 Verified Categories</span>
        </div>

        <div className="flex gap-2.5 overflow-x-auto px-4 pb-1 no-scrollbar">
          {/* All Category Pill */}
          <button
            onClick={() => handleCategorySelect('All')}
            className={`px-3.5 py-2 rounded-2xl flex items-center gap-1.5 shrink-0 border transition-all text-xs font-bold active:scale-95 ${
              selectedCat === 'All'
                ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white border-pink-400 shadow-md shadow-pink-900/30 font-black'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
          >
            <span>✨</span>
            <span>All Items</span>
          </button>

          {RESELLER_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => handleCategorySelect(cat.id)}
              className={`px-3.5 py-2 rounded-2xl flex items-center gap-1.5 shrink-0 border transition-all text-xs font-bold active:scale-95 ${
                selectedCat === cat.id
                  ? 'bg-gradient-to-r from-pink-500 to-rose-500 text-white border-pink-400 shadow-md shadow-pink-900/30 font-black'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 4. FAST RESELLER BENEFIT BANNER */}
      <div className="px-4">
        <div className="p-2.5 rounded-xl bg-gradient-to-r from-slate-900 via-[#0d1322] to-slate-900 border border-slate-800 flex items-center justify-between text-[11px]">
          <div className="flex items-center gap-2 text-slate-300">
            <Truck className="w-4 h-4 text-amber-400 shrink-0" />
            <span><strong>100% Free Shipping</strong> on all reseller customer orders</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-bold">Pan India COD</span>
        </div>
      </div>

      {/* 5. PRODUCT CATALOGUE GRID */}
      <div className="px-4 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-slate-200">
            {selectedCat === 'All' ? 'Trending Wholesale Catalog' : `${selectedCat} Collection`} ({products.length})
          </span>
          <span className="text-[10px] text-slate-400 font-mono">Surat & Jaipur Direct</span>
        </div>

        {products.length === 0 ? (
          <div className="p-8 text-center rounded-2xl bg-slate-900/50 border border-slate-800 space-y-2">
            <Package className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-xs text-slate-400">No products match your search or filter.</p>
            <button
              onClick={() => {
                handleCategorySelect('All');
                handleSearchChange('');
              }}
              className="py-1.5 px-3 rounded-xl bg-pink-500 text-white text-xs font-bold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {products.map((p) => {
              const estMargin = 250;
              const estCustomerPrice = p.supplierPrice + estMargin;

              return (
                <div
                  key={p.id}
                  onClick={() => onOpenProductDetail(p)}
                  className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden flex flex-col hover:border-pink-500/40 transition-all cursor-pointer group shadow-sm active:scale-99"
                >
                  {/* Product Thumbnail */}
                  <div className="relative aspect-[4/3] bg-slate-950 overflow-hidden">
                    <img
                      src={p.images[0]}
                      alt={p.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />

                    {/* Wholesale badge */}
                    <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded-md bg-black/80 backdrop-blur-sm text-[9px] font-black text-amber-300 border border-amber-500/30">
                      Wholesale: ₹{p.supplierPrice}
                    </div>

                    {/* Estimated Profit badge */}
                    <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded-md bg-emerald-950/80 backdrop-blur-sm text-[9px] font-black text-emerald-400 border border-emerald-500/30">
                      Earn ~₹{estMargin}
                    </div>
                  </div>

                  {/* Product Details */}
                  <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                    <div>
                      <span className="text-[9px] font-bold text-pink-400 uppercase tracking-wider block truncate">
                        {p.category}
                      </span>
                      <h4 className="text-xs font-bold text-white line-clamp-2 leading-snug">
                        {p.title}
                      </h4>
                    </div>

                    <div className="pt-1 border-t border-slate-800/80 flex items-baseline justify-between text-xs">
                      <div>
                        <span className="text-[9px] text-slate-400 block">Sell for:</span>
                        <span className="font-bold text-white">₹{estCustomerPrice}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-emerald-400 block font-bold">Your Profit:</span>
                        <span className="font-black text-emerald-400">+₹{estMargin}</span>
                      </div>
                    </div>

                    {/* Quick Action Buttons */}
                    <div className="grid grid-cols-2 gap-1.5 pt-1">
                      <button
                        onClick={(e) => handleQuickWhatsAppShare(e, p)}
                        className="py-2 px-1.5 rounded-xl bg-emerald-600/90 hover:bg-emerald-500 text-white text-[10px] font-bold flex items-center justify-center gap-1 active:scale-95 transition-all"
                        title="Share catalogue on WhatsApp"
                      >
                        <Share2 className="w-3 h-3" />
                        <span>{sharedProductId === p.id ? 'Shared!' : 'Share'}</span>
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          audioEffectsService.playClick();
                          onPlaceQuickOrder(p);
                        }}
                        className="py-2 px-1.5 rounded-xl bg-pink-500 hover:bg-pink-600 text-white text-[10px] font-bold flex items-center justify-center gap-1 active:scale-95 transition-all"
                      >
                        <ShoppingCart className="w-3 h-3" />
                        <span>Order</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
