import { useState, useEffect } from 'react';
import { 
  DollarSign, TrendingUp, Package, ArrowUpRight, 
  CheckCircle2, Clock, Truck, ShieldCheck, Share2, 
  CreditCard, Smartphone, ChevronRight, X, ExternalLink 
} from 'lucide-react';
import { ResellerEarnings, ResellerOrder } from '../../types';
import { resellingService } from '../../services/resellingService';
import { audioEffectsService } from '../../services/audioEffectsService';

interface ResellerDashboardViewProps {
  onClose?: () => void;
  onExploreProducts: () => void;
  initialTab?: 'orders' | 'payout' | 'analytics';
}

export default function ResellerDashboardView({
  onClose,
  onExploreProducts,
  initialTab = 'orders'
}: ResellerDashboardViewProps) {
  const [earnings, setEarnings] = useState<ResellerEarnings>(resellingService.getEarnings());
  const [orders, setOrders] = useState<ResellerOrder[]>(resellingService.getOrders());
  const [activeTab, setActiveTab] = useState<'orders' | 'payout' | 'analytics'>(initialTab);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Payout Form
  const [withdrawAmount, setWithdrawAmount] = useState<number>(earnings.totalMarginEarned || 500);
  const [upiId, setUpiId] = useState(earnings.upiId || '');
  const [payoutMsg, setPayoutMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const unsub = resellingService.subscribe(() => {
      setEarnings({ ...resellingService.getEarnings() });
      setOrders([...resellingService.getOrders()]);
    });
    return unsub;
  }, []);

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    setPayoutMsg(null);
    audioEffectsService.playClick();

    if (!upiId.includes('@')) {
      setPayoutMsg({ type: 'error', text: 'Please enter a valid UPI ID (e.g. yourname@okaxis, 9876543210@paytm)' });
      return;
    }

    resellingService.updateBankDetails({ upiId });
    const res = resellingService.requestPayoutWithdrawal(withdrawAmount);

    if (res.success) {
      setPayoutMsg({ type: 'success', text: res.message });
      audioEffectsService.playWin();
    } else {
      setPayoutMsg({ type: 'error', text: res.message });
    }
  };

  const filteredOrders = orders.filter(o => {
    if (statusFilter === 'all') return true;
    if (statusFilter === 'delivered') return o.status === 'Delivered';
    if (statusFilter === 'transit') return ['Dispatched', 'Out for Delivery'].includes(o.status);
    if (statusFilter === 'pending') return ['Placed', 'Confirmed'].includes(o.status);
    return true;
  });

  return (
    <div id="reseller-dashboard-view" className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-y-auto">
      {/* Top Bar */}
      <div className="sticky top-0 z-30 bg-[#070b14]/95 backdrop-blur-md px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-pink-500 to-amber-500 text-white flex items-center justify-center font-black text-sm shadow-md">
            ₹
          </div>
          <div>
            <h2 className="text-xs font-black text-white uppercase tracking-wider">Reseller Business Hub</h2>
            <span className="text-[10px] text-slate-400">Zero Investment • Direct Bank/UPI Payouts</span>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="p-4 space-y-4 pb-24">
        {/* EARNINGS SUMMARY HERO CARD */}
        <div className="relative overflow-hidden p-4 rounded-2xl bg-gradient-to-br from-pink-950/40 via-slate-900 to-amber-950/30 border border-pink-500/30 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-pink-300 uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              Total Margin Earned
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
              Ready to Withdraw
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-white">₹{earnings.totalMarginEarned.toLocaleString()}</span>
            <span className="text-xs text-slate-400 font-medium">Earned directly on delivered orders</span>
          </div>

          {/* Sub Metrics Grid */}
          <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 text-xs">
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[9px] text-amber-400 uppercase font-bold block">In Transit</span>
              <span className="text-sm font-black text-white">₹{earnings.pendingPayout}</span>
              <span className="text-[8px] text-slate-500 block">Pending delivery</span>
            </div>

            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[9px] text-emerald-400 uppercase font-bold block">Withdrawn</span>
              <span className="text-sm font-black text-white">₹{earnings.withdrawnAmount}</span>
              <span className="text-[8px] text-slate-500 block">Sent to Bank</span>
            </div>

            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <span className="text-[9px] text-blue-400 uppercase font-bold block">Delivered</span>
              <span className="text-sm font-black text-white">{earnings.deliveredOrdersCount} / {earnings.totalOrdersCount}</span>
              <span className="text-[8px] text-slate-500 block">Orders</span>
            </div>
          </div>

          {/* Quick Withdraw CTA */}
          <div className="pt-1 flex gap-2">
            <button
              onClick={() => setActiveTab('payout')}
              className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Withdraw to UPI (₹{earnings.totalMarginEarned})</span>
            </button>
          </div>
        </div>

        {/* NAVIGATION TABS */}
        <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('orders')}
            className={`py-2 rounded-lg transition-all ${
              activeTab === 'orders' ? 'bg-pink-500 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Orders ({orders.length})
          </button>
          <button
            onClick={() => setActiveTab('payout')}
            className={`py-2 rounded-lg transition-all ${
              activeTab === 'payout' ? 'bg-pink-500 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            UPI Payout
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-2 rounded-lg transition-all ${
              activeTab === 'analytics' ? 'bg-pink-500 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            How it Works
          </button>
        </div>

        {/* TAB 1: CUSTOMER ORDERS LIST & TRACKING */}
        {activeTab === 'orders' && (
          <div className="space-y-3">
            {/* Filter Chips */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-[11px]">
              {[
                { id: 'all', label: 'All Orders' },
                { id: 'transit', label: 'In Transit 🚚' },
                { id: 'delivered', label: 'Delivered ✅' },
                { id: 'pending', label: 'Placed 📦' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setStatusFilter(f.id)}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap border transition-all ${
                    statusFilter === f.id
                      ? 'bg-slate-800 text-white border-pink-500/50 font-bold'
                      : 'bg-slate-950 text-slate-400 border-slate-800'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            {filteredOrders.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-slate-900/40 border border-slate-800 space-y-3">
                <Package className="w-10 h-10 text-slate-600 mx-auto" />
                <h4 className="text-xs font-bold text-white">No Orders Found</h4>
                <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                  Browse our wholesale catalogue, share with friends or customer groups on WhatsApp, and earn on every parcel!
                </p>
                <button
                  onClick={onExploreProducts}
                  className="py-2 px-4 rounded-xl bg-pink-500 text-white font-bold text-xs"
                >
                  Browse Wholesale Products
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3 hover:border-slate-700 transition-all"
                  >
                    {/* Order Top Bar */}
                    <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800/80">
                      <div>
                        <span className="font-mono font-bold text-white">{ord.orderNumber}</span>
                        <span className="text-[10px] text-slate-500 block">{ord.createdAt}</span>
                      </div>

                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        ord.status === 'Delivered'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : ord.status === 'Out for Delivery'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30 animate-pulse'
                          : 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                      }`}>
                        {ord.status}
                      </span>
                    </div>

                    {/* Order Product Snapshot */}
                    <div className="flex items-center gap-3">
                      <img
                        src={ord.productImage}
                        alt={ord.productTitle}
                        className="w-14 h-14 rounded-xl object-cover border border-slate-700 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-bold text-white truncate">{ord.productTitle}</h4>
                        <div className="text-[10px] text-slate-400 mt-0.5 flex flex-wrap gap-2">
                          <span>Size: {ord.size}</span>
                          <span>Qty: {ord.quantity}</span>
                          <span>{ord.paymentMethod}</span>
                        </div>
                        <div className="flex items-center justify-between mt-1 text-xs">
                          <span className="text-slate-300">Customer: ₹{ord.finalCustomerPrice}</span>
                          <span className="text-emerald-400 font-black">Your Margin: +₹{ord.resellerMargin}</span>
                        </div>
                      </div>
                    </div>

                    {/* Customer & Tracking Details */}
                    <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Customer: <strong className="text-white">{ord.customerName}</strong> ({ord.city})</span>
                        <span className="font-mono text-[10px] text-slate-400">{ord.customerPhone}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-slate-500">Courier: {ord.courierName}</span>
                        <span className="font-mono text-amber-400">Awb: {ord.trackingNumber}</span>
                      </div>
                    </div>

                    {/* Progress Step Bar */}
                    <div className="grid grid-cols-4 gap-1 text-center pt-1 text-[9px] font-bold">
                      <div className={`p-1 rounded ${['Placed', 'Confirmed', 'Dispatched', 'Out for Delivery', 'Delivered'].includes(ord.status) ? 'bg-pink-500/30 text-pink-300' : 'bg-slate-950 text-slate-600'}`}>
                        1. Placed
                      </div>
                      <div className={`p-1 rounded ${['Dispatched', 'Out for Delivery', 'Delivered'].includes(ord.status) ? 'bg-pink-500/30 text-pink-300' : 'bg-slate-950 text-slate-600'}`}>
                        2. Packed
                      </div>
                      <div className={`p-1 rounded ${['Out for Delivery', 'Delivered'].includes(ord.status) ? 'bg-amber-500/30 text-amber-300' : 'bg-slate-950 text-slate-600'}`}>
                        3. In Transit
                      </div>
                      <div className={`p-1 rounded ${ord.status === 'Delivered' ? 'bg-emerald-500/30 text-emerald-300' : 'bg-slate-950 text-slate-600'}`}>
                        4. Delivered
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 2: INSTANT UPI / BANK PAYOUT */}
        {activeTab === 'payout' && (
          <form onSubmit={handleWithdraw} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white">Instant Margin Withdrawal</h3>
                <span className="text-[10px] text-slate-400">Directly deposited via UPI IMPS (0% fee)</span>
              </div>
            </div>

            {payoutMsg && (
              <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                payoutMsg.type === 'success'
                  ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-200'
                  : 'bg-red-950/50 border-red-500/40 text-red-200'
              }`}>
                {payoutMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <X className="w-4 h-4 text-red-400 shrink-0" />}
                <span>{payoutMsg.text}</span>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Available Balance to Withdraw</label>
              <div className="text-2xl font-black text-emerald-400">₹{earnings.totalMarginEarned}</div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Enter Withdrawal Amount (₹)</label>
              <input
                type="number"
                min="10"
                max={earnings.totalMarginEarned}
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(Math.max(1, Number(e.target.value)))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-sm font-bold text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Your UPI ID (VPA)</label>
              <input
                type="text"
                placeholder="e.g. yourname@okhdfcbank or 9876543210@paytm"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              />
            </div>

            <button
              type="submit"
              disabled={earnings.totalMarginEarned <= 0}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-black text-xs shadow-md shadow-emerald-900/40 active:scale-95 transition-all disabled:opacity-40"
            >
              Transfer ₹{withdrawAmount} to UPI Now
            </button>
          </form>
        )}

        {/* TAB 3: HOW IT WORKS GUIDE */}
        {activeTab === 'analytics' && (
          <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-4 text-xs">
            <h3 className="font-bold text-white text-sm">How KhelMitra Reselling Works</h3>

            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                <span className="w-6 h-6 rounded-full bg-pink-500/20 text-pink-400 font-black text-xs flex items-center justify-center shrink-0">1</span>
                <div>
                  <h4 className="font-bold text-white">Pick High-Demand Products</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">Browse authentic Surat sarees, Jaipuri kurtis, beauty herbal kits, and home items at lowest factory rates.</p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                <span className="w-6 h-6 rounded-full bg-pink-500/20 text-pink-400 font-black text-xs flex items-center justify-center shrink-0">2</span>
                <div>
                  <h4 className="font-bold text-white">Add Your Profit Margin & Share</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">Set ₹150–₹500 margin. 1-click share to WhatsApp groups and contacts without showing supplier costs.</p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                <span className="w-6 h-6 rounded-full bg-pink-500/20 text-pink-400 font-black text-xs flex items-center justify-center shrink-0">3</span>
                <div>
                  <h4 className="font-bold text-white">We Deliver & Collect COD</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">Place customer order with their address. KhelMitra factory couriers the parcel with Free COD and 7-day returns.</p>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 font-black text-xs flex items-center justify-center shrink-0">4</span>
                <div>
                  <h4 className="font-bold text-emerald-300">Instant Margin in Your Bank</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">When parcel delivers, your profit margin is automatically credited and withdrawable to UPI instantly.</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
