import { useState } from 'react';
import { 
  X, CheckCircle2, Truck, ShieldCheck, MapPin, 
  Phone, User, AlertCircle, ArrowRight, DollarSign 
} from 'lucide-react';
import { ResellerProduct, ResellerOrder } from '../../types';
import { resellingService } from '../../services/resellingService';
import { audioEffectsService } from '../../services/audioEffectsService';

interface ResellerOrderModalProps {
  product: ResellerProduct;
  initialSize: string;
  initialMargin: number;
  onClose: () => void;
  onOrderSuccess: (order: ResellerOrder) => void;
}

export default function ResellerOrderModal({
  product,
  initialSize,
  initialMargin,
  onClose,
  onOrderSuccess
}: ResellerOrderModalProps) {
  const [size, setSize] = useState(initialSize || product.sizes[0] || 'Free Size');
  const [quantity, setQuantity] = useState(1);
  const [margin, setMargin] = useState(initialMargin || 150);

  // Customer Shipping Details
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'Online'>('COD');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { finalCustomerPrice, resellerProfit } = resellingService.calculateFinalPrice(
    product.supplierPrice * quantity,
    margin
  );

  const handlePincodeChange = (pin: string) => {
    const clean = pin.replace(/\D/g, '').slice(0, 6);
    setPincode(clean);
    // Simple city/state auto-filler for common Indian pin prefixes
    if (clean.startsWith('11')) { setCity('New Delhi'); setState('Delhi'); }
    else if (clean.startsWith('40') || clean.startsWith('41')) { setCity('Mumbai / Pune'); setState('Maharashtra'); }
    else if (clean.startsWith('56')) { setCity('Bengaluru'); setState('Karnataka'); }
    else if (clean.startsWith('50')) { setCity('Hyderabad'); setState('Telangana'); }
    else if (clean.startsWith('60')) { setCity('Chennai'); setState('Tamil Nadu'); }
    else if (clean.startsWith('70')) { setCity('Kolkata'); setState('West Bengal'); }
    else if (clean.startsWith('30') || clean.startsWith('34')) { setCity('Jaipur'); setState('Rajasthan'); }
    else if (clean.startsWith('38') || clean.startsWith('39')) { setCity('Surat'); setState('Gujarat'); }
    else if (clean.startsWith('22') || clean.startsWith('20')) { setCity('Lucknow'); setState('Uttar Pradesh'); }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!customerName.trim() || customerName.trim().length < 2) {
      setErrorMsg('Please enter customer full name');
      return;
    }
    const cleanPhone = customerPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number for delivery courier updates');
      return;
    }
    if (!customerAddress.trim() || customerAddress.trim().length < 8) {
      setErrorMsg('Please enter complete street delivery address with house/flat number');
      return;
    }
    if (pincode.length !== 6) {
      setErrorMsg('Please enter a valid 6-digit postal pincode');
      return;
    }

    setIsSubmitting(true);
    audioEffectsService.playClick();

    const res = resellingService.placeCustomerOrder({
      product,
      size,
      quantity,
      resellerMargin: margin,
      customerName,
      customerPhone: cleanPhone,
      customerAddress,
      pincode,
      city: city || 'City',
      state: state || 'State',
      paymentMethod
    });

    setIsSubmitting(false);

    if (res.success && res.order) {
      onOrderSuccess(res.order);
    } else {
      setErrorMsg(res.message || 'Failed to place order');
    }
  };

  return (
    <div id="reseller-order-modal" className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-y-auto">
      {/* Modal Header */}
      <div className="sticky top-0 z-30 bg-[#070b14]/95 backdrop-blur-md px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center">
            <Truck className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Place Customer Order</h3>
            <span className="text-[10px] text-slate-400">Direct Delivery to Customer • Your Margin Protected</span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-4 space-y-4 pb-28">
        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/40 text-xs text-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Product Snapshot */}
        <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
          <img
            src={product.images[0]}
            alt={product.title}
            className="w-16 h-16 rounded-xl object-cover shrink-0 border border-slate-700"
            referrerPolicy="no-referrer"
          />
          <div className="flex-1 min-w-0">
            <span className="text-[10px] text-pink-400 font-bold uppercase">{product.category}</span>
            <h4 className="text-xs font-bold text-white truncate">{product.title}</h4>
            <div className="flex items-center gap-2 mt-1 text-[11px]">
              <span className="text-slate-400">Wholesale: ₹{product.supplierPrice}</span>
              <span className="text-emerald-400 font-bold">Margin: +₹{margin}</span>
            </div>
          </div>
        </div>

        {/* Size & Quantity Selection */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-300">Selected Size</label>
            <select
              value={size}
              onChange={(e) => setSize(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-pink-500"
            >
              {product.sizes.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-300">Quantity</label>
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-8 py-2 text-slate-400 hover:text-white font-bold"
              >
                -
              </button>
              <span className="flex-1 text-center text-xs font-bold text-white">{quantity}</span>
              <button
                type="button"
                onClick={() => setQuantity(Math.min(10, quantity + 1))}
                className="w-8 py-2 text-slate-400 hover:text-white font-bold"
              >
                +
              </button>
            </div>
          </div>
        </div>

        {/* Reseller Profit Margin Adjustment */}
        <div className="p-3 rounded-2xl bg-gradient-to-r from-pink-500/10 via-slate-900 to-amber-500/10 border border-pink-500/30 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-200">Your Margin Profit:</span>
            <div className="flex items-center gap-1">
              <span className="text-slate-400">₹</span>
              <input
                type="number"
                min="0"
                max="1500"
                value={margin}
                onChange={(e) => setMargin(Math.max(0, Number(e.target.value) || 0))}
                className="w-16 px-1.5 py-0.5 bg-slate-950 border border-pink-500 rounded text-xs font-black text-pink-300 text-right"
              />
            </div>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Customer Total (COD): <strong className="text-white">₹{finalCustomerPrice}</strong></span>
            <span className="text-emerald-400 font-bold">Your Bank Profit: ₹{resellerProfit}</span>
          </div>
        </div>

        {/* Customer Address Details Form */}
        <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white">
            <MapPin className="w-4 h-4 text-pink-400" />
            <span>Customer Delivery Address</span>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] uppercase font-semibold text-slate-400">Customer Full Name *</label>
            <input
              type="text"
              placeholder="e.g. Smt. Priya Sharma"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-pink-500"
              required
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] uppercase font-semibold text-slate-400">Customer Mobile (10 Digits) *</label>
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl px-2.5">
              <span className="text-xs text-slate-500 font-mono pr-1">+91</span>
              <input
                type="tel"
                placeholder="98765 43210"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full py-2 bg-transparent text-xs text-white placeholder:text-slate-600 focus:outline-none"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] uppercase font-semibold text-slate-400">Complete Street Address & Landmark *</label>
            <textarea
              rows={2}
              placeholder="House/Flat No, Apartment, Street, Near Landmark"
              value={customerAddress}
              onChange={(e) => setCustomerAddress(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-pink-500 resize-none"
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Pincode *</label>
              <input
                type="text"
                placeholder="6 Digits"
                value={pincode}
                onChange={(e) => handlePincodeChange(e.target.value)}
                maxLength={6}
                className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-pink-500 font-mono"
                required
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">City</label>
              <input
                type="text"
                placeholder="City"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-pink-500"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">State</label>
              <input
                type="text"
                placeholder="State"
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-pink-500"
              />
            </div>
          </div>
        </div>

        {/* Payment Method */}
        <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
          <label className="text-xs font-bold text-white block">Payment Method for Customer</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMethod('COD')}
              className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                paymentMethod === 'COD'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500 shadow-sm'
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              <span>💵 Cash on Delivery</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('Online')}
              className={`p-2.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                paymentMethod === 'Online'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-sm'
                  : 'bg-slate-950 text-slate-400 border-slate-800'
              }`}
            >
              <span>💳 Prepaid / Online</span>
            </button>
          </div>
        </div>

        {/* Fixed Submit Button */}
        <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40 bg-[#080c16]/95 backdrop-blur-md px-4 py-3 border-t border-slate-800">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 text-white font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-pink-900/40 active:scale-95 transition-all disabled:opacity-50"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Confirm Order • Collect ₹{finalCustomerPrice} on Delivery</span>
          </button>
        </div>
      </form>
    </div>
  );
}
