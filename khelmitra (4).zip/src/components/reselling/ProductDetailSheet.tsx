import { useState } from 'react';
import { 
  X, Star, Share2, ShoppingCart, Truck, ShieldCheck, 
  RotateCcw, Sparkles, Check, ChevronRight, HelpCircle, 
  TrendingUp, Award, Layers, DollarSign 
} from 'lucide-react';
import { ResellerProduct } from '../../types';
import { resellingService } from '../../services/resellingService';
import { audioEffectsService } from '../../services/audioEffectsService';

interface ProductDetailSheetProps {
  product: ResellerProduct;
  onClose: () => void;
  onPlaceOrder: (product: ResellerProduct, selectedSize: string, margin: number) => void;
}

export default function ProductDetailSheet({
  product,
  onClose,
  onPlaceOrder
}: ProductDetailSheetProps) {
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'Free Size');
  const [customMargin, setCustomMargin] = useState<number>(Math.max(150, product.minMargin));
  const [showShareSuccess, setShowShareSuccess] = useState(false);

  const { finalCustomerPrice, resellerProfit, profitPercent } = resellingService.calculateFinalPrice(
    product.supplierPrice,
    customMargin
  );

  const handleShare = () => {
    audioEffectsService.playClick();
    resellingService.shareProductOnWhatsApp(product, customMargin);
    setShowShareSuccess(true);
    setTimeout(() => setShowShareSuccess(false), 3000);
  };

  const handleOrderClick = () => {
    audioEffectsService.playClick();
    onPlaceOrder(product, selectedSize, customMargin);
  };

  return (
    <div id="product-detail-modal" className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-y-auto">
      {/* Top Header */}
      <div className="sticky top-0 z-30 bg-[#070b14]/95 backdrop-blur-md px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xs px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-400 font-bold border border-pink-500/30">
            {product.category}
          </span>
          <span className="text-xs text-slate-400">Wholesale ID: {product.id}</span>
        </div>

        <button
          onClick={onClose}
          className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white active:scale-95 transition-all"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4 pb-28">
        {/* Main Product Image Carousel */}
        <div className="space-y-2">
          <div className="relative w-full aspect-[4/3] rounded-2xl overflow-hidden bg-slate-900 border border-slate-800">
            <img
              src={product.images[selectedImageIdx] || product.images[0]}
              alt={product.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            {/* Badges */}
            <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1.5">
              <span className="px-2 py-0.5 rounded-md bg-black/75 text-emerald-400 text-[10px] font-black border border-emerald-500/30 backdrop-blur-sm">
                Free COD Delivery
              </span>
              <span className="px-2 py-0.5 rounded-md bg-black/75 text-amber-300 text-[10px] font-black border border-amber-500/30 backdrop-blur-sm flex items-center gap-1">
                <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                {product.rating}★ ({product.reviewsCount})
              </span>
            </div>

            <div className="absolute bottom-2.5 right-2.5 px-2 py-1 rounded-lg bg-black/80 backdrop-blur-sm text-[10px] text-slate-300 border border-slate-700">
              By {product.supplierName}
            </div>
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIdx(idx)}
                  className={`w-14 h-14 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                    selectedImageIdx === idx ? 'border-pink-500 scale-105' : 'border-slate-800 opacity-60'
                  }`}
                >
                  <img src={img} alt="thumb" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Title & Wholesale Pricing */}
        <div className="space-y-2">
          <h2 className="text-base font-bold text-white leading-snug">{product.title}</h2>

          <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 block uppercase tracking-wider font-semibold">
                Factory Wholesale Price
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-xl font-black text-amber-400">₹{product.supplierPrice}</span>
                <span className="text-xs text-slate-500 line-through">MRP ₹{product.suggestedMrp}</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-emerald-400 font-bold block">Wholesale Discount</span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                {Math.round(((product.suggestedMrp - product.supplierPrice) / product.suggestedMrp) * 100)}% Off
              </span>
            </div>
          </div>
        </div>

        {/* INTERACTIVE RESELLER MARGIN CALCULATOR */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-[#0d1322] to-slate-900 border border-pink-500/40 shadow-md space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <div className="w-6 h-6 rounded-lg bg-pink-500/20 text-pink-400 flex items-center justify-center">
                <DollarSign className="w-3.5 h-3.5" />
              </div>
              <h3 className="text-xs font-black text-pink-300 uppercase tracking-wide">
                Reseller Margin Calculator
              </h3>
            </div>
            <span className="text-[10px] text-amber-400 font-bold">Your Direct Profit</span>
          </div>

          <p className="text-[11px] text-slate-400 leading-tight">
            Add your profit margin. When your customer receives the parcel and pays, KhelMitra transfers your margin straight to your UPI!
          </p>

          {/* Margin Input Slider */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Your Profit Margin:</span>
              <div className="flex items-center gap-1">
                <span className="text-slate-400">₹</span>
                <input
                  type="number"
                  min="0"
                  max="1500"
                  step="10"
                  value={customMargin}
                  onChange={(e) => setCustomMargin(Math.max(0, Number(e.target.value) || 0))}
                  className="w-20 px-2 py-1 bg-slate-950 border border-pink-500/50 rounded-lg text-sm font-black text-pink-300 text-right focus:outline-none focus:border-pink-400"
                />
              </div>
            </div>

            <input
              type="range"
              min={product.minMargin}
              max={product.maxMargin}
              step="10"
              value={customMargin}
              onChange={(e) => setCustomMargin(Number(e.target.value))}
              className="w-full accent-pink-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
            />

            <div className="flex justify-between text-[9px] text-slate-500 font-mono">
              <span>Min: ₹{product.minMargin}</span>
              <span>Recommended: ₹250</span>
              <span>Max: ₹{product.maxMargin}</span>
            </div>
          </div>

          {/* Calculation Summary Box */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block">Customer Pays (COD):</span>
              <span className="text-sm font-black text-white">₹{finalCustomerPrice}</span>
              <span className="text-[9px] text-slate-500 block">Includes Free Delivery</span>
            </div>
            <div className="border-l border-slate-800 pl-2">
              <span className="text-[10px] text-emerald-400 font-bold block">You Earn Profit:</span>
              <span className="text-sm font-black text-emerald-300">₹{resellerProfit}</span>
              <span className="text-[9px] text-emerald-400 block font-mono">({profitPercent}% margin)</span>
            </div>
          </div>
        </div>

        {/* Size Selection */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-200">Select Size:</span>
            <span className="text-[10px] text-slate-400">{product.sizes.length} Options</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {product.sizes.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all active:scale-95 ${
                  selectedSize === size
                    ? 'bg-pink-500 text-white border-pink-400 shadow-sm'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* Fabric & Product Specifications */}
        <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs space-y-2">
          <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            Product Details & Fabric
          </h4>
          <p className="text-slate-300 text-[11px] leading-relaxed">{product.description}</p>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[11px]">
            <div>
              <span className="text-slate-500 block text-[9px] uppercase">Fabric / Material</span>
              <span className="text-slate-200 font-medium">{product.fabric || 'Standard Pure Material'}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[9px] uppercase">Stock Available</span>
              <span className="text-emerald-400 font-bold">{product.stock} Units Ready</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[9px] uppercase">Supplier Location</span>
              <span className="text-slate-200 font-medium">Surat / Jaipur Mills</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[9px] uppercase">Dispatch Time</span>
              <span className="text-slate-200 font-medium">Within 24 Hours</span>
            </div>
          </div>
        </div>

        {/* Customer Trust Badges */}
        <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
          <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <Truck className="w-4 h-4 text-amber-400 mx-auto" />
            <span className="font-bold text-slate-200 block">Free COD</span>
            <span className="text-slate-500 text-[9px]">All India</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <RotateCcw className="w-4 h-4 text-blue-400 mx-auto" />
            <span className="font-bold text-slate-200 block">7-Day Returns</span>
            <span className="text-slate-500 text-[9px]">Hassle Free</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
            <ShieldCheck className="w-4 h-4 text-emerald-400 mx-auto" />
            <span className="font-bold text-slate-200 block">Verified Factory</span>
            <span className="text-slate-500 text-[9px]">100% Quality</span>
          </div>
        </div>
      </div>

      {/* Fixed Sticky Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40 bg-[#080c16]/95 backdrop-blur-md px-4 py-3 border-t border-slate-800 flex items-center gap-2">
        {/* Share on WhatsApp Button */}
        <button
          onClick={handleShare}
          className="flex-1 py-3 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-emerald-900/40 active:scale-95 transition-all"
        >
          <Share2 className="w-4 h-4" />
          <span>{showShareSuccess ? 'Shared!' : 'Share WhatsApp'}</span>
        </button>

        {/* Order for Customer Button */}
        <button
          onClick={handleOrderClick}
          className="flex-1 py-3 px-3 rounded-xl bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-pink-900/40 active:scale-95 transition-all"
        >
          <ShoppingCart className="w-4 h-4" />
          <span>Order for Customer</span>
        </button>
      </div>
    </div>
  );
}
