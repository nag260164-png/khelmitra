import { Sparkles, ShoppingBag, Gamepad2, ArrowRightLeft } from 'lucide-react';
import { SuperAppMode } from '../../types';
import { audioEffectsService } from '../../services/audioEffectsService';

interface SuperAppModeSwitcherProps {
  mode: SuperAppMode;
  onSwitchMode: (mode: SuperAppMode) => void;
  gamingCoins: number;
  resellerEarnings: number;
}

export default function SuperAppModeSwitcher({
  mode,
  onSwitchMode,
  gamingCoins,
  resellerEarnings
}: SuperAppModeSwitcherProps) {
  const handleToggle = (newMode: SuperAppMode) => {
    if (newMode !== mode) {
      audioEffectsService.playClick();
      onSwitchMode(newMode);
    }
  };

  return (
    <div id="super-app-mode-switcher" className="px-4 pt-2.5 pb-1">
      <div className="p-1 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border border-slate-800 shadow-lg">
        {/* Dual Mode Switcher Tabs */}
        <div className="grid grid-cols-2 gap-1 relative">
          {/* 1. Gaming Mode Tab */}
          <button
            id="tab-gaming-mode"
            onClick={() => handleToggle('gaming')}
            className={`relative flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all duration-200 active:scale-98 ${
              mode === 'gaming'
                ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 shadow-md shadow-amber-500/25 font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Gamepad2 className={`w-4 h-4 ${mode === 'gaming' ? 'text-slate-950 fill-slate-950/20' : 'text-amber-400'}`} />
            <span>🎮 GAMING MODE</span>
            {mode === 'gaming' && (
              <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 rounded-full bg-black/30 text-[9px] text-slate-900 font-mono">
                {gamingCoins.toLocaleString()} 🪙
              </span>
            )}
          </button>

          {/* 2. Reselling Mode Tab */}
          <button
            id="tab-reselling-mode"
            onClick={() => handleToggle('reselling')}
            className={`relative flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all duration-200 active:scale-98 ${
              mode === 'reselling'
                ? 'bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 text-white shadow-md shadow-rose-500/25 font-black'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <ShoppingBag className={`w-4 h-4 ${mode === 'reselling' ? 'text-white' : 'text-pink-400'}`} />
            <span>🛍️ RESELLING MODE</span>
            <span className="px-1 py-0.2 rounded bg-amber-400/90 text-slate-950 text-[8px] font-black uppercase tracking-wider">
              Earn ₹
            </span>
          </button>
        </div>

        {/* Dynamic Mode Sub-bar Context */}
        <div className="mt-1.5 px-2 py-1 rounded-lg bg-slate-950/80 border border-slate-800/60 flex items-center justify-between text-[10px]">
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            {mode === 'gaming' ? (
              <span>Active: <strong>Cricket, Ludo, Teen Patti & Fantasy</strong> (Free-to-play)</span>
            ) : (
              <span>Active: <strong>Wholesale Reseller Marketplace</strong> (Zero Investment)</span>
            )}
          </div>

          <button
            onClick={() => handleToggle(mode === 'gaming' ? 'reselling' : 'gaming')}
            className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 active:scale-95 transition-all text-[9px]"
            title="Switch Super App Mode"
          >
            <ArrowRightLeft className="w-2.5 h-2.5" />
            <span>Switch to {mode === 'gaming' ? 'Reselling' : 'Gaming'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
