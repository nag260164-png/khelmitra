import { useState, useEffect } from 'react';
import { 
  Building2, PlusCircle, PackageCheck, Truck, 
  CheckCircle2, AlertCircle, X, ShieldAlert, Layers, Image as ImageIcon 
} from 'lucide-react';
import { SupplierProfile, ResellerCategory, ResellerProduct } from '../../types';
import { resellingService } from '../../services/resellingService';
import { RESELLER_CATEGORIES } from '../../data/resellingData';
import { audioEffectsService } from '../../services/audioEffectsService';

interface SupplierPortalViewProps {
  onClose?: () => void;
}

export default function SupplierPortalView({ onClose }: SupplierPortalViewProps) {
  const [activeTab, setActiveTab] = useState<'register' | 'upload' | 'my-products'>('upload');
  const [suppliers, setSuppliers] = useState<SupplierProfile[]>(resellingService.getSuppliers());
  const [products, setProducts] = useState<ResellerProduct[]>(resellingService.getProducts());

  // Registration Form State
  const [regBusiness, setRegBusiness] = useState('');
  const [regOwner, setRegOwner] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regCity, setRegCity] = useState('');
  const [regGst, setRegGst] = useState('');
  const [regCategory, setRegCategory] = useState<ResellerCategory>('Ladies Kurti');
  const [regMsg, setRegMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Upload Product Form State
  const [prodTitle, setProdTitle] = useState('');
  const [prodCategory, setProdCategory] = useState<ResellerCategory>('Ladies Kurti');
  const [prodPrice, setProdPrice] = useState<number>(350);
  const [prodMrp, setProdMrp] = useState<number>(899);
  const [prodStock, setProdStock] = useState<number>(100);
  const [prodFabric, setProdFabric] = useState('');
  const [prodImg, setProdImg] = useState('');
  const [uploadMsg, setUploadMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    const unsub = resellingService.subscribe(() => {
      setSuppliers([...resellingService.getSuppliers()]);
      setProducts([...resellingService.getProducts()]);
    });
    return unsub;
  }, []);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegMsg(null);
    audioEffectsService.playClick();

    const res = resellingService.registerSupplier({
      businessName: regBusiness,
      ownerName: regOwner,
      phone: regPhone,
      email: `${regBusiness.toLowerCase().replace(/\s+/g, '')}@example.com`,
      city: regCity,
      state: 'Gujarat',
      categories: [regCategory],
      gstOrPan: regGst
    });

    if (res.success) {
      setRegMsg({ type: 'success', text: res.message });
      setRegBusiness('');
      setRegOwner('');
      setRegPhone('');
      setRegCity('');
      setRegGst('');
      audioEffectsService.playWin();
    } else {
      setRegMsg({ type: 'error', text: res.message });
    }
  };

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    setUploadMsg(null);
    audioEffectsService.playClick();

    const res = resellingService.uploadSupplierProduct({
      title: prodTitle,
      category: prodCategory,
      description: `Factory wholesale lot. High quality ${prodFabric || 'fabric'} crafted for premium resellers.`,
      supplierPrice: prodPrice,
      suggestedMrp: prodMrp,
      stock: prodStock,
      fabric: prodFabric || '100% Cotton / Rayon Standard',
      sizes: ['M (38)', 'L (40)', 'XL (42)', 'XXL (44)'],
      imageUrl: prodImg || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800'
    });

    if (res.success) {
      setUploadMsg({ type: 'success', text: res.message });
      setProdTitle('');
      setProdFabric('');
      setProdImg('');
      audioEffectsService.playWin();
      setActiveTab('my-products');
    } else {
      setUploadMsg({ type: 'error', text: res.message });
    }
  };

  return (
    <div id="supplier-portal-view" className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-[#070b14]/95 backdrop-blur-md px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-slate-950 flex items-center justify-center font-bold">
            <Building2 className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-xs font-black text-white uppercase tracking-wider">Wholesale Supplier Portal</h2>
            <span className="text-[10px] text-slate-400">List Catalogue • Surat & Jaipur Mills</span>
          </div>
        </div>

        {onClose && (
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="p-4 space-y-4 pb-24">
        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('upload')}
            className={`py-2 rounded-lg transition-all ${
              activeTab === 'upload' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            + Upload Product
          </button>
          <button
            onClick={() => setActiveTab('my-products')}
            className={`py-2 rounded-lg transition-all ${
              activeTab === 'my-products' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Wholesale Catalog
          </button>
          <button
            onClick={() => setActiveTab('register')}
            className={`py-2 rounded-lg transition-all ${
              activeTab === 'register' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Register Mill
          </button>
        </div>

        {/* TAB 1: UPLOAD WHOLESALE PRODUCT */}
        {activeTab === 'upload' && (
          <form onSubmit={handleUpload} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <PlusCircle className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-white">Upload New Wholesale Inventory</h3>
            </div>

            {uploadMsg && (
              <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                uploadMsg.type === 'success'
                  ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-200'
                  : 'bg-red-950/50 border-red-500/40 text-red-200'
              }`}>
                {uploadMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
                <span>{uploadMsg.text}</span>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Product Title *</label>
              <input
                type="text"
                placeholder="e.g. Surat Soft Silk Jacquard Saree with Zari Pallu"
                value={prodTitle}
                onChange={(e) => setProdTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-slate-400">Category *</label>
                <select
                  value={prodCategory}
                  onChange={(e) => setProdCategory(e.target.value as ResellerCategory)}
                  className="w-full px-2 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                >
                  {RESELLER_CATEGORIES.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.label}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-slate-400">Stock Quantity</label>
                <input
                  type="number"
                  min="1"
                  value={prodStock}
                  onChange={(e) => setProdStock(Number(e.target.value))}
                  className="w-full px-2 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-amber-400">Wholesale Price (₹) *</label>
                <input
                  type="number"
                  min="50"
                  value={prodPrice}
                  onChange={(e) => setProdPrice(Number(e.target.value))}
                  className="w-full px-2 py-2 bg-slate-950 border border-amber-500/60 rounded-xl text-xs font-bold text-amber-300 focus:outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-slate-400">Suggested Retail MRP (₹)</label>
                <input
                  type="number"
                  min={prodPrice}
                  value={prodMrp}
                  onChange={(e) => setProdMrp(Number(e.target.value))}
                  className="w-full px-2 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Fabric / Material Specifications</label>
              <input
                type="text"
                placeholder="e.g. 100% Pure Cambric Cotton 60x60 / Art Silk"
                value={prodFabric}
                onChange={(e) => setProdFabric(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Image URL (Optional)</label>
              <input
                type="url"
                placeholder="https://... (Leave blank for default premium photo)"
                value={prodImg}
                onChange={(e) => setProdImg(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all mt-2"
            >
              Publish to KhelMitra Reseller Network
            </button>
          </form>
        )}

        {/* TAB 2: MY WHOLESALE CATALOGUE */}
        {activeTab === 'my-products' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-200">Catalogue Products ({products.length})</span>
              <span className="text-[10px] text-emerald-400 font-bold">100% Live on Reselling App</span>
            </div>

            <div className="space-y-2">
              {products.map((p) => (
                <div key={p.id} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center gap-3">
                  <img
                    src={p.images[0]}
                    alt={p.title}
                    className="w-14 h-14 rounded-xl object-cover border border-slate-700 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <span className="text-[9px] text-pink-400 font-bold uppercase">{p.category}</span>
                    <h4 className="text-xs font-bold text-white truncate">{p.title}</h4>
                    <div className="flex items-center gap-2 mt-1 text-[11px]">
                      <span className="text-amber-400 font-bold">Wholesale: ₹{p.supplierPrice}</span>
                      <span className="text-slate-400">Stock: {p.stock}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      audioEffectsService.playClick();
                      resellingService.toggleProductStock(p.id);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all ${
                      p.inStock
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : 'bg-red-500/20 text-red-300 border-red-500/30'
                    }`}
                  >
                    {p.inStock ? 'In Stock' : 'Out of Stock'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: REGISTER NEW WHOLESALE MILL */}
        {activeTab === 'register' && (
          <form onSubmit={handleRegister} className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-white">Register as Verified Wholesale Supplier</h3>
            </div>

            {regMsg && (
              <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                regMsg.type === 'success'
                  ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-200'
                  : 'bg-red-950/50 border-red-500/40 text-red-200'
              }`}>
                {regMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
                <span>{regMsg.text}</span>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] uppercase font-semibold text-slate-400">Mill / Enterprise Name *</label>
              <input
                type="text"
                placeholder="e.g. Surat Textile Mills & Weavers"
                value={regBusiness}
                onChange={(e) => setRegBusiness(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-slate-400">Proprietor Name *</label>
                <input
                  type="text"
                  placeholder="Owner Name"
                  value={regOwner}
                  onChange={(e) => setRegOwner(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-slate-400">Phone Number *</label>
                <input
                  type="tel"
                  placeholder="10 Digits"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-slate-400">City / Manufacturing Hub</label>
                <input
                  type="text"
                  placeholder="e.g. Surat / Jaipur"
                  value={regCity}
                  onChange={(e) => setRegCity(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] uppercase font-semibold text-slate-400">GST or PAN (Optional)</label>
                <input
                  type="text"
                  placeholder="GSTIN"
                  value={regGst}
                  onChange={(e) => setRegGst(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all mt-2"
            >
              Submit Application to Master Owner
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
