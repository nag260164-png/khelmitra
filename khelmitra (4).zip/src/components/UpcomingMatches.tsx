import { useState } from 'react';
import { Calendar, Trophy, ChevronRight, Clock, ShieldAlert, Zap, Radio } from 'lucide-react';
import { UpcomingMatch, ActiveSheetType } from '../types';
import { UPCOMING_MATCHES } from '../data/mockData';
import TeamLogoBadge from './cricket/TeamLogoBadge';

interface UpcomingMatchesProps {
  onOpenSheet: (sheet: ActiveSheetType) => void;
}

export default function UpcomingMatches({ onOpenSheet }: UpcomingMatchesProps) {
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | 'T20' | 'ODI'>('ALL');

  const filteredMatches = UPCOMING_MATCHES.filter((m) => {
    if (selectedFilter === 'ALL') return true;
    return m.matchType === selectedFilter;
  });

  return (
    <section id="upcoming-matches-section" className="px-4 py-3">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Calendar className="w-3.5 h-3.5" />
          </div>
          <div>
            <h2 className="text-xs uppercase font-extrabold tracking-wider text-slate-200 font-mono">
              Upcoming Matches
            </h2>
            <span className="text-[10px] text-slate-400">Build fantasy 11 before toss</span>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center bg-slate-900/90 p-0.5 rounded-lg border border-slate-800">
          {(['ALL', 'T20', 'ODI'] as const).map((filter) => (
            <button
              key={filter}
              id={`filter-upcoming-${filter.toLowerCase()}`}
              onClick={() => setSelectedFilter(filter)}
              className={`px-2.5 py-1 rounded-md text-[10px] font-bold transition-colors ${
                selectedFilter === filter
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Upcoming Matches List */}
      <div className="space-y-3">
        {filteredMatches.map((match) => (
          <div
            key={match.id}
            id={`upcoming-match-card-${match.id}`}
            className="rounded-2xl bg-gradient-to-br from-[#0e1424] via-[#0b101c] to-[#070b14] border border-slate-800/90 shadow-md hover:border-slate-700/80 transition-all overflow-hidden"
          >
            {/* Top Match Info Bar */}
            <div className="px-3.5 py-2 bg-slate-900/60 border-b border-slate-800/60 flex items-center justify-between text-[11px]">
              <span className="text-slate-300 font-semibold truncate max-w-[210px]">
                {match.tournament}
              </span>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 font-bold text-[10px] flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" />
                  {match.countdown}
                </span>
              </div>
            </div>

            {/* Teams Matchup Row */}
            <div className="p-3.5">
              <div className="grid grid-cols-5 items-center">
                {/* Team 1 */}
                <div className="col-span-2 flex items-center gap-2.5">
                  <TeamLogoBadge
                    code={match.team1.code}
                    name={match.team1.name}
                    size="md"
                  />
                  <div>
                    <span className="text-sm font-bold text-white leading-tight block">
                      {match.team1.code}
                    </span>
                    <span className="text-[11px] text-slate-400 leading-none truncate max-w-[80px] block">
                      {match.team1.name}
                    </span>
                  </div>
                </div>

                {/* VS Center */}
                <div className="col-span-1 flex flex-col items-center justify-center text-center">
                  <div className="w-6 h-6 rounded-full bg-slate-800/90 border border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-400">
                    VS
                  </div>
                  <span className="text-[9px] font-semibold text-slate-500 mt-1">
                    {match.matchType}
                  </span>
                </div>

                {/* Team 2 */}
                <div className="col-span-2 flex items-center justify-end gap-2.5 text-right">
                  <div>
                    <span className="text-sm font-bold text-white leading-tight block">
                      {match.team2.code}
                    </span>
                    <span className="text-[11px] text-slate-400 leading-none truncate max-w-[80px] block">
                      {match.team2.name}
                    </span>
                  </div>
                  <TeamLogoBadge
                    code={match.team2.code}
                    name={match.team2.name}
                    size="md"
                  />
                </div>
              </div>

              {/* Venue & Time line */}
              <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2.5 pt-2 border-t border-slate-800/50">
                <span className="truncate max-w-[180px]">{match.venue}</span>
                <span className="text-amber-400/90 font-medium">{match.startTime}</span>
              </div>
            </div>

            {/* Bottom Contest & Quick Actions Bar */}
            <div className="px-3.5 py-2.5 bg-slate-950/70 border-t border-slate-800/70 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <div className="flex flex-col">
                  <span className="text-[9px] text-slate-400 leading-none">Mega Contest</span>
                  <span className="text-xs font-bold text-amber-300 leading-tight">
                    {match.megaContestPrize}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  id={`btn-create-team-${match.id}`}
                  onClick={() => onOpenSheet('my-teams')}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-[11px] active:scale-95 transition-all"
                >
                  Create Team
                </button>
                <button
                  id={`btn-join-contest-${match.id}`}
                  onClick={() => onOpenSheet('fantasy-cricket')}
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-extrabold text-[11px] shadow-sm active:scale-95 transition-all flex items-center gap-1"
                >
                  <span>Join ₹{match.entryFee}</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
