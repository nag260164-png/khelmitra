import React, { useState, useEffect, useMemo } from 'react';
import { 
  ArrowLeft, RotateCcw, HelpCircle, Trophy, Sparkles, 
  Volume2, ShieldCheck, ChevronRight, Award, Crown, Zap 
} from 'lucide-react';
import { demoPointsService } from '../../services/demoPointsService';
import { audioEffectsService } from '../../services/audioEffectsService';
import MultiplayerRoomBar from './MultiplayerRoomBar';

interface CallBreakGameProps {
  onBack: () => void;
  onOpenRules?: () => void;
}

export type Suit = 'spades' | 'hearts' | 'diamonds' | 'clubs';
export type Rank = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';

export interface Card {
  id: string;
  suit: Suit;
  rank: Rank;
  value: number; // 2 to 14
}

interface Player {
  id: string;
  name: string;
  avatar: string;
  isHuman: boolean;
  bid: number;
  tricksWon: number;
  totalScore: number;
  hand: Card[];
  currentCard: Card | null;
}

const SUIT_ICONS: Record<Suit, string> = {
  spades: '♠',
  hearts: '♥',
  diamonds: '♦',
  clubs: '♣',
};

const SUIT_COLORS: Record<Suit, string> = {
  spades: 'text-slate-200',
  hearts: 'text-red-500',
  diamonds: 'text-rose-500',
  clubs: 'text-amber-400',
};

function createDeck(): Card[] {
  const suits: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
  const ranks: Rank[] = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  const deck: Card[] = [];

  for (const suit of suits) {
    for (let i = 0; i < ranks.length; i++) {
      deck.push({
        id: `${ranks[i]}_${suit}`,
        suit,
        rank: ranks[i],
        value: i + 2, // 2 = 2 ... A = 14
      });
    }
  }

  // Shuffle deck
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  return deck;
}

function sortCards(cards: Card[]): Card[] {
  const suitOrder: Record<Suit, number> = { spades: 0, hearts: 1, clubs: 2, diamonds: 3 };
  return [...cards].sort((a, b) => {
    if (suitOrder[a.suit] !== suitOrder[b.suit]) {
      return suitOrder[a.suit] - suitOrder[b.suit];
    }
    return b.value - a.value;
  });
}

export default function CallBreakGame({ onBack }: CallBreakGameProps) {
  const [roundNumber, setRoundNumber] = useState(1);
  const [phase, setPhase] = useState<'bidding' | 'playing' | 'round-over' | 'match-over'>('bidding');
  const [currentTurn, setCurrentTurn] = useState<number>(0); // 0: South (Human), 1: West, 2: North, 3: East
  const [dealer, setDealer] = useState<number>(3);
  const [leadSuit, setLeadSuit] = useState<Suit | null>(null);
  const [trickWinnerMessage, setTrickWinnerMessage] = useState<string | null>(null);
  const [showScoreboard, setShowScoreboard] = useState(false);
  const [showRulesModal, setShowRulesModal] = useState(false);
  const [coinsBalance, setCoinsBalance] = useState(demoPointsService.getPoints());

  const initialPlayers: Player[] = useMemo(() => [
    {
      id: 'p0',
      name: 'You (Champion)',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      isHuman: true,
      bid: 0,
      tricksWon: 0,
      totalScore: 0,
      hand: [],
      currentCard: null,
    },
    {
      id: 'p1',
      name: 'Kabir (West)',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      isHuman: false,
      bid: 0,
      tricksWon: 0,
      totalScore: 0,
      hand: [],
      currentCard: null,
    },
    {
      id: 'p2',
      name: 'Aarav (North)',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80',
      isHuman: false,
      bid: 0,
      tricksWon: 0,
      totalScore: 0,
      hand: [],
      currentCard: null,
    },
    {
      id: 'p3',
      name: 'Priya (East)',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
      isHuman: false,
      bid: 0,
      tricksWon: 0,
      totalScore: 0,
      hand: [],
      currentCard: null,
    },
  ], []);

  const [players, setPlayers] = useState<Player[]>(initialPlayers);
  const [isMultiplayer, setIsMultiplayer] = useState(false);

  // Subscribe to virtual coins
  useEffect(() => {
    const unsub = demoPointsService.subscribe(setCoinsBalance);
    return () => unsub();
  }, []);

  // Initialize a new round
  const startNewRound = () => {
    const deck = createDeck();
    const p0Cards = sortCards(deck.slice(0, 13));
    const p1Cards = sortCards(deck.slice(13, 26));
    const p2Cards = sortCards(deck.slice(26, 39));
    const p3Cards = sortCards(deck.slice(39, 52));

    // Calculate AI bids
    const calcAiBid = (hand: Card[]) => {
      let count = 0;
      for (const card of hand) {
        if (card.suit === 'spades' && card.value >= 11) count++;
        if (card.value === 14) count++; // Ace
        if (card.value === 13 && Math.random() > 0.4) count++; // King
      }
      return Math.max(2, Math.min(5, count));
    };

    setPlayers(prev => [
      { ...prev[0], hand: p0Cards, bid: 0, tricksWon: 0, currentCard: null },
      { ...prev[1], hand: p1Cards, bid: calcAiBid(p1Cards), tricksWon: 0, currentCard: null },
      { ...prev[2], hand: p2Cards, bid: calcAiBid(p2Cards), tricksWon: 0, currentCard: null },
      { ...prev[3], hand: p3Cards, bid: calcAiBid(p3Cards), tricksWon: 0, currentCard: null },
    ]);

    setPhase('bidding');
    setCurrentTurn(0);
    setLeadSuit(null);
    setTrickWinnerMessage(null);
  };

  useEffect(() => {
    startNewRound();
  }, [roundNumber]);

  // Submit human player bid
  const handleSelectBid = (bid: number) => {
    setPlayers(prev => {
      const updated = [...prev];
      updated[0].bid = bid;
      return updated;
    });
    setPhase('playing');
    setCurrentTurn(0); // South leads first or next after dealer
  };

  // Check valid cards for human player
  const isValidCard = (card: Card): boolean => {
    if (!leadSuit) return true; // Leading card
    const humanHand = players[0].hand;
    const hasLeadSuit = humanHand.some(c => c.suit === leadSuit);

    if (hasLeadSuit) {
      return card.suit === leadSuit;
    }
    // Void in lead suit, can play spade (trump) or any other
    return true;
  };

  // Bot Auto Play
  useEffect(() => {
    if (phase !== 'playing') return;
    if (currentTurn === 0) return; // Human turn

    const botIndex = currentTurn;
    const bot = players[botIndex];
    if (bot.hand.length === 0 || bot.currentCard) return;

    const timer = setTimeout(() => {
      // Bot chooses valid card
      let validCards = bot.hand;
      if (leadSuit) {
        const matchingSuit = bot.hand.filter(c => c.suit === leadSuit);
        if (matchingSuit.length > 0) {
          validCards = matchingSuit;
        } else {
          // Can trump with spade
          const spades = bot.hand.filter(c => c.suit === 'spades');
          validCards = spades.length > 0 ? spades : bot.hand;
        }
      }

      // Choose lowest winning card or lowest card
      const chosenCard = validCards[Math.floor(Math.random() * validCards.length)];

      playCardForPlayer(botIndex, chosenCard);
    }, 650);

    return () => clearTimeout(timer);
  }, [currentTurn, phase, players, leadSuit]);

  // Play card
  const playCardForPlayer = (playerIdx: number, card: Card) => {
    audioEffectsService.playCardDeal();
    setPlayers(prev => {
      const updated = [...prev];
      updated[playerIdx] = {
        ...updated[playerIdx],
        hand: updated[playerIdx].hand.filter(c => c.id !== card.id),
        currentCard: card,
      };
      return updated;
    });

    const newLeadSuit = leadSuit || card.suit;
    if (!leadSuit) {
      setLeadSuit(card.suit);
    }

    // Advance turn or evaluate trick if 4 cards played
    const cardsPlayedCount = players.filter(p => p.currentCard !== null).length + 1;

    if (cardsPlayedCount === 4) {
      // Trick is complete
      setTimeout(() => {
        evaluateTrick(newLeadSuit, playerIdx, card);
      }, 1000);
    } else {
      setCurrentTurn((playerIdx + 1) % 4);
    }
  };

  // Evaluate who wins the 4-card trick
  const evaluateTrick = (suitLed: Suit, lastPlayerIdx: number, lastCard: Card) => {
    // Collect all 4 cards
    const currentTableCards: { playerIdx: number; card: Card }[] = players.map((p, idx) => ({
      playerIdx: idx,
      card: idx === lastPlayerIdx ? lastCard : p.currentCard!,
    }));

    // In Call Break, Spades is ALWAYS Trump.
    // Highest spade wins. If no spades, highest of suitLed wins.
    let winningItem = currentTableCards[0];

    for (let i = 1; i < currentTableCards.length; i++) {
      const challenger = currentTableCards[i];
      const winCard = winningItem.card;
      const chCard = challenger.card;

      if (chCard.suit === 'spades') {
        if (winCard.suit !== 'spades') {
          winningItem = challenger;
        } else if (chCard.value > winCard.value) {
          winningItem = challenger;
        }
      } else if (winCard.suit !== 'spades' && chCard.suit === suitLed) {
        if (chCard.value > winCard.value) {
          winningItem = challenger;
        }
      }
    }

    const winnerIdx = winningItem.playerIdx;
    const winnerName = players[winnerIdx].name;

    setTrickWinnerMessage(`${winnerName} won the trick!`);

    setTimeout(() => {
      setPlayers(prev => {
        const updated = prev.map((p, idx) => ({
          ...p,
          tricksWon: idx === winnerIdx ? p.tricksWon + 1 : p.tricksWon,
          currentCard: null,
        }));
        return updated;
      });

      setLeadSuit(null);
      setTrickWinnerMessage(null);
      setCurrentTurn(winnerIdx);

      // Check if round is over (13 tricks completed)
      const humanRemainingCards = players[0].hand.length - (lastPlayerIdx === 0 ? 1 : 0);
      if (humanRemainingCards <= 0) {
        finishRound();
      }
    }, 1200);
  };

  // Finish Round & Compute Call Break Scores
  const finishRound = () => {
    setPhase('round-over');

    setPlayers(prev => {
      const updated = prev.map(p => {
        let roundScore = 0;
        if (p.tricksWon >= p.bid) {
          // Bid made + extra trick bonus
          roundScore = p.bid + (p.tricksWon - p.bid) * 0.1;
        } else {
          // Under-bid penalty
          roundScore = -p.bid;
        }
        return {
          ...p,
          totalScore: +(p.totalScore + roundScore).toFixed(1),
        };
      });

      // If user met or exceeded bid, reward virtual coins
      const userPlayer = updated[0];
      if (userPlayer.tricksWon >= userPlayer.bid) {
        const coinsEarned = 350;
        demoPointsService.addPoints(coinsEarned, 'Call Break', `Won round ${roundNumber} (${userPlayer.tricksWon} tricks)`);
        demoPointsService.recordMatch({
          gameName: 'Call Break',
          gameKey: 'call-break',
          result: 'WON',
          coinsWon: coinsEarned,
          coinsSpent: 0,
          details: `Round ${roundNumber} • Bid: ${userPlayer.bid}, Tricks: ${userPlayer.tricksWon} • Score: +${coinsEarned} coins`,
        });
      }

      return updated;
    });
  };

  const handleNextRound = () => {
    if (roundNumber >= 5) {
      setPhase('match-over');
    } else {
      setRoundNumber(r => r + 1);
    }
  };

  const handleRestartMatch = () => {
    setRoundNumber(1);
    setPlayers(initialPlayers);
    startNewRound();
  };

  return (
    <div id="call-break-game-screen" className="flex flex-col h-full bg-[#040810] text-slate-100 overflow-hidden select-none">
      {/* Top Gaming Navigation Header */}
      <div className="px-4 py-2.5 bg-[#080d1a] border-b border-slate-800/90 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-2">
          <button
            id="call-break-back-btn"
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black tracking-wider text-amber-400 uppercase font-mono">♠ Call Break</span>
              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                Round {roundNumber}/5
              </span>
            </div>
            <span className="text-[10px] text-slate-400">4-Player Classic • Spades Trump</span>
          </div>
        </div>

        {/* Right Info: Coin Balance & Scoreboard button */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-2 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold font-mono">
            <span>🪙</span>
            <span>{coinsBalance.toLocaleString()}</span>
          </div>
          <button
            onClick={() => setShowScoreboard(!showScoreboard)}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-amber-400 text-xs flex items-center gap-1 font-bold"
            title="Scoreboard"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
          </button>
          <button
            onClick={() => setShowRulesModal(true)}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs"
            title="Rules"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Multiplayer & AI Tactical Bar */}
      <MultiplayerRoomBar
        gameId="call-break"
        gameTitle="Call Break Master"
        isMultiplayer={isMultiplayer}
        onToggleMode={setIsMultiplayer}
      />

      {/* Main Virtual Felt Card Table */}
      <div className="flex-1 relative flex flex-col justify-between p-3 bg-radial from-[#0d2a1b] via-[#07160e] to-[#040810] overflow-hidden">
        {/* Subtle Felt texture & Oval Table boundary */}
        <div className="absolute inset-4 rounded-[40px] border-2 border-emerald-600/25 pointer-events-none shadow-[inset_0_0_50px_rgba(0,0,0,0.8)]"></div>

        {/* North Seat: Bot Aarav */}
        <div className="flex flex-col items-center relative z-10">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950/80 border border-emerald-500/30 backdrop-blur-sm">
            <img src={players[2].avatar} alt="" className="w-6 h-6 rounded-full object-cover border border-emerald-400/50" />
            <div className="text-left">
              <div className="text-[11px] font-bold text-white leading-tight">{players[2].name}</div>
              <div className="text-[9px] text-emerald-400 leading-none">
                Bid: {players[2].bid || '-'} • Won: {players[2].tricksWon}
              </div>
            </div>
            {currentTurn === 2 && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            )}
          </div>
          {/* Card Back representation */}
          <div className="flex -space-x-4 mt-1">
            {players[2].hand.slice(0, 5).map((_, i) => (
              <div key={i} className="w-6 h-8 rounded bg-gradient-to-br from-blue-900 to-indigo-950 border border-blue-400/40 shadow-sm"></div>
            ))}
          </div>
        </div>

        {/* Middle Row: West Seat | Center Trick Arena | East Seat */}
        <div className="flex items-center justify-between relative z-10 my-auto px-2">
          {/* West Seat: Bot Kabir */}
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/80 border border-emerald-500/30">
              <img src={players[1].avatar} alt="" className="w-6 h-6 rounded-full object-cover border border-emerald-400/50" />
              <div className="text-left">
                <div className="text-[10px] font-bold text-white">{players[1].name.split(' ')[0]}</div>
                <div className="text-[9px] text-emerald-400">Bid: {players[1].bid || '-'} | {players[1].tricksWon}</div>
              </div>
              {currentTurn === 1 && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>}
            </div>
          </div>

          {/* Center Table: 4 Played Cards in Trick */}
          <div className="relative w-44 h-36 rounded-2xl bg-black/40 border border-emerald-500/20 backdrop-blur-sm flex items-center justify-center shadow-inner">
            {/* Lead Trump indicator */}
            <div className="absolute top-1 left-2 text-[10px] text-emerald-300 font-mono flex items-center gap-1">
              <span>Trump:</span>
              <span className="text-amber-400 font-bold">♠ Spades</span>
            </div>

            {trickWinnerMessage && (
              <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md rounded-2xl flex flex-col items-center justify-center p-2 z-20 animate-in fade-in zoom-in-95">
                <Sparkles className="w-5 h-5 text-amber-400 animate-spin" />
                <span className="text-xs font-bold text-amber-300 mt-1 text-center">{trickWinnerMessage}</span>
              </div>
            )}

            {/* 4 Player Card Positions in Center */}
            <div className="relative w-full h-full flex items-center justify-center">
              {/* North Card (Top) */}
              {players[2].currentCard && (
                <div className="absolute top-2 animate-in slide-in-from-top-4 duration-200">
                  <MiniCard card={players[2].currentCard} />
                </div>
              )}

              {/* West Card (Left) */}
              {players[1].currentCard && (
                <div className="absolute left-3 animate-in slide-in-from-left-4 duration-200">
                  <MiniCard card={players[1].currentCard} />
                </div>
              )}

              {/* East Card (Right) */}
              {players[3].currentCard && (
                <div className="absolute right-3 animate-in slide-in-from-right-4 duration-200">
                  <MiniCard card={players[3].currentCard} />
                </div>
              )}

              {/* South Card (Bottom) */}
              {players[0].currentCard && (
                <div className="absolute bottom-2 animate-in slide-in-from-bottom-4 duration-200">
                  <MiniCard card={players[0].currentCard} />
                </div>
              )}

              {!players[0].currentCard && !players[1].currentCard && !players[2].currentCard && !players[3].currentCard && (
                <span className="text-[11px] text-emerald-400/50 font-medium">
                  {phase === 'bidding' ? 'Place your bid' : currentTurn === 0 ? 'Your turn to play' : `${players[currentTurn].name.split(' ')[0]} thinking...`}
                </span>
              )}
            </div>
          </div>

          {/* East Seat: Bot Priya */}
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-950/80 border border-emerald-500/30">
              <img src={players[3].avatar} alt="" className="w-6 h-6 rounded-full object-cover border border-emerald-400/50" />
              <div className="text-left">
                <div className="text-[10px] font-bold text-white">{players[3].name.split(' ')[0]}</div>
                <div className="text-[9px] text-emerald-400">Bid: {players[3].bid || '-'} | {players[3].tricksWon}</div>
              </div>
              {currentTurn === 3 && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>}
            </div>
          </div>
        </div>

        {/* South Seat: Human Player Hand & Bid Selector */}
        <div className="relative z-10 flex flex-col items-center">
          {/* User Status Bar */}
          <div className="flex items-center justify-between w-full max-w-sm px-3 py-1 rounded-t-xl bg-slate-950/80 border-t border-x border-emerald-500/30 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-white">{players[0].name}</span>
              {currentTurn === 0 && phase === 'playing' && (
                <span className="px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 font-extrabold text-[10px] animate-pulse">
                  YOUR TURN
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <span>Bid: <strong className="text-amber-400">{players[0].bid || '-'}</strong></span>
              <span>•</span>
              <span>Tricks: <strong className="text-emerald-400">{players[0].tricksWon}</strong></span>
            </div>
          </div>

          {/* Bidding Phase Selector */}
          {phase === 'bidding' && (
            <div className="w-full bg-slate-950/95 border border-amber-500/40 rounded-xl p-3 shadow-xl flex flex-col items-center mb-2 animate-in zoom-in-95">
              <div className="text-xs font-bold text-amber-300 mb-1 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5" />
                Select Your Call Break Bid (Expected Tricks):
              </div>
              <div className="flex gap-1.5 mt-1 overflow-x-auto w-full justify-center pb-1">
                {[1, 2, 3, 4, 5, 6, 7, 8].map(bidNum => (
                  <button
                    key={bidNum}
                    onClick={() => handleSelectBid(bidNum)}
                    className="w-9 h-9 rounded-xl bg-slate-900 border border-amber-500/30 hover:border-amber-400 hover:bg-amber-500 hover:text-slate-950 text-white font-bold text-sm transition-all active:scale-90 flex items-center justify-center"
                  >
                    {bidNum}
                  </button>
                ))}
              </div>
              <span className="text-[10px] text-slate-400 mt-1">Hint: Count your high cards (Aces, Kings, high Spades)</span>
            </div>
          )}

          {/* Player Hand - 13 Cards with smooth horizontal overlap */}
          <div className="w-full flex items-center justify-center overflow-x-auto py-1 px-2 no-scrollbar">
            <div className="flex -space-x-5 py-2">
              {players[0].hand.map((card) => {
                const valid = currentTurn === 0 && phase === 'playing' && isValidCard(card);
                return (
                  <button
                    key={card.id}
                    disabled={!valid}
                    onClick={() => playCardForPlayer(0, card)}
                    className={`relative w-12 h-18 rounded-lg bg-slate-100 text-slate-950 border-2 font-bold shadow-md transition-all flex flex-col justify-between p-1 select-none ${
                      valid 
                        ? 'hover:-translate-y-3 cursor-pointer hover:border-amber-400 border-slate-300 ring-2 ring-emerald-500/40' 
                        : 'opacity-65 cursor-not-allowed border-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] leading-none">
                      <span>{card.rank}</span>
                      <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
                    </div>
                    <div className={`text-base text-center my-auto ${SUIT_COLORS[card.suit]}`}>
                      {SUIT_ICONS[card.suit]}
                    </div>
                    <div className="flex items-center justify-between text-[10px] leading-none rotate-180">
                      <span>{card.rank}</span>
                      <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Round Complete Modal */}
      {phase === 'round-over' && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0a0f1d] border border-amber-500/40 rounded-3xl p-5 shadow-2xl animate-in zoom-in-95 text-center">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mx-auto mb-3 text-amber-400">
              <Trophy className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-white">Round {roundNumber} Completed!</h3>
            <p className="text-xs text-slate-400 mt-1">Check current trick counts and scores</p>

            <div className="my-4 bg-slate-950/80 rounded-xl p-3 border border-slate-800 space-y-2">
              {players.map(p => (
                <div key={p.id} className="flex items-center justify-between text-xs py-1 border-b border-slate-800/60 last:border-0">
                  <div className="flex items-center gap-2">
                    <img src={p.avatar} alt="" className="w-5 h-5 rounded-full object-cover" />
                    <span className="font-bold text-slate-200">{p.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-400">Bid: {p.bid} | Won: {p.tricksWon}</span>
                    <span className={`font-mono font-bold ${p.tricksWon >= p.bid ? 'text-emerald-400' : 'text-red-400'}`}>
                      {p.totalScore} pts
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {players[0].tricksWon >= players[0].bid ? (
              <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold mb-4 flex items-center justify-center gap-1.5">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Target Achieved! +350 Free Virtual Coins Earned!</span>
              </div>
            ) : (
              <div className="p-2.5 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-bold mb-4">
                Bid Missed ({players[0].tricksWon}/{players[0].bid}). Try again in the next round!
              </div>
            )}

            <button
              onClick={handleNextRound}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm active:scale-95 transition-all shadow-lg flex items-center justify-center gap-2"
            >
              <span>{roundNumber >= 5 ? 'View Final Results' : 'Proceed to Round ' + (roundNumber + 1)}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Match Over Modal */}
      {phase === 'match-over' && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0a0f1d] border border-amber-500/50 rounded-3xl p-5 shadow-2xl text-center">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mx-auto mb-3 text-amber-400">
              <Crown className="w-9 h-9 text-amber-400 animate-bounce" />
            </div>
            <h3 className="text-xl font-black text-white">Call Break 5-Round Match Complete!</h3>
            <p className="text-xs text-slate-400 mt-1">Final Leaderboard Standings</p>

            <div className="my-4 space-y-2">
              {[...players].sort((a, b) => b.totalScore - a.totalScore).map((p, rank) => (
                <div key={p.id} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center font-mono font-bold text-amber-400">
                      {rank + 1}
                    </span>
                    <span className="font-bold text-white">{p.name}</span>
                  </div>
                  <span className="font-mono font-bold text-amber-400">{p.totalScore} pts</span>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleRestartMatch}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Play Again
              </button>
              <button
                onClick={onBack}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                Exit to Games
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rules Modal */}
      {showRulesModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowRulesModal(false)}>
          <div className="w-full max-w-sm bg-[#0c1222] border border-slate-800 rounded-3xl p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Call Break Rules & Points
              </h4>
              <button onClick={() => setShowRulesModal(false)} className="text-xs text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="space-y-2 text-xs text-slate-300 leading-relaxed max-h-72 overflow-y-auto pr-1">
              <p>• <strong>Spades are permanent Trump</strong>: Spades beat any other card suit.</p>
              <p>• <strong>Must Follow Suit</strong>: If you have the led suit, you must play it.</p>
              <p>• <strong>Trumping</strong>: If void in the led suit, you can play a Spade to win the trick.</p>
              <p>• <strong>Bidding</strong>: Call how many tricks you expect to win (1 to 8).</p>
              <p>• <strong>Scoring</strong>: Reaching your bid awards your bid points plus 0.1 for extra tricks. Failing your bid gives minus points equal to your bid.</p>
              <p>• <strong>Virtual Coins Only</strong>: 100% free-to-play with zero real money betting.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniCard({ card }: { card: Card }) {
  const SUIT_ICONS: Record<Suit, string> = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' };
  const SUIT_COLORS: Record<Suit, string> = { spades: 'text-slate-900', hearts: 'text-red-600', diamonds: 'text-rose-600', clubs: 'text-amber-700' };

  return (
    <div className="w-11 h-16 rounded-lg bg-white border border-slate-400 shadow-md p-1 flex flex-col justify-between select-none">
      <div className="flex items-center justify-between text-[10px] font-bold text-slate-900 leading-none">
        <span>{card.rank}</span>
        <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
      </div>
      <div className={`text-sm text-center my-auto ${SUIT_COLORS[card.suit]}`}>
        {SUIT_ICONS[card.suit]}
      </div>
      <div className="flex items-center justify-between text-[9px] font-bold text-slate-900 leading-none rotate-180">
        <span>{card.rank}</span>
        <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
      </div>
    </div>
  );
}
