import React, { useState } from 'react';
import { 
  Trophy, Medal, Crown, Flame, ArrowLeft, Sparkles, 
  TrendingUp, Users, Shield, Zap, Award, ChevronRight 
} from 'lucide-react';
import { audioEffectsService } from '../../services/audioEffectsService';

interface LeaderboardModalProps {
  onClose: () => void;
  onSelectGame?: (gameId: string) => void;
}

type Timeframe = 'daily' | 'weekly' | 'allTime';
type GameFilter = 'all' | 'call-break' | 'teen-patti' | 'ludo' | 'rummy';

interface LeaderboardEntry {
  rank: number;
  name: string;
  avatar: string;
  location: string;
  tier: string;
  coinsWon: number;
  winStreak: number;
  winRate: string;
  isUser?: boolean;
}

const LEADERBOARD_DATA: Record<Timeframe, LeaderboardEntry[]> = {
  daily: [
    { rank: 1, name: 'Vikram Rajput', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150', location: 'Jaipur', tier: 'Grandmaster', coinsWon: 48500, winStreak: 9, winRate: '82%' },
    { rank: 2, name: 'Ananya Roy', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', location: 'Kolkata', tier: 'Diamond', coinsWon: 36200, winStreak: 6, winRate: '75%' },
    { rank: 3, name: 'Aarav Sharma', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', location: 'Mumbai', tier: 'Master', coinsWon: 29800, winStreak: 5, winRate: '71%' },
    { rank: 4, name: 'Priya Patel', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', location: 'Ahmedabad', tier: 'Diamond', coinsWon: 24500, winStreak: 4, winRate: '68%' },
    { rank: 5, name: 'Rohan Verma', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', location: 'Delhi', tier: 'Gold', coinsWon: 19400, winStreak: 3, winRate: '64%' },
    { rank: 6, name: 'Neha Joshi', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', location: 'Pune', tier: 'Diamond', coinsWon: 17800, winStreak: 4, winRate: '67%' },
    { rank: 7, name: 'Kabir Mehta', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', location: 'Bengaluru', tier: 'Platinum', coinsWon: 15200, winStreak: 2, winRate: '61%' },
    { rank: 8, name: 'Sneha Rao', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150', location: 'Hyderabad', tier: 'Gold', coinsWon: 13900, winStreak: 3, winRate: '59%' },
    { rank: 14, name: 'Rahul Sharma (You)', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', location: 'Delhi', tier: 'Master', coinsWon: 8450, winStreak: 4, winRate: '66%', isUser: true },
  ],
  weekly: [
    { rank: 1, name: 'Aarav Sharma', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', location: 'Mumbai', tier: 'Grandmaster', coinsWon: 184500, winStreak: 12, winRate: '84%' },
    { rank: 2, name: 'Vikram Rajput', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150', location: 'Jaipur', tier: 'Grandmaster', coinsWon: 162000, winStreak: 11, winRate: '80%' },
    { rank: 3, name: 'Neha Joshi', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', location: 'Pune', tier: 'Diamond', coinsWon: 138000, winStreak: 8, winRate: '76%' },
    { rank: 4, name: 'Ananya Roy', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', location: 'Kolkata', tier: 'Diamond', coinsWon: 115000, winStreak: 7, winRate: '73%' },
    { rank: 5, name: 'Priya Patel', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', location: 'Ahmedabad', tier: 'Platinum', coinsWon: 98000, winStreak: 5, winRate: '69%' },
    { rank: 18, name: 'Rahul Sharma (You)', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', location: 'Delhi', tier: 'Master', coinsWon: 42500, winStreak: 4, winRate: '66%', isUser: true },
  ],
  allTime: [
    { rank: 1, name: 'Grandmaster Karan', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150', location: 'Chandigarh', tier: 'Grandmaster', coinsWon: 1250000, winStreak: 21, winRate: '89%' },
    { rank: 2, name: 'Aarav Sharma', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', location: 'Mumbai', tier: 'Grandmaster', coinsWon: 980000, winStreak: 18, winRate: '86%' },
    { rank: 3, name: 'Vikram Rajput', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', location: 'Jaipur', tier: 'Grandmaster', coinsWon: 840000, winStreak: 15, winRate: '81%' },
    { rank: 4, name: 'Pooja Hegde', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', location: 'Bengaluru', tier: 'Diamond', coinsWon: 720000, winStreak: 14, winRate: '79%' },
    { rank: 24, name: 'Rahul Sharma (You)', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', location: 'Delhi', tier: 'Master', coinsWon: 184500, winStreak: 4, winRate: '66%', isUser: true },
  ],
};

export default function LeaderboardModal({ onClose, onSelectGame }: LeaderboardModalProps) {
  const [timeframe, setTimeframe] = useState<Timeframe>('daily');
  const [gameFilter, setGameFilter] = useState<GameFilter>('all');

  const list = LEADERBOARD_DATA[timeframe];
  const top3 = list.slice(0, 3);
  const remaining = list.slice(3);
  const userEntry = list.find(e => e.isUser);

  const handleTimeframeChange = (t: Timeframe) => {
    audioEffectsService.playButtonTap();
    setTimeframe(t);
  };

  return (
    <div 
      id="leaderboard-modal-overlay" 
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="leaderboard-modal-sheet"
        className="w-full max-w-md h-[92vh] bg-[#070b14] border-t border-slate-800 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
                <Trophy className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-black text-white uppercase tracking-wider font-mono">
                  Gaming Leaderboards
                </h2>
                <span className="text-[10px] text-slate-400">
                  Daily Reset in 04h 32m • 100% Virtual Coins
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-full text-amber-400 text-[10px] font-bold">
            <Sparkles className="w-3 h-3" />
            <span>Top 10 Win Coins</span>
          </div>
        </div>

        {/* Timeframe Filter Tabs */}
        <div className="px-4 pt-3 pb-2 bg-slate-950/40 flex gap-2">
          {[
            { id: 'daily' as Timeframe, label: 'Daily Cup 🏆' },
            { id: 'weekly' as Timeframe, label: 'Weekly Series ⭐' },
            { id: 'allTime' as Timeframe, label: 'Hall of Fame 👑' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTimeframeChange(tab.id)}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
                timeframe === tab.id
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-md'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Game Filter Chips */}
        <div className="px-4 py-2 border-b border-slate-800/80 flex gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'All 4 Games' },
            { id: 'call-break', label: '♠️ Call Break' },
            { id: 'teen-patti', label: '🎴 Teen Patti' },
            { id: 'ludo', label: '🎲 Ludo' },
            { id: 'rummy', label: '🃏 Rummy' },
          ].map((g) => (
            <button
              key={g.id}
              onClick={() => {
                audioEffectsService.playButtonTap();
                setGameFilter(g.id as GameFilter);
              }}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-bold whitespace-nowrap transition-all ${
                gameFilter === g.id
                  ? 'bg-purple-600/30 text-purple-300 border border-purple-500/50'
                  : 'bg-slate-900/80 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              {g.label}
            </button>
          ))}
        </div>

        {/* Scrollable Leaderboard Area */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
          {/* Top 3 Podium Cards */}
          <div className="grid grid-cols-3 gap-2 pt-4 items-end">
            {/* 2nd Place */}
            {top3[1] && (
              <div className="p-2.5 rounded-2xl bg-gradient-to-b from-slate-800/70 to-slate-900/90 border border-slate-700/80 flex flex-col items-center text-center relative h-36 justify-between">
                <span className="absolute -top-3 px-2 py-0.5 rounded-full bg-slate-300 text-slate-950 text-[10px] font-black border border-white">
                  #2 Silver
                </span>
                <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-slate-300 mt-1 shadow-md">
                  <img src={top3[1].avatar} alt={top3[1].name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className="text-xs font-black text-white block line-clamp-1">{top3[1].name.split(' ')[0]}</span>
                  <span className="text-[10px] text-amber-300 font-mono font-bold">{top3[1].coinsWon.toLocaleString()}</span>
                </div>
                <span className="text-[9px] text-slate-400 bg-slate-800/80 px-1.5 py-0.5 rounded">{top3[1].winRate} Win</span>
              </div>
            )}

            {/* 1st Place (Winner) */}
            {top3[0] && (
              <div className="p-2.5 rounded-2xl bg-gradient-to-b from-amber-500/30 via-amber-950/40 to-slate-900 border-2 border-amber-400 flex flex-col items-center text-center relative h-42 justify-between shadow-xl shadow-amber-500/20 -translate-y-2">
                <div className="absolute -top-3.5 flex items-center gap-0.5 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 text-[10px] font-black shadow-md">
                  <Crown className="w-3 h-3 fill-slate-950" />
                  <span>#1 Champion</span>
                </div>
                <div className="w-14 h-14 rounded-full overflow-hidden border-2 border-amber-400 mt-2 shadow-lg ring-2 ring-amber-400/50">
                  <img src={top3[0].avatar} alt={top3[0].name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className="text-xs font-black text-amber-200 block line-clamp-1">{top3[0].name.split(' ')[0]}</span>
                  <span className="text-xs text-amber-300 font-mono font-black">{top3[0].coinsWon.toLocaleString()} 🪙</span>
                </div>
                <div className="flex items-center gap-1 text-[9px] text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full font-bold">
                  <Flame className="w-2.5 h-2.5 fill-amber-400" />
                  <span>{top3[0].winStreak} Streak</span>
                </div>
              </div>
            )}

            {/* 3rd Place */}
            {top3[2] && (
              <div className="p-2.5 rounded-2xl bg-gradient-to-b from-amber-900/30 to-slate-900/90 border border-amber-700/60 flex flex-col items-center text-center relative h-34 justify-between">
                <span className="absolute -top-3 px-2 py-0.5 rounded-full bg-amber-700 text-amber-100 text-[10px] font-black border border-amber-600">
                  #3 Bronze
                </span>
                <div className="w-11 h-11 rounded-full overflow-hidden border-2 border-amber-600 mt-1 shadow-md">
                  <img src={top3[2].avatar} alt={top3[2].name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className="text-xs font-black text-white block line-clamp-1">{top3[2].name.split(' ')[0]}</span>
                  <span className="text-[10px] text-amber-300 font-mono font-bold">{top3[2].coinsWon.toLocaleString()}</span>
                </div>
                <span className="text-[9px] text-slate-400 bg-slate-800/80 px-1.5 py-0.5 rounded">{top3[2].winRate} Win</span>
              </div>
            )}
          </div>

          {/* Ranks 4+ List */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Top Ranked Players
            </h3>

            {remaining.map((entry) => (
              <div
                key={entry.rank}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all ${
                  entry.isUser
                    ? 'bg-amber-500/15 border-amber-500/50 shadow-md'
                    : 'bg-slate-900/80 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="w-6 text-center text-xs font-black text-slate-400 font-mono">
                    #{entry.rank}
                  </span>
                  <div className="w-9 h-9 rounded-full overflow-hidden border border-slate-700">
                    <img src={entry.avatar} alt={entry.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white leading-none">
                        {entry.name}
                      </span>
                      {entry.isUser && (
                        <span className="px-1.5 py-0.2 rounded bg-amber-500 text-slate-950 text-[9px] font-black">
                          YOU
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                      <span>{entry.location}</span> • <span className="text-purple-300">{entry.tier}</span>
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-mono font-black text-amber-300 block">
                    +{entry.coinsWon.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-emerald-400 font-bold">
                    {entry.winRate} Win Rate
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sticky User Rank Footer */}
        {userEntry && (
          <div className="p-3 bg-slate-950 border-t border-amber-500/30 flex items-center justify-between shadow-2xl">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400 font-black text-xs font-mono">
                #{userEntry.rank}
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block leading-none">
                  Your Current Standings
                </span>
                <span className="text-xs font-black text-white mt-0.5 block">
                  {userEntry.tier} Tier • {userEntry.winStreak} Streak
                </span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">Coins Earned</span>
              <span className="text-xs font-mono font-black text-amber-300">
                {userEntry.coinsWon.toLocaleString()} COINS
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
