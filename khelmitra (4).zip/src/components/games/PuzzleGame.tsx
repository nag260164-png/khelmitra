import { useState } from 'react';
import { 
  ArrowLeft, Sparkles, Award, RotateCcw, ChevronRight, 
  HelpCircle, CheckCircle2, ShieldCheck, Gamepad2, Lightbulb
} from 'lucide-react';
import { PUZZLE_LEVELS } from '../../data/gamesData';
import { demoPointsService } from '../../services/demoPointsService';
import { dailyMissionService } from '../../services/dailyMissionService';

interface PuzzleGameProps {
  onBack: () => void;
}

export default function PuzzleGame({ onBack }: PuzzleGameProps) {
  const [levelIndex, setLevelIndex] = useState(0);
  const [currentGuess, setCurrentGuess] = useState<string[]>([]);
  const [availableLetters, setAvailableLetters] = useState<string[]>(() => 
    PUZZLE_LEVELS[0].scrambledWord.split('')
  );
  const [showHint, setShowHint] = useState(false);
  const [isLevelSolved, setIsLevelSolved] = useState(false);
  const [solvedLevelsCount, setSolvedLevelsCount] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [totalPointsEarned, setTotalPointsEarned] = useState(0);

  const level = PUZZLE_LEVELS[levelIndex];

  const handlePickLetter = (letter: string, index: number) => {
    if (isLevelSolved) return;

    const newGuess = [...currentGuess, letter];
    setCurrentGuess(newGuess);

    const newAvailable = [...availableLetters];
    newAvailable.splice(index, 1);
    setAvailableLetters(newAvailable);

    // Check if word is complete
    if (newGuess.length === level.originalWord.length) {
      if (newGuess.join('') === level.originalWord) {
        setIsLevelSolved(true);
        setSolvedLevelsCount((prev) => prev + 1);
      }
    }
  };

  const handleRemoveLetter = (index: number) => {
    if (isLevelSolved) return;

    const removedLetter = currentGuess[index];
    const newGuess = [...currentGuess];
    newGuess.splice(index, 1);
    setCurrentGuess(newGuess);

    setAvailableLetters([...availableLetters, removedLetter]);
  };

  const handleResetCurrentLevel = () => {
    setCurrentGuess([]);
    setAvailableLetters(level.scrambledWord.split(''));
    setIsLevelSolved(false);
  };

  const handleNextLevel = () => {
    if (levelIndex < PUZZLE_LEVELS.length - 1) {
      const nextIndex = levelIndex + 1;
      setLevelIndex(nextIndex);
      setCurrentGuess([]);
      setAvailableLetters(PUZZLE_LEVELS[nextIndex].scrambledWord.split(''));
      setShowHint(false);
      setIsLevelSolved(false);
    } else {
      // Puzzle completed!
      const earned = (solvedLevelsCount + 1) * 40; // 200 demo points for 5 levels
      setTotalPointsEarned(earned);
      demoPointsService.addPoints(earned, 'Cricket Logic Puzzle', `Completed ${solvedLevelsCount + 1}/5 Cricket Word Logic Puzzles`);
      dailyMissionService.incrementProgress('mission-puzzle-match', 1);
      setIsFinished(true);
    }
  };

  const handleRestart = () => {
    setLevelIndex(0);
    setCurrentGuess([]);
    setAvailableLetters(PUZZLE_LEVELS[0].scrambledWord.split(''));
    setShowHint(false);
    setIsLevelSolved(false);
    setSolvedLevelsCount(0);
    setIsFinished(false);
    setTotalPointsEarned(0);
  };

  return (
    <div className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-hidden">
      {/* Top Bar Navigation */}
      <div className="px-4 py-3 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 active:scale-95 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Games</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold flex items-center gap-1">
            <Gamepad2 className="w-3 h-3" />
            Cricket Puzzle
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-amber-400 font-mono font-bold">
            Free Demo
          </span>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {!isFinished ? (
          <>
            {/* Header Status Row */}
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">
                  Level {levelIndex + 1} of {PUZZLE_LEVELS.length}
                </span>
                <span className="text-xs font-bold text-emerald-400">
                  {level.category}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowHint(!showHint)}
                  className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 text-amber-400 text-xs font-bold flex items-center gap-1 active:scale-95"
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  <span>{showHint ? 'Hide Hint' : 'Get Hint'}</span>
                </button>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800/80">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full transition-all duration-300"
                style={{ width: `${((levelIndex + 1) / PUZZLE_LEVELS.length) * 100}%` }}
              ></div>
            </div>

            {/* Puzzle Clue Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0a1815] via-[#071310] to-[#040907] border border-emerald-900/40 shadow-xl space-y-2">
              <span className="text-[10px] font-mono font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 inline-block">
                Cricket Clue
              </span>
              <p className="text-sm font-semibold text-slate-200 leading-relaxed">
                &ldquo;{level.clue}&rdquo;
              </p>

              {showHint && (
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2 mt-2 animate-in fade-in">
                  <Lightbulb className="w-4 h-4 text-amber-400 shrink-0" />
                  <span><strong>Hint:</strong> {level.hint}</span>
                </div>
              )}
            </div>

            {/* Word Slots (Answer Input Area) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Tap tiles to solve ({level.originalWord.length} letters):</span>
                {currentGuess.length > 0 && !isLevelSolved && (
                  <button
                    onClick={handleResetCurrentLevel}
                    className="text-[11px] text-red-400 hover:text-red-300 font-bold"
                  >
                    Reset Letters
                  </button>
                )}
              </div>

              {/* Solved / Current Guess Slots */}
              <div className="flex justify-center gap-2 flex-wrap py-3 min-h-[58px] bg-slate-950/60 rounded-2xl border border-slate-800/80 p-2">
                {Array.from({ length: level.originalWord.length }).map((_, idx) => {
                  const letter = currentGuess[idx];
                  return (
                    <button
                      key={idx}
                      onClick={() => letter && handleRemoveLetter(idx)}
                      disabled={isLevelSolved || !letter}
                      className={`w-11 h-12 rounded-xl text-lg font-mono font-black flex items-center justify-center transition-all ${
                        isLevelSolved
                          ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 scale-105'
                          : letter
                          ? 'bg-slate-800 text-white border-2 border-emerald-500/80 shadow-md cursor-pointer hover:bg-slate-700 active:scale-95'
                          : 'bg-slate-900/50 border border-dashed border-slate-700 text-slate-600'
                      }`}
                    >
                      {letter || ''}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Available Letters Rack */}
            {!isLevelSolved && (
              <div className="space-y-2">
                <span className="text-xs text-slate-400 block text-center">Available Letter Tiles:</span>
                <div className="flex justify-center gap-2 flex-wrap">
                  {availableLetters.map((letter, idx) => (
                    <button
                      key={idx}
                      onClick={() => handlePickLetter(letter, idx)}
                      className="w-11 h-12 rounded-xl bg-gradient-to-b from-slate-800 to-slate-900 border border-slate-700 text-amber-300 hover:text-white hover:border-amber-400 text-lg font-mono font-black shadow-md flex items-center justify-center active:scale-90 transition-all"
                    >
                      {letter}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Level Solved Celebration */}
            {isLevelSolved && (
              <div className="p-4 rounded-2xl bg-emerald-950/70 border border-emerald-500/50 text-center space-y-3 animate-in zoom-in-95">
                <div className="flex items-center justify-center gap-2 text-emerald-400 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Correct! You solved &ldquo;{level.originalWord}&rdquo;</span>
                </div>
                <p className="text-xs text-slate-300">
                  +40 Demo Points for this level!
                </p>

                <button
                  onClick={handleNextLevel}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
                >
                  <span>
                    {levelIndex < PUZZLE_LEVELS.length - 1 ? 'Next Puzzle Level' : 'Complete Challenge'}
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        ) : (
          /* Finished Screen */
          <div className="p-6 rounded-3xl bg-gradient-to-br from-[#0a1a15] via-[#07130f] to-[#040907] border border-emerald-500/30 text-center space-y-5 my-2 shadow-2xl animate-in zoom-in-95">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-500/20">
              <Award className="w-9 h-9 text-amber-400" />
            </div>

            <div>
              <span className="text-[10px] text-emerald-400 font-mono font-bold uppercase tracking-wider block">
                Puzzle Champion
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                All 5 Cricket Word Puzzles Solved! 🧩
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                You unscrambled every cricket legend, delivery, and match concept!
              </p>
            </div>

            {/* Points Award Card */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-2">
              <span className="text-[11px] text-slate-400 font-mono">Demo Points Credited</span>
              <div className="flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400 animate-bounce" />
                <span className="text-2xl font-black font-mono text-amber-400">
                  +{totalPointsEarned} Demo Pts
                </span>
              </div>
              <span className="text-[10px] text-emerald-400 block font-medium">
                ✓ Added to your shared KhelMitra demo balance
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                onClick={handleRestart}
                className="flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Play Again</span>
              </button>

              <button
                onClick={onBack}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
              >
                <span>All Games</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Free Demo Notice */}
            <div className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-900 text-[10px] text-slate-500 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>100% Free Demo Puzzle • No Real Money or Gambling</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
