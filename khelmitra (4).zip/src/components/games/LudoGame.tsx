import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, RotateCcw, HelpCircle, Trophy, Sparkles, 
  ShieldCheck, Dices, Crown, Users, Zap 
} from 'lucide-react';
import { demoPointsService } from '../../services/demoPointsService';
import { audioEffectsService } from '../../services/audioEffectsService';
import MultiplayerRoomBar from './MultiplayerRoomBar';

interface LudoGameProps {
  onBack: () => void;
}

type LudoColor = 'red' | 'green' | 'yellow' | 'blue';

interface Token {
  id: string;
  color: LudoColor;
  stepIndex: number; // -1: in base, 0-50: on track, 51-56: home path, 57: finished
}

interface LudoPlayer {
  id: string;
  name: string;
  color: LudoColor;
  isHuman: boolean;
  avatar: string;
  tokens: Token[];
  hasWon: boolean;
}

// 52 common track steps mapped to standard Ludo coordinates
// Starting positions on 52 track: Red: 0, Green: 13, Yellow: 26, Blue: 39
const START_OFFSETS: Record<LudoColor, number> = {
  red: 0,
  green: 13,
  yellow: 26,
  blue: 39,
};

const SAFE_STEPS = [0, 8, 13, 21, 26, 34, 39, 47];

const COLOR_CLASSES: Record<LudoColor, { bg: string; text: string; border: string; ring: string }> = {
  red: { bg: 'bg-red-500', text: 'text-red-400', border: 'border-red-400', ring: 'ring-red-500' },
  green: { bg: 'bg-emerald-500', text: 'text-emerald-400', border: 'border-emerald-400', ring: 'ring-emerald-500' },
  yellow: { bg: 'bg-amber-400', text: 'text-amber-400', border: 'border-amber-400', ring: 'ring-amber-400' },
  blue: { bg: 'bg-blue-500', text: 'text-blue-400', border: 'border-blue-400', ring: 'ring-blue-500' },
};

export default function LudoGame({ onBack }: LudoGameProps) {
  const [playerMode, setPlayerMode] = useState<2 | 4>(2);
  const [diceValue, setDiceValue] = useState<number>(6);
  const [isRolling, setIsRolling] = useState(false);
  const [currentTurn, setCurrentTurn] = useState<number>(0); // index in activePlayers
  const [hasRolled, setHasRolled] = useState(false);
  const [winner, setWinner] = useState<LudoPlayer | null>(null);
  const [showRules, setShowRules] = useState(false);
  const [coinsBalance, setCoinsBalance] = useState(demoPointsService.getPoints());
  const [message, setMessage] = useState<string>('Roll the dice to start!');

  useEffect(() => {
    const unsub = demoPointsService.subscribe(setCoinsBalance);
    return () => unsub();
  }, []);

  const initializePlayers = (mode: 2 | 4): LudoPlayer[] => {
    const p1: LudoPlayer = {
      id: 'lp-red',
      name: 'You (Red)',
      color: 'red',
      isHuman: true,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      tokens: [
        { id: 'red-0', color: 'red', stepIndex: -1 },
        { id: 'red-1', color: 'red', stepIndex: -1 },
        { id: 'red-2', color: 'red', stepIndex: -1 },
        { id: 'red-3', color: 'red', stepIndex: -1 },
      ],
      hasWon: false,
    };

    const p2: LudoPlayer = {
      id: 'lp-yellow',
      name: 'Rohan (Yellow)',
      color: 'yellow',
      isHuman: false,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80',
      tokens: [
        { id: 'yellow-0', color: 'yellow', stepIndex: -1 },
        { id: 'yellow-1', color: 'yellow', stepIndex: -1 },
        { id: 'yellow-2', color: 'yellow', stepIndex: -1 },
        { id: 'yellow-3', color: 'yellow', stepIndex: -1 },
      ],
      hasWon: false,
    };

    if (mode === 2) {
      return [p1, p2];
    }

    const p3: LudoPlayer = {
      id: 'lp-green',
      name: 'Kabir (Green)',
      color: 'green',
      isHuman: false,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      tokens: [
        { id: 'green-0', color: 'green', stepIndex: -1 },
        { id: 'green-1', color: 'green', stepIndex: -1 },
        { id: 'green-2', color: 'green', stepIndex: -1 },
        { id: 'green-3', color: 'green', stepIndex: -1 },
      ],
      hasWon: false,
    };

    const p4: LudoPlayer = {
      id: 'lp-blue',
      name: 'Ananya (Blue)',
      color: 'blue',
      isHuman: false,
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
      tokens: [
        { id: 'blue-0', color: 'blue', stepIndex: -1 },
        { id: 'blue-1', color: 'blue', stepIndex: -1 },
        { id: 'blue-2', color: 'blue', stepIndex: -1 },
        { id: 'blue-3', color: 'blue', stepIndex: -1 },
      ],
      hasWon: false,
    };

    return [p1, p3, p2, p4];
  };

  const [players, setPlayers] = useState<LudoPlayer[]>(() => initializePlayers(2));
  const [isMultiplayer, setIsMultiplayer] = useState(false);

  const handleRestart = (mode: 2 | 4 = playerMode) => {
    setPlayerMode(mode);
    setPlayers(initializePlayers(mode));
    setCurrentTurn(0);
    setDiceValue(6);
    setHasRolled(false);
    setIsRolling(false);
    setWinner(null);
    setMessage('Roll the dice to start!');
  };

  const activePlayer = players[currentTurn] || players[0];

  // Roll dice action
  const rollDice = () => {
    if (isRolling || hasRolled) return;
    setIsRolling(true);
    audioEffectsService.playDiceRoll();

    let rollCount = 0;
    const interval = setInterval(() => {
      setDiceValue(Math.floor(Math.random() * 6) + 1);
      rollCount++;
      if (rollCount > 8) {
        clearInterval(interval);
        const finalValue = Math.floor(Math.random() * 6) + 1;
        setDiceValue(finalValue);
        setIsRolling(false);
        setHasRolled(true);
        handlePostRoll(finalValue, activePlayer);
      }
    }, 60);
  };

  // Check valid moves after roll
  const getMovableTokens = (player: LudoPlayer, roll: number): Token[] => {
    return player.tokens.filter(t => {
      if (t.stepIndex === 57) return false; // Already finished in home
      if (t.stepIndex === -1) {
        return roll === 6; // Needs 6 to unlock from base
      }
      return t.stepIndex + roll <= 57; // Cannot overshoot 57
    });
  };

  const handlePostRoll = (roll: number, player: LudoPlayer) => {
    const movable = getMovableTokens(player, roll);

    if (movable.length === 0) {
      setMessage(`${player.name} rolled ${roll} - No valid moves!`);
      setTimeout(() => {
        advanceTurn(roll === 6);
      }, 900);
      return;
    }

    if (player.isHuman) {
      setMessage(`You rolled ${roll}! Tap a token to move.`);
      // If only one token is movable, auto move it for convenience
      if (movable.length === 1) {
        setTimeout(() => moveToken(movable[0], roll), 400);
      }
    } else {
      // Bot chooses optimal token to move
      setTimeout(() => {
        const chosen = movable.find(t => t.stepIndex >= 0) || movable[0];
        moveToken(chosen, roll);
      }, 700);
    }
  };

  // Move token
  const moveToken = (token: Token, steps: number) => {
    setPlayers(prev => {
      let extraTurn = steps === 6;
      let targetPlayer = prev[currentTurn];

      const updatedTokens = targetPlayer.tokens.map(t => {
        if (t.id !== token.id) return t;
        if (t.stepIndex === -1) {
          // Unlocking to start
          return { ...t, stepIndex: 0 };
        }
        return { ...t, stepIndex: Math.min(57, t.stepIndex + steps) };
      });

      // Check for capture if landing on track
      const movedToken = updatedTokens.find(t => t.id === token.id)!;
      let capturedOpponent = false;

      const updatedAllPlayers = prev.map((p, pIdx) => {
        if (pIdx === currentTurn) {
          return { ...p, tokens: updatedTokens };
        }
        // Check if any opponent token was captured
        const newOppTokens = p.tokens.map(oppToken => {
          if (
            oppToken.stepIndex >= 0 &&
            oppToken.stepIndex < 51 &&
            movedToken.stepIndex >= 0 &&
            movedToken.stepIndex < 51
          ) {
            // Absolute position check
            const movedAbs = (START_OFFSETS[targetPlayer.color] + movedToken.stepIndex) % 52;
            const oppAbs = (START_OFFSETS[p.color] + oppToken.stepIndex) % 52;

            if (movedAbs === oppAbs && !SAFE_STEPS.includes(movedAbs)) {
              capturedOpponent = true;
              extraTurn = true; // Award extra turn for capture!
              return { ...oppToken, stepIndex: -1 }; // Send back to base
            }
          }
          return oppToken;
        });

        return { ...p, tokens: newOppTokens };
      });

      // Check win condition
      const finishedCount = updatedTokens.filter(t => t.stepIndex === 57).length;
      if (finishedCount === 4) {
        triggerWinner(targetPlayer);
      } else {
        setTimeout(() => {
          advanceTurn(extraTurn);
        }, 600);
      }

      return updatedAllPlayers;
    });
  };

  const advanceTurn = (extraTurn: boolean) => {
    setHasRolled(false);
    if (extraTurn) {
      setMessage(`${activePlayer.name} rolled a 6 / captured! Free extra turn.`);
      return;
    }

    const nextTurn = (currentTurn + 1) % players.length;
    setCurrentTurn(nextTurn);
    setMessage(`${players[nextTurn].name}'s turn to roll.`);
  };

  // Bot Turn Effect
  useEffect(() => {
    if (winner) return;
    if (activePlayer.isHuman) return;
    if (hasRolled || isRolling) return;

    const botRollTimer = setTimeout(() => {
      rollDice();
    }, 900);

    return () => clearTimeout(botRollTimer);
  }, [currentTurn, hasRolled, isRolling, winner]);

  const triggerWinner = (winningPlayer: LudoPlayer) => {
    setWinner(winningPlayer);
    if (winningPlayer.isHuman) {
      const rewardCoins = playerMode === 2 ? 300 : 600;
      demoPointsService.addPoints(rewardCoins, 'Ludo Champion', 'First place in Ludo tournament');
      demoPointsService.recordMatch({
        gameName: 'Ludo',
        gameKey: 'ludo',
        result: 'WON',
        coinsWon: rewardCoins,
        coinsSpent: 0,
        details: `${playerMode}-Player Ludo Match • All 4 Tokens in Home!`,
      });
    } else {
      demoPointsService.recordMatch({
        gameName: 'Ludo',
        gameKey: 'ludo',
        result: 'LOST',
        coinsWon: 0,
        coinsSpent: 0,
        details: `Winner: ${winningPlayer.name}`,
      });
    }
  };

  const movableTokens = hasRolled ? getMovableTokens(activePlayer, diceValue) : [];

  return (
    <div id="ludo-game-screen" className="flex flex-col h-full bg-[#040810] text-slate-100 overflow-hidden select-none">
      {/* Top Header */}
      <div className="px-4 py-2 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black tracking-wider text-amber-400 uppercase font-mono">🎲 Khel Ludo</span>
              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                {playerMode} Players
              </span>
            </div>
            <span className="text-[10px] text-slate-400">Classic Board Game • Safe Stars & Home Track</span>
          </div>
        </div>

        {/* Right Header Coins & Mode Selector */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold font-mono">
            <span>🪙</span>
            <span>{coinsBalance.toLocaleString()}</span>
          </div>
          <div className="flex rounded-lg bg-slate-900 p-0.5 border border-slate-800 text-xs font-bold">
            <button
              onClick={() => handleRestart(2)}
              className={`px-2 py-0.5 rounded ${playerMode === 2 ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
            >
              2P
            </button>
            <button
              onClick={() => handleRestart(4)}
              className={`px-2 py-0.5 rounded ${playerMode === 4 ? 'bg-amber-500 text-slate-950' : 'text-slate-400'}`}
            >
              4P
            </button>
          </div>
        </div>
      </div>

      {/* Multiplayer & AI Tactical Bar */}
      <MultiplayerRoomBar
        gameId="ludo"
        gameTitle="Khel Ludo Classic"
        isMultiplayer={isMultiplayer}
        onToggleMode={setIsMultiplayer}
      />

      {/* Main Ludo Arena */}
      <div className="flex-1 p-3 flex flex-col justify-between items-center overflow-y-auto">
        {/* Status Prompt */}
        <div className="w-full max-w-sm px-3 py-1.5 rounded-xl bg-slate-950/90 border border-slate-800 text-center text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`w-3 h-3 rounded-full ${COLOR_CLASSES[activePlayer.color].bg} animate-ping`}></span>
            <span className="font-bold text-white">{activePlayer.name}</span>
          </div>
          <span className="text-[11px] text-amber-300 font-medium">{message}</span>
        </div>

        {/* Realistic Ludo Board Canvas Layout */}
        <div className="relative w-76 h-76 max-w-full aspect-square my-auto bg-slate-950 rounded-2xl border-4 border-slate-800 shadow-2xl p-2 grid grid-cols-15 grid-rows-15 gap-0.5 select-none">
          {/* Top-Left: Red Base */}
          <div className="col-span-6 row-span-6 bg-red-600/30 border-2 border-red-500 rounded-xl p-2 flex flex-col justify-between">
            <span className="text-[9px] font-black text-red-300 uppercase">Red Yard</span>
            <div className="grid grid-cols-2 gap-2 my-auto">
              {players[0].tokens.map((t, idx) => (
                <button
                  key={t.id}
                  disabled={!hasRolled || !activePlayer.isHuman || !movableTokens.some(m => m.id === t.id)}
                  onClick={() => moveToken(t, diceValue)}
                  className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shadow-lg transition-transform ${
                    t.stepIndex === -1 ? 'bg-red-500 text-white border-2 border-white' : 'bg-red-950/60 text-red-400/40'
                  } ${movableTokens.some(m => m.id === t.id) ? 'ring-4 ring-amber-400 animate-bounce scale-110' : ''}`}
                >
                  {t.stepIndex === -1 ? idx + 1 : '✓'}
                </button>
              ))}
            </div>
          </div>

          {/* Top-Middle: Green Path Tracks */}
          <div className="col-span-3 row-span-6 grid grid-cols-3 grid-rows-6 gap-0.5">
            {Array.from({ length: 18 }).map((_, i) => (
              <div
                key={i}
                className={`rounded-[3px] border border-slate-800 flex items-center justify-center text-[8px] ${
                  i % 3 === 1 ? 'bg-emerald-600/40 text-emerald-300 font-bold' : 'bg-slate-900/60'
                }`}
              >
                {i === 4 ? '⭐' : ''}
              </div>
            ))}
          </div>

          {/* Top-Right: Green Base */}
          <div className="col-span-6 row-span-6 bg-emerald-600/30 border-2 border-emerald-500 rounded-xl p-2 flex flex-col justify-between">
            <span className="text-[9px] font-black text-emerald-300 uppercase">Green Yard</span>
            <div className="grid grid-cols-2 gap-2 my-auto">
              {(players.find(p => p.color === 'green')?.tokens || []).map((t, idx) => (
                <div
                  key={t.id}
                  className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shadow ${
                    t.stepIndex === -1 ? 'bg-emerald-500 text-white border-2 border-white' : 'bg-emerald-950/60'
                  }`}
                >
                  {t.stepIndex === -1 ? idx + 1 : '✓'}
                </div>
              ))}
            </div>
          </div>

          {/* Center Winning Home Triangle */}
          <div className="col-start-7 col-span-3 row-start-7 row-span-3 bg-slate-900 border-2 border-amber-500 rounded-lg flex items-center justify-center relative overflow-hidden shadow-inner">
            <div className="text-center">
              <Crown className="w-5 h-5 text-amber-400 mx-auto" />
              <span className="text-[8px] font-black text-amber-400 uppercase tracking-widest">HOME</span>
            </div>
          </div>

          {/* Bottom-Left: Blue Base */}
          <div className="col-span-6 row-span-6 col-start-1 row-start-10 bg-blue-600/30 border-2 border-blue-500 rounded-xl p-2 flex flex-col justify-between">
            <span className="text-[9px] font-black text-blue-300 uppercase">Blue Yard</span>
            <div className="grid grid-cols-2 gap-2 my-auto">
              {(players.find(p => p.color === 'blue')?.tokens || []).map((t, idx) => (
                <div
                  key={t.id}
                  className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shadow ${
                    t.stepIndex === -1 ? 'bg-blue-500 text-white border-2 border-white' : 'bg-blue-950/60'
                  }`}
                >
                  {t.stepIndex === -1 ? idx + 1 : '✓'}
                </div>
              ))}
            </div>
          </div>

          {/* Bottom-Right: Yellow Base */}
          <div className="col-span-6 row-span-6 col-start-10 row-start-10 bg-amber-600/30 border-2 border-amber-500 rounded-xl p-2 flex flex-col justify-between">
            <span className="text-[9px] font-black text-amber-300 uppercase">Yellow Yard</span>
            <div className="grid grid-cols-2 gap-2 my-auto">
              {(players.find(p => p.color === 'yellow')?.tokens || []).map((t, idx) => (
                <div
                  key={t.id}
                  className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shadow ${
                    t.stepIndex === -1 ? 'bg-amber-400 text-slate-950 border-2 border-white' : 'bg-amber-950/60'
                  }`}
                >
                  {t.stepIndex === -1 ? idx + 1 : '✓'}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Interactive Dice Roller & Player Tokens Bar */}
        <div className="w-full max-w-sm bg-slate-950/95 border border-slate-800 rounded-2xl p-3 flex items-center justify-between shadow-2xl">
          {/* Player Active Token Quick-Selection */}
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 mb-1">Your Tokens Status:</span>
            <div className="flex gap-1.5">
              {players[0].tokens.map((t, i) => {
                const canMove = hasRolled && activePlayer.isHuman && movableTokens.some(m => m.id === t.id);
                return (
                  <button
                    key={t.id}
                    disabled={!canMove}
                    onClick={() => moveToken(t, diceValue)}
                    className={`px-2 py-1 rounded-lg text-xs font-bold transition-all border ${
                      canMove 
                        ? 'bg-red-500 text-white border-amber-400 ring-2 ring-amber-400 animate-pulse active:scale-95' 
                        : 'bg-slate-900 text-slate-400 border-slate-800'
                    }`}
                  >
                    T{i + 1}: {t.stepIndex === -1 ? 'Base' : t.stepIndex === 57 ? 'Home' : `${t.stepIndex}/57`}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dice Box */}
          <div className="flex flex-col items-center">
            <button
              disabled={!activePlayer.isHuman || isRolling || hasRolled}
              onClick={rollDice}
              className={`w-14 h-14 rounded-2xl bg-gradient-to-br from-white to-slate-200 border-2 border-amber-400 shadow-xl flex items-center justify-center font-black text-2xl text-slate-950 active:scale-90 transition-transform ${
                isRolling ? 'animate-spin' : ''
              } ${activePlayer.isHuman && !hasRolled ? 'ring-4 ring-amber-400/50 cursor-pointer animate-pulse' : 'cursor-not-allowed opacity-90'}`}
            >
              {diceValue}
            </button>
            <span className="text-[10px] font-bold text-amber-400 mt-1">
              {activePlayer.isHuman && !hasRolled ? 'Tap to Roll' : 'Dice'}
            </span>
          </div>
        </div>
      </div>

      {/* Winner Modal */}
      {winner && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0a0f1d] border border-amber-500/40 rounded-3xl p-5 shadow-2xl text-center animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mx-auto mb-3 text-amber-400">
              <Trophy className="w-9 h-9 animate-bounce" />
            </div>
            <h3 className="text-xl font-black text-white">{winner.name} Wins!</h3>
            <p className="text-xs text-slate-400 mt-1">All 4 Tokens successfully entered the Home Triangle!</p>

            {winner.isHuman ? (
              <div className="my-4 p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-sm font-bold flex items-center justify-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Victory Prize: +{playerMode === 2 ? '300' : '600'} Virtual Coins!</span>
              </div>
            ) : (
              <div className="my-4 p-3 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 text-xs font-bold">
                Good game! Play another round to claim victory.
              </div>
            )}

            <div className="flex gap-2">
              <button
                onClick={() => handleRestart(playerMode)}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Play Again
              </button>
              <button
                onClick={onBack}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                Exit Game
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rules Modal */}
      {showRules && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowRules(false)}>
          <div className="w-full max-w-sm bg-[#0c1222] border border-slate-800 rounded-3xl p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Ludo Rules & Gameplay
              </h4>
              <button onClick={() => setShowRules(false)} className="text-xs text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="space-y-2 text-xs text-slate-300 leading-relaxed max-h-72 overflow-y-auto pr-1">
              <p>• <strong>Roll a 6 to Unlock</strong>: A roll of 6 releases a token from your base.</p>
              <p>• <strong>Extra Turn</strong>: Rolling a 6 or capturing an opponent's token gives an extra roll.</p>
              <p>• <strong>Safe Stars ⭐</strong>: Opponent tokens cannot be captured on safe star spots.</p>
              <p>• <strong>Capturing</strong>: Landing on an opponent's token sends it back to their base!</p>
              <p>• <strong>Winning</strong>: First player to guide all 4 tokens into Home wins the game.</p>
              <p>• <strong>Free to Play</strong>: 100% demo virtual coins gaming.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
