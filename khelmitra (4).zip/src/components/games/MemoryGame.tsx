import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Clock, Sparkles, Award, RotateCcw, 
  ChevronRight, ShieldCheck, Flame, Radio, Trophy, 
  Target, Shield, Zap, CheckCircle2, Star
} from 'lucide-react';
import { MEMORY_CARD_TYPES } from '../../data/gamesData';
import { demoPointsService } from '../../services/demoPointsService';

interface MemoryCard {
  id: string;
  type: string;
  name: string;
  iconName: string;
  color: string;
}

interface MemoryGameProps {
  onBack: () => void;
}

export default function MemoryGame({ onBack }: MemoryGameProps) {
  const [cards, setCards] = useState<MemoryCard[]>([]);
  const [flippedIds, setFlippedIds] = useState<string[]>([]);
  const [matchedTypes, setMatchedTypes] = useState<string[]>([]);
  const [turns, setTurns] = useState(0);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [isGameActive, setIsGameActive] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [pointsEarned, setPointsEarned] = useState(0);

  // Initialize and shuffle cards
  const initializeGame = () => {
    const deck: MemoryCard[] = [];
    MEMORY_CARD_TYPES.forEach((item, index) => {
      deck.push({
        ...item,
        id: `card-${item.type}-1-${index}`,
      });
      deck.push({
        ...item,
        id: `card-${item.type}-2-${index}`,
      });
    });

    // Fisher-Yates shuffle
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }

    setCards(deck);
    setFlippedIds([]);
    setMatchedTypes([]);
    setTurns(0);
    setTimerSeconds(0);
    setIsGameActive(true);
    setIsComplete(false);
    setPointsEarned(0);
  };

  useEffect(() => {
    initializeGame();
  }, []);

  // Timer interval
  useEffect(() => {
    if (!isGameActive || isComplete) return;

    const interval = setInterval(() => {
      setTimerSeconds((prev) => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [isGameActive, isComplete]);

  // Card click handler
  const handleCardClick = (card: MemoryCard) => {
    if (!isGameActive || isComplete) return;
    if (flippedIds.includes(card.id) || matchedTypes.includes(card.type)) return;
    if (flippedIds.length >= 2) return;

    const newFlipped = [...flippedIds, card.id];
    setFlippedIds(newFlipped);

    if (newFlipped.length === 2) {
      setTurns((prev) => prev + 1);
      const firstCard = cards.find((c) => c.id === newFlipped[0]);
      const secondCard = cards.find((c) => c.id === newFlipped[1]);

      if (firstCard && secondCard && firstCard.type === secondCard.type) {
        // Match!
        const newMatched = [...matchedTypes, firstCard.type];
        setMatchedTypes(newMatched);
        setFlippedIds([]);

        // Check if all 6 pairs matched
        if (newMatched.length === MEMORY_CARD_TYPES.length) {
          setIsComplete(true);
          setIsGameActive(false);

          // Calculate Demo Points: 180 base + turn efficiency bonus
          const bonus = turns <= 10 ? 50 : turns <= 14 ? 20 : 0;
          const total = 180 + bonus;
          setPointsEarned(total);
          demoPointsService.addPoints(total, 'Cricket Memory Match', `Matched all 6 cricket pairs in ${turns + 1} turns`);
        }
      } else {
        // No match - flip back after 800ms
        setTimeout(() => {
          setFlippedIds([]);
        }, 800);
      }
    }
  };

  const renderCardIcon = (iconName: string) => {
    switch (iconName) {
      case 'Flame': return <Flame className="w-6 h-6 text-amber-400" />;
      case 'Radio': return <Radio className="w-6 h-6 text-red-400" />;
      case 'Trophy': return <Trophy className="w-6 h-6 text-yellow-400" />;
      case 'Target': return <Target className="w-6 h-6 text-emerald-400" />;
      case 'Shield': return <Shield className="w-6 h-6 text-sky-400" />;
      case 'Zap': return <Zap className="w-6 h-6 text-purple-400" />;
      default: return <Sparkles className="w-6 h-6 text-amber-400" />;
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const getStarRating = () => {
    if (turns <= 9) return 3;
    if (turns <= 14) return 2;
    return 1;
  };

  return (
    <div className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-hidden">
      {/* Top Bar Navigation */}
      <div className="px-4 py-3 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 active:scale-95 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Games</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30 text-[11px] font-bold flex items-center gap-1">
            <Flame className="w-3 h-3" />
            Memory Match
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-amber-400 font-mono font-bold">
            Free Arcade
          </span>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {!isComplete ? (
          <>
            {/* Header Status Row */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-slate-300">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{formatTime(timerSeconds)}</span>
                </div>
                <div className="px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-800 font-mono text-xs text-slate-300">
                  <span>Turns: <strong>{turns}</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-1 text-xs font-mono text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{matchedTypes.length} / {MEMORY_CARD_TYPES.length} Pairs</span>
              </div>
            </div>

            {/* Instruction Banner */}
            <div className="px-3 py-2 rounded-xl bg-purple-950/40 border border-purple-500/30 text-[11px] text-purple-200 flex items-center justify-between">
              <span>Find matching pairs of cricket gear & trophies!</span>
              <button
                onClick={initializeGame}
                className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            </div>

            {/* 4x3 Card Grid */}
            <div className="grid grid-cols-3 gap-2.5 sm:gap-3 py-1">
              {cards.map((card) => {
                const isFlipped = flippedIds.includes(card.id) || matchedTypes.includes(card.type);
                const isMatched = matchedTypes.includes(card.type);

                return (
                  <button
                    key={card.id}
                    disabled={isFlipped}
                    onClick={() => handleCardClick(card)}
                    className={`h-24 sm:h-28 rounded-2xl border transition-all duration-300 flex flex-col items-center justify-center p-2 relative active:scale-95 ${
                      isMatched
                        ? 'bg-emerald-950/60 border-emerald-500/80 shadow-md shadow-emerald-950/50'
                        : isFlipped
                        ? 'bg-gradient-to-br from-slate-800 to-slate-900 border-purple-500/80 shadow-lg'
                        : 'bg-gradient-to-br from-slate-900 to-[#0c1220] border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {isFlipped ? (
                      <div className="flex flex-col items-center gap-1.5 animate-in zoom-in-75 duration-200">
                        <div className={`p-2 rounded-xl ${card.color}`}>
                          {renderCardIcon(card.iconName)}
                        </div>
                        <span className="text-[10px] font-bold text-slate-200 text-center leading-tight">
                          {card.name}
                        </span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center gap-1 text-slate-600">
                        <div className="w-8 h-8 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center font-black font-mono text-xs text-purple-400/80">
                          KM
                        </div>
                        <span className="text-[9px] font-mono text-slate-500">Tap Flip</span>
                      </div>
                    )}

                    {isMatched && (
                      <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-400"></span>
                    )}
                  </button>
                );
              })}
            </div>
          </>
        ) : (
          /* Memory Game Completion Screen */
          <div className="p-6 rounded-3xl bg-gradient-to-br from-[#1b0e24] via-[#120a1a] to-[#07050d] border border-purple-500/30 text-center space-y-5 my-2 shadow-2xl animate-in zoom-in-95">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 shadow-lg shadow-purple-500/20">
              <Award className="w-9 h-9 text-amber-400" />
            </div>

            <div>
              <span className="text-[10px] text-purple-400 font-mono font-bold uppercase tracking-wider block">
                Memory Board Cleared!
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                Outstanding Memory! 🧠✨
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Completed in {turns} turns • Time: {formatTime(timerSeconds)}
              </p>

              {/* Star Rating */}
              <div className="flex items-center justify-center gap-1.5 pt-2">
                {[1, 2, 3].map((star) => (
                  <Star
                    key={star}
                    className={`w-6 h-6 ${
                      star <= getStarRating()
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-slate-700'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Points Award Card */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-2">
              <span className="text-[11px] text-slate-400 font-mono">Demo Points Credited</span>
              <div className="flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400 animate-bounce" />
                <span className="text-2xl font-black font-mono text-amber-400">
                  +{pointsEarned} Demo Pts
                </span>
              </div>
              <span className="text-[10px] text-emerald-400 block font-medium">
                ✓ Added to your shared KhelMitra demo balance
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                onClick={initializeGame}
                className="flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Play Again</span>
              </button>

              <button
                onClick={onBack}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
              >
                <span>All Games</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Free Demo Notice */}
            <div className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-900 text-[10px] text-slate-500 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>100% Free Demo Arcade • No Real Money or Gambling</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
