import React, { useState, useEffect } from 'react';
import { 
  Users, Bot, Wifi, MessageSquare, Sparkles, 
  Copy, Check, Volume2, VolumeX, X 
} from 'lucide-react';
import { multiplayerService, MultiplayerEmoteEvent, MultiplayerChatMessage, SupportedGameId } from '../../services/multiplayerService';
import { audioEffectsService } from '../../services/audioEffectsService';

interface MultiplayerRoomBarProps {
  gameId: SupportedGameId;
  gameTitle: string;
  isMultiplayer: boolean;
  onToggleMode: (multiplayer: boolean) => void;
}

const QUICK_CHATS = [
  'Well played! 👏',
  'Good game! 🤝',
  'Hurry up! ⏱️',
  'Nice move! 🎯',
  'Watch this! 🔥',
  'GG 👑',
];

const QUICK_EMOTES = ['👍', '🔥', '🏆', '😂', '👏', '💥', '😎', '🎯'];

export default function MultiplayerRoomBar({ gameId, gameTitle, isMultiplayer, onToggleMode }: MultiplayerRoomBarProps) {
  const [activeEmotes, setActiveEmotes] = useState<MultiplayerEmoteEvent[]>([]);
  const [activeChat, setActiveChat] = useState<MultiplayerChatMessage | null>(null);
  const [showChatDrawer, setShowChatDrawer] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [roomCode, setRoomCode] = useState('KHEL-7829');

  useEffect(() => {
    // Generate or fetch room
    const room = multiplayerService.getRoom();
    if (room) {
      setRoomCode(room.roomId);
    } else {
      const newRoom = multiplayerService.createPrivateRoom(gameId, gameTitle);
      setRoomCode(newRoom.roomId);
    }

    const unsubEmotes = multiplayerService.subscribeEmotes((ev) => {
      setActiveEmotes((prev) => [...prev, ev]);
      audioEffectsService.playButtonTap();
      setTimeout(() => {
        setActiveEmotes((prev) => prev.filter((e) => e.id !== ev.id));
      }, 2500);
    });

    const unsubChat = multiplayerService.subscribeChat((msg) => {
      setActiveChat(msg);
      audioEffectsService.playButtonTap();
      setTimeout(() => {
        setActiveChat(null);
      }, 3500);
    });

    return () => {
      unsubEmotes();
      unsubChat();
    };
  }, [gameId, gameTitle]);

  const handleCopyCode = () => {
    try {
      navigator.clipboard.writeText(roomCode);
      setCopiedCode(true);
      audioEffectsService.playButtonTap();
      setTimeout(() => setCopiedCode(false), 2000);
    } catch {
      // ignore
    }
  };

  const handleSendEmote = (emote: string) => {
    multiplayerService.sendEmote(emote);
    audioEffectsService.playButtonTap();
  };

  const handleSendChat = (text: string) => {
    multiplayerService.sendChat(text);
    setShowChatDrawer(false);
    audioEffectsService.playButtonTap();
  };

  const toggleSound = () => {
    const next = !soundOn;
    setSoundOn(next);
    audioEffectsService.setSoundEnabled(next);
  };

  return (
    <div className="relative z-30">
      {/* Floating Emote Overlay (animated from bottom to top) */}
      <div className="fixed top-24 left-1/2 -translate-x-1/2 pointer-events-none z-50 flex flex-col items-center gap-1">
        {activeEmotes.map((ev) => (
          <div
            key={ev.id}
            className="px-3 py-1.5 rounded-full bg-slate-950/90 border border-amber-500/50 text-white shadow-2xl flex items-center gap-1.5 animate-in fade-in zoom-in slide-in-from-bottom-3 duration-300"
          >
            <span className="text-xl">{ev.emote}</span>
            <span className="text-[11px] font-bold text-amber-300">{ev.playerName}</span>
          </div>
        ))}

        {activeChat && (
          <div className="px-3 py-1.5 rounded-2xl bg-slate-900/95 border border-purple-500/60 text-white shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
            <div>
              <span className="text-[9px] text-purple-300 font-bold block">{activeChat.senderName}</span>
              <span className="text-xs font-semibold text-slate-100">{activeChat.text}</span>
            </div>
          </div>
        )}
      </div>

      {/* Top Gaming Room Bar */}
      <div className="px-3 py-1.5 bg-[#090e1a]/95 border-b border-slate-800 flex items-center justify-between text-xs">
        {/* Left: Mode Switcher & Room Code */}
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => onToggleMode(false)}
              className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1 transition-all ${
                !isMultiplayer 
                  ? 'bg-amber-500 text-slate-950 shadow-sm' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Bot className="w-3 h-3" />
              <span>AI Match</span>
            </button>
            <button
              onClick={() => onToggleMode(true)}
              className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1 transition-all ${
                isMultiplayer 
                  ? 'bg-purple-600 text-white shadow-sm' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3 h-3" />
              <span>Multiplayer</span>
            </button>
          </div>

          {isMultiplayer && (
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-[10px] text-amber-400 font-mono active:scale-95"
              title="Click to copy Room Code"
            >
              <span>{roomCode}</span>
              {copiedCode ? <Check className="w-2.5 h-2.5 text-emerald-400" /> : <Copy className="w-2.5 h-2.5" />}
            </button>
          )}
        </div>

        {/* Right: Sound, Ping & Chat */}
        <div className="flex items-center gap-1.5">
          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[9px] text-emerald-400 font-mono">
            <Wifi className="w-2.5 h-2.5" />
            <span>24ms</span>
          </div>

          <button
            onClick={toggleSound}
            className="w-6 h-6 rounded bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
            title={soundOn ? 'Mute Game Sound' : 'Unmute Game Sound'}
          >
            {soundOn ? <Volume2 className="w-3 h-3 text-amber-400" /> : <VolumeX className="w-3 h-3 text-slate-500" />}
          </button>

          <button
            onClick={() => setShowChatDrawer(!showChatDrawer)}
            className="px-2 py-0.5 rounded bg-purple-600/30 border border-purple-500/40 text-purple-300 hover:text-white text-[10px] font-bold flex items-center gap-1 active:scale-95"
          >
            <MessageSquare className="w-3 h-3" />
            <span>Chat</span>
          </button>
        </div>
      </div>

      {/* Emote Quick Bar */}
      <div className="px-3 py-1 bg-slate-950/70 border-b border-slate-800/60 flex items-center justify-between">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <span className="text-[9px] text-slate-500 font-bold uppercase mr-1">Emotes:</span>
          {QUICK_EMOTES.map((emote) => (
            <button
              key={emote}
              onClick={() => handleSendEmote(emote)}
              className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-center text-sm active:scale-125 transition-transform"
            >
              {emote}
            </button>
          ))}
        </div>
      </div>

      {/* Tactical Quick Chat Drawer */}
      {showChatDrawer && (
        <div className="absolute top-full left-0 right-0 z-40 bg-[#090e1a] border-b border-slate-700 p-3 shadow-2xl animate-in slide-in-from-top-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Tactical Quick Chat
            </span>
            <button
              onClick={() => setShowChatDrawer(false)}
              className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-slate-400"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {QUICK_CHATS.map((chat) => (
              <button
                key={chat}
                onClick={() => handleSendChat(chat)}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-purple-500/60 text-slate-200 hover:text-white text-xs text-left active:scale-95 transition-all"
              >
                {chat}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
