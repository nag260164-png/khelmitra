import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Gamepad2, Sparkles, Trophy, ShieldCheck, 
  Flame, Award, Search, Filter, History, ChevronRight, Gift
} from 'lucide-react';
import { KHELM_GAMES, GameCategory } from '../../data/gamesData';
import { demoPointsService, DemoPointTransaction } from '../../services/demoPointsService';
import GameCard from './GameCard';
import GKQuizGame from './GKQuizGame';
import CricketQuizGame from './CricketQuizGame';
import PuzzleGame from './PuzzleGame';
import MemoryGame from './MemoryGame';
import CallBreakGame from './CallBreakGame';
import TeenPattiGame from './TeenPattiGame';
import LudoGame from './LudoGame';
import RummyGame from './RummyGame';
import GameHistoryModal from './GameHistoryModal';

interface GamesDashboardProps {
  onClose: () => void;
  onNavigateToFantasy?: () => void;
  onOpenDailyMissions?: () => void;
  initialGameId?: string | null;
}

export default function GamesDashboard({
  onClose,
  onNavigateToFantasy,
  onOpenDailyMissions,
  initialGameId,
}: GamesDashboardProps) {
  const [activeGameId, setActiveGameId] = useState<string | null>(initialGameId || null);
  const [selectedCategory, setSelectedCategory] = useState<GameCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [demoPoints, setDemoPoints] = useState<number>(demoPointsService.getPoints());
  const [recentTransactions, setRecentTransactions] = useState<DemoPointTransaction[]>(demoPointsService.getHistory());
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  // Subscribe to live demo points
  useEffect(() => {
    const unsubscribe = demoPointsService.subscribe((newPoints) => {
      setDemoPoints(newPoints);
      setRecentTransactions(demoPointsService.getHistory());
    });
    return () => unsubscribe();
  }, []);

  const handlePlayGame = (gameId: string) => {
    if (gameId === 'fantasy-cricket') {
      if (onNavigateToFantasy) {
        onNavigateToFantasy();
      } else {
        setActiveGameId('fantasy-cricket');
      }
      return;
    }
    setActiveGameId(gameId);
  };

  // Filter games
  const filteredGames = KHELM_GAMES.filter((game) => {
    const matchesCategory =
      selectedCategory === 'all' ||
      (selectedCategory === 'quiz' && game.category === 'quiz') ||
      (selectedCategory === 'puzzle' && game.category === 'puzzle') ||
      (selectedCategory === 'fantasy' && game.category === 'fantasy') ||
      (selectedCategory === 'coming-soon' && game.category === 'coming-soon');

    const matchesSearch =
      searchQuery.trim() === '' ||
      game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      game.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  // Render individual active games
  if (activeGameId === 'call-break') {
    return <CallBreakGame onBack={() => setActiveGameId(null)} />;
  }

  if (activeGameId === 'teen-patti') {
    return <TeenPattiGame onBack={() => setActiveGameId(null)} />;
  }

  if (activeGameId === 'ludo') {
    return <LudoGame onBack={() => setActiveGameId(null)} />;
  }

  if (activeGameId === 'rummy') {
    return <RummyGame onBack={() => setActiveGameId(null)} />;
  }

  if (activeGameId === 'gk-quiz') {
    return <GKQuizGame onBack={() => setActiveGameId(null)} />;
  }

  if (activeGameId === 'cricket-quiz') {
    return <CricketQuizGame onBack={() => setActiveGameId(null)} />;
  }

  if (activeGameId === 'puzzle-game') {
    return <PuzzleGame onBack={() => setActiveGameId(null)} />;
  }

  if (activeGameId === 'memory-game') {
    return <MemoryGame onBack={() => setActiveGameId(null)} />;
  }

  return (
    <div id="games-dashboard-screen" className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-hidden">
      {/* Top Sticky Header */}
      <div className="px-4 py-3 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <button
            id="games-dashboard-back-btn"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95 transition-all"
            title="Return to previous screen"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Gamepad2 className="w-4 h-4 text-purple-400" />
              <span>Khel Games Arena</span>
            </h2>
            <span className="text-[10px] text-slate-400 block -mt-0.5">
              Free-to-Play Demo Arcade
            </span>
          </div>
        </div>

        {/* Live Shared Demo Points Balance Pill */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowHistoryModal(!showHistoryModal)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/15 to-orange-500/10 border border-amber-500/30 hover:border-amber-500/60 active:scale-95 transition-all"
            title="Click to view demo points history"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <div className="text-right">
              <span className="text-[9px] text-slate-400 block leading-none font-mono">Demo Balance</span>
              <span className="text-xs font-mono font-black text-amber-300">
                {demoPoints.toLocaleString()} <span className="text-[9px] text-amber-500 font-bold">PTS</span>
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Banner: Free-to-Play Promise */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900/80 to-indigo-950/60 border border-purple-500/30 shadow-lg flex items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[9px] font-black tracking-wider uppercase border border-purple-500/40">
                100% Free To Play
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-0.5">
                <ShieldCheck className="w-3 h-3" />
                Zero Risk
              </span>
            </div>
            <h3 className="text-sm font-bold text-white">
              Play Skill Games, Earn Free Demo Points!
            </h3>
            <p className="text-[11px] text-slate-300 leading-tight">
              Test your sports IQ, solve cricket puzzles, and climb demo leaderboards with no real money.
            </p>
          </div>
        </div>

        {/* Daily Missions Action Pill in Games */}
        {onOpenDailyMissions && (
          <div 
            onClick={onOpenDailyMissions}
            className="p-3 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/10 to-slate-900 border border-amber-500/30 hover:border-amber-400/60 transition-all cursor-pointer flex items-center justify-between gap-3 active:scale-[0.99]"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                <Gift className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">
                  Daily Missions & Ad Coin Rewards
                </span>
                <span className="text-[10px] text-slate-300">
                  Complete daily check-in, watch sponsor clips & unlock mega chests!
                </span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs font-bold text-amber-400 shrink-0">
              <span>Missions</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        {/* Search & Category Filter Pills */}
        <div className="space-y-2.5">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search quizzes, puzzles, memory games..."
              className="w-full bg-[#0b1120] border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500/60 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-[10px] text-slate-400 hover:text-white absolute right-3 top-1/2 -translate-y-1/2"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {[
              { id: 'all' as GameCategory, label: 'All Games', count: KHELM_GAMES.length },
              { id: 'quiz' as GameCategory, label: 'Quizzes', count: 2 },
              { id: 'puzzle' as GameCategory, label: 'Puzzles', count: 2 },
              { id: 'fantasy' as GameCategory, label: 'Fantasy', count: 1 },
              { id: 'coming-soon' as GameCategory, label: 'Coming Soon', count: 3 },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all shrink-0 active:scale-95 ${
                  selectedCategory === cat.id
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                    : 'bg-slate-900/90 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <span>{cat.label}</span>
                <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                  selectedCategory === cat.id ? 'bg-purple-800 text-purple-200' : 'bg-slate-800 text-slate-500'
                }`}>
                  {cat.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Games Grid */}
        <div className="grid grid-cols-1 gap-3.5">
          {filteredGames.map((game) => (
            <GameCard
              key={game.id}
              game={game}
              onPlay={handlePlayGame}
            />
          ))}

          {filteredGames.length === 0 && (
            <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
              <Search className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-xs font-bold text-white">No games found</p>
              <p className="text-[11px] text-slate-400">
                Try searching for a different keyword or resetting your filter.
              </p>
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSearchQuery('');
                }}
                className="px-3 py-1.5 rounded-xl bg-purple-600 text-white text-xs font-bold mt-2"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>

        {/* Demo Points Recent History Card */}
        <div className="p-3.5 rounded-2xl bg-[#0b101d] border border-slate-800/80 space-y-2.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span>Recent Demo Points Activity</span>
            </h4>
            <span className="text-[10px] text-slate-500 font-mono">100% Free Demo</span>
          </div>

          <div className="space-y-1.5">
            {recentTransactions.slice(0, 3).map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between py-1.5 px-2.5 rounded-xl bg-slate-950/60 border border-slate-800/60 text-xs"
              >
                <div>
                  <span className="font-semibold text-slate-200 block text-[11px]">{tx.game}</span>
                  <span className="text-[10px] text-slate-500">{tx.description}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-emerald-400">+{tx.amount} Pts</span>
                  <span className="text-[9px] text-slate-500 block">{tx.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Disclaimer & Fair Play Note */}
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-900 text-center space-y-1 text-[10px] text-slate-500">
          <div className="flex items-center justify-center gap-1.5 text-slate-400 font-bold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>KhelMitra Responsible Demo Gaming Policy</span>
          </div>
          <p>
            All points and coins in the Games Arena are 100% free virtual demo credits with zero monetary value.
            No cash prizes, real-money wagering, or gambling is permitted.
          </p>
        </div>
      </div>

      {/* Game History Modal */}
      {showHistoryModal && (
        <GameHistoryModal onClose={() => setShowHistoryModal(false)} />
      )}
    </div>
  );
}
