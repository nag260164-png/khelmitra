import React, { useState, useEffect, useMemo } from 'react';
import { 
  ArrowLeft, RotateCcw, HelpCircle, Trophy, Sparkles, 
  ShieldCheck, Layers, ArrowDownUp, CheckCircle2, AlertCircle, Award 
} from 'lucide-react';
import { demoPointsService } from '../../services/demoPointsService';
import { audioEffectsService } from '../../services/audioEffectsService';
import MultiplayerRoomBar from './MultiplayerRoomBar';
import { Card, Suit, Rank } from './CallBreakGame';

interface RummyGameProps {
  onBack: () => void;
}

interface RummyPlayer {
  name: string;
  avatar: string;
  isHuman: boolean;
  hand: Card[];
  score: number;
}

const SUIT_ICONS: Record<Suit, string> = {
  spades: '♠',
  hearts: '♥',
  diamonds: '♦',
  clubs: '♣',
};

const SUIT_COLORS: Record<Suit, string> = {
  spades: 'text-slate-900',
  hearts: 'text-red-600',
  diamonds: 'text-rose-600',
  clubs: 'text-amber-800',
};

function createRummyDeck(): Card[] {
  const suits: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
  const ranks: Rank[] = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const deck: Card[] = [];

  // 1 full standard deck
  for (const suit of suits) {
    for (let i = 0; i < ranks.length; i++) {
      const val = ranks[i] === 'A' ? 1 : i >= 9 ? 10 : i + 1;
      deck.push({
        id: `${ranks[i]}_${suit}_${Math.random().toString(36).substr(2, 4)}`,
        suit,
        rank: ranks[i],
        value: val,
      });
    }
  }

  // Shuffle
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  return deck;
}

export default function RummyGame({ onBack }: RummyGameProps) {
  const [deck, setDeck] = useState<Card[]>([]);
  const [discardPile, setDiscardPile] = useState<Card[]>([]);
  const [wildJoker, setWildJoker] = useState<Card | null>(null);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [turnState, setTurnState] = useState<'draw' | 'discard'>('draw');
  const [isBotTurn, setIsBotTurn] = useState(false);
  const [declarationResult, setDeclarationResult] = useState<{ isSuccess: boolean; message: string; coinsWon?: number } | null>(null);
  const [showRules, setShowRules] = useState(false);
  const [coinsBalance, setCoinsBalance] = useState(demoPointsService.getPoints());
  const [isMultiplayer, setIsMultiplayer] = useState(false);

  const [humanHand, setHumanHand] = useState<Card[]>([]);
  const [botHand, setBotHand] = useState<Card[]>([]);

  useEffect(() => {
    const unsub = demoPointsService.subscribe(setCoinsBalance);
    return () => unsub();
  }, []);

  const dealNewGame = () => {
    const freshDeck = createRummyDeck();
    const pHand = sortRummyHand(freshDeck.slice(0, 13));
    const bHand = sortRummyHand(freshDeck.slice(13, 26));
    const joker = freshDeck[26];
    const firstDiscard = freshDeck[27];
    const remainingDeck = freshDeck.slice(28);

    setHumanHand(pHand);
    setBotHand(bHand);
    setWildJoker(joker);
    setDiscardPile([firstDiscard]);
    setDeck(remainingDeck);
    setTurnState('draw');
    setIsBotTurn(false);
    setSelectedCardId(null);
    setDeclarationResult(null);
  };

  useEffect(() => {
    dealNewGame();
  }, []);

  // Sort Hand by Suits
  function sortRummyHand(cards: Card[]): Card[] {
    const suitOrder: Record<Suit, number> = { spades: 0, hearts: 1, clubs: 2, diamonds: 3 };
    return [...cards].sort((a, b) => {
      if (suitOrder[a.suit] !== suitOrder[b.suit]) {
        return suitOrder[a.suit] - suitOrder[b.suit];
      }
      return a.value - b.value;
    });
  }

  const handleSortHand = () => {
    setHumanHand(prev => sortRummyHand(prev));
  };

  // Draw from Closed Deck
  const handleDrawFromDeck = () => {
    if (turnState !== 'draw' || isBotTurn || deck.length === 0) return;
    audioEffectsService.playCardDeal();
    const drawnCard = deck[0];
    setDeck(prev => prev.slice(1));
    setHumanHand(prev => [...prev, drawnCard]);
    setTurnState('discard');
  };

  // Draw from Discard Pile
  const handleDrawFromDiscard = () => {
    if (turnState !== 'draw' || isBotTurn || discardPile.length === 0) return;
    audioEffectsService.playCardDeal();
    const drawnCard = discardPile[discardPile.length - 1];
    setDiscardPile(prev => prev.slice(0, -1));
    setHumanHand(prev => [...prev, drawnCard]);
    setTurnState('discard');
  };

  // Discard Card
  const handleDiscard = (card: Card) => {
    if (turnState !== 'discard' || isBotTurn) return;
    audioEffectsService.playCardDeal();
    setHumanHand(prev => prev.filter(c => c.id !== card.id));
    setDiscardPile(prev => [...prev, card]);
    setSelectedCardId(null);
    setTurnState('draw');
    setIsBotTurn(true);

    // Trigger Bot turn
    setTimeout(() => {
      handleBotPlay();
    }, 1000);
  };

  // Bot Turn Automation
  const handleBotPlay = () => {
    // Bot draws
    let drawnCard: Card;
    if (deck.length > 0) {
      drawnCard = deck[0];
      setDeck(prev => prev.slice(1));
    } else {
      drawnCard = discardPile[0];
    }

    setBotHand(prev => {
      const newBotCards = [...prev, drawnCard];
      // Bot discards a card
      const discardedCard = newBotCards[Math.floor(Math.random() * newBotCards.length)];
      const remainingBot = newBotCards.filter(c => c.id !== discardedCard.id);

      setDiscardPile(p => [...p, discardedCard]);
      return remainingBot;
    });

    setIsBotTurn(false);
    setTurnState('draw');
  };

  // Check Indian Rummy Meld Validations
  const meldCheck = useMemo(() => {
    // Check for at least 1 pure sequence of 3 or more consecutive cards of same suit
    // Group by suit
    const suitGroups: Record<Suit, Card[]> = { spades: [], hearts: [], diamonds: [], clubs: [] };
    for (const c of humanHand) {
      suitGroups[c.suit].push(c);
    }

    let hasPureSequence = false;
    let sequenceCount = 0;

    for (const suit in suitGroups) {
      const group = suitGroups[suit as Suit].sort((a, b) => a.value - b.value);
      if (group.length >= 3) {
        // Check for 3 consecutive
        for (let i = 0; i <= group.length - 3; i++) {
          if (
            group[i + 1].value === group[i].value + 1 &&
            group[i + 2].value === group[i + 1].value + 1
          ) {
            hasPureSequence = true;
            sequenceCount++;
            break;
          }
        }
      }
    }

    return {
      hasPureSequence,
      sequenceCount,
      isValidDeclare: hasPureSequence && humanHand.length === 13,
    };
  }, [humanHand]);

  // Handle Declare
  const handleDeclare = () => {
    if (turnState !== 'discard') {
      alert('Please draw a card first before declaring!');
      return;
    }

    if (meldCheck.hasPureSequence) {
      const coinsEarned = 400;
      demoPointsService.addPoints(coinsEarned, 'Rummy Victory', 'Valid Rummy declaration with Pure Sequence');
      demoPointsService.recordMatch({
        gameName: 'Rummy',
        gameKey: 'rummy',
        result: 'WON',
        coinsWon: coinsEarned,
        coinsSpent: 0,
        details: 'Valid 13-Card Rummy Declaration • Pure Sequence Melded!',
      });

      setDeclarationResult({
        isSuccess: true,
        message: 'Congratulations! Valid Rummy Declaration with Pure Sequence! Opponent penalised 80 points.',
        coinsWon: coinsEarned,
      });
    } else {
      setDeclarationResult({
        isSuccess: false,
        message: 'Invalid Declare: At least one Pure Sequence (3+ consecutive cards of the same suit without joker) is required!',
      });
    }
  };

  const topDiscard = discardPile[discardPile.length - 1];

  return (
    <div id="rummy-game-screen" className="flex flex-col h-full bg-[#040810] text-slate-100 overflow-hidden select-none">
      {/* Top Header */}
      <div className="px-4 py-2.5 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black tracking-wider text-amber-400 uppercase font-mono">🃏 Classic Rummy</span>
              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                13 Cards Indian
              </span>
            </div>
            <span className="text-[10px] text-slate-400">Pure Sequences • Sets • Discard Pile</span>
          </div>
        </div>

        {/* Right Header Balance & Rules */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold font-mono">
            <span>🪙</span>
            <span>{coinsBalance.toLocaleString()}</span>
          </div>
          <button
            onClick={() => setShowRules(true)}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs"
            title="Rules"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Multiplayer & AI Tactical Bar */}
      <MultiplayerRoomBar
        gameId="rummy"
        gameTitle="Classic 13-Card Rummy"
        isMultiplayer={isMultiplayer}
        onToggleMode={setIsMultiplayer}
      />

      {/* Main Rummy Felt Table */}
      <div className="flex-1 relative flex flex-col justify-between p-3 bg-radial from-[#122e1b] via-[#07160d] to-[#040810] overflow-hidden">
        {/* Opponent Bot Hand Representation */}
        <div className="flex flex-col items-center relative z-10">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-950/80 border border-slate-800">
            <div className="w-6 h-6 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-xs">
              AI
            </div>
            <div className="text-left">
              <div className="text-[11px] font-bold text-white leading-tight">Master Bot (Aarav)</div>
              <div className="text-[9px] text-slate-400 leading-none">13 Cards in Hand</div>
            </div>
            {isBotTurn && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping ml-1"></span>}
          </div>
          <div className="flex -space-x-4 mt-1">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="w-6 h-9 rounded bg-gradient-to-br from-indigo-950 to-slate-900 border border-indigo-500/30 shadow-sm"></div>
            ))}
          </div>
        </div>

        {/* Center Table: Closed Deck | Wild Joker | Open Discard Pile */}
        <div className="flex items-center justify-center gap-6 my-auto relative z-10">
          {/* 1. Closed Draw Deck */}
          <div className="flex flex-col items-center">
            <button
              disabled={turnState !== 'draw' || isBotTurn}
              onClick={handleDrawFromDeck}
              className={`relative w-16 h-24 rounded-xl bg-gradient-to-br from-blue-900 via-indigo-950 to-slate-950 border-2 border-indigo-400/40 shadow-xl flex flex-col items-center justify-center transition-all ${
                turnState === 'draw' && !isBotTurn ? 'hover:scale-105 cursor-pointer ring-4 ring-amber-400/50 animate-pulse' : 'opacity-80'
              }`}
            >
              <Layers className="w-5 h-5 text-indigo-300" />
              <span className="text-[10px] font-bold text-white mt-1">Draw</span>
              <span className="text-[9px] text-indigo-300 font-mono">{deck.length} left</span>
            </button>
            <span className="text-[10px] text-slate-400 mt-1 font-medium">Closed Deck</span>
          </div>

          {/* 2. Wild Joker Card Indicator */}
          {wildJoker && (
            <div className="flex flex-col items-center">
              <div className="relative rotate-90 transform translate-y-1">
                <RCardView card={wildJoker} />
                <span className="absolute -top-1 -right-1 px-1 py-0.2 bg-amber-500 text-slate-950 font-black text-[8px] rounded">
                  JOKER
                </span>
              </div>
              <span className="text-[10px] text-amber-400 mt-3 font-bold">Wild Joker</span>
            </div>
          )}

          {/* 3. Open Discard Pile */}
          <div className="flex flex-col items-center">
            {topDiscard ? (
              <button
                disabled={turnState !== 'draw' || isBotTurn}
                onClick={handleDrawFromDiscard}
                className={`relative transition-transform ${
                  turnState === 'draw' && !isBotTurn ? 'hover:scale-105 cursor-pointer ring-2 ring-emerald-400' : ''
                }`}
              >
                <RCardView card={topDiscard} />
              </button>
            ) : (
              <div className="w-16 h-24 rounded-xl border-2 border-dashed border-slate-700 flex items-center justify-center text-xs text-slate-500">
                Empty
              </div>
            )}
            <span className="text-[10px] text-slate-400 mt-1 font-medium">Discard Pile</span>
          </div>
        </div>

        {/* Player Rummy Control & 13 Cards Hand */}
        <div className="relative z-10 flex flex-col items-center">
          {/* Quick Helper Bar */}
          <div className="flex items-center justify-between w-full max-w-sm px-3 py-1.5 rounded-t-xl bg-slate-950/90 border-t border-x border-slate-800 text-xs mb-1">
            <div className="flex items-center gap-2">
              <span className="font-bold text-white">Your Hand (13)</span>
              {meldCheck.hasPureSequence ? (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold flex items-center gap-1 border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" />
                  Pure Seq OK
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-bold flex items-center gap-1 border border-amber-500/30">
                  <AlertCircle className="w-3 h-3" />
                  Need Pure Seq
                </span>
              )}
            </div>

            {/* Action Buttons: Sort & Declare */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={handleSortHand}
                className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-700 hover:border-amber-400 text-slate-200 text-xs font-bold flex items-center gap-1 active:scale-95 transition-all"
              >
                <ArrowDownUp className="w-3 h-3 text-amber-400" />
                <span>Sort</span>
              </button>

              <button
                onClick={handleDeclare}
                className="px-3 py-1 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 text-xs font-black flex items-center gap-1 shadow-md active:scale-95 transition-all"
              >
                <Award className="w-3 h-3" />
                <span>Declare</span>
              </button>
            </div>
          </div>

          {/* Turn Guidance Pill */}
          <div className="text-[11px] text-amber-300 font-bold mb-1">
            {isBotTurn 
              ? 'Bot is taking turn...' 
              : turnState === 'draw' 
              ? '1. Draw a card from Closed Deck or Discard Pile' 
              : '2. Select a card from your hand and tap Discard'}
          </div>

          {/* Player Cards Fan */}
          <div className="w-full flex items-center justify-center overflow-x-auto py-1 px-1 no-scrollbar">
            <div className="flex -space-x-4 py-2">
              {humanHand.map((card) => {
                const isSelected = selectedCardId === card.id;
                return (
                  <button
                    key={card.id}
                    onClick={() => {
                      if (turnState === 'discard') {
                        if (isSelected) {
                          handleDiscard(card);
                        } else {
                          setSelectedCardId(card.id);
                        }
                      } else {
                        setSelectedCardId(isSelected ? null : card.id);
                      }
                    }}
                    className={`relative transition-all select-none ${
                      isSelected 
                        ? '-translate-y-4 ring-2 ring-amber-400 rounded-xl shadow-2xl z-20' 
                        : 'hover:-translate-y-2'
                    }`}
                  >
                    <RCardView card={card} />
                    {isSelected && turnState === 'discard' && (
                      <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-red-600 text-white font-bold text-[9px] px-1.5 py-0.5 rounded shadow animate-bounce">
                        Discard
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Declaration Result Modal */}
      {declarationResult && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0a0f1d] border border-amber-500/40 rounded-3xl p-5 shadow-2xl text-center animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mx-auto mb-3 text-amber-400">
              {declarationResult.isSuccess ? <Trophy className="w-9 h-9 animate-bounce" /> : <AlertCircle className="w-9 h-9 text-red-400" />}
            </div>
            <h3 className="text-xl font-black text-white">
              {declarationResult.isSuccess ? 'Rummy Game Won!' : 'Declaration Notice'}
            </h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">{declarationResult.message}</p>

            {declarationResult.isSuccess && (
              <div className="my-4 p-3 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-sm font-bold flex items-center justify-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <span>Prize Reward: +{declarationResult.coinsWon} Virtual Coins!</span>
              </div>
            )}

            <div className="flex gap-2 mt-4">
              {declarationResult.isSuccess ? (
                <button
                  onClick={dealNewGame}
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Deal New Hand
                </button>
              ) : (
                <button
                  onClick={() => setDeclarationResult(null)}
                  className="flex-1 py-3 rounded-xl bg-amber-500 text-slate-950 font-black text-xs"
                >
                  Continue Hand
                </button>
              )}
              <button
                onClick={onBack}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                Exit Game
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rules Modal */}
      {showRules && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowRules(false)}>
          <div className="w-full max-w-sm bg-[#0c1222] border border-slate-800 rounded-3xl p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                13-Card Indian Rummy Rules
              </h4>
              <button onClick={() => setShowRules(false)} className="text-xs text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="space-y-2 text-xs text-slate-300 leading-relaxed max-h-72 overflow-y-auto pr-1">
              <p>• <strong>Pure Sequence is Mandatory</strong>: You must have at least one sequence of 3+ consecutive cards of the same suit without a wildcard (e.g. 5♠ 6♠ 7♠).</p>
              <p>• <strong>Second Sequence</strong>: At least one other sequence is required (can use Wild Joker).</p>
              <p>• <strong>Sets</strong>: 3 or 4 cards of the same rank but different suits (e.g. 8♥ 8♦ 8♣).</p>
              <p>• <strong>Draw & Discard</strong>: Pick one card from Closed Deck or Discard Pile, then discard one card to keep 13 cards.</p>
              <p>• <strong>Zero Real Money</strong>: Purely free demo gaming with virtual coins.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function RCardView({ card }: { card: Card }) {
  const SUIT_ICONS: Record<Suit, string> = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' };
  const SUIT_COLORS: Record<Suit, string> = { spades: 'text-slate-900', hearts: 'text-red-600', diamonds: 'text-rose-600', clubs: 'text-amber-800' };

  return (
    <div className="w-13 h-20 rounded-xl bg-white border border-slate-300 shadow-lg p-1.5 flex flex-col justify-between select-none">
      <div className="flex items-center justify-between text-xs font-black text-slate-950 leading-none">
        <span>{card.rank}</span>
        <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
      </div>
      <div className={`text-base text-center my-auto ${SUIT_COLORS[card.suit]}`}>
        {SUIT_ICONS[card.suit]}
      </div>
      <div className="flex items-center justify-between text-xs font-black text-slate-950 leading-none rotate-180">
        <span>{card.rank}</span>
        <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
      </div>
    </div>
  );
}
