import React, { useState, useEffect } from 'react';
import { 
  X, History, Trophy, TrendingUp, Sparkles, 
  ArrowUpRight, ArrowDownRight, Award, ShieldCheck 
} from 'lucide-react';
import { demoPointsService, GameMatchRecord } from '../../services/demoPointsService';

interface GameHistoryModalProps {
  onClose: () => void;
}

export default function GameHistoryModal({ onClose }: GameHistoryModalProps) {
  const [matches, setMatches] = useState<GameMatchRecord[]>([]);
  const [filter, setFilter] = useState<'all' | 'call-break' | 'teen-patti' | 'ludo' | 'rummy'>('all');
  const [points, setPoints] = useState(demoPointsService.getPoints());

  useEffect(() => {
    setMatches(demoPointsService.getMatchHistory());
    const unsub = demoPointsService.subscribe(setPoints);
    return () => unsub();
  }, []);

  const filteredMatches = matches.filter(m => {
    if (filter === 'all') return true;
    return m.gameKey === filter;
  });

  const totalWon = matches.filter(m => m.result === 'WON').length;
  const winRate = matches.length > 0 ? Math.round((totalWon / matches.length) * 100) : 0;
  const totalCoinsWon = matches.reduce((sum, m) => sum + m.coinsWon, 0);

  return (
    <div 
      id="game-history-modal-overlay" 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="game-history-modal-sheet"
        className="w-full max-w-md max-h-[85vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="pt-3 pb-3 px-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">Gaming Match History</h3>
              <span className="text-[10px] text-slate-400">Past rounds & virtual coin records</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stats Summary Bento Banner */}
        <div className="p-4 border-b border-slate-800/80 bg-gradient-to-r from-amber-500/10 via-slate-900/60 to-purple-500/10">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">Matches</span>
              <span className="text-base font-black text-white font-mono">{matches.length}</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">Win Rate</span>
              <span className="text-base font-black text-emerald-400 font-mono">{winRate}%</span>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">Total Won</span>
              <span className="text-base font-black text-amber-400 font-mono">+{totalCoinsWon} 🪙</span>
            </div>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="px-4 py-2 border-b border-slate-800/60 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'All Games' },
            { id: 'call-break', label: 'Call Break' },
            { id: 'teen-patti', label: 'Teen Patti' },
            { id: 'ludo', label: 'Ludo' },
            { id: 'rummy', label: 'Rummy' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all ${
                filter === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Match List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filteredMatches.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              No match records yet. Play a game to record history!
            </div>
          ) : (
            filteredMatches.map(match => (
              <div
                key={match.id}
                className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/90 flex flex-col gap-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs">{match.gameName}</span>
                    <span className={`px-1.5 py-0.2 rounded text-[9px] font-black uppercase ${
                      match.result === 'WON' 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                        : 'bg-slate-800 text-slate-400'
                    }`}>
                      {match.result}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500">{match.timestamp}</span>
                </div>

                <p className="text-[11px] text-slate-400 leading-snug">{match.details}</p>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800/60 text-[11px]">
                  <span className="text-slate-500">Entry: {match.coinsSpent || 0} Coins</span>
                  <span className={`font-mono font-bold ${match.coinsWon > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                    {match.coinsWon > 0 ? `+${match.coinsWon} 🪙` : '0 🪙'}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
