import { 
  Trophy, Radio, Sparkles, Gamepad2, Flame, Zap, Target, 
  Award, Play, Clock, ChevronRight, Lock, CheckCircle2
} from 'lucide-react';
import { GameDefinition } from '../../data/gamesData';

interface GameCardProps {
  game: GameDefinition;
  onPlay: (gameId: string) => void;
}

export default function GameCard({ game, onPlay }: GameCardProps) {
  const getIcon = () => {
    switch (game.icon) {
      case 'Trophy': return <Trophy className="w-5 h-5 text-amber-400" />;
      case 'Radio': return <Radio className="w-5 h-5 text-red-400" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-blue-400" />;
      case 'Gamepad2': return <Gamepad2 className="w-5 h-5 text-emerald-400" />;
      case 'Flame': return <Flame className="w-5 h-5 text-purple-400" />;
      case 'Zap': return <Zap className="w-5 h-5 text-amber-400" />;
      case 'Target': return <Target className="w-5 h-5 text-rose-400" />;
      case 'Award': return <Award className="w-5 h-5 text-indigo-400" />;
      default: return <Gamepad2 className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <div
      id={`game-card-${game.id}`}
      className={`rounded-2xl bg-gradient-to-br ${game.bgGradient} border border-slate-800/90 shadow-xl transition-all duration-200 overflow-hidden flex flex-col justify-between ${
        game.isPlayable ? `${game.borderHoverColor} hover:shadow-2xl hover:-translate-y-0.5` : 'opacity-90'
      }`}
    >
      {/* Card Header */}
      <div className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-2">
          {/* Icon Badge */}
          <div className="w-11 h-11 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-center shrink-0 shadow-inner">
            {getIcon()}
          </div>

          {/* Badges */}
          <div className="flex items-center gap-1.5 flex-wrap justify-end">
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider border ${game.tagColor}`}
            >
              {game.tag}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-slate-900/80 border border-slate-800 text-slate-400 text-[10px] font-mono">
              {game.categoryLabel}
            </span>
          </div>
        </div>

        {/* Title & Description */}
        <div>
          <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-1.5">
            {game.title}
          </h3>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            {game.description}
          </p>
        </div>

        {/* Feature Pills */}
        <div className="flex flex-wrap gap-1.5 pt-1">
          {game.features.map((feat, idx) => (
            <span
              key={idx}
              className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-md bg-slate-950/60 border border-slate-800/70 text-slate-300 font-medium"
            >
              <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
              {feat}
            </span>
          ))}
        </div>
      </div>

      {/* Card Footer */}
      <div className="px-4 py-3 bg-slate-950/80 border-t border-slate-800/80 flex items-center justify-between gap-2">
        <div>
          <span className="text-[10px] text-slate-400 block font-mono">Demo Reward</span>
          <span className="text-xs font-bold font-mono text-amber-400">
            {game.demoPointsReward}
          </span>
        </div>

        {game.isPlayable ? (
          <button
            id={`play-btn-${game.id}`}
            onClick={() => onPlay(game.id)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>Play Now</span>
          </button>
        ) : (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 text-xs font-semibold">
            <Lock className="w-3 h-3 text-slate-500" />
            <span>{game.comingSoonDate || 'Coming Soon'}</span>
          </div>
        )}
      </div>
    </div>
  );
}
