import { useState, useEffect } from 'react';
import { 
  ArrowLeft, Clock, Sparkles, Award, CheckCircle2, 
  XCircle, RotateCcw, ChevronRight, ShieldCheck, Zap
} from 'lucide-react';
import { GK_QUIZ_QUESTIONS } from '../../data/gamesData';
import { demoPointsService } from '../../services/demoPointsService';
import { dailyMissionService } from '../../services/dailyMissionService';

interface GKQuizGameProps {
  onBack: () => void;
}

export default function GKQuizGame({ onBack }: GKQuizGameProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [timer, setTimer] = useState(15);
  const [isFinished, setIsFinished] = useState(false);
  const [pointsEarned, setPointsEarned] = useState(0);

  const currentQ = GK_QUIZ_QUESTIONS[currentIndex];

  // 15-second countdown timer per question
  useEffect(() => {
    if (isAnswered || isFinished) return;

    if (timer <= 0) {
      handleTimeUp();
      return;
    }

    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [timer, isAnswered, isFinished]);

  const handleTimeUp = () => {
    setIsAnswered(true);
    setSelectedOption(-1); // Timed out
    setStreak(0);
  };

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correctIndex;
    if (isCorrect) {
      const newStreak = streak + 1;
      setStreak(newStreak);
      setScore((prev) => prev + 1);
    } else {
      setStreak(0);
    }
  };

  const handleNext = () => {
    if (currentIndex < GK_QUIZ_QUESTIONS.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setTimer(15);
    } else {
      // Finished! Calculate and award demo points
      const basePoints = score * 30;
      const streakBonus = score >= 4 ? 50 : 0;
      const totalEarned = basePoints + streakBonus;
      setPointsEarned(totalEarned);
      if (totalEarned > 0) {
        demoPointsService.addPoints(totalEarned, 'GK Quiz Game', `Scored ${score}/5 in General Knowledge Quiz`);
      }
      dailyMissionService.incrementProgress('mission-cricket-quiz', 1);
      setIsFinished(true);
    }
  };

  const handleRestart = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setStreak(0);
    setTimer(15);
    setIsFinished(false);
    setPointsEarned(0);
  };

  return (
    <div className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-hidden">
      {/* Top Bar Navigation */}
      <div className="px-4 py-3 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-bold text-slate-300 hover:text-white px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 active:scale-95 transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Games</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[11px] font-bold flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            GK Quiz IQ
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-amber-400 font-mono font-bold">
            Demo Play
          </span>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {!isFinished ? (
          <>
            {/* Header Status Row */}
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider block">
                  Question {currentIndex + 1} of {GK_QUIZ_QUESTIONS.length}
                </span>
                <span className="text-xs font-bold text-slate-300">
                  {currentQ.category}
                </span>
              </div>

              {/* Countdown Timer Badge */}
              <div
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-mono text-xs font-bold border transition-colors ${
                  timer <= 5
                    ? 'bg-red-500/20 border-red-500/40 text-red-400 animate-pulse'
                    : 'bg-slate-900 border-slate-800 text-amber-400'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>{timer}s</span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800/80">
              <div
                className="bg-gradient-to-r from-blue-500 to-indigo-500 h-full transition-all duration-300"
                style={{ width: `${((currentIndex + 1) / GK_QUIZ_QUESTIONS.length) * 100}%` }}
              ></div>
            </div>

            {/* Question Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0c1324] via-[#090f1d] to-[#060a15] border border-blue-900/40 shadow-xl space-y-3">
              <span className="text-[10px] font-mono font-bold text-blue-400 px-2 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 inline-block">
                Q{currentIndex + 1}
              </span>
              <h3 className="text-base font-bold text-white leading-snug">
                {currentQ.question}
              </h3>
            </div>

            {/* Options List */}
            <div className="space-y-2.5 pt-1">
              {currentQ.options.map((opt, idx) => {
                let btnStyle = 'bg-[#0b1120] border-slate-800 text-slate-200 hover:border-blue-500/60 hover:bg-slate-900/80';
                
                if (isAnswered) {
                  if (idx === currentQ.correctIndex) {
                    btnStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-900/30';
                  } else if (idx === selectedOption) {
                    btnStyle = 'bg-red-950/80 border-red-500 text-red-300';
                  } else {
                    btnStyle = 'bg-slate-950/60 border-slate-800/60 text-slate-500 opacity-60';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={isAnswered}
                    onClick={() => handleSelectOption(idx)}
                    className={`w-full p-3.5 rounded-2xl border text-left font-medium text-xs sm:text-sm flex items-center justify-between gap-3 transition-all duration-150 active:scale-[0.99] ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] font-mono font-bold flex items-center justify-center shrink-0 text-slate-300">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{opt}</span>
                    </div>

                    {isAnswered && idx === currentQ.correctIndex && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    )}
                    {isAnswered && idx === selectedOption && idx !== currentQ.correctIndex && (
                      <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Answer Explanation & Next Button */}
            {isAnswered && (
              <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3 animate-in fade-in duration-200">
                <div className="text-xs">
                  <span className="font-bold text-amber-400 block mb-0.5">Explanation:</span>
                  <p className="text-slate-300 leading-relaxed text-[11px]">
                    {currentQ.explanation}
                  </p>
                </div>

                <button
                  onClick={handleNext}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
                >
                  <span>
                    {currentIndex < GK_QUIZ_QUESTIONS.length - 1 ? 'Next Question' : 'View Results'}
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        ) : (
          /* Quiz Results Screen */
          <div className="p-6 rounded-3xl bg-gradient-to-br from-[#0c1426] via-[#090f1d] to-[#060a14] border border-blue-500/30 text-center space-y-5 my-2 shadow-2xl animate-in zoom-in-95">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400 shadow-lg shadow-blue-500/20">
              <Award className="w-9 h-9 text-amber-400" />
            </div>

            <div>
              <span className="text-[10px] text-blue-400 font-mono font-bold uppercase tracking-wider block">
                Challenge Completed
              </span>
              <h3 className="text-xl font-bold text-white mt-1">
                {score === 5 ? 'Perfect Brain Score! 🎯' : score >= 3 ? 'Great IQ Performance! 🌟' : 'Good Effort! Keep Playing 📚'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                You answered {score} of {GK_QUIZ_QUESTIONS.length} questions correctly.
              </p>
            </div>

            {/* Points Award Card */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/90 space-y-2">
              <span className="text-[11px] text-slate-400 font-mono">Demo Points Credited</span>
              <div className="flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400 animate-bounce" />
                <span className="text-2xl font-black font-mono text-amber-400">
                  +{pointsEarned} Demo Pts
                </span>
              </div>
              <span className="text-[10px] text-emerald-400 block font-medium">
                ✓ Added to your shared KhelMitra demo balance
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 pt-2">
              <button
                onClick={handleRestart}
                className="flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Play Again</span>
              </button>

              <button
                onClick={onBack}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
              >
                <span>All Games</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Free Demo Notice */}
            <div className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-900 text-[10px] text-slate-500 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>100% Free Demo Quiz • No Real Money or Gambling</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
