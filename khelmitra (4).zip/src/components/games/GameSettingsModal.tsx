import React, { useState, useEffect } from 'react';
import { 
  X, Settings, Volume2, VolumeX, Vibrate, 
  Sparkles, ShieldCheck, Zap, Coins, Check, Award, Smartphone, Download,
  Headphones, UserPlus, ChevronRight, Lock, KeyRound
} from 'lucide-react';
import { demoPointsService, GameSettings } from '../../services/demoPointsService';

interface GameSettingsModalProps {
  onClose: () => void;
  onOpenApkCenter?: () => void;
  onOpenCustomerCare?: () => void;
  onOpenInviteFriends?: () => void;
  onOpenMasterOwner?: () => void;
}

export default function GameSettingsModal({ 
  onClose, 
  onOpenApkCenter,
  onOpenCustomerCare,
  onOpenInviteFriends,
  onOpenMasterOwner
}: GameSettingsModalProps) {
  const [settings, setSettings] = useState<GameSettings>(demoPointsService.getSettings());
  const [coins, setCoins] = useState(demoPointsService.getPoints());
  const [refillSuccess, setRefillSuccess] = useState(false);

  useEffect(() => {
    const unsub = demoPointsService.subscribe(setCoins);
    return () => unsub();
  }, []);

  const handleToggle = (key: keyof GameSettings) => {
    const updated = demoPointsService.updateSettings({ [key]: !settings[key] });
    setSettings(updated);
  };

  const handleRefillCoins = () => {
    demoPointsService.refillFreeCoins(1000);
    setRefillSuccess(true);
    setTimeout(() => setRefillSuccess(false), 3000);
  };

  return (
    <div 
      id="game-settings-modal-overlay" 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="game-settings-modal-sheet"
        className="w-full max-w-md max-h-[85vh] bg-[#070b14] border-t border-slate-700/80 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="pt-3 pb-3 px-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <Settings className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">Gaming Preferences</h3>
              <span className="text-[10px] text-slate-400">Sound, Haptics & Free Coin Refill</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4 overflow-y-auto">
          {/* Virtual Coin Refill Card */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-950/30 to-slate-900 border border-amber-500/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider block">
                Free Virtual Coins
              </span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-lg font-black text-white font-mono">{coins.toLocaleString()}</span>
                <span className="text-xs text-amber-400 font-bold">Coins</span>
              </div>
              <span className="text-[10px] text-slate-400">100% Free • No Real Money</span>
            </div>

            <button
              onClick={handleRefillCoins}
              className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs active:scale-95 transition-all shadow-md flex items-center gap-1.5"
            >
              {refillSuccess ? (
                <>
                  <Check className="w-3.5 h-3.5 text-slate-950" />
                  <span>+1,000 Added!</span>
                </>
              ) : (
                <>
                  <Coins className="w-3.5 h-3.5" />
                  <span>Claim 1,000 Coins</span>
                </>
              )}
            </button>
          </div>

          {/* Settings Toggles List */}
          <div className="space-y-2">
            {/* Sound Effects */}
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  {settings.soundEffects ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Game Sound Effects</span>
                  <span className="text-[10px] text-slate-400">Card clicks, dice roll & win sounds</span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('soundEffects')}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  settings.soundEffects ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                  settings.soundEffects ? 'right-1' : 'left-1'
                }`} />
              </button>
            </div>

            {/* Haptic Vibration */}
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
                  <Vibrate className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Haptic Vibration</span>
                  <span className="text-[10px] text-slate-400">Tactile pulse on card drops & turns</span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('hapticFeedback')}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  settings.hapticFeedback ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                  settings.hapticFeedback ? 'right-1' : 'left-1'
                }`} />
              </button>
            </div>

            {/* Fast Card Animations */}
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Turbo Speed Mode</span>
                  <span className="text-[10px] text-slate-400">Faster AI bot play and card dealing</span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('fastAnimations')}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  settings.fastAnimations ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                  settings.fastAnimations ? 'right-1' : 'left-1'
                }`} />
              </button>
            </div>

            {/* Auto Sort Cards */}
            <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">Auto-Sort Hands</span>
                  <span className="text-[10px] text-slate-400">Sort cards by suit automatically on deal</span>
                </div>
              </div>
              <button
                onClick={() => handleToggle('autoSortCards')}
                className={`w-11 h-6 rounded-full transition-colors relative ${
                  settings.autoSortCards ? 'bg-amber-500' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform absolute top-1 ${
                  settings.autoSortCards ? 'right-1' : 'left-1'
                }`} />
              </button>
            </div>
          </div>

          {/* Android APK Download & Build Box */}
          {onOpenApkCenter && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-900 to-emerald-950/30 border border-emerald-500/30 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                  <Smartphone className="w-4 h-4 text-emerald-400" />
                  <span>Android APK & Build Center</span>
                </div>
                <span className="text-[10px] text-slate-400">Download project .zip, .apk build scripts & PWA</span>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenApkCenter();
                }}
                className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs active:scale-95 transition-all flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Open</span>
              </button>
            </div>
          )}

          {/* Customer Care & Invite Friends Grid */}
          <div className="grid grid-cols-2 gap-2">
            {onOpenInviteFriends && (
              <button
                onClick={() => {
                  onClose();
                  onOpenInviteFriends();
                }}
                className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-amber-400/60 text-left active:scale-95 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                    <UserPlus className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">Invite Friends</span>
                    <span className="text-[10px] text-amber-300 font-semibold">+1,000 Coins</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 transition-colors" />
              </button>
            )}

            {onOpenCustomerCare && (
              <button
                onClick={() => {
                  onClose();
                  onOpenCustomerCare();
                }}
                className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-blue-400/60 text-left active:scale-95 transition-all flex items-center justify-between group"
              >
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                    <Headphones className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-white block">Customer Care</span>
                    <span className="text-[10px] text-emerald-400 font-semibold">24/7 Help</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-blue-400 transition-colors" />
              </button>
            )}
          </div>

          {/* Master Owner Control Panel Access Card */}
          {onOpenMasterOwner && (
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-amber-950/20 border border-amber-500/40 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Master Owner Control Panel</span>
                </div>
                <span className="text-[10px] text-slate-400">Owner auth, user management, game rules & API status</span>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenMasterOwner();
                }}
                className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs active:scale-95 transition-all flex items-center gap-1 shadow-sm"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Manage</span>
              </button>
            </div>
          )}

          {/* Fair Play Certified Box */}
          <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800/90 text-[11px] text-slate-400 space-y-1.5">
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <ShieldCheck className="w-4 h-4" />
              <span>Certified 100% Free-to-Play Fair Play</span>
            </div>
            <p className="leading-relaxed text-slate-400">
              KhelMitra uses cryptographic RNG card shuffling and dice rolling algorithms. Zero real-money wagering is involved.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
