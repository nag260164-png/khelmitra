import React, { useState } from 'react';
import { 
  Gift, Trophy, Sparkles, ArrowLeft, CheckCircle2, 
  RotateCw, Crown, Flame, ShieldCheck, Zap, Lock 
} from 'lucide-react';
import { demoPointsService } from '../../services/demoPointsService';
import { audioEffectsService } from '../../services/audioEffectsService';

interface RewardsModalProps {
  onClose: () => void;
}

interface StreakDay {
  day: number;
  rewardCoins: number;
  label: string;
  isClaimed: boolean;
  isCurrent: boolean;
  isLocked: boolean;
}

const WHEEL_PRIZES = [
  { label: '+250 Coins', coins: 250, color: 'from-amber-600 to-amber-700' },
  { label: '+500 Coins', coins: 500, color: 'from-purple-600 to-indigo-700' },
  { label: '+100 Coins', coins: 100, color: 'from-slate-700 to-slate-800' },
  { label: 'JACKPOT 1,500', coins: 1500, color: 'from-amber-400 to-orange-600' },
  { label: '+300 Coins', coins: 300, color: 'from-emerald-600 to-teal-700' },
  { label: '+750 Coins', coins: 750, color: 'from-rose-600 to-red-700' },
];

export default function RewardsModal({ onClose }: RewardsModalProps) {
  const [activeTab, setActiveTab] = useState<'spin' | 'streak' | 'chests'>('spin');
  const [isSpinning, setIsSpinning] = useState(false);
  const [spinAngle, setSpinAngle] = useState(0);
  const [wonPrize, setWonPrize] = useState<string | null>(null);
  const [hasSpunToday, setHasSpunToday] = useState(false);

  const [streakDays, setStreakDays] = useState<StreakDay[]>([
    { day: 1, rewardCoins: 200, label: 'Day 1', isClaimed: true, isCurrent: false, isLocked: false },
    { day: 2, rewardCoins: 350, label: 'Day 2', isClaimed: true, isCurrent: false, isLocked: false },
    { day: 3, rewardCoins: 500, label: 'Day 3', isClaimed: false, isCurrent: true, isLocked: false },
    { day: 4, rewardCoins: 750, label: 'Day 4', isClaimed: false, isCurrent: false, isLocked: true },
    { day: 5, rewardCoins: 1000, label: 'Day 5', isClaimed: false, isCurrent: false, isLocked: true },
    { day: 6, rewardCoins: 1500, label: 'Day 6', isClaimed: false, isCurrent: false, isLocked: true },
    { day: 7, rewardCoins: 3000, label: 'Mega Chest', isClaimed: false, isCurrent: false, isLocked: true },
  ]);

  const [claimedNotice, setClaimedNotice] = useState<string | null>(null);

  const handleClaimDay3 = () => {
    demoPointsService.refillFreeCoins(500);
    audioEffectsService.playCoinReward();
    setStreakDays(prev => prev.map(d => d.day === 3 ? { ...d, isClaimed: true, isCurrent: false } : d));
    setClaimedNotice('+500 Virtual Coins added to your wallet!');
    setTimeout(() => setClaimedNotice(null), 3000);
  };

  const handleSpinWheel = () => {
    if (isSpinning || hasSpunToday) return;

    setIsSpinning(true);
    setWonPrize(null);
    audioEffectsService.playDiceRoll();

    // Calculate random rotations
    const randomPrizeIndex = Math.floor(Math.random() * WHEEL_PRIZES.length);
    const degreesPerSlice = 360 / WHEEL_PRIZES.length;
    const extraRotations = 360 * 5; // 5 full turns
    const targetAngle = spinAngle + extraRotations + (randomPrizeIndex * degreesPerSlice) + (degreesPerSlice / 2);

    setSpinAngle(targetAngle);

    setTimeout(() => {
      setIsSpinning(false);
      const selected = WHEEL_PRIZES[randomPrizeIndex];
      demoPointsService.refillFreeCoins(selected.coins);
      audioEffectsService.playWinFanfare();
      setWonPrize(`🎉 You Won ${selected.label}!`);
      setHasSpunToday(true);
    }, 3200);
  };

  return (
    <div 
      id="rewards-modal-overlay" 
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="rewards-modal-sheet"
        className="w-full max-w-md h-[92vh] bg-[#070b14] border-t border-slate-800 rounded-t-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2.5">
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 active:scale-95"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center">
                <Gift className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-sm font-black text-white uppercase tracking-wider font-mono">
                  Rewards & Lucky Spin
                </h2>
                <span className="text-[10px] text-slate-400">
                  Daily Free Claims • Virtual Coins Only
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-0.5 rounded-full text-emerald-400 text-[10px] font-bold">
            <ShieldCheck className="w-3 h-3" />
            <span>100% Free</span>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="px-4 pt-3 pb-2 bg-slate-950/40 flex gap-2">
          {[
            { id: 'spin' as const, label: '🎰 Lucky Wheel' },
            { id: 'streak' as const, label: '🔥 7-Day Streak' },
            { id: 'chests' as const, label: '🎁 Milestone Chests' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                audioEffectsService.playButtonTap();
                setActiveTab(tab.id);
              }}
              className={`flex-1 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {claimedNotice && (
          <div className="mx-4 mt-2 p-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center animate-in fade-in">
            {claimedNotice}
          </div>
        )}

        {/* Body Area */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
          {/* TAB 1: LUCKY WHEEL */}
          {activeTab === 'spin' && (
            <div className="flex flex-col items-center justify-center space-y-4 py-2">
              <div className="text-center">
                <h3 className="text-base font-black text-white font-mono uppercase">
                  Daily Fortune Wheel
                </h3>
                <p className="text-xs text-slate-400">
                  Spin once every 24 hours to win free virtual coins!
                </p>
              </div>

              {/* Wheel Container */}
              <div className="relative w-64 h-64 flex items-center justify-center my-2">
                {/* Fixed Top Pointer */}
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 w-6 h-8 flex flex-col items-center">
                  <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-t-[18px] border-t-amber-400 drop-shadow-md"></div>
                </div>

                {/* Rotating Wheel Disc */}
                <div 
                  className="w-60 h-60 rounded-full border-4 border-amber-500/80 shadow-[0_0_30px_rgba(245,158,11,0.25)] relative overflow-hidden transition-transform duration-[3200ms] ease-out"
                  style={{ transform: `rotate(${spinAngle}deg)` }}
                >
                  {WHEEL_PRIZES.map((prize, idx) => {
                    const rotation = idx * 60;
                    return (
                      <div
                        key={idx}
                        className={`absolute w-full h-full flex justify-center pt-2 text-[10px] font-black uppercase tracking-wider text-white bg-gradient-to-b ${prize.color}`}
                        style={{
                          transformOrigin: '50% 50%',
                          transform: `rotate(${rotation}deg)`,
                          clipPath: 'polygon(50% 50%, 21% 0%, 79% 0%)',
                        }}
                      >
                        <span className="mt-2 drop-shadow">{prize.label}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Center Hub Button */}
                <div className="absolute z-10 w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 border-2 border-slate-900 shadow-xl flex items-center justify-center text-slate-950 font-black text-xs">
                  <span>KHEL</span>
                </div>
              </div>

              {wonPrize && (
                <div className="p-3 rounded-2xl bg-amber-500/20 border border-amber-500/50 text-amber-300 text-sm font-black text-center animate-bounce shadow-lg">
                  {wonPrize}
                </div>
              )}

              {/* Spin Trigger Button */}
              <button
                id="spin-wheel-btn"
                disabled={isSpinning || hasSpunToday}
                onClick={handleSpinWheel}
                className={`w-full max-w-xs py-3.5 rounded-2xl font-black text-sm uppercase tracking-wider flex items-center justify-center gap-2 shadow-xl transition-all ${
                  isSpinning || hasSpunToday
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 text-slate-950 active:scale-95 shadow-amber-500/30'
                }`}
              >
                <RotateCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
                <span>{isSpinning ? 'Spinning...' : hasSpunToday ? 'Claimed Today (Next in 18h)' : 'Spin For Free'}</span>
              </button>
            </div>
          )}

          {/* TAB 2: 7-DAY STREAK */}
          {activeTab === 'streak' && (
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 via-slate-900 to-purple-500/20 border border-amber-500/30 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
                    <Flame className="w-5 h-5 fill-amber-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white">Day 3 Active Streak</h4>
                    <p className="text-[11px] text-slate-400">Keep opening daily to unlock the Day 7 Mega Chest!</p>
                  </div>
                </div>

                <span className="text-xs font-black text-amber-300 font-mono">
                  3 / 7 Days
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                {streakDays.map((d) => (
                  <div
                    key={d.day}
                    className={`p-3 rounded-2xl border flex flex-col justify-between transition-all ${
                      d.isClaimed
                        ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                        : d.isCurrent
                        ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-lg shadow-amber-500/10'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black font-mono">{d.label}</span>
                      {d.isClaimed ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      ) : d.isLocked ? (
                        <Lock className="w-3.5 h-3.5 text-slate-500" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                      )}
                    </div>

                    <div className="my-2">
                      <span className="text-base font-mono font-black text-white block">
                        +{d.rewardCoins.toLocaleString()}
                      </span>
                      <span className="text-[10px] text-slate-400">Virtual Coins</span>
                    </div>

                    {d.isClaimed ? (
                      <span className="text-[10px] font-bold text-emerald-400 py-1 bg-emerald-500/10 rounded-lg text-center">
                        Claimed ✓
                      </span>
                    ) : d.isCurrent ? (
                      <button
                        onClick={handleClaimDay3}
                        className="w-full py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 text-xs font-black active:scale-95 shadow-md"
                      >
                        Claim Now
                      </button>
                    ) : (
                      <span className="text-[10px] text-slate-500 py-1 text-center font-semibold">
                        Locked
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: MILESTONE CHESTS */}
          {activeTab === 'chests' && (
            <div className="space-y-2.5">
              {[
                { title: 'Call Break Novice', desc: 'Make 3 successful bids in Call Break', reward: '+500 Coins', progress: '3 / 3', completed: true },
                { title: 'Teen Patti High Roller', desc: 'Win 2 showdown hands in Teen Patti', reward: '+750 Coins', progress: '1 / 2', completed: false },
                { title: 'Ludo Speedster', desc: 'Take 2 tokens safely to Home in Ludo', reward: '+600 Coins', progress: '2 / 2', completed: true },
                { title: 'Rummy Grand Slam', desc: 'Declare a pure sequence hand in 13-Card Rummy', reward: '+800 Coins', progress: '1 / 1', completed: true },
              ].map((chest, i) => (
                <div
                  key={i}
                  className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
                      <Gift className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">{chest.title}</h4>
                      <p className="text-[10px] text-slate-400">{chest.desc}</p>
                      <span className="text-[10px] text-amber-300 font-mono font-bold mt-0.5 block">
                        {chest.reward}
                      </span>
                    </div>
                  </div>

                  <div>
                    {chest.completed ? (
                      <button
                        onClick={() => {
                          demoPointsService.refillFreeCoins(500);
                          audioEffectsService.playCoinReward();
                          setClaimedNotice(`${chest.reward} Claimed!`);
                          setTimeout(() => setClaimedNotice(null), 3000);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs active:scale-95"
                      >
                        Claim
                      </button>
                    ) : (
                      <span className="text-xs text-slate-400 font-mono bg-slate-800 px-2 py-1 rounded-lg">
                        {chest.progress}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
