import React, { useState, useEffect, useMemo } from 'react';
import { 
  ArrowLeft, RotateCcw, HelpCircle, Trophy, Sparkles, 
  ShieldCheck, Eye, EyeOff, Plus, Minus, Crown, Flame 
} from 'lucide-react';
import { demoPointsService } from '../../services/demoPointsService';
import { audioEffectsService } from '../../services/audioEffectsService';
import MultiplayerRoomBar from './MultiplayerRoomBar';
import { Card, Suit, Rank } from './CallBreakGame';

interface TeenPattiGameProps {
  onBack: () => void;
}

interface TPPlayer {
  id: string;
  name: string;
  avatar: string;
  isHuman: boolean;
  cards: Card[];
  isSeen: boolean;
  isPacked: boolean;
  currentBet: number;
  totalInvested: number;
}

type HandType = 'Trail (Trio)' | 'Pure Sequence' | 'Sequence' | 'Color (Flush)' | 'Pair' | 'High Card';

interface HandEvaluation {
  handType: HandType;
  score: number;
  description: string;
}

const SUIT_ICONS: Record<Suit, string> = {
  spades: '♠',
  hearts: '♥',
  diamonds: '♦',
  clubs: '♣',
};

const SUIT_COLORS: Record<Suit, string> = {
  spades: 'text-slate-900',
  hearts: 'text-red-600',
  diamonds: 'text-rose-600',
  clubs: 'text-amber-800',
};

function createDeck(): Card[] {
  const suits: Suit[] = ['spades', 'hearts', 'diamonds', 'clubs'];
  const ranks: Rank[] = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  const deck: Card[] = [];

  for (const suit of suits) {
    for (let i = 0; i < ranks.length; i++) {
      deck.push({
        id: `${ranks[i]}_${suit}_${Math.random().toString(36).substr(2, 4)}`,
        suit,
        rank: ranks[i],
        value: i + 2,
      });
    }
  }

  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }

  return deck;
}

function evaluateTeenPattiHand(cards: Card[]): HandEvaluation {
  if (cards.length < 3) return { handType: 'High Card', score: 0, description: 'Incomplete' };

  // Sort values descending
  const sorted = [...cards].sort((a, b) => b.value - a.value);
  const [c1, c2, c3] = sorted;

  const isFlush = c1.suit === c2.suit && c2.suit === c3.suit;
  const isTrio = c1.value === c2.value && c2.value === c3.value;
  const isPair = c1.value === c2.value || c2.value === c3.value || c1.value === c3.value;

  // Straight check (A-K-Q, K-Q-J ... A-2-3)
  const isStraightNormal = c1.value - c2.value === 1 && c2.value - c3.value === 1;
  const isA23Straight = c1.value === 14 && c2.value === 3 && c3.value === 2;
  const isStraight = isStraightNormal || isA23Straight;

  // Scoring weights: Trio > Pure Seq > Seq > Flush > Pair > High Card
  if (isTrio) {
    return {
      handType: 'Trail (Trio)',
      score: 600000 + c1.value * 100,
      description: `Three of a Kind (${c1.rank}'s)`,
    };
  }

  if (isFlush && isStraight) {
    return {
      handType: 'Pure Sequence',
      score: 500000 + (isA23Straight ? 14 : c1.value) * 100,
      description: `Pure Sequence (${c1.rank}-${c2.rank}-${c3.rank} ${SUIT_ICONS[c1.suit]})`,
    };
  }

  if (isStraight) {
    return {
      handType: 'Sequence',
      score: 400000 + (isA23Straight ? 14 : c1.value) * 100,
      description: `Sequence (${c1.rank}-${c2.rank}-${c3.rank})`,
    };
  }

  if (isFlush) {
    return {
      handType: 'Color (Flush)',
      score: 300000 + c1.value * 100 + c2.value * 10 + c3.value,
      description: `Color Flush (${SUIT_ICONS[c1.suit]})`,
    };
  }

  if (isPair) {
    const pairVal = c1.value === c2.value ? c1.value : c2.value === c3.value ? c2.value : c1.value;
    const kicker = c1.value === c2.value ? c3.value : c2.value === c3.value ? c1.value : c2.value;
    return {
      handType: 'Pair',
      score: 200000 + pairVal * 100 + kicker,
      description: `Pair of ${pairVal}`,
    };
  }

  return {
    handType: 'High Card',
    score: 100000 + c1.value * 100 + c2.value * 10 + c3.value,
    description: `High Card ${c1.rank}`,
  };
}

export default function TeenPattiGame({ onBack }: TeenPattiGameProps) {
  const [pot, setPot] = useState(0);
  const [bootAmount] = useState(20);
  const [currentStake, setCurrentStake] = useState(20);
  const [currentTurn, setCurrentTurn] = useState(0); // 0: User, 1: Vikram, 2: Ananya, 3: Rohan
  const [phase, setPhase] = useState<'betting' | 'showdown'>('betting');
  const [showdownResult, setShowdownResult] = useState<{ winner: TPPlayer; handDesc: string } | null>(null);
  const [showRules, setShowRules] = useState(false);
  const [coinsBalance, setCoinsBalance] = useState(demoPointsService.getPoints());

  const initialPlayers: TPPlayer[] = useMemo(() => [
    {
      id: 'tp0',
      name: 'You (Player)',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
      isHuman: true,
      cards: [],
      isSeen: false,
      isPacked: false,
      currentBet: 0,
      totalInvested: 0,
    },
    {
      id: 'tp1',
      name: 'Vikram',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
      isHuman: false,
      cards: [],
      isSeen: false,
      isPacked: false,
      currentBet: 0,
      totalInvested: 0,
    },
    {
      id: 'tp2',
      name: 'Ananya',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80',
      isHuman: false,
      cards: [],
      isSeen: false,
      isPacked: false,
      currentBet: 0,
      totalInvested: 0,
    },
    {
      id: 'tp3',
      name: 'Rohan',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80',
      isHuman: false,
      cards: [],
      isSeen: false,
      isPacked: false,
      currentBet: 0,
      totalInvested: 0,
    },
  ], []);

  const [players, setPlayers] = useState<TPPlayer[]>(initialPlayers);
  const [isMultiplayer, setIsMultiplayer] = useState(false);

  // Subscribe to coins
  useEffect(() => {
    const unsub = demoPointsService.subscribe(setCoinsBalance);
    return () => unsub();
  }, []);

  // Start new round
  const dealNewGame = () => {
    const deck = createDeck();
    const p0Cards = deck.slice(0, 3);
    const p1Cards = deck.slice(3, 6);
    const p2Cards = deck.slice(6, 9);
    const p3Cards = deck.slice(9, 12);

    // Boot collection
    const initialPot = bootAmount * 4;
    demoPointsService.deductPoints(bootAmount, 'Teen Patti Boot', 'Initial boot deduction for 4-player table');

    setPlayers([
      { ...initialPlayers[0], cards: p0Cards, isSeen: false, isPacked: false, currentBet: bootAmount, totalInvested: bootAmount },
      { ...initialPlayers[1], cards: p1Cards, isSeen: false, isPacked: false, currentBet: bootAmount, totalInvested: bootAmount },
      { ...initialPlayers[2], cards: p2Cards, isSeen: false, isPacked: false, currentBet: bootAmount, totalInvested: bootAmount },
      { ...initialPlayers[3], cards: p3Cards, isSeen: false, isPacked: false, currentBet: bootAmount, totalInvested: bootAmount },
    ]);

    setPot(initialPot);
    setCurrentStake(bootAmount);
    setPhase('betting');
    setCurrentTurn(0);
    setShowdownResult(null);
  };

  useEffect(() => {
    dealNewGame();
  }, []);

  const activePlayers = players.filter(p => !p.isPacked);

  // Bot Turn Automation
  useEffect(() => {
    if (phase !== 'betting') return;
    if (currentTurn === 0) return; // User turn

    const bot = players[currentTurn];
    if (!bot || bot.isPacked) {
      advanceTurn();
      return;
    }

    const timer = setTimeout(() => {
      // Bot decision logic
      const evalResult = evaluateTeenPattiHand(bot.cards);
      const isGoodHand = evalResult.score >= 200000; // Pair or better

      // Bot decides to see cards if not already seen
      if (!bot.isSeen && Math.random() > 0.4) {
        setPlayers(prev => prev.map((p, idx) => idx === currentTurn ? { ...p, isSeen: true } : p));
      }

      // Check if only 2 players left -> Bot can Show
      if (activePlayers.length === 2 && Math.random() > 0.6) {
        handleShowdown();
        return;
      }

      // Bot fold condition
      if (!isGoodHand && bot.isSeen && Math.random() > 0.55 && pot > 200) {
        packPlayer(currentTurn);
        return;
      }

      // Chaal / Blind Bet
      const betAmt = bot.isSeen ? currentStake * 2 : currentStake;
      placeBet(currentTurn, betAmt);
    }, 900);

    return () => clearTimeout(timer);
  }, [currentTurn, phase, players, activePlayers.length]);

  const advanceTurn = () => {
    let nextIdx = (currentTurn + 1) % 4;
    while (players[nextIdx].isPacked) {
      nextIdx = (nextIdx + 1) % 4;
    }
    setCurrentTurn(nextIdx);
  };

  const placeBet = (playerIdx: number, amount: number) => {
    const player = players[playerIdx];

    if (player.isHuman) {
      audioEffectsService.playCoinReward();
      demoPointsService.deductPoints(amount, 'Teen Patti Chaal', 'In-game virtual bet');
    }

    setPot(p => p + amount);
    setPlayers(prev => prev.map((p, idx) => {
      if (idx === playerIdx) {
        return {
          ...p,
          currentBet: amount,
          totalInvested: p.totalInvested + amount,
        };
      }
      return p;
    }));

    // If only one player left un-packed, they win automatically
    const remaining = players.filter((p, idx) => idx === playerIdx || !p.isPacked);
    if (remaining.length === 1) {
      triggerWinner(remaining[0], 'All opponents packed (folded)');
      return;
    }

    advanceTurn();
  };

  const packPlayer = (playerIdx: number) => {
    setPlayers(prev => prev.map((p, idx) => idx === playerIdx ? { ...p, isPacked: true } : p));

    const remaining = players.filter((p, idx) => idx !== playerIdx && !p.isPacked);
    if (remaining.length === 1) {
      triggerWinner(remaining[0], 'All other players packed!');
    } else {
      advanceTurn();
    }
  };

  const handleSeeCards = () => {
    setPlayers(prev => prev.map((p, idx) => idx === 0 ? { ...p, isSeen: true } : p));
  };

  const handleShowdown = () => {
    setPhase('showdown');
    // Evaluate all active players
    let bestPlayer = activePlayers[0];
    let bestEval = evaluateTeenPattiHand(bestPlayer.cards);

    for (let i = 1; i < activePlayers.length; i++) {
      const challenger = activePlayers[i];
      const chEval = evaluateTeenPattiHand(challenger.cards);
      if (chEval.score > bestEval.score) {
        bestPlayer = challenger;
        bestEval = chEval;
      }
    }

    triggerWinner(bestPlayer, bestEval.description);
  };

  const triggerWinner = (winner: TPPlayer, handDesc: string) => {
    setPhase('showdown');
    setShowdownResult({ winner, handDesc });

    if (winner.isHuman) {
      demoPointsService.addPoints(pot, 'Teen Patti Victory', `Won showdown with ${handDesc}`);
      demoPointsService.recordMatch({
        gameName: 'Teen Patti',
        gameKey: 'teen-patti',
        result: 'WON',
        coinsWon: pot,
        coinsSpent: winner.totalInvested,
        details: `Won ${pot} Virtual Coins • Hand: ${handDesc}`,
      });
    } else {
      demoPointsService.recordMatch({
        gameName: 'Teen Patti',
        gameKey: 'teen-patti',
        result: 'LOST',
        coinsWon: 0,
        coinsSpent: players[0].totalInvested,
        details: `Winner: ${winner.name} (${handDesc})`,
      });
    }
  };

  const humanPlayer = players[0];
  const humanHandEval = useMemo(() => evaluateTeenPattiHand(humanPlayer.cards), [humanPlayer.cards]);
  const userMinBet = humanPlayer.isSeen ? currentStake * 2 : currentStake;

  return (
    <div id="teen-patti-game-screen" className="flex flex-col h-full bg-[#040810] text-slate-100 overflow-hidden select-none">
      {/* Top Header */}
      <div className="px-4 py-2.5 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black tracking-wider text-amber-400 uppercase font-mono">🎴 Teen Patti</span>
              <span className="px-1.5 py-0.2 rounded bg-red-500/20 text-red-300 text-[10px] font-bold border border-red-500/30">
                4-Player Live Table
              </span>
            </div>
            <span className="text-[10px] text-slate-400">Pure Indian 3-Card Poker • Virtual Coins Only</span>
          </div>
        </div>

        {/* Right Header Balance & Rules */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold font-mono">
            <span>🪙</span>
            <span>{coinsBalance.toLocaleString()}</span>
          </div>
          <button
            onClick={() => setShowRules(true)}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs"
            title="Teen Patti Rules"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Multiplayer & AI Tactical Bar */}
      <MultiplayerRoomBar
        gameId="teen-patti"
        gameTitle="Teen Patti Royal"
        isMultiplayer={isMultiplayer}
        onToggleMode={setIsMultiplayer}
      />

      {/* Main Oval Green Table */}
      <div className="flex-1 relative flex flex-col justify-between p-3 bg-radial from-[#123820] via-[#071a10] to-[#040810] overflow-hidden">
        {/* Table Felt Rim & Center Logo */}
        <div className="absolute inset-3 rounded-[50px] border-4 border-amber-600/30 pointer-events-none shadow-[inset_0_0_80px_rgba(0,0,0,0.85)] flex items-center justify-center">
          <div className="text-emerald-500/10 font-black text-4xl tracking-widest uppercase select-none font-mono">
            KhelMitra
          </div>
        </div>

        {/* North Seat: Ananya */}
        <div className="flex flex-col items-center relative z-10">
          <PlayerSeatView 
            player={players[2]} 
            isCurrentTurn={currentTurn === 2} 
            showCards={phase === 'showdown'}
          />
        </div>

        {/* Middle Row: West Seat | Center Pot Tray | East Seat */}
        <div className="flex items-center justify-between relative z-10 my-auto px-2">
          {/* West: Vikram */}
          <PlayerSeatView 
            player={players[1]} 
            isCurrentTurn={currentTurn === 1} 
            showCards={phase === 'showdown'}
          />

          {/* Center Table: Virtual Pot */}
          <div className="flex flex-col items-center justify-center px-4 py-3 rounded-2xl bg-black/60 border border-amber-500/40 backdrop-blur-md shadow-2xl">
            <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold uppercase tracking-wider">
              <span>🪙 Total Pot</span>
            </div>
            <div className="text-xl font-black text-amber-300 font-mono mt-0.5 animate-pulse">
              {pot.toLocaleString()} Coins
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              Current Stake: {currentStake}
            </div>
          </div>

          {/* East: Rohan */}
          <PlayerSeatView 
            player={players[3]} 
            isCurrentTurn={currentTurn === 3} 
            showCards={phase === 'showdown'}
          />
        </div>

        {/* South Seat: Human Player */}
        <div className="relative z-10 flex flex-col items-center">
          {/* Player Cards Display */}
          <div className="relative flex items-center justify-center -space-x-3 mb-2">
            {humanPlayer.cards.map((card, i) => (
              <div 
                key={card.id}
                style={{ transform: `rotate(${(i - 1) * 6}deg)` }}
                className="transition-transform duration-300"
              >
                {humanPlayer.isSeen || phase === 'showdown' ? (
                  <TPCardView card={card} />
                ) : (
                  <div className="w-14 h-20 rounded-xl bg-gradient-to-br from-red-950 via-slate-900 to-red-900 border-2 border-amber-500/40 shadow-xl flex items-center justify-center">
                    <span className="text-amber-500 font-bold text-xs font-mono">KM</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Hand Evaluation Badge */}
          {humanPlayer.isSeen && (
            <div className="px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-bold mb-2 flex items-center gap-1.5 animate-in fade-in">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{humanHandEval.handType} • {humanHandEval.description}</span>
            </div>
          )}

          {/* Player Action Controls Container */}
          <div className="w-full max-w-sm bg-slate-950/95 border border-slate-800 rounded-2xl p-3 shadow-2xl flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">{humanPlayer.name}</span>
                {humanPlayer.isSeen ? (
                  <span className="px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-500/30">
                    SEEN
                  </span>
                ) : (
                  <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                    BLIND (Cheaper)
                  </span>
                )}
              </div>
              <div className="text-[11px] text-slate-400">
                Turn: <strong className={currentTurn === 0 ? 'text-amber-400 animate-pulse' : 'text-slate-300'}>
                  {currentTurn === 0 ? 'Your Turn' : players[currentTurn].name}
                </strong>
              </div>
            </div>

            {/* Action Buttons */}
            {phase === 'betting' && !humanPlayer.isPacked && (
              <div className="grid grid-cols-4 gap-2 pt-1">
                {/* 1. Pack / Fold */}
                <button
                  disabled={currentTurn !== 0}
                  onClick={() => packPlayer(0)}
                  className="py-2.5 px-2 rounded-xl bg-red-950/60 hover:bg-red-900 border border-red-500/30 text-red-300 font-bold text-xs disabled:opacity-50 transition-all active:scale-95"
                >
                  Pack
                </button>

                {/* 2. See Cards (If Blind) */}
                {!humanPlayer.isSeen ? (
                  <button
                    onClick={handleSeeCards}
                    className="py-2.5 px-2 rounded-xl bg-blue-950/60 hover:bg-blue-900 border border-blue-500/30 text-blue-300 font-bold text-xs flex items-center justify-center gap-1 active:scale-95"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>See</span>
                  </button>
                ) : (
                  <button
                    disabled
                    className="py-2.5 px-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-500 font-bold text-xs flex items-center justify-center gap-1"
                  >
                    <EyeOff className="w-3.5 h-3.5" />
                    <span>Seen</span>
                  </button>
                )}

                {/* 3. Chaal / Blind Bet */}
                <button
                  disabled={currentTurn !== 0}
                  onClick={() => placeBet(0, userMinBet)}
                  className="py-2.5 px-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs disabled:opacity-50 transition-all active:scale-95 shadow-md flex flex-col items-center justify-center"
                >
                  <span>{humanPlayer.isSeen ? 'Chaal' : 'Blind'}</span>
                  <span className="text-[10px] font-mono leading-none">+{userMinBet} 🪙</span>
                </button>

                {/* 4. Show (Available when only 2 players remain) */}
                <button
                  disabled={currentTurn !== 0 || activePlayers.length > 2}
                  onClick={handleShowdown}
                  className="py-2.5 px-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 font-bold text-xs disabled:opacity-40 transition-all active:scale-95 flex flex-col items-center justify-center"
                >
                  <span>Show</span>
                  <span className="text-[9px] text-emerald-400/80 leading-none">
                    {activePlayers.length === 2 ? 'Showdown' : '2 Left'}
                  </span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Showdown Victory Modal */}
      {phase === 'showdown' && showdownResult && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0a0f1d] border border-amber-500/40 rounded-3xl p-5 shadow-2xl text-center animate-in zoom-in-95">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mx-auto mb-3 text-amber-400">
              <Trophy className="w-9 h-9 animate-bounce" />
            </div>
            <h3 className="text-xl font-black text-white">{showdownResult.winner.name} Wins!</h3>
            <p className="text-xs text-amber-300 mt-1 font-semibold">{showdownResult.handDesc}</p>

            <div className="my-4 p-3 rounded-2xl bg-slate-950/80 border border-amber-500/20">
              <span className="text-xs text-slate-400 block mb-1">Total Virtual Pot Collected</span>
              <span className="text-2xl font-black text-amber-400 font-mono">+{pot.toLocaleString()} 🪙</span>
            </div>

            {/* All player cards reveal */}
            <div className="space-y-2 mb-4">
              {players.filter(p => !p.isPacked).map(p => (
                <div key={p.id} className="flex items-center justify-between p-2 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <img src={p.avatar} alt="" className="w-5 h-5 rounded-full object-cover" />
                    <span className="font-bold text-white">{p.name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {p.cards.map(c => (
                      <span key={c.id} className="px-1.5 py-0.5 rounded bg-white text-slate-950 font-bold text-[10px]">
                        {c.rank}{SUIT_ICONS[c.suit]}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <button
                onClick={dealNewGame}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 active:scale-95 shadow-md"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Next Hand
              </button>
              <button
                onClick={onBack}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                Exit Table
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Rules Modal */}
      {showRules && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowRules(false)}>
          <div className="w-full max-w-sm bg-[#0c1222] border border-slate-800 rounded-3xl p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Teen Patti Hand Rankings
              </h4>
              <button onClick={() => setShowRules(false)} className="text-xs text-slate-400 hover:text-white">✕</button>
            </div>
            <div className="space-y-2 text-xs text-slate-300 leading-relaxed max-h-72 overflow-y-auto pr-1">
              <p>1. <strong>Trail (Trio)</strong>: Three cards of the same rank (e.g. A-A-A, K-K-K). Highest hand.</p>
              <p>2. <strong>Pure Sequence</strong>: Consecutive 3 cards of the same suit (e.g. A♠ K♠ Q♠).</p>
              <p>3. <strong>Sequence</strong>: Consecutive 3 cards of mixed suits (e.g. A♠ K♥ Q♦).</p>
              <p>4. <strong>Color (Flush)</strong>: All 3 cards of the same suit but not in sequence.</p>
              <p>5. <strong>Pair</strong>: Any two cards of the same rank.</p>
              <p>6. <strong>High Card</strong>: When no combination exists, highest card wins.</p>
              <p>• <strong>Blind vs Seen</strong>: Blind bet is half the Chaal bet. You can see cards anytime.</p>
              <p>• <strong>Zero Real Money</strong>: Uses 100% demo virtual coins.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PlayerSeatView({ player, isCurrentTurn, showCards }: { player: TPPlayer; isCurrentTurn: boolean; showCards: boolean }) {
  const SUIT_ICONS: Record<Suit, string> = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' };

  return (
    <div className={`flex flex-col items-center relative ${player.isPacked ? 'opacity-40' : ''}`}>
      <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/80 border ${isCurrentTurn ? 'border-amber-400 ring-2 ring-amber-400/30' : 'border-slate-800'}`}>
        <img src={player.avatar} alt="" className="w-6 h-6 rounded-full object-cover border border-slate-700" />
        <div className="text-left">
          <div className="text-[10px] font-bold text-white flex items-center gap-1">
            <span>{player.name}</span>
            {player.isPacked && <span className="text-red-400 text-[9px]">(Packed)</span>}
          </div>
          <div className="text-[9px] text-amber-400">
            {player.isSeen ? 'Seen' : 'Blind'} • Bet: {player.currentBet}
          </div>
        </div>
        {isCurrentTurn && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping ml-1"></span>}
      </div>

      {/* Cards Display */}
      <div className="flex -space-x-4 mt-1">
        {player.cards.map((c, i) => (
          <div key={i} className="w-7 h-10 rounded bg-slate-900 border border-slate-700 flex items-center justify-center text-[10px] font-bold shadow">
            {showCards ? (
              <span className="text-amber-400">{c.rank}{SUIT_ICONS[c.suit]}</span>
            ) : (
              <div className="w-full h-full rounded bg-gradient-to-br from-red-950 to-slate-950 border border-amber-500/20"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function TPCardView({ card }: { card: Card }) {
  const SUIT_ICONS: Record<Suit, string> = { spades: '♠', hearts: '♥', diamonds: '♦', clubs: '♣' };
  const SUIT_COLORS: Record<Suit, string> = { spades: 'text-slate-900', hearts: 'text-red-600', diamonds: 'text-rose-600', clubs: 'text-amber-800' };

  return (
    <div className="w-14 h-22 rounded-xl bg-white border-2 border-slate-300 shadow-xl p-1.5 flex flex-col justify-between select-none">
      <div className="flex items-center justify-between text-xs font-black text-slate-950 leading-none">
        <span>{card.rank}</span>
        <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
      </div>
      <div className={`text-xl text-center my-auto ${SUIT_COLORS[card.suit]}`}>
        {SUIT_ICONS[card.suit]}
      </div>
      <div className="flex items-center justify-between text-xs font-black text-slate-950 leading-none rotate-180">
        <span>{card.rank}</span>
        <span className={SUIT_COLORS[card.suit]}>{SUIT_ICONS[card.suit]}</span>
      </div>
    </div>
  );
}
