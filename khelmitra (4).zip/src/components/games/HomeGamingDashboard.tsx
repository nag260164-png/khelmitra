import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, Sparkles, Trophy, Flame, Play, History, 
  Settings, Gift, User, ShieldCheck, Coins, ChevronRight, 
  Users, Crown, Zap, Award, CheckCircle2, Bot, Wifi, Smartphone, Download,
  Headphones, UserPlus, Lock, KeyRound
} from 'lucide-react';
import { ActiveSheetType } from '../../types';
import { demoPointsService } from '../../services/demoPointsService';
import { audioEffectsService } from '../../services/audioEffectsService';
import { masterOwnerService } from '../../services/masterOwnerService';

interface HomeGamingDashboardProps {
  onOpenSheet: (sheet: ActiveSheetType) => void;
}

interface GameCardInfo {
  id: ActiveSheetType;
  title: string;
  subtitle: string;
  category: string;
  iconText: string;
  badge: string;
  badgeColor: string;
  rewardText: string;
  playersOnline: string;
  gradientBg: string;
  borderColor: string;
  features: string[];
}

export default function HomeGamingDashboard({ onOpenSheet }: HomeGamingDashboardProps) {
  const [coins, setCoins] = useState<number>(demoPointsService.getPoints());
  const [matchesCount, setMatchesCount] = useState<number>(0);
  const [enabledGames, setEnabledGames] = useState(masterOwnerService.getEnabledGames());
  const [copiedNotification, setCopiedNotification] = useState<string | null>(null);

  useEffect(() => {
    const unsub = demoPointsService.subscribe(setCoins);
    const unsubOwner = masterOwnerService.subscribe(() => {
      setEnabledGames({ ...masterOwnerService.getEnabledGames() });
    });
    setMatchesCount(demoPointsService.getMatchHistory().length);
    return () => {
      unsub();
      unsubOwner();
    };
  }, []);

  const handleQuickClaimBonus = () => {
    demoPointsService.refillFreeCoins(500);
    audioEffectsService.playCoinReward();
    setCopiedNotification('+500 Free Virtual Coins Claimed!');
    setTimeout(() => setCopiedNotification(null), 3000);
  };

  const handleNavClick = (sheet: ActiveSheetType) => {
    audioEffectsService.playButtonTap();
    onOpenSheet(sheet);
  };

  const getGameKey = (id: ActiveSheetType): 'callBreak' | 'teenPatti' | 'ludo' | 'rummy' => {
    if (id === 'call-break') return 'callBreak';
    if (id === 'teen-patti') return 'teenPatti';
    if (id === 'ludo') return 'ludo';
    return 'rummy';
  };

  const handleGameLaunch = (sheet: ActiveSheetType) => {
    const key = getGameKey(sheet);
    if (!enabledGames[key]) {
      setCopiedNotification(`⚠️ ${sheet.replace('-', ' ').toUpperCase()} is currently undergoing scheduled upgrade by Master Owner. Please try another skill game!`);
      setTimeout(() => setCopiedNotification(null), 4000);
      return;
    }
    audioEffectsService.playButtonTap();
    onOpenSheet(sheet);
  };

  const FOUR_GAMES: GameCardInfo[] = [
    {
      id: 'call-break',
      title: 'Call Break Master',
      subtitle: '4-Player Tactical Trick Taking',
      category: 'Card Strategy',
      iconText: '♠️',
      badge: 'POPULAR',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      rewardText: '+500 Coins',
      playersOnline: '42.8k live',
      gradientBg: 'from-amber-950/70 via-slate-900/90 to-amber-950/50',
      borderColor: 'border-amber-500/30 hover:border-amber-400/80',
      features: ['5-Round Match', 'Spades Trump Rule', 'Smart AI Seats', 'Trick Tracker'],
    },
    {
      id: 'teen-patti',
      title: 'Teen Patti Royal',
      subtitle: 'Indian 3-Card Table & Pot Showdown',
      category: 'Indian Poker',
      iconText: '🎴',
      badge: 'HOT TABLE',
      badgeColor: 'bg-red-500/20 text-red-300 border-red-500/40',
      rewardText: '+1,000 Coins',
      playersOnline: '61.4k live',
      gradientBg: 'from-red-950/70 via-slate-900/90 to-rose-950/50',
      borderColor: 'border-red-500/30 hover:border-red-400/80',
      features: ['4-Player Live Table', 'Blind & Chaal', 'Trail & Sequence', 'Pot Showdown'],
    },
    {
      id: 'ludo',
      title: 'Khel Ludo Classic',
      subtitle: 'Board Game, Dice & Safe Star Spots',
      category: 'Board Game',
      iconText: '🎲',
      badge: 'FAMILY FAVORITE',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
      rewardText: '+600 Coins',
      playersOnline: '78.2k live',
      gradientBg: 'from-emerald-950/70 via-slate-900/90 to-teal-950/50',
      borderColor: 'border-emerald-500/30 hover:border-emerald-400/80',
      features: ['2P & 4P Modes', '3D Rolling Dice', 'Safe Stars ⭐', 'Capture & Home'],
    },
    {
      id: 'rummy',
      title: '13-Card Indian Rummy',
      subtitle: 'Pure Sequences, Sets & Discard Pile',
      category: 'Classic Rummy',
      iconText: '🃏',
      badge: 'SKILL GAME',
      badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
      rewardText: '+800 Coins',
      playersOnline: '53.9k live',
      gradientBg: 'from-blue-950/70 via-slate-900/90 to-indigo-950/50',
      borderColor: 'border-blue-500/30 hover:border-blue-400/80',
      features: ['Auto-Sort Cards', 'Wild Joker', 'Pure Seq Validator', 'Fast Discard'],
    },
  ];

  return (
    <section id="home-gaming-dashboard" className="px-4 py-3 space-y-3">
      {/* 1. Main Header with KhelMitra Branding & Live Indicator */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900/90 to-amber-950/50 border border-purple-500/30 shadow-xl flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-purple-600 p-0.5 shadow-lg">
              <div className="w-full h-full bg-[#090e1a] rounded-[10px] flex items-center justify-center text-amber-400">
                <Gamepad2 className="w-5 h-5" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-black text-white tracking-wider uppercase font-mono">
                  KhelMitra Gaming Arena
                </h2>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              </div>
              <span className="text-[10px] text-slate-400">
                4 Free-to-Play Games • 100% Virtual Coins • Zero Risk
              </span>
            </div>
          </div>

          <button
            onClick={() => onOpenSheet('games')}
            className="px-2.5 py-1 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold flex items-center gap-1 active:scale-95 transition-all"
          >
            <span>Arcade</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 2. Virtual Coin Balance & Quick Refill Banner */}
        <div className="p-2.5 rounded-xl bg-slate-950/80 border border-amber-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-base font-bold">
              🪙
            </div>
            <div>
              <span className="text-[9px] text-slate-400 uppercase font-bold tracking-wider block leading-none">
                Virtual Coin Balance
              </span>
              <span className="text-sm font-black text-amber-300 font-mono mt-0.5 block">
                {coins.toLocaleString()} <span className="text-[10px] text-amber-400 font-bold">COINS</span>
              </span>
            </div>
          </div>

          <button
            onClick={handleQuickClaimBonus}
            className="py-1.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5 text-slate-950" />
            <span>+500 Free</span>
          </button>
        </div>

        {copiedNotification && (
          <div className="text-center py-1 px-3 bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold rounded-lg animate-in fade-in">
            {copiedNotification}
          </div>
        )}

        {/* 3. Essential Utility Hub: Missions | Rewards | Ranks | History | Invite | Support | Profile | Settings */}
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 pt-1">
          {/* Daily Missions */}
          <button
            id="hub-missions-btn"
            onClick={() => handleNavClick('daily-missions')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Gift className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight">Missions</span>
          </button>

          {/* Rewards */}
          <button
            id="hub-rewards-btn"
            onClick={() => handleNavClick('rewards')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/50 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-purple-500/15 text-purple-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight">Rewards</span>
          </button>

          {/* Leaderboard */}
          <button
            id="hub-leaderboard-btn"
            onClick={() => handleNavClick('leaderboard')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Trophy className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight">Ranks</span>
          </button>

          {/* Game History */}
          <button
            id="hub-history-btn"
            onClick={() => handleNavClick('game-history')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/50 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-blue-500/15 text-blue-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <History className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight">History</span>
          </button>

          {/* Invite Friends */}
          <button
            id="hub-invite-btn"
            onClick={() => handleNavClick('invite-friends')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-amber-400/60 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <UserPlus className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight text-amber-300">Invite</span>
          </button>

          {/* Customer Care */}
          <button
            id="hub-support-btn"
            onClick={() => handleNavClick('customer-care')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-blue-400/60 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Headphones className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight text-blue-300">Support</span>
          </button>

          {/* Profile */}
          <button
            id="hub-profile-btn"
            onClick={() => handleNavClick('profile')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <User className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight">Profile</span>
          </button>

          {/* Settings */}
          <button
            id="hub-settings-btn"
            onClick={() => handleNavClick('settings')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-600 text-slate-300 hover:text-white active:scale-95 transition-all group"
          >
            <div className="w-6 h-6 rounded-lg bg-slate-800 text-slate-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Settings className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight">Settings</span>
          </button>

          {/* Master Owner Panel Button */}
          <button
            id="hub-master-owner-btn"
            onClick={() => handleNavClick('master-owner')}
            className="flex flex-col items-center justify-center p-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 hover:border-amber-400 text-amber-300 active:scale-95 transition-all group"
            title="Master Owner Control Panel"
          >
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-1 group-hover:scale-110 transition-transform">
              <Lock className="w-3.5 h-3.5" />
            </div>
            <span className="text-[9px] font-bold leading-tight text-amber-400">Owner</span>
          </button>
        </div>

        {/* Quick Duo: Invite Friends + 24/7 Customer Care */}
        <div className="grid grid-cols-2 gap-2 pt-0.5">
          <div
            id="quick-banner-invite-friends"
            onClick={() => handleNavClick('invite-friends')}
            className="p-2.5 rounded-2xl bg-gradient-to-br from-amber-950/60 via-slate-900 to-amber-950/30 border border-amber-500/30 hover:border-amber-400/60 cursor-pointer active:scale-95 transition-all flex items-center gap-2 shadow-md shadow-black/30"
          >
            <div className="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <UserPlus className="w-3.5 h-3.5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-white leading-tight truncate">Invite Friends</span>
              </div>
              <span className="text-[10px] text-amber-300 font-semibold truncate block">+1,000 Coins / Invite</span>
            </div>
          </div>

          <div
            id="quick-banner-customer-care"
            onClick={() => handleNavClick('customer-care')}
            className="p-2.5 rounded-2xl bg-gradient-to-br from-blue-950/60 via-slate-900 to-indigo-950/30 border border-blue-500/30 hover:border-blue-400/60 cursor-pointer active:scale-95 transition-all flex items-center gap-2 shadow-md shadow-black/30"
          >
            <div className="w-7 h-7 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
              <Headphones className="w-3.5 h-3.5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-white leading-tight truncate">Customer Care</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-semibold truncate block">24/7 WhatsApp & Help</span>
            </div>
          </div>
        </div>

        {/* Android APK Download & Install Callout Banner */}
        <div 
          onClick={() => handleNavClick('apk-download')}
          className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950/60 via-slate-900/90 to-emerald-950/40 border border-emerald-500/30 hover:border-emerald-400/70 cursor-pointer active:scale-[0.98] transition-all flex items-center justify-between shadow-lg shadow-black/40"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white leading-tight">Get KhelMitra Android APK</span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/30">
                  v1.0 Ready
                </span>
              </div>
              <span className="text-[10px] text-slate-300">
                Direct APK project download & instant PWA install
              </span>
            </div>
          </div>
          <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 group-hover:bg-emerald-500 group-hover:text-slate-950 transition-colors">
            <Download className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* 4. Four Game Cards with Attractive Icons & Play Now Buttons */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-wider text-amber-400 font-mono">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Featured Free Games (4)</span>
          </div>
          <span className="text-[10px] text-slate-400 font-semibold flex items-center gap-1">
            <Users className="w-3 h-3 text-emerald-400" />
            <span>236k Active Players</span>
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {FOUR_GAMES.map((game) => {
            const isGameActive = enabledGames[getGameKey(game.id)];

            return (
              <div
                key={game.id}
                id={`game-card-${game.id}`}
                className={`p-3.5 rounded-2xl bg-gradient-to-br ${game.gradientBg} border ${game.borderColor} shadow-xl flex flex-col justify-between transition-all group hover:scale-[1.01] ${!isGameActive ? 'opacity-85' : ''}`}
              >
                <div>
                  {/* Card Top Row: Big Icon + Badges */}
                  <div className="flex items-start justify-between mb-2">
                    <div className="w-11 h-11 rounded-2xl bg-slate-950/80 border border-slate-700/80 flex items-center justify-center text-2xl shadow-inner group-hover:scale-110 transition-transform">
                      {game.iconText}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-full border ${
                        !isGameActive 
                          ? 'bg-red-500/20 text-red-300 border-red-500/40' 
                          : game.badgeColor
                      }`}>
                        {!isGameActive ? 'MAINTENANCE' : game.badge}
                      </span>
                      <span className="text-[10px] text-amber-300 font-mono font-bold">
                        {game.rewardText}
                      </span>
                    </div>
                  </div>

                  {/* Title & Subtitle */}
                  <h3 className="text-sm font-black text-white group-hover:text-amber-300 transition-colors">
                    {game.title}
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5 line-clamp-1">
                    {game.subtitle}
                  </p>

                  {/* Feature Chips */}
                  <div className="flex flex-wrap gap-1 mt-2.5">
                    {game.features.slice(0, 3).map((feat, idx) => (
                      <span
                        key={idx}
                        className="px-1.5 py-0.5 rounded-md bg-black/40 border border-slate-800 text-[9px] text-slate-400 font-medium"
                      >
                        {feat}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom Row: Active Players & "Play Now" Button */}
                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <span className={`w-1.5 h-1.5 rounded-full ${isGameActive ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`}></span>
                    <span>{isGameActive ? game.playersOnline : 'Upgrading'}</span>
                  </span>

                  <button
                    id={`play-now-${game.id}-btn`}
                    onClick={() => handleGameLaunch(game.id)}
                    className={`py-1.5 px-3.5 rounded-xl font-black text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all ${
                      isGameActive
                        ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Play className="w-3 h-3 fill-current ml-0.5" />
                    <span>{isGameActive ? 'Play Now' : 'Upgrading'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
