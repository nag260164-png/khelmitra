import { useState, useEffect } from 'react';
import { 
  X, Volume2, VolumeX, Sparkles, CheckCircle2, 
  Play, Radio, Trophy, ShieldCheck, Flame, Zap
} from 'lucide-react';
import { dailyMissionService } from '../../services/dailyMissionService';

interface SimulatedAdModalProps {
  onClose: () => void;
  onRewardEarned: (coins: number) => void;
}

const AD_CAMPAIGNS = [
  {
    sponsor: 'SG Cricket Pro Gear',
    tagline: 'English Willow Bats & Test-Grade Batting Gloves',
    accentColor: 'from-amber-500 to-red-600',
    badgeText: 'OFFICIAL CRICKET PARTNER',
    ctaText: 'Visit Pro Cricket Shop',
    discountCode: 'KHEL20',
  },
  {
    sponsor: 'SpeedSter Energy Drink',
    tagline: 'Zero Sugar • High Electrolytes for Super Over Stamina',
    accentColor: 'from-blue-500 to-indigo-600',
    badgeText: 'MATCHDAY ENERGY',
    ctaText: 'Grab Sports Hydration Pack',
    discountCode: 'ENERGY50',
  },
  {
    sponsor: 'CricPass OTT Live Stream',
    tagline: 'Watch World T20 Matches in 4K Ultra HD & Dolby Atmos',
    accentColor: 'from-emerald-500 to-teal-600',
    badgeText: 'LIVE BROADCAST PARTNER',
    ctaText: 'Explore Cricket Pass',
    discountCode: 'CRICLIVE',
  },
];

export default function SimulatedAdModal({ onClose, onRewardEarned }: SimulatedAdModalProps) {
  const [secondsRemaining, setSecondsRemaining] = useState(5);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isClaimed, setIsClaimed] = useState(false);
  const [campaign] = useState(() => 
    AD_CAMPAIGNS[Math.floor(Math.random() * AD_CAMPAIGNS.length)]
  );

  // 5-second countdown timer for the simulated video ad
  useEffect(() => {
    if (secondsRemaining <= 0) {
      setIsCompleted(true);
      return;
    }

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [secondsRemaining]);

  const handleClaimAdReward = () => {
    if (!isCompleted || isClaimed) return;
    setIsClaimed(true);

    const result = dailyMissionService.recordAdWatched();
    if (result.success) {
      onRewardEarned(result.coins);
    }
  };

  return (
    <div 
      id="simulated-ad-overlay"
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
    >
      <div 
        id="simulated-ad-card"
        className="w-full max-w-sm rounded-3xl bg-[#0a0f1d] border border-amber-500/40 shadow-2xl overflow-hidden flex flex-col text-slate-100 relative"
      >
        {/* Top Ad Navigation Bar */}
        <div className="px-4 py-2.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-amber-300 font-mono text-[10px] font-black uppercase tracking-wider">
              Sponsor Ad
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Reward in: {secondsRemaining > 0 ? `${secondsRemaining}s` : 'Ready!'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMuted(!isMuted)}
              className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            </button>

            {isCompleted ? (
              <button
                id="close-ad-btn"
                onClick={onClose}
                className="p-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95"
                title="Close ad"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <span className="text-[10px] font-mono text-slate-500 px-1">
                Skip in {secondsRemaining}s
              </span>
            )}
          </div>
        </div>

        {/* Video Stage / Visual Simulation */}
        <div className="relative h-56 bg-gradient-to-br from-slate-950 via-[#0d162b] to-[#080d1a] flex flex-col items-center justify-center p-6 text-center overflow-hidden border-b border-slate-800">
          {/* Animated Background Rings */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
            <div className="w-64 h-64 rounded-full border border-amber-500/30 animate-ping"></div>
          </div>

          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] font-black uppercase tracking-wider mb-2">
            {campaign.badgeText}
          </span>

          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg shadow-amber-500/30 mb-3 animate-pulse">
            <Trophy className="w-8 h-8 fill-slate-950" />
          </div>

          <h3 className="text-lg font-black text-white tracking-tight leading-tight">
            {campaign.sponsor}
          </h3>
          <p className="text-xs text-slate-300 mt-1 max-w-[260px] leading-relaxed">
            {campaign.tagline}
          </p>

          <div className="mt-3 px-3 py-1 rounded-full bg-slate-900/90 border border-slate-700 text-[10px] text-amber-300 font-mono">
            Promo Code: <strong>{campaign.discountCode}</strong> (Save 20%)
          </div>

          {/* Video Progress Bar */}
          <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-slate-900">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-1000 ease-linear"
              style={{ width: `${((5 - secondsRemaining) / 5) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Bottom Reward Action Container */}
        <div className="p-4 bg-[#090e1b] space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-medium">Demo Ad Reward</span>
            <span className="text-amber-400 font-mono font-black flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              +50 Demo Coins
            </span>
          </div>

          {!isCompleted ? (
            <div className="w-full py-3 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
              <span className="text-xs font-mono text-slate-400 flex items-center justify-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                Playing Clip... {secondsRemaining}s remaining
              </span>
            </div>
          ) : isClaimed ? (
            <div className="space-y-2">
              <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-center text-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 animate-in zoom-in-95">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>+50 Demo Coins Added to Wallet!</span>
              </div>
              <button
                onClick={onClose}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs active:scale-95 transition-all"
              >
                Close & Return
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              <button
                id="claim-ad-reward-btn"
                onClick={handleClaimAdReward}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 active:scale-95 transition-all"
              >
                <Sparkles className="w-4 h-4 fill-slate-950" />
                <span>Claim +50 Demo Coins</span>
              </button>
              <span className="text-[10px] text-slate-500 text-center block">
                Free-to-play demo credit • No real money purchase required
              </span>
            </div>
          )}

          {/* Fair play reminder */}
          <div className="pt-1 flex items-center justify-center gap-1 text-[10px] text-slate-500">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>KhelMitra 100% Free Demo Arcade</span>
          </div>
        </div>
      </div>
    </div>
  );
}
