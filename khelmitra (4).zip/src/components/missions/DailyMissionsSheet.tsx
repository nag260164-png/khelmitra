import { useState, useEffect } from 'react';
import { 
  ArrowLeft, CalendarCheck, Flame, Sparkles, Clock, 
  Trophy, PlayCircle, HelpCircle, Gamepad2, CheckCircle2, 
  ChevronRight, ShieldCheck, Lock, Gift, RefreshCw, 
  Coins, Zap, AlertCircle
} from 'lucide-react';
import { 
  dailyMissionService, 
  DAILY_LOGIN_REWARDS 
} from '../../services/dailyMissionService';
import { demoPointsService } from '../../services/demoPointsService';
import { DailyMission, DailyMissionState, ActiveSheetType } from '../../types';
import SimulatedAdModal from './SimulatedAdModal';

interface DailyMissionsSheetProps {
  onClose: () => void;
  onNavigateToSheet?: (sheet: ActiveSheetType) => void;
}

export default function DailyMissionsSheet({ 
  onClose, 
  onNavigateToSheet 
}: DailyMissionsSheetProps) {
  const [state, setState] = useState<DailyMissionState>(dailyMissionService.getState());
  const [missions, setMissions] = useState<DailyMission[]>(dailyMissionService.getMissionsList());
  const [demoPoints, setDemoPoints] = useState<number>(demoPointsService.getPoints());
  const [countdown, setCountdown] = useState<string>(dailyMissionService.getTimeUntilMidnight());
  const [showAdModal, setShowAdModal] = useState(false);
  const [claimFeedback, setClaimFeedback] = useState<{ title: string; coins: number } | null>(null);

  // Sync state & points
  useEffect(() => {
    const unsubMission = dailyMissionService.subscribe((newState) => {
      setState(newState);
      setMissions(dailyMissionService.getMissionsList());
    });

    const unsubPoints = demoPointsService.subscribe((newPoints) => {
      setDemoPoints(newPoints);
    });

    // 1-second interval for countdown timer
    const interval = setInterval(() => {
      setCountdown(dailyMissionService.getTimeUntilMidnight());
    }, 1000);

    return () => {
      unsubMission();
      unsubPoints();
      clearInterval(interval);
    };
  }, []);

  // Handle Feature 1: Claim Daily Login Reward
  const handleClaimLoginReward = () => {
    const result = dailyMissionService.claimDailyLoginReward();
    if (result.success) {
      setClaimFeedback({
        title: `Day ${((state.dailyStreak - 1) % 7) + 1} Login Streak Reward`,
        coins: result.coins,
      });
      setTimeout(() => setClaimFeedback(null), 3500);
    }
  };

  // Handle Feature 4 & 5: Claim Individual Mission Reward
  const handleClaimMission = (missionId: string) => {
    const result = dailyMissionService.claimMissionReward(missionId);
    if (result.success) {
      const missionDef = missions.find((m) => m.id === missionId);
      setClaimFeedback({
        title: missionDef ? missionDef.title : 'Daily Mission',
        coins: result.coins,
      });
      setTimeout(() => setClaimFeedback(null), 3500);
    }
  };

  // Handle Mega Chest Claim
  const handleClaimMegaChest = () => {
    const result = dailyMissionService.claimMegaBonus();
    if (result.success) {
      setClaimFeedback({
        title: 'Mega Daily Chest Master Bonus',
        coins: result.coins,
      });
      setTimeout(() => setClaimFeedback(null), 3500);
    }
  };

  // Render icon for mission
  const renderMissionIcon = (category: string) => {
    switch (category) {
      case 'login':
        return <CalendarCheck className="w-5 h-5 text-amber-400" />;
      case 'ad':
        return <PlayCircle className="w-5 h-5 text-rose-400" />;
      case 'quiz':
        return <HelpCircle className="w-5 h-5 text-blue-400" />;
      case 'fantasy':
        return <Trophy className="w-5 h-5 text-amber-400" />;
      case 'puzzle':
        return <Gamepad2 className="w-5 h-5 text-emerald-400" />;
      default:
        return <Zap className="w-5 h-5 text-purple-400" />;
    }
  };

  // Progress calculations
  const completedMissionsCount = missions.filter((m) => m.isCompleted).length;
  const totalMissionsCount = missions.length;
  const megaTarget = 4;
  const currentStreakDay = ((state.dailyStreak - 1) % 7) + 1;
  const todayLoginReward = dailyMissionService.getLoginRewardForToday();

  return (
    <div 
      id="daily-missions-dashboard-sheet"
      className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-hidden"
    >
      {/* Top Header */}
      <div className="px-4 py-3 bg-[#0a0f1d] border-b border-slate-800 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <button
            id="close-daily-missions-btn"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95 transition-all"
            title="Return to Home"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-amber-400" />
              <span>Daily Missions & Rewards</span>
            </h2>
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
              <Clock className="w-3 h-3 text-amber-400" />
              <span>Resets in: <strong className="font-mono text-slate-300">{countdown}</strong></span>
            </div>
          </div>
        </div>

        {/* Live Shared Demo Coin Balance */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30">
          <Coins className="w-3.5 h-3.5 text-amber-400" />
          <div className="text-right">
            <span className="text-[9px] text-slate-400 block font-mono leading-none">Coins</span>
            <span className="text-xs font-mono font-black text-amber-300">
              {demoPoints.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Floating Celebratory Claim Banner */}
      {claimFeedback && (
        <div className="mx-4 mt-3 p-3 rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-500/80 shadow-xl text-center animate-in zoom-in-95 duration-200">
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400 animate-bounce" />
            <span className="text-sm font-black text-white">
              Reward Claimed! +{claimFeedback.coins} Demo Coins
            </span>
          </div>
          <span className="text-[11px] text-emerald-300 block mt-0.5">
            {claimFeedback.title} credited to your shared wallet!
          </span>
        </div>
      )}

      {/* Scrollable Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* ================= SECTION 1: DAILY LOGIN STREAK REWARD ================= */}
        <div 
          id="daily-login-reward-card"
          className="p-4 rounded-3xl bg-gradient-to-br from-[#121024] via-[#0d0f1e] to-[#070b14] border border-amber-500/30 shadow-xl space-y-3.5"
        >
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[9px] font-black uppercase tracking-wider flex items-center gap-1">
                  <Flame className="w-3 h-3 text-orange-400" />
                  {state.dailyStreak} Day Streak
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold">
                  Free Daily Gift
                </span>
              </div>
              <h3 className="text-base font-black text-white mt-1">
                Daily Login Bonus
              </h3>
              <p className="text-xs text-slate-300">
                Log in every consecutive day to unlock bigger demo coin chests!
              </p>
            </div>

            {/* Claim Login Reward Button (Prevent multiple claims) */}
            {state.loginClaimed ? (
              <div className="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold text-xs flex items-center gap-1.5 shrink-0">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Claimed Today</span>
              </div>
            ) : (
              <button
                id="claim-daily-login-btn"
                onClick={handleClaimLoginReward}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20 active:scale-95 transition-all shrink-0 animate-pulse"
              >
                <Gift className="w-4 h-4 fill-slate-950" />
                <span>Claim +{todayLoginReward.coins}</span>
              </button>
            )}
          </div>

          {/* 7-Day Streak Roadmap */}
          <div className="grid grid-cols-7 gap-1.5 pt-1">
            {DAILY_LOGIN_REWARDS.map((item) => {
              const isPastClaimed = item.day < currentStreakDay;
              const isToday = item.day === currentStreakDay;
              const isTodayClaimed = isToday && state.loginClaimed;
              const isFuture = item.day > currentStreakDay;

              return (
                <div
                  key={item.day}
                  className={`rounded-2xl p-2 text-center flex flex-col items-center justify-between border transition-all ${
                    isTodayClaimed
                      ? 'bg-emerald-950/50 border-emerald-500/60 shadow-sm'
                      : isToday
                      ? 'bg-gradient-to-b from-amber-500/20 to-orange-500/10 border-amber-400 ring-2 ring-amber-500/40 shadow-md'
                      : isPastClaimed
                      ? 'bg-slate-900/60 border-slate-800 opacity-80'
                      : 'bg-slate-950/70 border-slate-800/80'
                  }`}
                >
                  <span className="text-[9px] font-mono text-slate-400">
                    Day {item.day}
                  </span>

                  <div className="my-1">
                    {isPastClaimed || isTodayClaimed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : item.isMega ? (
                      <Trophy className="w-4 h-4 text-amber-400 animate-pulse" />
                    ) : (
                      <Coins className="w-4 h-4 text-amber-400" />
                    )}
                  </div>

                  <span className={`text-[10px] font-mono font-black ${
                    isToday ? 'text-amber-300' : isPastClaimed ? 'text-slate-400' : 'text-slate-300'
                  }`}>
                    +{item.coins}
                  </span>

                  {isToday && !isTodayClaimed && (
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1 animate-ping"></span>
                  )}
                </div>
              );
            })}
          </div>

          {state.loginClaimed && (
            <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
              <span className="flex items-center gap-1 text-slate-300">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Day {currentStreakDay} reward collected.
              </span>
              <span className="font-mono text-[10px] text-amber-400">
                Next reward in {countdown}
              </span>
            </div>
          )}
        </div>

        {/* ================= SECTION 2: WATCH AD & EARN DEMO COINS ================= */}
        <div 
          id="watch-ad-card"
          className="p-4 rounded-3xl bg-gradient-to-r from-rose-950/50 via-slate-900/90 to-purple-950/40 border border-rose-500/30 shadow-lg flex items-center justify-between gap-3"
        >
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[9px] font-black uppercase tracking-wider">
                Video Boost
              </span>
              <span className="text-[10px] text-amber-400 font-mono font-bold">
                +50 Coins Per Clip
              </span>
            </div>
            <h4 className="text-sm font-bold text-white">
              Watch Sponsor Clips & Earn
            </h4>
            <p className="text-[11px] text-slate-300 leading-tight">
              Watch 5-second sponsor clips to earn free demo coins. ({state.adsWatchedToday}/{state.maxDailyAds} watched today)
            </p>
          </div>

          <button
            id="watch-video-ad-btn"
            disabled={state.adsWatchedToday >= state.maxDailyAds}
            onClick={() => setShowAdModal(true)}
            className={`px-3.5 py-2.5 rounded-2xl font-black text-xs flex items-center gap-1.5 shrink-0 shadow-md active:scale-95 transition-all ${
              state.adsWatchedToday >= state.maxDailyAds
                ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                : 'bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white shadow-rose-600/30'
            }`}
          >
            <PlayCircle className="w-4 h-4 fill-white" />
            <span>
              {state.adsWatchedToday >= state.maxDailyAds ? 'Limit Reached' : 'Watch Ad (+50)'}
            </span>
          </button>
        </div>

        {/* ================= SECTION 3: DAILY MISSIONS OVERVIEW & MEGA CHEST ================= */}
        <div 
          id="mega-chest-progress-card"
          className="p-4 rounded-3xl bg-[#0a0f1d] border border-blue-900/40 shadow-xl space-y-3"
        >
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-wider block">
                Daily Completion Meter
              </span>
              <h4 className="text-sm font-bold text-white">
                Complete 4 Missions for Mega Chest
              </h4>
            </div>

            <span className="text-xs font-mono font-black text-blue-300 px-2.5 py-1 rounded-xl bg-blue-500/15 border border-blue-500/30">
              {completedMissionsCount} / {totalMissionsCount} Ready
            </span>
          </div>

          {/* Master Progress Bar */}
          <div className="w-full bg-slate-900 h-2.5 rounded-full overflow-hidden border border-slate-800 p-0.5">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 via-indigo-500 to-amber-400 transition-all duration-300"
              style={{ width: `${Math.min(100, (completedMissionsCount / totalMissionsCount) * 100)}%` }}
            ></div>
          </div>

          {/* Mega Chest Claim Row */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <Trophy className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-amber-300 block">Mega Daily Chest</span>
                <span className="text-[10px] text-slate-400">+250 Bonus Demo Coins</span>
              </div>
            </div>

            {state.megaBonusClaimed ? (
              <div className="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 font-bold text-xs flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Chest Claimed</span>
              </div>
            ) : (
              <button
                id="claim-mega-chest-btn"
                disabled={completedMissionsCount < megaTarget}
                onClick={handleClaimMegaChest}
                className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all ${
                  completedMissionsCount >= megaTarget
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black shadow-md shadow-amber-500/20 animate-bounce'
                    : 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed'
                }`}
              >
                {completedMissionsCount < megaTarget ? (
                  <>
                    <Lock className="w-3 h-3 text-slate-600" />
                    <span>Need {megaTarget - completedMissionsCount} More</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3 h-3 fill-slate-950" />
                    <span>Open Chest (+250)</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* ================= SECTION 4: INDIVIDUAL DAILY MISSION CARDS ================= */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-400 font-mono">
              Today's Missions ({missions.length})
            </h4>
            <span className="text-[11px] text-slate-500">
              Auto-refreshes at 00:00 midnight
            </span>
          </div>

          {missions.map((mission) => {
            const isCompleted = mission.isCompleted;
            const isClaimed = mission.isClaimed;

            return (
              <div
                key={mission.id}
                id={`mission-card-${mission.id}`}
                className={`p-3.5 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                  isClaimed
                    ? 'bg-slate-950/60 border-slate-800/80 opacity-80'
                    : isCompleted
                    ? 'bg-gradient-to-r from-amber-950/40 via-slate-900/90 to-slate-900 border-amber-500/60 shadow-lg shadow-amber-950/30'
                    : 'bg-[#090e1b] border-slate-800/90 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                      {renderMissionIcon(mission.category)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h5 className="text-xs font-bold text-white">
                          {mission.title}
                        </h5>
                        <span className="text-[10px] font-mono font-bold text-amber-400">
                          +{mission.rewardCoins} Pts
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-0.5 leading-tight">
                        {mission.description}
                      </p>
                    </div>
                  </div>

                  {/* Right Status Badge */}
                  <div className="shrink-0 text-right">
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-slate-300">
                      {mission.currentProgress} / {mission.targetProgress}
                    </span>
                  </div>
                </div>

                {/* Progress Bar & Actions */}
                <div className="flex items-center justify-between gap-3 pt-1 border-t border-slate-800/60">
                  {/* Progress Line */}
                  <div className="flex-1 bg-slate-900 h-1.5 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isClaimed
                          ? 'bg-emerald-500'
                          : isCompleted
                          ? 'bg-amber-400'
                          : 'bg-blue-500'
                      }`}
                      style={{
                        width: `${Math.min(100, (mission.currentProgress / mission.targetProgress) * 100)}%`,
                      }}
                    ></div>
                  </div>

                  {/* Feature 4 & 5: Claim Reward Button / Action Shortcut */}
                  <div>
                    {isClaimed ? (
                      <div className="px-3 py-1 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-400 font-bold text-[11px] flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Claimed ✓</span>
                      </div>
                    ) : isCompleted ? (
                      <button
                        id={`claim-mission-btn-${mission.id}`}
                        onClick={() => handleClaimMission(mission.id)}
                        className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs flex items-center gap-1 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
                      >
                        <Sparkles className="w-3 h-3 fill-slate-950" />
                        <span>Claim +{mission.rewardCoins}</span>
                      </button>
                    ) : mission.category === 'ad' ? (
                      <button
                        onClick={() => setShowAdModal(true)}
                        className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1 active:scale-95 transition-all"
                      >
                        <PlayCircle className="w-3 h-3" />
                        <span>Watch Ad</span>
                      </button>
                    ) : mission.actionSheet && onNavigateToSheet ? (
                      <button
                        onClick={() => onNavigateToSheet(mission.actionSheet!)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs flex items-center gap-1 active:scale-95 transition-all"
                      >
                        <span>{mission.actionLabel || 'Start'}</span>
                        <ChevronRight className="w-3 h-3 text-slate-400" />
                      </button>
                    ) : (
                      <span className="text-[10px] text-slate-500 font-medium">In Progress</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Responsible Gaming & Free-to-Play Guarantee */}
        <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-900 text-center space-y-1 text-[10px] text-slate-500">
          <div className="flex items-center justify-center gap-1.5 text-slate-400 font-bold">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>KhelMitra 100% Free Demo Coins Guarantee</span>
          </div>
          <p>
            All coins, rewards, and chests in Daily Missions are free virtual demo credits.
            No purchase necessary, no real money gambling, and multiple claims per calendar day are prevented.
          </p>
        </div>

        {/* Demo Day Simulation Tester (Convenience for testing date reset & multi-claim prevention) */}
        <div className="p-3 rounded-2xl bg-slate-900/40 border border-dashed border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="text-[11px]">Testing day rollover & streak?</span>
          <button
            onClick={() => {
              dailyMissionService.simulateNextDay();
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-[11px] flex items-center gap-1 active:scale-95"
            title="Simulate advancing calendar to tomorrow to test fresh daily claims"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Test Next Day Reset</span>
          </button>
        </div>
      </div>

      {/* Simulated Ad Modal */}
      {showAdModal && (
        <SimulatedAdModal
          onClose={() => setShowAdModal(false)}
          onRewardEarned={(coins) => {
            setClaimFeedback({
              title: 'Sponsor Video Clip Bonus',
              coins,
            });
            setTimeout(() => setClaimFeedback(null), 3500);
          }}
        />
      )}
    </div>
  );
}
