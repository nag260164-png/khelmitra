import { Wifi, BatteryMedium, Signal } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function AndroidStatusBar() {
  const [time, setTime] = useState('12:30');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div 
      id="android-status-bar"
      className="w-full flex items-center justify-between px-5 pt-2 pb-1 text-[11px] font-semibold text-slate-400 select-none bg-[#080b11] border-b border-slate-900/60"
    >
      <div className="flex items-center gap-1.5">
        <span className="text-slate-200 tracking-tight">{time}</span>
        <span className="text-[10px] text-amber-500 font-bold px-1 py-0.2 bg-amber-500/10 rounded">LIVE</span>
      </div>

      {/* Android Center Camera Notch subtle indicator */}
      <div className="w-3.5 h-3.5 rounded-full bg-slate-950 border border-slate-800/80 mx-auto opacity-70"></div>

      <div className="flex items-center gap-2">
        <span className="text-[10px] font-bold text-slate-300">5G</span>
        <Signal className="w-3 h-3 text-slate-300" />
        <Wifi className="w-3 h-3 text-slate-300" />
        <div className="flex items-center gap-0.5">
          <span className="text-[10px] text-slate-300">92%</span>
          <BatteryMedium className="w-3.5 h-3.5 text-emerald-400" />
        </div>
      </div>
    </div>
  );
}
