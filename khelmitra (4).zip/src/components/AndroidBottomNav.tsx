import { Home, Radio, Gamepad2, Bell, User, ShoppingBag, Package, DollarSign, Building2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { ActiveSheetType, SuperAppMode } from '../types';
import { notificationService } from '../services/notificationService';
import { audioEffectsService } from '../services/audioEffectsService';

interface AndroidBottomNavProps {
  activeSheet: ActiveSheetType;
  onNavigate: (sheet: ActiveSheetType) => void;
  mode?: SuperAppMode;
}

export default function AndroidBottomNav({ activeSheet, onNavigate, mode = 'gaming' }: AndroidBottomNavProps) {
  const [unreadCount, setUnreadCount] = useState(notificationService.getUnreadCount());

  useEffect(() => {
    const unsub = notificationService.subscribe((items) => {
      setUnreadCount(items.filter((n) => !n.read).length);
    });
    return () => unsub();
  }, []);

  const gamingNavItems = [
    {
      key: 'gaming-home',
      id: 'none' as ActiveSheetType,
      label: 'Home',
      icon: Home,
      badge: null,
      badgeColor: '',
      color: 'text-amber-400',
    },
    {
      key: 'gaming-cricket',
      id: 'live-cricket' as ActiveSheetType,
      label: 'Cricket',
      icon: Radio,
      badge: 'LIVE',
      badgeColor: 'bg-red-500',
      color: 'text-red-400',
    },
    {
      key: 'gaming-games',
      id: 'games' as ActiveSheetType,
      label: 'Games',
      icon: Gamepad2,
      badge: '4 IN 1',
      badgeColor: 'bg-purple-600',
      color: 'text-purple-400',
    },
    {
      key: 'gaming-alerts',
      id: 'notifications' as ActiveSheetType,
      label: 'Alerts',
      icon: Bell,
      badge: unreadCount > 0 ? (unreadCount > 9 ? '9+' : `${unreadCount}`) : null,
      badgeColor: 'bg-red-500',
      color: 'text-amber-400',
    },
    {
      key: 'gaming-profile',
      id: 'profile' as ActiveSheetType,
      label: 'Profile',
      icon: User,
      badge: null,
      badgeColor: '',
      color: 'text-emerald-400',
    },
  ];

  const resellingNavItems = [
    {
      key: 'resell-shop',
      id: 'none' as ActiveSheetType,
      label: 'Shop',
      icon: ShoppingBag,
      badge: null,
      badgeColor: '',
      color: 'text-pink-400',
    },
    {
      key: 'resell-orders',
      id: 'order-tracking' as ActiveSheetType,
      label: 'Orders',
      icon: Package,
      badge: 'COD',
      badgeColor: 'bg-amber-500',
      color: 'text-amber-400',
    },
    {
      key: 'resell-earnings',
      id: 'reseller-dashboard' as ActiveSheetType,
      label: 'Earnings',
      icon: DollarSign,
      badge: '₹ EARN',
      badgeColor: 'bg-emerald-500',
      color: 'text-emerald-400',
    },
    {
      key: 'resell-suppliers',
      id: 'supplier-portal' as ActiveSheetType,
      label: 'Suppliers',
      icon: Building2,
      badge: null,
      badgeColor: '',
      color: 'text-blue-400',
    },
    {
      key: 'resell-profile',
      id: 'profile' as ActiveSheetType,
      label: 'Profile',
      icon: User,
      badge: null,
      badgeColor: '',
      color: 'text-emerald-400',
    },
  ];

  const navItems = mode === 'reselling' ? resellingNavItems : gamingNavItems;

  return (
    <nav
      id="android-bottom-navigation"
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#080c16]/95 backdrop-blur-lg border-t border-slate-800/90 shadow-[0_-5px_25px_rgba(0,0,0,0.7)]"
    >
      <div className="max-w-md mx-auto px-2 pt-2 pb-1 flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive =
            activeSheet === item.id ||
            (item.id === 'live-cricket' && (activeSheet === 'fantasy-cricket' || activeSheet === 'my-teams'));

          return (
            <button
              key={item.key}
              id={`nav-btn-${item.key}`}
              onClick={() => {
                audioEffectsService.playClick();
                onNavigate(item.id);
              }}
              className={`relative flex flex-col items-center justify-center py-1.5 px-2 min-w-[58px] rounded-xl transition-all duration-150 active:scale-95 ${
                isActive ? 'text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {/* Active glow line */}
              {isActive && (
                <span className="absolute -top-2 w-8 h-1 rounded-full bg-gradient-to-r from-amber-400 to-orange-500 shadow-sm shadow-amber-400/50"></span>
              )}

              <div className="relative">
                <Icon
                  className={`w-4 h-4 transition-transform ${
                    isActive ? `${item.color} scale-110` : 'text-slate-400'
                  }`}
                />

                {/* Badge */}
                {item.badge && (
                  <span
                    className={`absolute -top-1.5 -right-3.5 px-1 py-0.2 rounded-full text-[8px] leading-tight font-extrabold text-white ${
                      item.badgeColor || 'bg-red-500'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </div>

              <span
                className={`text-[10px] font-semibold mt-1 tracking-tight ${
                  isActive ? 'text-white font-bold' : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Android Gesture Navigation Bar indicator */}
      <div className="w-full flex justify-center pb-1 pt-0.5">
        <div className="w-32 h-1 bg-slate-700/60 rounded-full"></div>
      </div>
    </nav>
  );
}
