import { useState, useEffect } from 'react';
import { Users, Plus, Shield, ChevronRight, Award } from 'lucide-react';
import { UserTeam, ActiveSheetType } from '../types';
import { fantasyTeamService } from '../services/fantasyTeamService';

interface MyTeamsWidgetProps {
  teams?: UserTeam[];
  onOpenMyTeams: (sheet: ActiveSheetType) => void;
}

export default function MyTeamsWidget({ teams: propTeams, onOpenMyTeams }: MyTeamsWidgetProps) {
  const [liveTeams, setLiveTeams] = useState<UserTeam[]>(() => fantasyTeamService.getTeams());

  useEffect(() => {
    const unsub = fantasyTeamService.subscribe((updated) => {
      setLiveTeams(updated);
    });
    return () => unsub();
  }, []);

  const teams = liveTeams.length > 0 ? liveTeams : propTeams || [];
  const topTeam = teams[0];

  return (
    <section id="my-teams-widget-section" className="px-4 py-2">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xs uppercase font-extrabold tracking-wider text-blue-400 font-mono flex items-center gap-1.5">
          <Users className="w-3.5 h-3.5 text-blue-400" />
          My Fantasy Lineups
        </h2>
        <button
          id="see-all-teams-btn"
          onClick={() => onOpenMyTeams('my-teams')}
          className="text-xs font-bold text-blue-400 hover:text-blue-300 flex items-center gap-0.5"
        >
          View All ({teams.length})
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div 
        id="my-teams-card"
        className="rounded-2xl bg-gradient-to-br from-blue-950/30 via-slate-900 to-slate-950 border border-blue-500/30 p-4 shadow-lg shadow-black/40"
      >
        {topTeam ? (
          <>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-black text-xs font-mono">
                  {topTeam.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">{topTeam.name}</span>
                    <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-extrabold border border-emerald-500/30">
                      {topTeam.status}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400">{topTeam.match}</span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">Total Pts</span>
                <span className="text-xl font-sports font-bold text-amber-400 leading-tight">
                  {topTeam.totalPoints}
                </span>
              </div>
            </div>

            {/* Captain & Vice Captain stats */}
            <div className="grid grid-cols-2 gap-2 my-2.5 text-xs">
              <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
                <span className="text-slate-400 font-medium text-[11px]">Captain:</span>
                <span className="font-bold text-amber-300 truncate text-[11px]">
                  {topTeam.captain.replace('(2x Pts)', '').trim()} (2x)
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-950/70 border border-slate-800/80 flex items-center justify-between">
                <span className="text-slate-400 font-medium text-[11px]">Vice-Cap:</span>
                <span className="font-bold text-slate-200 truncate text-[11px]">
                  {topTeam.viceCaptain.replace('(1.5x Pts)', '').trim()} (1.5x)
                </span>
              </div>
            </div>

            {/* Squad Composition Bar */}
            <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 mb-3">
              <span>WK: <strong className="text-slate-200">{topTeam.wicketKeepers}</strong></span>
              <span>BAT: <strong className="text-slate-200">{topTeam.batsmen}</strong></span>
              <span>AR: <strong className="text-slate-200">{topTeam.allRounders}</strong></span>
              <span>BOWL: <strong className="text-slate-200">{topTeam.bowlers}</strong></span>
              <span className="text-amber-400 font-bold flex items-center gap-0.5">
                <Award className="w-3 h-3" />
                {topTeam.rank ? `#${topTeam.rank}` : 'Ready'}
              </span>
            </div>
          </>
        ) : (
          <div className="py-4 text-center space-y-1">
            <span className="text-sm font-bold text-white block">No Lineups Created Yet</span>
            <span className="text-xs text-slate-400 block">Pick 11 players and set Captain & Vice-Captain</span>
          </div>
        )}

        {/* My Teams Actions */}
        <div className="grid grid-cols-2 gap-2">
          <button
            id="my-teams-manage-btn"
            onClick={() => onOpenMyTeams('my-teams')}
            className="py-2.5 px-3 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
          >
            <Users className="w-3.5 h-3.5" />
            <span>My Teams ({teams.length})</span>
          </button>

          <button
            id="create-new-team-btn"
            onClick={() => onOpenMyTeams('create-team')}
            className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-blue-600/20 active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create New Team</span>
          </button>
        </div>
      </div>
    </section>
  );
}
