import { useState, useEffect } from 'react';
import {
  Radio,
  RefreshCw,
  Search,
  AlertCircle,
  Clock,
  MapPin,
  ChevronRight,
  TrendingUp,
  X,
  Sparkles,
  ShieldAlert,
  RotateCcw,
} from 'lucide-react';
import { LiveMatch } from '../../types';
import { cricketLiveService } from '../../services/cricketLiveService';
import TeamLogoBadge from './TeamLogoBadge';
import MatchDetailsModal from './MatchDetailsModal';

interface LiveCricketHubProps {
  onClose?: () => void;
  initialSelectedMatchId?: string | null;
}

type StatusTab = 'LIVE' | 'UPCOMING' | 'COMPLETED';
type FormatFilter = 'ALL' | 'T20' | 'ODI' | 'TEST';

export default function LiveCricketHub({
  onClose,
  initialSelectedMatchId,
}: LiveCricketHubProps) {
  const [matches, setMatches] = useState<LiveMatch[]>(cricketLiveService.getMatches());
  const [isError, setIsError] = useState<boolean>(cricketLiveService.isErrorState());
  const [selectedStatusTab, setSelectedStatusTab] = useState<StatusTab>('LIVE');
  const [selectedFormat, setSelectedFormat] = useState<FormatFilter>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [autoRefresh, setAutoRefresh] = useState<boolean>(cricketLiveService.isAutoRefreshActive());
  const [countdown, setCountdown] = useState<number>(cricketLiveService.getCountdown());
  const [lastUpdatedText, setLastUpdatedText] = useState<string>(cricketLiveService.getLastUpdatedText());
  const [activeMatchForDetails, setActiveMatchForDetails] = useState<LiveMatch | null>(null);

  // Subscribe to Live Cricket Service
  useEffect(() => {
    const unsubscribe = cricketLiveService.subscribe((updatedMatches, simulatedError) => {
      setMatches([...updatedMatches]);
      setIsError(simulatedError);
      setCountdown(cricketLiveService.getCountdown());
      setLastUpdatedText(cricketLiveService.getLastUpdatedText());
      setAutoRefresh(cricketLiveService.isAutoRefreshActive());

      // If viewing active match details, keep it in sync with live ball updates
      if (activeMatchForDetails) {
        const freshActive = updatedMatches.find((m) => m.id === activeMatchForDetails.id);
        if (freshActive) {
          setActiveMatchForDetails({ ...freshActive });
        }
      }
    });

    return () => unsubscribe();
  }, [activeMatchForDetails]);

  // Handle initial selected match if provided
  useEffect(() => {
    if (initialSelectedMatchId) {
      const match = matches.find((m) => m.id === initialSelectedMatchId);
      if (match) {
        setActiveMatchForDetails(match);
      }
    }
  }, [initialSelectedMatchId, matches]);

  // Filter matches based on tab, format, and search
  const filteredMatches = matches.filter((m) => {
    if (m.status !== selectedStatusTab) return false;

    if (selectedFormat !== 'ALL') {
      if (selectedFormat === 'T20' && !m.matchType.includes('T20') && m.format !== 'T20') return false;
      if (selectedFormat === 'ODI' && !m.matchType.includes('ODI') && m.format !== 'ODI') return false;
      if (selectedFormat === 'TEST' && !m.matchType.includes('Test') && m.format !== 'TEST') return false;
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTeam = m.team1.name.toLowerCase().includes(q) ||
        m.team2.name.toLowerCase().includes(q) ||
        m.team1.shortName.toLowerCase().includes(q) ||
        m.team2.shortName.toLowerCase().includes(q) ||
        m.tournament.toLowerCase().includes(q);
      if (!matchTeam) return false;
    }

    return true;
  });

  // Count matches by status
  const liveCount = matches.filter((m) => m.status === 'LIVE').length;
  const upcomingCount = matches.filter((m) => m.status === 'UPCOMING').length;
  const completedCount = matches.filter((m) => m.status === 'COMPLETED').length;

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await cricketLiveService.refreshMatchesNow();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 400);
  };

  const handleToggleAutoRefresh = () => {
    const nextVal = cricketLiveService.toggleAutoRefresh();
    setAutoRefresh(nextVal);
  };

  const handleSimulateError = () => {
    cricketLiveService.triggerErrorSimulation();
  };

  const handleRetryError = () => {
    setIsLoading(true);
    cricketLiveService.clearErrorState();
    setTimeout(() => {
      setIsLoading(false);
    }, 500);
  };

  return (
    <div id="live-cricket-feature-hub" className="flex flex-col h-full bg-[#070b14] text-slate-100">
      {/* Top Header / App Bar */}
      <div className="p-4 bg-gradient-to-r from-[#0c1424] via-[#090e1a] to-[#0c1424] border-b border-slate-800/80 sticky top-0 z-20 shadow-md">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="relative w-9 h-9 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500 shadow-inner">
              <Radio className="w-5 h-5 animate-pulse" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#090e1a] animate-ping" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white tracking-wide">
                  Live Cricket Match Center
                </h2>
                <span className="px-1.5 py-0.5 rounded bg-red-600 text-[9px] font-black text-white uppercase tracking-wider animate-pulse">
                  LIVE
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Official Ball-by-Ball Scores, Scorecards & Telemetry
              </p>
            </div>
          </div>

          {onClose && (
            <button
              id="close-live-hub-btn"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Search Bar & Format Filter Pills */}
        <div className="space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="cricket-search-input"
              type="text"
              placeholder="Search team, tournament, or series..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-900/90 border border-slate-800 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-400/60 focus:ring-1 focus:ring-amber-400/30 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center justify-between gap-2 overflow-x-auto no-scrollbar">
            {/* Format filters */}
            <div className="flex items-center gap-1.5">
              {(['ALL', 'T20', 'ODI', 'TEST'] as FormatFilter[]).map((fmt) => (
                <button
                  key={fmt}
                  id={`filter-fmt-${fmt}`}
                  onClick={() => setSelectedFormat(fmt)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                    selectedFormat === fmt
                      ? 'bg-slate-200 text-slate-950 shadow-sm'
                      : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {fmt}
                </button>
              ))}
            </div>

            {/* Auto-Refresh Toggle Pill */}
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                id="toggle-auto-refresh-btn"
                onClick={handleToggleAutoRefresh}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all ${
                  autoRefresh
                    ? 'bg-emerald-950/40 text-emerald-400 border-emerald-500/40'
                    : 'bg-slate-900 text-slate-500 border-slate-800'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${autoRefresh ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`} />
                {autoRefresh ? `Auto Sync (${countdown}s)` : 'Auto Sync OFF'}
              </button>

              <button
                id="hub-manual-sync-btn"
                onClick={handleManualRefresh}
                disabled={isRefreshing}
                title="Sync live match data now"
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white active:scale-95 disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Status Segment Tabs: LIVE | UPCOMING | COMPLETED */}
      <div className="px-4 pt-3 pb-2 bg-[#070b14] border-b border-slate-800/80 flex gap-2 sticky top-[148px] z-10">
        <button
          id="tab-status-live"
          onClick={() => setSelectedStatusTab('LIVE')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-black tracking-wide flex items-center justify-center gap-1.5 transition-all border ${
            selectedStatusTab === 'LIVE'
              ? 'bg-gradient-to-r from-red-600 to-rose-600 text-white border-red-500 shadow-md shadow-red-600/30'
              : 'bg-slate-900/90 text-slate-400 border-slate-800 hover:border-slate-700'
          }`}
        >
          <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
          LIVE ({liveCount})
        </button>

        <button
          id="tab-status-upcoming"
          onClick={() => setSelectedStatusTab('UPCOMING')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-black tracking-wide flex items-center justify-center gap-1.5 transition-all border ${
            selectedStatusTab === 'UPCOMING'
              ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20'
              : 'bg-slate-900/90 text-slate-400 border-slate-800 hover:border-slate-700'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          UPCOMING ({upcomingCount})
        </button>

        <button
          id="tab-status-completed"
          onClick={() => setSelectedStatusTab('COMPLETED')}
          className={`flex-1 py-2.5 rounded-xl text-xs font-black tracking-wide flex items-center justify-center gap-1.5 transition-all border ${
            selectedStatusTab === 'COMPLETED'
              ? 'bg-slate-200 text-slate-950 border-white shadow-md'
              : 'bg-slate-900/90 text-slate-400 border-slate-800 hover:border-slate-700'
          }`}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          RESULTS ({completedCount})
        </button>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3.5 no-scrollbar">
        {/* Error Simulation Notice / Recovery Banner */}
        {isError && (
          <div
            id="cricket-api-error-card"
            className="p-4 rounded-2xl bg-gradient-to-br from-red-950/70 to-[#180d12] border border-red-500/50 shadow-lg space-y-3"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400 shrink-0">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h4 className="text-sm font-bold text-white">
                  Live Score Stream Interrupted
                </h4>
                <p className="text-xs text-red-300/90 mt-0.5">
                  Cricket telemetry feed dropped or encountered an API rate limit. Cached state is preserved.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1 border-t border-red-800/40">
              <button
                id="retry-stream-btn"
                onClick={handleRetryError}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-md shadow-red-600/30 active:scale-95 flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retry Connection
              </button>
            </div>
          </div>
        )}

        {/* Loading Skeleton */}
        {isLoading && (
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div
                key={i}
                className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 animate-pulse space-y-3"
              >
                <div className="h-4 w-1/3 bg-slate-800 rounded"></div>
                <div className="h-12 w-full bg-slate-800/70 rounded-xl"></div>
                <div className="h-4 w-2/3 bg-slate-800 rounded"></div>
              </div>
            ))}
          </div>
        )}

        {/* Empty State / No Data Screen */}
        {!isLoading && filteredMatches.length === 0 && (
          <div
            id="cricket-no-data-screen"
            className="p-8 rounded-2xl bg-[#0b101c] border border-slate-800/80 text-center space-y-3 my-4"
          >
            <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500">
              <Search className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                No {selectedStatusTab.toLowerCase()} matches found
              </h3>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                No matches match your current search &quot;{searchQuery}&quot; or format filter ({selectedFormat}).
              </p>
            </div>
            <button
              id="reset-filters-btn"
              onClick={() => {
                setSearchQuery('');
                setSelectedFormat('ALL');
              }}
              className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs hover:bg-amber-400 transition-all shadow-md active:scale-95"
            >
              Reset All Filters
            </button>
          </div>
        )}

        {/* Match Cards List */}
        {!isLoading &&
          filteredMatches.map((match) => (
            <div
              key={match.id}
              id={`match-card-${match.id}`}
              className="rounded-2xl bg-gradient-to-br from-[#0c1220] via-[#090e1a] to-[#070b14] border border-slate-800/90 shadow-lg hover:border-slate-700 transition-all overflow-hidden"
            >
              {/* Card Header: Tournament & Status */}
              <div className="px-4 py-2.5 bg-slate-900/60 border-b border-slate-800/80 flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-300 truncate max-w-[220px]">
                  {match.tournament}
                </span>
                <div className="flex items-center gap-1.5 shrink-0">
                  {match.status === 'LIVE' && (
                    <span className="px-2 py-0.5 rounded-full bg-red-600/90 text-white text-[9px] font-black uppercase tracking-wider flex items-center gap-1 animate-pulse">
                      <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                      LIVE
                    </span>
                  )}
                  {match.status === 'COMPLETED' && (
                    <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[9px] font-extrabold uppercase tracking-wider">
                      FINAL
                    </span>
                  )}
                  {match.status === 'UPCOMING' && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[9px] font-extrabold uppercase tracking-wider flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {match.countdown || 'UPCOMING'}
                    </span>
                  )}
                </div>
              </div>

              {/* Main Scores Grid */}
              <div className="p-4 space-y-3.5">
                {/* Team 1 Row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <TeamLogoBadge
                      code={match.team1.logoCode || match.team1.shortName}
                      name={match.team1.name}
                      size="md"
                    />
                    <div>
                      <span className="text-sm font-bold text-white block leading-tight">
                        {match.team1.name}
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        {match.team1.shortName}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-lg font-sports font-black text-amber-300 tracking-wide">
                      {match.team1.score}
                    </span>
                    {match.team1.overs && match.team1.overs !== '0.0' && (
                      <span className="text-[10px] text-slate-400 block">
                        ({match.team1.overs} ov)
                      </span>
                    )}
                  </div>
                </div>

                {/* Team 2 Row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <TeamLogoBadge
                      code={match.team2.logoCode || match.team2.shortName}
                      name={match.team2.name}
                      size="md"
                    />
                    <div>
                      <span className="text-sm font-bold text-white block leading-tight">
                        {match.team2.name}
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        {match.team2.shortName}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-lg font-sports font-black text-amber-300 tracking-wide">
                      {match.team2.score}
                    </span>
                    {match.team2.overs && match.team2.overs !== '0.0' && (
                      <span className="text-[10px] text-slate-400 block">
                        ({match.team2.overs} ov) {match.team2.crr ? `• CRR ${match.team2.crr}` : ''}
                      </span>
                    )}
                  </div>
                </div>

                {/* Status / Requirement Banner */}
                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="font-bold text-amber-400 truncate pr-2">
                    {match.result || match.statusText}
                  </span>
                  {match.requiredRuns && match.status === 'LIVE' && (
                    <span className="text-[10px] font-mono text-slate-300 shrink-0 font-semibold">
                      Req: {match.requiredRuns}
                    </span>
                  )}
                </div>

                {/* Live Highlights: Current Batsmen and Bowler if LIVE */}
                {match.status === 'LIVE' && (
                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                    <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800/60">
                      <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono block">
                        Batting
                      </span>
                      <span className="font-bold text-white truncate block">
                        {match.currentBatsman.name}*
                      </span>
                      <span className="text-amber-300 font-mono font-semibold">
                        {match.currentBatsman.runs} ({match.currentBatsman.balls}b)
                      </span>
                    </div>

                    <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800/60">
                      <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono block">
                        Bowling
                      </span>
                      <span className="font-bold text-white truncate block">
                        {match.currentBowler.name}
                      </span>
                      <span className="text-emerald-400 font-mono font-semibold">
                        {match.currentBowler.wickets}/{match.currentBowler.runs} ({match.currentBowler.overs} ov)
                      </span>
                    </div>
                  </div>
                )}

                {/* Recent Balls Ticker */}
                {match.status === 'LIVE' && match.recentBalls && match.recentBalls.length > 0 && (
                  <div className="flex items-center justify-between text-[11px] pt-1">
                    <span className="text-slate-400 font-mono text-[10px] uppercase">
                      This Over:
                    </span>
                    <div className="flex items-center gap-1.5">
                      {match.recentBalls.map((b, idx) => (
                        <span
                          key={idx}
                          className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                            b === 'W'
                              ? 'bg-red-600 text-white'
                              : b === '6'
                              ? 'bg-purple-600 text-white'
                              : b === '4'
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {b}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Card Action Button: Open Match Details Page */}
                <button
                  id={`open-match-details-${match.id}`}
                  onClick={() => setActiveMatchForDetails(match)}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 text-xs font-bold text-slate-200 hover:text-white transition-all flex items-center justify-center gap-2 active:scale-98 shadow-sm group"
                >
                  <span>View Full Scorecard, Overs & Squads</span>
                  <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 group-hover:text-amber-400 transition-all" />
                </button>
              </div>
            </div>
          ))}

        {/* Footer controls: Simulation of feed error for testing resilience */}
        <div className="pt-4 pb-2 text-center">
          <button
            onClick={isError ? handleRetryError : handleSimulateError}
            className="text-[10px] font-mono text-slate-500 hover:text-slate-400 underline decoration-dotted"
          >
            {isError ? 'Dismiss Simulated Error' : 'Test Live Feed Telemetry Error State'}
          </button>
        </div>
      </div>

      {/* Match Details Dedicated Page / Modal */}
      {activeMatchForDetails && (
        <MatchDetailsModal
          match={activeMatchForDetails}
          onClose={() => setActiveMatchForDetails(null)}
          onRefresh={handleManualRefresh}
          isRefreshing={isRefreshing}
          autoRefreshEnabled={autoRefresh}
          countdown={countdown}
        />
      )}
    </div>
  );
}
