import { useState } from 'react';
import {
  ArrowLeft,
  Radio,
  RefreshCw,
  Clock,
  MapPin,
  Trophy,
  Users,
  Info,
  Calendar,
  Sparkles,
  ChevronRight,
  TrendingUp,
} from 'lucide-react';
import { LiveMatch } from '../../types';
import TeamLogoBadge from './TeamLogoBadge';
import PlayerDetailsModal from '../player/PlayerDetailsModal';

interface MatchDetailsModalProps {
  match: LiveMatch;
  onClose: () => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
  autoRefreshEnabled?: boolean;
  countdown?: number;
}

type TabType = 'summary' | 'scorecard' | 'commentary' | 'squads' | 'info';

export default function MatchDetailsModal({
  match,
  onClose,
  onRefresh,
  isRefreshing = false,
  autoRefreshEnabled = true,
  countdown = 10,
}: MatchDetailsModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('summary');
  const [activeInning, setActiveInning] = useState<1 | 2>(match.innings2 ? 2 : 1);
  const [selectedPlayerForDetails, setSelectedPlayerForDetails] = useState<{ id?: string; name: string } | null>(null);

  const currentInningData = activeInning === 1 ? match.innings1 : (match.innings2 || match.innings1);

  return (
    <div
      id="match-details-modal-page"
      className="fixed inset-0 z-50 bg-[#060912] flex flex-col overflow-hidden text-slate-100"
    >
      {/* Top App Bar */}
      <header className="sticky top-0 z-20 bg-[#090e1a]/95 backdrop-blur-md border-b border-slate-800/90 px-4 py-3 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <button
            id="match-details-back-btn"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition-all"
            aria-label="Back to matches"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold text-white leading-tight truncate max-w-[200px]">
                {match.team1.shortName} vs {match.team2.shortName}
              </h1>
              {match.status === 'LIVE' && (
                <span className="px-1.5 py-0.5 rounded bg-red-600 text-[9px] font-black text-white uppercase tracking-wider flex items-center gap-1 animate-pulse">
                  <Radio className="w-2.5 h-2.5" />
                  LIVE
                </span>
              )}
              {match.status === 'COMPLETED' && (
                <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[9px] font-extrabold text-slate-300 uppercase tracking-wider">
                  FINAL
                </span>
              )}
              {match.status === 'UPCOMING' && (
                <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[9px] font-extrabold uppercase tracking-wider">
                  UPCOMING
                </span>
              )}
            </div>
            <p className="text-[10px] text-slate-400 truncate max-w-[220px]">
              {match.tournament} • {match.venue}
            </p>
          </div>
        </div>

        {/* Auto Refresh status & Manual Sync */}
        <div className="flex items-center gap-2">
          {match.status === 'LIVE' && autoRefreshEnabled && (
            <div className="hidden sm:flex items-center gap-1 text-[10px] text-slate-400 bg-slate-900/80 px-2 py-1 rounded-lg border border-slate-800">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
              <span>Sync {countdown}s</span>
            </div>
          )}

          {onRefresh && (
            <button
              id="match-details-refresh-btn"
              onClick={onRefresh}
              disabled={isRefreshing}
              title="Sync latest live balls"
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white active:scale-95 disabled:opacity-50 transition-all"
            >
              <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
            </button>
          )}
        </div>
      </header>

      {/* Main Scrollable Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        {/* Stadium Hero Match Header */}
        <div className="relative bg-gradient-to-b from-[#0e1627] via-[#0a101d] to-[#070b14] border-b border-slate-800/80 p-4 shadow-xl">
          <div className="grid grid-cols-5 items-center">
            {/* Team 1 */}
            <div className="col-span-2 flex items-center gap-3">
              <TeamLogoBadge code={match.team1.logoCode || match.team1.shortName} name={match.team1.name} size="lg" />
              <div>
                <span className="text-sm font-bold text-white block leading-tight">
                  {match.team1.name}
                </span>
                <span className="text-xl font-sports font-black text-amber-300 block tracking-wider">
                  {match.team1.score}
                </span>
                {match.team1.overs && match.team1.overs !== '0.0' && (
                  <span className="text-[10px] text-slate-400 block -mt-0.5">
                    ({match.team1.overs} ov)
                  </span>
                )}
              </div>
            </div>

            {/* VS Middle */}
            <div className="col-span-1 flex flex-col items-center justify-center text-center">
              <div className="w-7 h-7 rounded-full bg-slate-900/90 border border-slate-700/80 flex items-center justify-center text-[11px] font-bold text-slate-400">
                VS
              </div>
              <span className="text-[10px] font-semibold text-slate-500 mt-1 uppercase font-mono">
                {match.format || 'T20'}
              </span>
            </div>

            {/* Team 2 */}
            <div className="col-span-2 flex items-center justify-end gap-3 text-right">
              <div>
                <div className="flex items-center justify-end gap-1">
                  {match.status === 'LIVE' && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>}
                  <span className="text-sm font-bold text-white block leading-tight">
                    {match.team2.name}
                  </span>
                </div>
                <span className="text-xl font-sports font-black text-amber-300 block tracking-wider">
                  {match.team2.score}
                </span>
                {match.team2.overs && match.team2.overs !== '0.0' && (
                  <span className="text-[10px] text-slate-400 block -mt-0.5">
                    ({match.team2.overs} ov) {match.team2.crr ? `• CRR ${match.team2.crr}` : ''}
                  </span>
                )}
              </div>
              <TeamLogoBadge code={match.team2.logoCode || match.team2.shortName} name={match.team2.name} size="lg" />
            </div>
          </div>

          {/* Status / Requirement Pill */}
          <div className="mt-3.5 pt-2.5 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-1.5">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-extrabold text-amber-400 text-center sm:text-left">
                {match.result || match.statusText}
              </span>
            </div>
            {match.target && match.status === 'LIVE' && (
              <span className="text-[10px] font-mono font-bold text-slate-400">
                Target: <strong className="text-white">{match.target}</strong> | RRR: <strong className="text-amber-300">{match.requiredRunRate || '10.5'}</strong>
              </span>
            )}
          </div>

          {/* Win Probability Bar if LIVE */}
          {match.status === 'LIVE' && match.winProbability && (
            <div className="mt-2.5 pt-2 border-t border-slate-800/50 space-y-1">
              <div className="flex justify-between text-[10px] font-bold text-slate-400">
                <span className="text-amber-400">{match.team1.shortName} {match.winProbability.team1}%</span>
                <span className="text-[9px] uppercase tracking-wider text-slate-500 font-mono">Win Predictor</span>
                <span className="text-blue-400">{match.team2.shortName} {match.winProbability.team2}%</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-900 overflow-hidden flex">
                <div style={{ width: `${match.winProbability.team1}%` }} className="h-full bg-amber-500" />
                <div style={{ width: `${match.winProbability.team2}%` }} className="h-full bg-blue-500" />
              </div>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="sticky top-0 z-10 bg-[#070b14]/95 backdrop-blur border-b border-slate-800 px-4 py-1.5 flex gap-1 overflow-x-auto no-scrollbar">
          {[
            { id: 'summary' as TabType, label: 'Summary' },
            { id: 'scorecard' as TabType, label: 'Scorecard' },
            { id: 'commentary' as TabType, label: 'Commentary' },
            { id: 'squads' as TabType, label: 'Playing XI' },
            { id: 'info' as TabType, label: 'Match Info' },
          ].map((tab) => (
            <button
              key={tab.id}
              id={`tab-btn-${tab.id}`}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab 1: SUMMARY */}
        {activeTab === 'summary' && (
          <div className="p-4 space-y-3.5">
            {/* Live Batsmen on Crease */}
            {match.status === 'LIVE' && (
              <div className="rounded-2xl bg-gradient-to-br from-[#0c1220] to-[#080d17] border border-slate-800 p-3.5">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-2.5">
                  <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-300 font-mono flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    Batting at Crease
                  </h3>
                  <span className="text-[10px] text-slate-400 font-mono">R (B) • 4s • 6s • SR</span>
                </div>

                <div className="space-y-2.5">
                  {/* Striker */}
                  <div
                    onClick={() => setSelectedPlayerForDetails({ name: match.currentBatsman.name })}
                    className="flex items-center justify-between text-xs py-1 cursor-pointer hover:bg-slate-800/40 px-2 rounded-lg transition-colors group"
                    title="Click to view detailed player statistics & performance"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                      <span className="font-bold text-white group-hover:text-amber-400 transition-colors">
                        {match.currentBatsman.name} <span className="text-amber-400 text-[10px]">*</span>
                      </span>
                    </div>
                    <div className="font-mono text-right">
                      <span className="text-sm font-bold text-amber-300">{match.currentBatsman.runs}</span>
                      <span className="text-slate-400 text-[11px]"> ({match.currentBatsman.balls})</span>
                      <span className="text-slate-400 text-[11px] ml-2">• 4s:{match.currentBatsman.fours} • 6s:{match.currentBatsman.sixes}</span>
                    </div>
                  </div>

                  {/* Non-Striker */}
                  {match.nonStriker && (
                    <div
                      onClick={() => setSelectedPlayerForDetails({ name: match.nonStriker?.name || '' })}
                      className="flex items-center justify-between text-xs py-1 border-t border-slate-800/50 cursor-pointer hover:bg-slate-800/40 px-2 rounded-lg transition-colors group"
                      title="Click to view detailed player statistics & performance"
                    >
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-slate-600"></span>
                        <span className="font-semibold text-slate-300 group-hover:text-amber-400 transition-colors">
                          {match.nonStriker.name}
                        </span>
                      </div>
                      <div className="font-mono text-right">
                        <span className="text-sm font-bold text-slate-200">{match.nonStriker.runs}</span>
                        <span className="text-slate-400 text-[11px]"> ({match.nonStriker.balls})</span>
                        <span className="text-slate-400 text-[11px] ml-2">• 4s:{match.nonStriker.fours} • 6s:{match.nonStriker.sixes}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Current Bowler */}
            {match.status === 'LIVE' && match.currentBowler.name !== '-' && (
              <div
                onClick={() => setSelectedPlayerForDetails({ name: match.currentBowler.name })}
                className="rounded-2xl bg-gradient-to-br from-[#0c1220] to-[#080d17] border border-slate-800 p-3.5 cursor-pointer hover:border-slate-700 transition-all group"
                title="Click to view detailed bowler statistics & performance"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-2.5">
                  <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-300 font-mono flex items-center gap-1.5">
                    Current Bowler
                    <span className="text-[10px] text-amber-400/80 font-normal">View Stats →</span>
                  </h3>
                  <span className="text-[10px] text-slate-400 font-mono">O - M - R - W - ECO</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white group-hover:text-amber-400 transition-colors">{match.currentBowler.name}</span>
                  <span className="font-mono text-emerald-400 font-bold">
                    {match.currentBowler.overs} ov • {match.currentBowler.maidens}m • {match.currentBowler.runs}r •{' '}
                    <strong className="text-amber-300 text-sm">{match.currentBowler.wickets}w</strong> • Econ {match.currentBowler.economy || '8.5'}
                  </span>
                </div>
              </div>
            )}

            {/* Recent Balls / Over Ticker */}
            {match.recentBalls && match.recentBalls.length > 0 && (
              <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-3.5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400 font-mono">
                    Recent Balls (This Over)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {match.recentBalls.map((ball, idx) => {
                    const isWicket = ball === 'W';
                    const isSix = ball === '6';
                    const isFour = ball === '4';
                    return (
                      <span
                        key={idx}
                        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border ${
                          isWicket
                            ? 'bg-red-600 text-white border-red-400 shadow-md shadow-red-600/30'
                            : isSix
                            ? 'bg-purple-600 text-white border-purple-400'
                            : isFour
                            ? 'bg-blue-600 text-white border-blue-400'
                            : 'bg-slate-800 text-slate-200 border-slate-700'
                        }`}
                      >
                        {ball}
                      </span>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Key Partnership */}
            {match.keyPartnership && (
              <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-3.5">
                <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400 font-mono block mb-2">
                  Active Partnership
                </span>
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-300">
                    {match.keyPartnership.player1} ({match.keyPartnership.player1Runs})
                  </span>
                  <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    {match.keyPartnership.runs} runs ({match.keyPartnership.balls}b)
                  </span>
                  <span className="text-slate-300">
                    {match.keyPartnership.player2} ({match.keyPartnership.player2Runs})
                  </span>
                </div>
              </div>
            )}

            {/* Player of the Match (if completed) */}
            {match.playerOfTheMatch && (
              <div className="rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-950 border border-amber-500/30 p-3.5 flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                  <Trophy className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider block">
                    Player of the Match
                  </span>
                  <span className="text-sm font-bold text-white block">
                    {match.playerOfTheMatch.name} ({match.playerOfTheMatch.team})
                  </span>
                  <span className="text-xs text-slate-400 block">
                    {match.playerOfTheMatch.performance}
                  </span>
                </div>
              </div>
            )}

            {/* Quick Match Facts */}
            <div className="rounded-2xl bg-slate-900/70 border border-slate-800 p-3.5 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Toss</span>
                <span className="font-semibold text-slate-200 text-right">{match.matchInfo?.toss}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Venue</span>
                <span className="font-semibold text-slate-200 text-right">{match.venue}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Pitch & Weather</span>
                <span className="font-semibold text-slate-200 text-right">{match.matchInfo?.weather}</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: FULL SCORECARD */}
        {activeTab === 'scorecard' && (
          <div className="p-4 space-y-4">
            {/* Innings Selector Pills */}
            <div className="flex gap-2">
              <button
                id="btn-inning-1"
                onClick={() => setActiveInning(1)}
                className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                  activeInning === 1
                    ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                    : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                {match.innings1 ? `${match.innings1.teamShortName} Innings (${match.innings1.runs}/${match.innings1.wickets})` : '1st Innings'}
              </button>

              {match.innings2 && (
                <button
                  id="btn-inning-2"
                  onClick={() => setActiveInning(2)}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all border ${
                    activeInning === 2
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                >
                  {`${match.innings2.teamShortName} Innings (${match.innings2.runs}/${match.innings2.wickets})`}
                </button>
              )}
            </div>

            {currentInningData ? (
              <div className="space-y-4">
                {/* Batting Table */}
                <div className="rounded-2xl bg-[#0b101c] border border-slate-800 overflow-hidden shadow-lg">
                  <div className="px-3.5 py-2.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center text-xs">
                    <span className="font-bold text-white uppercase tracking-wider font-mono">
                      Batting • {currentInningData.teamName}
                    </span>
                    <span className="text-[11px] font-mono text-amber-300 font-bold">
                      {currentInningData.runs}/{currentInningData.wickets} ({currentInningData.overs} ov)
                    </span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-800/80 text-[10px] text-slate-400 uppercase font-mono bg-slate-950/40">
                          <th className="py-2 px-3">Batter</th>
                          <th className="py-2 px-2 text-right">R</th>
                          <th className="py-2 px-2 text-right">B</th>
                          <th className="py-2 px-2 text-right">4s</th>
                          <th className="py-2 px-2 text-right">6s</th>
                          <th className="py-2 px-3 text-right">SR</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/50">
                        {currentInningData.batting.map((batter) => (
                          <tr
                            key={batter.id}
                            onClick={() => setSelectedPlayerForDetails({ id: batter.id, name: batter.name })}
                            className="hover:bg-slate-900/60 cursor-pointer transition-colors group"
                            title="Click to view detailed player stats"
                          >
                            <td className="py-2.5 px-3">
                              <div className="font-bold text-slate-100 flex items-center gap-1 group-hover:text-amber-400 transition-colors">
                                {batter.name}
                                {batter.isCaptain && <span className="text-[9px] text-amber-400 font-mono">(c)</span>}
                                {batter.isWicketKeeper && <span className="text-[9px] text-sky-400 font-mono">(wk)</span>}
                                {batter.isNotOut && <span className="text-amber-400 font-black">*</span>}
                              </div>
                              <span className="text-[10px] text-slate-400 block leading-tight">
                                {batter.dismissal}
                              </span>
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono font-bold text-white text-sm">
                              {batter.runs}
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono text-slate-400">
                              {batter.balls}
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono text-slate-300">
                              {batter.fours}
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono text-slate-300">
                              {batter.sixes}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-slate-300 font-semibold">
                              {batter.strikeRate.toFixed(1)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Extras and Total Row */}
                  <div className="p-3 bg-slate-950/70 border-t border-slate-800 text-xs space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Extras</span>
                      <span className="font-mono text-slate-200">
                        {currentInningData.extras.total} (b {currentInningData.extras.b}, lb {currentInningData.extras.lb}, w {currentInningData.extras.wd}, nb {currentInningData.extras.nb})
                      </span>
                    </div>
                    <div className="flex justify-between text-sm font-bold text-white pt-1 border-t border-slate-800/60">
                      <span>Total Score</span>
                      <span className="font-mono text-amber-400">
                        {currentInningData.runs}/{currentInningData.wickets} ({currentInningData.overs} Overs, RR: {currentInningData.runRate})
                      </span>
                    </div>
                    {currentInningData.didNotBat && currentInningData.didNotBat.length > 0 && (
                      <div className="pt-1.5 text-[11px] text-slate-400">
                        <span className="font-semibold text-slate-300">Did not bat: </span>
                        {currentInningData.didNotBat.join(', ')}
                      </div>
                    )}
                  </div>
                </div>

                {/* Bowling Table */}
                <div className="rounded-2xl bg-[#0b101c] border border-slate-800 overflow-hidden shadow-lg">
                  <div className="px-3.5 py-2.5 bg-slate-900/80 border-b border-slate-800 flex justify-between items-center text-xs">
                    <span className="font-bold text-white uppercase tracking-wider font-mono">
                      Bowling
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">O - M - R - W - ECO</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-slate-800/80 text-[10px] text-slate-400 uppercase font-mono bg-slate-950/40">
                          <th className="py-2 px-3">Bowler</th>
                          <th className="py-2 px-2 text-right">O</th>
                          <th className="py-2 px-2 text-right">M</th>
                          <th className="py-2 px-2 text-right">R</th>
                          <th className="py-2 px-2 text-right">W</th>
                          <th className="py-2 px-3 text-right">ECO</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/50">
                        {currentInningData.bowling.map((bowler) => (
                          <tr
                            key={bowler.id}
                            onClick={() => setSelectedPlayerForDetails({ id: bowler.id, name: bowler.name })}
                            className="hover:bg-slate-900/60 cursor-pointer transition-colors group"
                            title="Click to view detailed bowler stats"
                          >
                            <td className="py-2.5 px-3 font-bold text-slate-200 group-hover:text-amber-400 transition-colors">
                              {bowler.name}
                              {bowler.isCurrentBowler && <span className="text-[9px] text-amber-400 ml-1 font-mono">*</span>}
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono text-slate-300">
                              {bowler.overs}
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono text-slate-400">
                              {bowler.maidens}
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono text-slate-300">
                              {bowler.runs}
                            </td>
                            <td className="py-2.5 px-2 text-right font-mono font-bold text-emerald-400 text-sm">
                              {bowler.wickets}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-slate-300">
                              {bowler.economy.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Fall of Wickets */}
                {currentInningData.fallOfWickets && currentInningData.fallOfWickets.length > 0 && (
                  <div className="rounded-2xl bg-slate-900/80 border border-slate-800 p-3.5">
                    <span className="text-xs uppercase font-extrabold tracking-wider text-slate-300 font-mono block mb-2">
                      Fall of Wickets
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {currentInningData.fallOfWickets.map((fow) => (
                        <div
                          key={fow.wicket}
                          className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800/60 font-mono"
                        >
                          <span className="text-amber-400 font-bold">
                            {fow.score}/{fow.wicket}
                          </span>
                          <span className="text-slate-300 truncate max-w-[120px] font-sans">
                            {fow.player}
                          </span>
                          <span className="text-slate-400 text-[10px]">
                            ({fow.over} ov)
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400">
                Scorecard for this innings is not yet available.
              </div>
            )}
          </div>
        )}

        {/* Tab 3: COMMENTARY */}
        {activeTab === 'commentary' && (
          <div className="p-4 space-y-3">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-300 font-mono">
                Ball-by-Ball Live Feed
              </h3>
              <span className="text-[10px] text-slate-400">Auto-updates in real time</span>
            </div>

            {match.commentary && match.commentary.length > 0 ? (
              <div className="space-y-2.5">
                {match.commentary.map((c) => {
                  const isBoundary = c.ballType === 'four' || c.ballType === 'six';
                  const isWicket = c.ballType === 'wicket';

                  return (
                    <div
                      key={c.id}
                      className={`p-3 rounded-2xl border transition-all ${
                        isWicket
                          ? 'bg-red-950/30 border-red-800/60'
                          : isBoundary
                          ? 'bg-amber-950/20 border-amber-500/30'
                          : 'bg-slate-900/70 border-slate-800/70'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-black text-amber-400">
                            {c.over}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                              isWicket
                                ? 'bg-red-600 text-white'
                                : c.ballType === 'six'
                                ? 'bg-purple-600 text-white'
                                : c.ballType === 'four'
                                ? 'bg-blue-600 text-white'
                                : 'bg-slate-800 text-slate-300'
                            }`}
                          >
                            {c.ballType === 'wicket' ? 'WICKET' : c.ballType === 'six' ? 'SIX 6' : c.ballType === 'four' ? 'FOUR 4' : `${c.runs} RUN`}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono text-slate-500">
                          {c.scoreSnapshot}
                        </span>
                      </div>

                      <p className="text-xs text-slate-200 leading-relaxed">
                        <strong className="text-white font-bold">{c.bowler} to {c.batsman}: </strong>
                        {c.text}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-8 text-center text-slate-400 bg-slate-900/50 rounded-2xl border border-slate-800">
                Ball-by-ball commentary will begin when play commences.
              </div>
            )}
          </div>
        )}

        {/* Tab 4: PLAYING XI */}
        {activeTab === 'squads' && (
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Team 1 Squad */}
              <div className="rounded-2xl bg-[#0b101c] border border-slate-800 p-3.5">
                <div className="flex items-center gap-2 pb-2.5 border-b border-slate-800 mb-3">
                  <TeamLogoBadge code={match.team1.logoCode || match.team1.shortName} size="sm" />
                  <h4 className="text-sm font-bold text-white">{match.team1.name} Playing XI</h4>
                </div>

                <div className="space-y-2">
                  {(match.playingXI?.team1 || []).map((player) => (
                    <div
                      key={player.id}
                      onClick={() => setSelectedPlayerForDetails({ id: player.id, name: player.name })}
                      className="flex items-center justify-between text-xs py-1.5 px-2 rounded-lg bg-slate-950/50 border border-slate-800/50 hover:bg-slate-900 hover:border-slate-700 cursor-pointer transition-all group"
                      title="Click to view detailed player statistics & performance"
                    >
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-slate-100 group-hover:text-amber-400 transition-colors">{player.name}</span>
                        {player.isCaptain && (
                          <span className="px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold">
                            C
                          </span>
                        )}
                        {player.isWk && (
                          <span className="px-1 py-0.2 rounded bg-sky-500/20 text-sky-300 text-[9px] font-bold">
                            WK
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                        {player.role}
                        <span className="text-amber-400 text-[9px] opacity-0 group-hover:opacity-100 transition-opacity">Stats →</span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Team 2 Squad */}
              <div className="rounded-2xl bg-[#0b101c] border border-slate-800 p-3.5">
                <div className="flex items-center gap-2 pb-2.5 border-b border-slate-800 mb-3">
                  <TeamLogoBadge code={match.team2.logoCode || match.team2.shortName} size="sm" />
                  <h4 className="text-sm font-bold text-white">{match.team2.name} Playing XI</h4>
                </div>

                <div className="space-y-2">
                  {(match.playingXI?.team2 || []).map((player) => (
                    <div
                      key={player.id}
                      onClick={() => setSelectedPlayerForDetails({ id: player.id, name: player.name })}
                      className="flex items-center justify-between text-xs py-1.5 px-2 rounded-lg bg-slate-950/50 border border-slate-800/50 hover:bg-slate-900 hover:border-slate-700 cursor-pointer transition-all group"
                      title="Click to view detailed player statistics & performance"
                    >
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-slate-100 group-hover:text-amber-400 transition-colors">{player.name}</span>
                        {player.isCaptain && (
                          <span className="px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold">
                            C
                          </span>
                        )}
                        {player.isWk && (
                          <span className="px-1 py-0.2 rounded bg-sky-500/20 text-sky-300 text-[9px] font-bold">
                            WK
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                        {player.role}
                        <span className="text-amber-400 text-[9px] opacity-0 group-hover:opacity-100 transition-opacity">Stats →</span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: MATCH INFO */}
        {activeTab === 'info' && (
          <div className="p-4 space-y-3.5 text-xs">
            <div className="rounded-2xl bg-[#0b101c] border border-slate-800 p-4 space-y-3">
              <h3 className="text-xs uppercase font-extrabold tracking-wider text-amber-400 font-mono pb-2 border-b border-slate-800">
                Official Match Details
              </h3>

              <div className="space-y-2.5">
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Series</span>
                  <span className="font-semibold text-white text-right">{match.matchInfo?.series || match.tournament}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Match Number</span>
                  <span className="font-semibold text-white text-right">{match.matchInfo?.matchNo || match.matchType}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Date & Time</span>
                  <span className="font-semibold text-white text-right">{match.matchInfo?.date} • {match.matchInfo?.time}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Venue & City</span>
                  <span className="font-semibold text-white text-right">{match.matchInfo?.venue}, {match.matchInfo?.city}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Toss</span>
                  <span className="font-semibold text-amber-300 text-right">{match.matchInfo?.toss}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">On-field Umpires</span>
                  <span className="font-semibold text-white text-right">{match.matchInfo?.umpires}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">TV / Third Umpire</span>
                  <span className="font-semibold text-white text-right">{match.matchInfo?.thirdUmpire}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Match Referee</span>
                  <span className="font-semibold text-white text-right">{match.matchInfo?.matchReferee}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800/50">
                  <span className="text-slate-400">Pitch Condition</span>
                  <span className="font-semibold text-slate-300 text-right max-w-[200px]">{match.matchInfo?.pitchReport || 'Dry sporting track with true carry'}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Weather</span>
                  <span className="font-semibold text-slate-300 text-right">{match.matchInfo?.weather}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Detailed Player Profile & Performance Modal */}
      {selectedPlayerForDetails && (
        <PlayerDetailsModal
          isOpen={!!selectedPlayerForDetails}
          onClose={() => setSelectedPlayerForDetails(null)}
          playerId={selectedPlayerForDetails.id}
          playerName={selectedPlayerForDetails.name}
        />
      )}
    </div>
  );
}
