interface TeamLogoBadgeProps {
  code: string;
  name?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export default function TeamLogoBadge({
  code,
  name,
  size = 'md',
  className = '',
}: TeamLogoBadgeProps) {
  const normalizedCode = (code || 'CRIC').toUpperCase().trim();

  // Size configurations
  const sizeClasses = {
    sm: 'w-7 h-7 text-[10px]',
    md: 'w-10 h-10 text-xs',
    lg: 'w-13 h-13 text-sm',
    xl: 'w-16 h-16 text-base',
  }[size];

  // Specific team styling and official color palettes
  const getTeamConfig = (teamCode: string) => {
    switch (teamCode) {
      case 'IND':
        return {
          bgGradient: 'from-blue-600 via-sky-600 to-indigo-800',
          borderColor: 'border-amber-400/80',
          textColor: 'text-amber-300',
          symbol: '🇮🇳',
          accent: '#f59e0b',
          iconType: 'chakra',
        };
      case 'AUS':
        return {
          bgGradient: 'from-amber-500 via-yellow-500 to-emerald-800',
          borderColor: 'border-yellow-400/80',
          textColor: 'text-slate-950',
          symbol: '🇦🇺',
          accent: '#10b981',
          iconType: 'kangaroo',
        };
      case 'ENG':
        return {
          bgGradient: 'from-rose-600 via-red-600 to-slate-900',
          borderColor: 'border-rose-400/80',
          textColor: 'text-white',
          symbol: '🏴󠁧󠁢󠁥󠁮󠁧󠁿',
          accent: '#3b82f6',
          iconType: 'crown',
        };
      case 'SA':
      case 'RSA':
        return {
          bgGradient: 'from-emerald-700 via-green-600 to-amber-600',
          borderColor: 'border-amber-400/80',
          textColor: 'text-amber-300',
          symbol: '🇿🇦',
          accent: '#f59e0b',
          iconType: 'protea',
        };
      case 'PAK':
        return {
          bgGradient: 'from-emerald-800 via-green-700 to-emerald-950',
          borderColor: 'border-emerald-400/70',
          textColor: 'text-emerald-200',
          symbol: '🇵🇰',
          accent: '#ffffff',
          iconType: 'star-crescent',
        };
      case 'NZ':
        return {
          bgGradient: 'from-neutral-900 via-stone-800 to-slate-900',
          borderColor: 'border-slate-400/60',
          textColor: 'text-white',
          symbol: '🇳🇿',
          accent: '#38bdf8',
          iconType: 'fern',
        };
      case 'WI':
        return {
          bgGradient: 'from-amber-700 via-rose-900 to-yellow-600',
          borderColor: 'border-yellow-500/70',
          textColor: 'text-yellow-300',
          symbol: '🌴',
          accent: '#facc15',
          iconType: 'palm',
        };
      case 'SL':
        return {
          bgGradient: 'from-blue-800 via-blue-900 to-amber-600',
          borderColor: 'border-amber-400/80',
          textColor: 'text-amber-300',
          symbol: '🇱🇰',
          accent: '#eab308',
          iconType: 'lion',
        };
      case 'CSK':
        return {
          bgGradient: 'from-yellow-400 via-amber-500 to-yellow-600',
          borderColor: 'border-yellow-300',
          textColor: 'text-slate-950',
          symbol: '🦁',
          accent: '#1e3a8a',
          iconType: 'lion',
        };
      case 'MI':
        return {
          bgGradient: 'from-blue-600 via-sky-600 to-blue-800',
          borderColor: 'border-amber-400/80',
          textColor: 'text-amber-300',
          symbol: '🌪️',
          accent: '#f59e0b',
          iconType: 'tornado',
        };
      case 'RCB':
        return {
          bgGradient: 'from-red-600 via-rose-700 to-neutral-950',
          borderColor: 'border-amber-400/80',
          textColor: 'text-amber-300',
          symbol: '👑',
          accent: '#fbbf24',
          iconType: 'crown',
        };
      case 'KKR':
        return {
          bgGradient: 'from-purple-800 via-indigo-900 to-amber-600',
          borderColor: 'border-amber-400/80',
          textColor: 'text-amber-300',
          symbol: '⚔️',
          accent: '#fbbf24',
          iconType: 'sword',
        };
      default:
        return {
          bgGradient: 'from-slate-700 via-slate-800 to-slate-900',
          borderColor: 'border-slate-600',
          textColor: 'text-white',
          symbol: '🏏',
          accent: '#94a3b8',
          iconType: 'ball',
        };
    }
  };

  const config = getTeamConfig(normalizedCode);

  return (
    <div
      className={`relative ${sizeClasses} rounded-2xl p-[1.5px] bg-gradient-to-br ${config.bgGradient} border ${config.borderColor} shadow-md flex items-center justify-center shrink-0 select-none overflow-hidden group ${className}`}
      title={name || normalizedCode}
    >
      {/* Inner sheen effect */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-white/20 pointer-events-none" />

      {/* Team Content */}
      <div className="w-full h-full flex flex-col items-center justify-center relative z-10 px-0.5">
        <span className="font-sports font-black tracking-wider leading-none text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
          {normalizedCode}
        </span>
        <span className="text-[7px] leading-tight opacity-90 filter drop-shadow">
          {config.symbol}
        </span>
      </div>
    </div>
  );
}
