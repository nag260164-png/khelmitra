import { Radio, Trophy, Users, Gamepad2, User, ChevronRight, Zap, Sparkles, BookOpen, Award, Gift, Headphones, UserPlus } from 'lucide-react';
import { ActiveSheetType } from '../types';

interface MainActionCardsProps {
  onSelectAction: (action: ActiveSheetType) => void;
  activeSheet: ActiveSheetType;
}

export default function MainActionCards({ onSelectAction, activeSheet }: MainActionCardsProps) {
  return (
    <section id="core-action-buttons-section" className="px-4 pt-4 pb-2">
      <div className="flex items-center justify-between mb-2.5">
        <h2 className="text-xs uppercase font-extrabold tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          Khel Quick Hub
        </h2>
        <span className="text-[11px] text-amber-400 font-semibold flex items-center">
          Tap any button to open
        </span>
      </div>

      {/* Main 5 Required Buttons in a sleek sports gaming grid */}
      <div className="grid grid-cols-2 gap-2.5">
        {/* 1. Live Cricket Button */}
        <button
          id="btn-live-cricket"
          onClick={() => onSelectAction('live-cricket')}
          className={`relative col-span-2 group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'live-cricket'
              ? 'bg-gradient-to-r from-red-950/80 via-rose-900/60 to-slate-900 border-red-500 shadow-lg shadow-red-900/40'
              : 'bg-gradient-to-r from-red-950/40 via-slate-900/80 to-slate-900 border-red-500/30 hover:border-red-500/70 hover:shadow-md hover:shadow-red-950/40'
          } active:scale-[0.98]`}
        >
          {/* Subtle animated red beam */}
          <div className="absolute top-0 right-0 w-32 h-full bg-gradient-to-l from-red-500/10 to-transparent pointer-events-none"></div>

          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="relative w-11 h-11 rounded-xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-400 shadow-inner group-hover:scale-105 transition-transform">
                <Radio className="w-5 h-5 text-red-500 animate-pulse" />
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-[#080b11] animate-ping"></span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold text-white tracking-wide group-hover:text-red-300 transition-colors">
                    Live Cricket
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-red-600 text-[9px] font-black text-white uppercase tracking-wider animate-pulse">
                    LIVE
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-medium">
                  IND vs AUS • 165/4 (17.2 ov) • Need 28 off 16
                </p>
              </div>
            </div>
            <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center text-red-400 group-hover:bg-red-500 group-hover:text-white transition-colors">
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        </button>

        {/* 2. Fantasy Cricket Button */}
        <button
          id="btn-fantasy-cricket"
          onClick={() => onSelectAction('fantasy-cricket')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'fantasy-cricket'
              ? 'bg-gradient-to-b from-amber-950/70 to-slate-900 border-amber-400 shadow-lg shadow-amber-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-amber-500/25 hover:border-amber-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
              <Trophy className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              25L COINS MEGA
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-amber-300 transition-colors">
            Fantasy Cricket
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Join Leagues & Win Big
          </span>
        </button>

        {/* 3. My Teams Button */}
        <button
          id="btn-my-teams"
          onClick={() => onSelectAction('my-teams')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'my-teams'
              ? 'bg-gradient-to-b from-blue-950/70 to-slate-900 border-blue-400 shadow-lg shadow-blue-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-blue-500/25 hover:border-blue-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-blue-500/15 border border-blue-400/30 flex items-center justify-center text-blue-400 group-hover:scale-105 transition-transform">
              <Users className="w-5 h-5 text-blue-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
              3 ACTIVE
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-blue-300 transition-colors">
            My Teams
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Manage Squads & Pts
          </span>
        </button>

        {/* 4. Fantasy Rules & Demo Points System Button */}
        <button
          id="btn-fantasy-rules"
          onClick={() => onSelectAction('fantasy-rules')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'fantasy-rules'
              ? 'bg-gradient-to-b from-amber-950/70 via-orange-950/50 to-slate-900 border-amber-400 shadow-lg shadow-amber-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-amber-500/25 hover:border-amber-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
              <BookOpen className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              DEMO RULES
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-amber-300 transition-colors">
            Rules & Points
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            C/VC, Batting & Bowling
          </span>
        </button>

        {/* 5. Games Button */}
        <button
          id="btn-games"
          onClick={() => onSelectAction('games')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'games'
              ? 'bg-gradient-to-b from-purple-950/70 to-slate-900 border-purple-400 shadow-lg shadow-purple-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-purple-500/25 hover:border-purple-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-purple-500/15 border border-purple-400/30 flex items-center justify-center text-purple-400 group-hover:scale-105 transition-transform">
              <Gamepad2 className="w-5 h-5 text-purple-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-0.5">
              <Sparkles className="w-2.5 h-2.5" />
              ARCADE
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-purple-300 transition-colors">
            Games
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Super Over & Quizzes
          </span>
        </button>

        {/* 6. Daily Missions Button */}
        <button
          id="btn-daily-missions"
          onClick={() => onSelectAction('daily-missions')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'daily-missions'
              ? 'bg-gradient-to-b from-amber-950/70 via-orange-950/50 to-slate-900 border-amber-400 shadow-lg shadow-amber-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-amber-500/25 hover:border-amber-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
              <Gift className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              STREAK COINS
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-amber-300 transition-colors">
            Daily Missions
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Login Gifts & Ad Bonus
          </span>
        </button>

        {/* 7. Profile Button */}
        <button
          id="btn-profile"
          onClick={() => onSelectAction('profile')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'profile'
              ? 'bg-gradient-to-b from-emerald-950/70 to-slate-900 border-emerald-400 shadow-lg shadow-emerald-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-emerald-500/25 hover:border-emerald-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-400/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform">
              <User className="w-5 h-5 text-emerald-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              VIP PRO
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-emerald-300 transition-colors">
            Player Profile
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Stats, Level & Wallet
          </span>
        </button>

        {/* 8. Invite Friends Button */}
        <button
          id="btn-invite-friends"
          onClick={() => onSelectAction('invite-friends')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'invite-friends'
              ? 'bg-gradient-to-b from-amber-950/70 to-slate-900 border-amber-400 shadow-lg shadow-amber-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-amber-500/25 hover:border-amber-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-400/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
              <UserPlus className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              +1,000 COINS
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-amber-300 transition-colors">
            Invite Friends
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            Share Link & Earn Coins
          </span>
        </button>

        {/* 9. Customer Care Button */}
        <button
          id="btn-customer-care"
          onClick={() => onSelectAction('customer-care')}
          className={`relative group overflow-hidden rounded-xl p-3.5 text-left transition-all border ${
            activeSheet === 'customer-care'
              ? 'bg-gradient-to-b from-blue-950/70 to-slate-900 border-blue-400 shadow-lg shadow-blue-900/30'
              : 'bg-gradient-to-b from-slate-900/90 to-slate-950/80 border-blue-500/25 hover:border-blue-400/60'
          } active:scale-[0.98]`}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="w-9 h-9 rounded-xl bg-blue-500/15 border border-blue-400/30 flex items-center justify-center text-blue-400 group-hover:scale-105 transition-transform">
              <Headphones className="w-5 h-5 text-blue-400" />
            </div>
            <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
              24/7 LIVE
            </span>
          </div>
          <span className="text-sm font-bold text-white block group-hover:text-blue-300 transition-colors">
            Customer Care
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">
            WhatsApp, FAQs & Help
          </span>
        </button>
      </div>
    </section>
  );
}
