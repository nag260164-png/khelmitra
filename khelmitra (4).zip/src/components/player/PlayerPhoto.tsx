import { useState } from 'react';
import { User, Shield } from 'lucide-react';

interface PlayerPhotoProps {
  photoUrl?: string;
  name: string;
  role?: string;
  teamShortName?: string;
  flagColor?: string;
  jerseyNumber?: number;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  showBadge?: boolean;
}

export default function PlayerPhoto({
  photoUrl,
  name,
  role = 'BAT',
  teamShortName = 'IND',
  flagColor = 'from-blue-600 to-sky-500',
  jerseyNumber,
  size = 'md',
  className = '',
  showBadge = true,
}: PlayerPhotoProps) {
  const [imageError, setImageError] = useState<boolean>(false);
  const [imageLoaded, setImageLoaded] = useState<boolean>(false);

  // Derive initials
  const initials = name
    ? name
        .split(' ')
        .filter(Boolean)
        .map((n) => n[0])
        .slice(0, 2)
        .join('')
        .toUpperCase()
    : 'P';

  // Dimension mapping
  const sizeMap = {
    xs: {
      container: 'w-7 h-7 text-[10px]',
      badge: 'w-3 h-3 text-[7px]',
      icon: 'w-3.5 h-3.5',
    },
    sm: {
      container: 'w-9 h-9 text-xs',
      badge: 'w-3.5 h-3.5 text-[8px]',
      icon: 'w-4 h-4',
    },
    md: {
      container: 'w-12 h-12 text-sm',
      badge: 'w-4.5 h-4.5 text-[9px]',
      icon: 'w-5 h-5',
    },
    lg: {
      container: 'w-16 h-16 text-base',
      badge: 'w-5 h-5 text-[10px]',
      icon: 'w-7 h-7',
    },
    xl: {
      container: 'w-20 h-20 text-lg',
      badge: 'w-6 h-6 text-xs',
      icon: 'w-9 h-9',
    },
    '2xl': {
      container: 'w-24 h-24 text-xl',
      badge: 'w-7 h-7 text-xs',
      icon: 'w-11 h-11',
    },
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  // Role color
  const getRoleBadgeColor = (r: string) => {
    const roleUpper = r.toUpperCase();
    if (roleUpper.includes('WK') || roleUpper.includes('KEEPER')) return 'bg-amber-500 text-slate-950';
    if (roleUpper.includes('AR') || roleUpper.includes('ALL')) return 'bg-purple-500 text-white';
    if (roleUpper.includes('BOWL')) return 'bg-emerald-500 text-slate-950';
    return 'bg-blue-500 text-white';
  };

  const getRoleShort = (r: string) => {
    const roleUpper = r.toUpperCase();
    if (roleUpper.includes('WK') || roleUpper.includes('KEEPER')) return 'WK';
    if (roleUpper.includes('AR') || roleUpper.includes('ALL')) return 'AR';
    if (roleUpper.includes('BOWL')) return 'BWL';
    return 'BAT';
  };

  const shouldRenderImage = photoUrl && !imageError;

  return (
    <div 
      className={`relative shrink-0 rounded-2xl overflow-hidden border border-slate-700/60 shadow-md ${currentSize.container} ${className}`}
    >
      {/* Background gradient themed by team */}
      <div className={`absolute inset-0 bg-gradient-to-br ${flagColor} opacity-20`} />

      {shouldRenderImage ? (
        <>
          {/* Fallback skeleton while image is loading */}
          {!imageLoaded && (
            <div className="absolute inset-0 bg-slate-800/80 animate-pulse flex items-center justify-center font-black text-slate-400">
              {initials}
            </div>
          )}
          <img
            src={photoUrl}
            alt={name}
            className={`w-full h-full object-cover object-top transition-opacity duration-300 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            loading="lazy"
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
          />
        </>
      ) : (
        /* Graceful fallback when image is missing or errors */
        <div className="w-full h-full bg-[#111928] flex flex-col items-center justify-center relative select-none">
          <div className="font-extrabold text-slate-200 tracking-wider">
            {initials}
          </div>
          {jerseyNumber && size !== 'xs' && size !== 'sm' && (
            <span className="text-[9px] font-mono text-slate-400 font-bold opacity-80">
              #{jerseyNumber}
            </span>
          )}
        </div>
      )}

      {/* Role Pill Badge */}
      {showBadge && (
        <div
          className={`absolute bottom-0 right-0 px-1 py-0.2 rounded-tl-md font-black tracking-tighter ${getRoleBadgeColor(
            role
          )} shadow`}
          style={{ fontSize: '8px', lineHeight: '10px' }}
        >
          {getRoleShort(role)}
        </div>
      )}
    </div>
  );
}
