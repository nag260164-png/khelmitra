import { useState, useEffect } from 'react';
import {
  X,
  Trophy,
  Shield,
  Award,
  TrendingUp,
  Activity,
  CheckCircle2,
  Plus,
  Minus,
  AlertCircle,
  HelpCircle,
  Calendar,
  Sparkles,
  Zap,
  ChevronRight,
  Flame,
  Clock,
  Radio,
  Info,
} from 'lucide-react';
import { PlayerDetailedProfile, PlayerRecentMatchPerformance } from '../../types';
import { playerDetailsService } from '../../services/playerDetailsService';
import PlayerPhoto from './PlayerPhoto';

interface PlayerDetailsModalProps {
  player?: PlayerDetailedProfile | null;
  playerId?: string | null;
  playerName?: string | null;
  isOpen: boolean;
  onClose: () => void;
  // Fantasy team selection integration
  isSelected?: boolean;
  onToggleSelect?: (player: PlayerDetailedProfile) => void;
  canSelect?: boolean;
  selectionDisabledReason?: string;
}

type TabType = 'overview' | 'batting' | 'bowling' | 'matches' | 'points';

export default function PlayerDetailsModal({
  player: propPlayer,
  playerId,
  playerName,
  isOpen,
  onClose,
  isSelected = false,
  onToggleSelect,
  canSelect = true,
  selectionDisabledReason,
}: PlayerDetailsModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [player, setPlayer] = useState<PlayerDetailedProfile | null>(propPlayer || null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Load player if ID or name is provided and propPlayer is not
  useEffect(() => {
    if (propPlayer) {
      setPlayer(propPlayer);
      setError(null);
      return;
    }

    if (playerId) {
      setLoading(true);
      setError(null);
      const found = playerDetailsService.getPlayerById(playerId);
      if (found) {
        setPlayer(found);
      } else {
        setError(`Player profile not found for ID "${playerId}".`);
      }
      setLoading(false);
    } else if (playerName) {
      setLoading(true);
      setError(null);
      const found = playerDetailsService.getPlayerByName(playerName);
      if (found) {
        setPlayer(found);
      } else {
        setError(`Player profile not found for name "${playerName}".`);
      }
      setLoading(false);
    }
  }, [propPlayer, playerId, playerName, isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      id="player-details-modal-overlay"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="player-details-modal-container"
        className="w-full max-w-md max-h-[92vh] h-[92vh] sm:h-auto sm:max-h-[85vh] bg-[#080d1a] border-t sm:border border-slate-700/80 rounded-t-3xl sm:rounded-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ================= HEADER ================= */}
        <header className="relative bg-gradient-to-b from-[#101728] to-[#0a101f] border-b border-slate-800 p-4 shrink-0">
          {/* Top Row: Dismiss & Credits/Selection Badges */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 border border-amber-500/30 text-amber-300 font-extrabold text-[10px] tracking-wider uppercase">
                Free Demo Fantasy
              </span>
              {player?.isCaptain && (
                <span className="px-1.5 py-0.5 rounded bg-amber-500 text-slate-950 font-black text-[9px]">
                  CAPTAIN (C)
                </span>
              )}
            </div>

            <button
              id="player-modal-close-btn"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center active:scale-95 transition-all"
              aria-label="Close player details"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Loading Skeleton */}
          {loading && (
            <div className="flex items-center gap-4 py-3 animate-pulse">
              <div className="w-16 h-16 rounded-2xl bg-slate-800" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-slate-800 rounded w-3/4" />
                <div className="h-3 bg-slate-800/70 rounded w-1/2" />
              </div>
            </div>
          )}

          {/* Error State */}
          {!loading && error && (
            <div className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 flex items-center gap-2 text-xs my-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* Player Info Card Header */}
          {!loading && player && (
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3.5">
                {/* Player Photo with fallback */}
                <PlayerPhoto
                  photoUrl={player.photoUrl}
                  name={player.name}
                  role={player.role}
                  teamShortName={player.teamShortName}
                  flagColor={player.flagColor}
                  jerseyNumber={player.jerseyNumber}
                  size="lg"
                />

                {/* Name, Team, Role */}
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base sm:text-lg font-black text-white leading-tight">
                      {player.name}
                    </h2>
                    {player.jerseyNumber && (
                      <span className="text-xs font-mono font-bold text-slate-400">
                        #{player.jerseyNumber}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 text-[10px] font-bold">
                      {player.teamName} ({player.teamShortName})
                    </span>
                    <span className="text-slate-600 text-xs">•</span>
                    <span className="text-xs font-semibold text-amber-400">
                      {player.role}
                    </span>
                  </div>

                  {/* Batting & Bowling Style Chips */}
                  <div className="flex flex-wrap items-center gap-1.5 mt-1 text-[10px] text-slate-400">
                    <span className="bg-slate-900/90 px-1.5 py-0.5 rounded border border-slate-800">
                      🏏 {player.battingStyle}
                    </span>
                    {player.bowlingStyle && player.bowlingStyle !== '-' && (
                      <span className="bg-slate-900/90 px-1.5 py-0.5 rounded border border-slate-800">
                        🎯 {player.bowlingStyle}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Fantasy Credits & Demo Points */}
              <div className="text-right shrink-0 bg-slate-900/80 border border-slate-800 rounded-xl p-2 min-w-[76px]">
                <span className="text-[9px] uppercase font-mono text-slate-400 block">
                  Credits
                </span>
                <span className="text-sm font-sports font-bold text-amber-400">
                  {player.credits} Cr
                </span>
                <span className="text-[9px] text-slate-500 block mt-0.5">
                  Sel {player.selectedByPercent}%
                </span>
              </div>
            </div>
          )}

          {/* Quick Stats Pill Banner */}
          {!loading && player && (
            <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-800/80 text-center">
              <div className="bg-[#070b14] rounded-xl py-1.5 px-2 border border-slate-800/60">
                <span className="text-[9px] uppercase text-slate-400 font-mono block">
                  Total Demo Pts
                </span>
                <span className="text-sm font-sports font-bold text-emerald-400">
                  {player.totalDemoPoints}
                </span>
              </div>
              <div className="bg-[#070b14] rounded-xl py-1.5 px-2 border border-slate-800/60">
                <span className="text-[9px] uppercase text-slate-400 font-mono block">
                  Avg Pts/Match
                </span>
                <span className="text-sm font-sports font-bold text-cyan-400">
                  {player.averageDemoPoints}
                </span>
              </div>
              <div className="bg-[#070b14] rounded-xl py-1.5 px-2 border border-slate-800/60">
                <span className="text-[9px] uppercase text-slate-400 font-mono block">
                  Matches Played
                </span>
                <span className="text-sm font-sports font-bold text-white">
                  {player.battingStats.matches}
                </span>
              </div>
            </div>
          )}
        </header>

        {/* ================= NAVIGATION TABS ================= */}
        {!loading && player && (
          <nav className="flex bg-[#070b14] border-b border-slate-800 text-xs shrink-0 overflow-x-auto no-scrollbar">
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'batting', label: 'Batting Stats' },
              { id: 'bowling', label: 'Bowling Stats' },
              { id: 'matches', label: 'Recent Matches' },
              { id: 'points', label: 'Demo Points' },
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`player-tab-${tab.id}`}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`flex-1 min-w-[72px] py-2.5 px-2 text-center font-bold text-xs border-b-2 transition-all whitespace-nowrap ${
                    isActive
                      ? 'border-amber-400 text-amber-400 bg-amber-500/5'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </nav>
        )}

        {/* ================= TAB BODY ================= */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar text-slate-200">
          {!loading && player && (
            <>
              {/* ------------ 1. OVERVIEW TAB ------------ */}
              {activeTab === 'overview' && (
                <div className="space-y-3.5 animate-in fade-in duration-200">
                  {/* Primary Performance Metrics Card */}
                  <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-[#0e1626] border border-slate-800 p-3.5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono flex items-center gap-1.5">
                        <Activity className="w-3.5 h-3.5 text-amber-400" />
                        Key Performance Record
                      </span>
                      <span className="text-[10px] text-slate-400">
                        Official International T20/ODI
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-center">
                        <span className="text-[10px] text-slate-400 block font-mono">Runs</span>
                        <span className="text-base font-sports font-bold text-white">
                          {player.battingStats.runs}
                        </span>
                        <span className="text-[9px] text-slate-500 block">
                          Avg: {player.battingStats.average}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-center">
                        <span className="text-[10px] text-slate-400 block font-mono">Strike Rate</span>
                        <span className="text-base font-sports font-bold text-amber-400">
                          {player.battingStats.strikeRate}
                        </span>
                        <span className="text-[9px] text-slate-500 block">
                          HS: {player.battingStats.highestScore}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-center">
                        <span className="text-[10px] text-slate-400 block font-mono">Wickets</span>
                        <span className="text-base font-sports font-bold text-emerald-400">
                          {player.bowlingStats.wickets}
                        </span>
                        <span className="text-[9px] text-slate-500 block">
                          BBI: {player.bowlingStats.bestBowling}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-center">
                        <span className="text-[10px] text-slate-400 block font-mono">Catches</span>
                        <span className="text-base font-sports font-bold text-cyan-400">
                          {player.fieldingStats.catches}
                        </span>
                        <span className="text-[9px] text-slate-500 block">
                          {player.fieldingStats.stumpings > 0 ? `${player.fieldingStats.stumpings} St` : 'Fielding'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Economy Rate & Boundary Index */}
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] font-mono text-slate-400 block uppercase">
                        Bowling Economy Rate
                      </span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-xl font-sports font-bold text-white">
                          {player.bowlingStats.economyRate > 0 ? player.bowlingStats.economyRate : 'N/A'}
                        </span>
                        <span className="text-[10px] text-slate-400">RPO</span>
                      </div>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {player.bowlingStats.maidens} maiden overs
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                      <span className="text-[10px] font-mono text-slate-400 block uppercase">
                        Boundaries Hit
                      </span>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className="text-xl font-sports font-bold text-amber-300">
                          {player.battingStats.fours} <span className="text-xs text-slate-400 font-sans">4s</span>
                        </span>
                        <span className="text-xl font-sports font-bold text-orange-400">
                          {player.battingStats.sixes} <span className="text-xs text-slate-400 font-sans">6s</span>
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        {player.battingStats.fifties} 50s • {player.battingStats.hundreds} 100s
                      </span>
                    </div>
                  </div>

                  {/* Recent Match Performance Teaser */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                        Recent Match Form
                      </span>
                      <button
                        onClick={() => setActiveTab('matches')}
                        className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-0.5"
                      >
                        All Matches
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>

                    {player.recentMatches.length > 0 ? (
                      player.recentMatches.slice(0, 2).map((rm, idx) => (
                        <div
                          key={idx}
                          className="p-3 rounded-xl bg-slate-900/70 border border-slate-800 flex items-center justify-between gap-3"
                        >
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-white">{rm.opponent}</span>
                              <span className="text-[10px] text-slate-400">• {rm.date}</span>
                            </div>
                            <div className="text-[11px] text-slate-300 mt-0.5">
                              {rm.runs > 0 && <span>{rm.runs} runs ({rm.balls}b, {rm.fours}x4, {rm.sixes}x6) </span>}
                              {rm.wickets > 0 && <span className="text-emerald-400">• {rm.wickets} wkts ({rm.overs} ov)</span>}
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <span className="text-xs font-sports font-bold text-emerald-400 block">
                              +{rm.demoPoints} Pts
                            </span>
                            <span className="text-[9px] text-slate-500 font-mono">Demo Fantasy</span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="p-3 rounded-xl bg-slate-900/40 border border-slate-800 text-center text-xs text-slate-400">
                        Tournament stage matches will update dynamically.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ------------ 2. BATTING STATISTICS TAB ------------ */}
              {activeTab === 'batting' && (
                <div className="space-y-3 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                      Career Batting Performance
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Format: International T20
                    </span>
                  </div>

                  {/* Batting Stats Grid */}
                  <div className="rounded-2xl bg-slate-900 border border-slate-800 divide-y divide-slate-800/80 overflow-hidden">
                    <div className="grid grid-cols-2 p-3 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Matches</span>
                        <span className="text-sm font-bold text-white">{player.battingStats.matches}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Innings</span>
                        <span className="text-sm font-bold text-white">{player.battingStats.innings}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 p-3 gap-2 bg-slate-950/40">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Total Runs</span>
                        <span className="text-base font-sports font-bold text-amber-300">{player.battingStats.runs}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Highest Score</span>
                        <span className="text-base font-sports font-bold text-white">{player.battingStats.highestScore}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 p-3 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Batting Average</span>
                        <span className="text-sm font-bold text-emerald-400">{player.battingStats.average}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Strike Rate</span>
                        <span className="text-sm font-bold text-cyan-400">{player.battingStats.strikeRate}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 p-3 gap-2 text-center bg-slate-950/40">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">100s</span>
                        <span className="text-sm font-bold text-white">{player.battingStats.hundreds}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">50s</span>
                        <span className="text-sm font-bold text-white">{player.battingStats.fifties}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">4s</span>
                        <span className="text-sm font-bold text-amber-400">{player.battingStats.fours}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">6s</span>
                        <span className="text-sm font-bold text-orange-400">{player.battingStats.sixes}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 p-3 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Not Outs</span>
                        <span className="text-sm font-bold text-slate-300">{player.battingStats.notOuts}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Ducks (0 runs)</span>
                        <span className="text-sm font-bold text-slate-300">{player.battingStats.ducks}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ------------ 3. BOWLING STATISTICS TAB ------------ */}
              {activeTab === 'bowling' && (
                <div className="space-y-3 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                      Career Bowling Performance
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Style: {player.bowlingStyle || 'Bowler'}
                    </span>
                  </div>

                  {/* Bowling Stats Grid */}
                  <div className="rounded-2xl bg-slate-900 border border-slate-800 divide-y divide-slate-800/80 overflow-hidden">
                    <div className="grid grid-cols-2 p-3 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Overs Bowled</span>
                        <span className="text-sm font-bold text-white">{player.bowlingStats.overs}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Maiden Overs</span>
                        <span className="text-sm font-bold text-white">{player.bowlingStats.maidens}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 p-3 gap-2 bg-slate-950/40">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Wickets Taken</span>
                        <span className="text-base font-sports font-bold text-emerald-400">
                          {player.bowlingStats.wickets}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Best Bowling (BBI)</span>
                        <span className="text-base font-sports font-bold text-white">
                          {player.bowlingStats.bestBowling}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 p-3 gap-2">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Economy Rate</span>
                        <span className="text-sm font-bold text-amber-400">
                          {player.bowlingStats.economyRate > 0 ? player.bowlingStats.economyRate : 'N/A'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono uppercase block">Bowling Average</span>
                        <span className="text-sm font-bold text-cyan-400">
                          {player.bowlingStats.bowlingAverage > 0 ? player.bowlingStats.bowlingAverage : 'N/A'}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 p-3 gap-2 text-center bg-slate-950/40">
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">Runs Conceded</span>
                        <span className="text-sm font-bold text-slate-200">{player.bowlingStats.runsConceded}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">3-Wkt Hauls</span>
                        <span className="text-sm font-bold text-white">{player.bowlingStats.threeWickets}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-mono block">5-Wkt Hauls</span>
                        <span className="text-sm font-bold text-emerald-400">{player.bowlingStats.fiveWickets}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ------------ 4. RECENT MATCHES TAB ------------ */}
              {activeTab === 'matches' && (
                <div className="space-y-3 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
                      Recent Match History
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {player.recentMatches.length} Matches Logged
                    </span>
                  </div>

                  {player.recentMatches.length === 0 ? (
                    <div className="p-6 text-center bg-slate-900/60 rounded-2xl border border-slate-800 space-y-1">
                      <Info className="w-6 h-6 text-slate-500 mx-auto" />
                      <span className="text-xs font-bold text-slate-300 block">No recent matches logged</span>
                      <span className="text-[11px] text-slate-500 block">
                        Live match performances are updated ball-by-ball.
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {player.recentMatches.map((rm, idx) => (
                        <div
                          key={idx}
                          className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800/90 hover:border-slate-700 space-y-2.5 transition-all"
                        >
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-bold text-white">vs {rm.opponent}</span>
                                <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 text-[9px] font-bold">
                                  {rm.format}
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-400 block">{rm.matchTitle}</span>
                              <span className="text-[10px] text-emerald-400 font-medium block mt-0.5">
                                {rm.result}
                              </span>
                            </div>

                            <div className="text-right">
                              <span className="text-xs font-sports font-bold text-amber-400 block">
                                +{rm.demoPoints} Demo Pts
                              </span>
                              <span className="text-[9px] text-slate-500">{rm.date}</span>
                            </div>
                          </div>

                          {/* Stat Line */}
                          <div className="grid grid-cols-3 gap-1.5 text-center p-2 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px]">
                            <div>
                              <span className="text-[9px] text-slate-500 font-mono block">BAT</span>
                              <span className="font-bold text-white">
                                {rm.runs} ({rm.balls}b)
                              </span>
                            </div>
                            <div>
                              <span className="text-[9px] text-slate-500 font-mono block">BOWL</span>
                              <span className="font-bold text-white">
                                {rm.wickets}/{rm.runsConceded} ({rm.overs} ov)
                              </span>
                            </div>
                            <div>
                              <span className="text-[9px] text-slate-500 font-mono block">FIELD</span>
                              <span className="font-bold text-white">
                                {rm.catches} ct, {rm.stumpings} st
                              </span>
                            </div>
                          </div>

                          {rm.breakdownSummary && (
                            <span className="text-[10px] text-slate-400 block italic leading-relaxed">
                              Breakdown: {rm.breakdownSummary}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* ------------ 5. DEMO POINTS TAB ------------ */}
              {activeTab === 'points' && (
                <div className="space-y-3 animate-in fade-in duration-200">
                  <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-slate-900 to-amber-500/5 border border-amber-500/30 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                        <Trophy className="w-3.5 h-3.5 text-amber-400" />
                        KhelMitra Demo Points System
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-black">
                        100% FREE PLAY
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block leading-relaxed">
                      Points earned by {player.name} in KhelMitra fantasy contests are demo practice points with no cash betting or real money value.
                    </span>
                  </div>

                  {/* Multiplier Impact Simulation */}
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-white block">
                      Captain & Vice-Captain Multiplier Impact
                    </span>

                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="text-[10px] text-slate-400 font-mono block">Regular Player</span>
                        <span className="text-base font-sports font-bold text-white">
                          {player.totalDemoPoints}
                        </span>
                        <span className="text-[9px] text-slate-500 block">1.0x Base</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/40">
                        <span className="text-[10px] text-amber-300 font-mono block">If Vice-Captain</span>
                        <span className="text-base font-sports font-bold text-amber-400">
                          {Math.round(player.totalDemoPoints * 1.5 * 10) / 10}
                        </span>
                        <span className="text-[9px] text-amber-500/80 block">1.5x Multiplier</span>
                      </div>

                      <div className="p-2.5 rounded-xl bg-orange-950/40 border border-orange-500/40">
                        <span className="text-[10px] text-orange-300 font-mono block">If Captain</span>
                        <span className="text-base font-sports font-bold text-orange-400">
                          {Math.round(player.totalDemoPoints * 2.0 * 10) / 10}
                        </span>
                        <span className="text-[9px] text-orange-500/80 block">2.0x (Doubled)</span>
                      </div>
                    </div>
                  </div>

                  {/* Scoring Rules Reminder */}
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1.5 text-xs">
                    <span className="text-[11px] font-bold text-slate-300 block">
                      Standard Scoring Rates:
                    </span>
                    <ul className="text-[11px] text-slate-400 space-y-1 list-disc list-inside">
                      <li>Batting: +1 pt per run, +1 four bonus, +2 six bonus</li>
                      <li>Milestones: +8 pts (50), +16 pts (100)</li>
                      <li>Bowling: +25 pts per wicket, +8 pts maiden over</li>
                      <li>Fielding: +8 pts catch, +12 pts stumping, +6 pts runout</li>
                    </ul>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* ================= FOOTER SELECTION ACTION ================= */}
        {!loading && player && (
          <footer className="p-3.5 bg-[#090f1d] border-t border-slate-800 shrink-0 flex items-center justify-between gap-3">
            <div>
              <span className="text-[10px] text-slate-400 block font-mono">
                {isSelected ? 'Selected in Current Team' : 'Available for Selection'}
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-sm font-sports font-bold text-amber-300">
                  {player.credits} Cr
                </span>
                <span className="text-slate-600">•</span>
                <span className="text-xs text-slate-300 font-bold">
                  {player.role} ({player.teamShortName})
                </span>
              </div>
            </div>

            {onToggleSelect && (
              <button
                id="modal-toggle-select-player-btn"
                disabled={!canSelect && !isSelected}
                onClick={() => onToggleSelect(player)}
                className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md active:scale-95 transition-all ${
                  isSelected
                    ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/20'
                    : canSelect
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black shadow-amber-500/20'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                {isSelected ? (
                  <>
                    <Minus className="w-3.5 h-3.5" />
                    <span>Remove from 11</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>Select Player</span>
                  </>
                )}
              </button>
            )}

            {!onToggleSelect && (
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold"
              >
                Close Profile
              </button>
            )}
          </footer>
        )}
      </div>
    </div>
  );
}
