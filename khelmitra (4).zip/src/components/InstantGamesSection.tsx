import { Gamepad2, Flame, Zap, Award, Sparkles, ChevronRight, Play } from 'lucide-react';
import { GameItem, ActiveSheetType } from '../types';

interface InstantGamesSectionProps {
  games: GameItem[];
  onOpenGames: (sheet: ActiveSheetType) => void;
}

export default function InstantGamesSection({ games, onOpenGames }: InstantGamesSectionProps) {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Flame': return <Flame className="w-4 h-4 text-orange-400" />;
      case 'Zap': return <Zap className="w-4 h-4 text-amber-400" />;
      case 'Award': return <Award className="w-4 h-4 text-emerald-400" />;
      default: return <Sparkles className="w-4 h-4 text-purple-400" />;
    }
  };

  return (
    <section id="games-section" className="px-4 py-2">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xs uppercase font-extrabold tracking-wider text-purple-400 font-mono flex items-center gap-1.5">
          <Gamepad2 className="w-3.5 h-3.5 text-purple-400" />
          Khel Games Arena
        </h2>
        <button
          id="see-all-games-btn"
          onClick={() => onOpenGames('games')}
          className="text-xs font-bold text-purple-400 hover:text-purple-300 flex items-center gap-0.5"
        >
          Games Zone
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        {games.slice(0, 2).map((game) => (
          <div
            key={game.id}
            onClick={() => onOpenGames('games')}
            className={`p-3.5 rounded-2xl bg-gradient-to-br ${game.bgGradient} bg-slate-900/90 border border-slate-800 hover:border-purple-500/50 cursor-pointer group active:scale-[0.98] transition-all flex flex-col justify-between`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="w-8 h-8 rounded-lg bg-slate-950/80 border border-slate-700/80 flex items-center justify-center">
                  {getIcon(game.iconName)}
                </div>
                <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {game.tag}
                </span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors">
                {game.title}
              </h3>
              <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                {game.description}
              </p>
            </div>

            <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-xs font-bold text-amber-400">{game.prizePool}</span>
              <button 
                id={`play-${game.id}-btn`}
                className="w-6 h-6 rounded-full bg-purple-600 group-hover:bg-purple-500 flex items-center justify-center text-white shadow-sm"
              >
                <Play className="w-3 h-3 fill-white ml-0.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Main Full-Width Games Button */}
      <div className="mt-2.5">
        <button
          id="explore-all-games-btn"
          onClick={() => onOpenGames('games')}
          className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-900/40 via-slate-900 to-purple-900/30 hover:from-purple-900/60 hover:to-purple-900/50 border border-purple-500/30 hover:border-purple-400/60 text-purple-200 font-bold text-xs flex items-center justify-center gap-2 active:scale-98 transition-all"
        >
          <Gamepad2 className="w-4 h-4 text-purple-400" />
          <span>Open Khel Games Arcade (Quizzes, Puzzles & Memory)</span>
          <ChevronRight className="w-4 h-4 text-purple-400" />
        </button>
      </div>
    </section>
  );
}
