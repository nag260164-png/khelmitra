import { Trophy, Zap, Clock, ShieldCheck, ChevronRight, Award, BookOpen } from 'lucide-react';
import { FantasyContest, ActiveSheetType } from '../types';

interface FantasyMegaBannerProps {
  contest: FantasyContest;
  onOpenFantasy: (sheet: ActiveSheetType) => void;
}

export default function FantasyMegaBanner({ contest, onOpenFantasy }: FantasyMegaBannerProps) {
  const percentFilled = Math.round((contest.filledSpots / contest.totalSpots) * 100);

  return (
    <section id="fantasy-cricket-banner-section" className="px-4 py-2">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-xs uppercase font-extrabold tracking-wider text-amber-400 font-mono flex items-center gap-1.5">
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          Fantasy Cricket League
        </h2>
        <div className="flex items-center gap-2">
          <button
            id="fantasy-banner-rules-btn"
            onClick={() => onOpenFantasy('fantasy-rules')}
            className="text-xs font-bold text-slate-300 hover:text-amber-300 flex items-center gap-1 transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            Rules & Points
          </button>
          <span className="text-slate-700">•</span>
          <button
            id="see-all-fantasy-btn"
            onClick={() => onOpenFantasy('fantasy-cricket')}
            className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-0.5"
          >
            Contests
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      <div 
        id="fantasy-mega-card"
        className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-[#101725] border border-amber-500/40 p-4 shadow-xl shadow-black/50"
      >
        {/* Shimmer background */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-b from-amber-500/10 via-orange-500/5 to-transparent rounded-full blur-2xl pointer-events-none"></div>

        <div className="flex items-center justify-between gap-2 mb-2 relative z-10">
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-black uppercase tracking-wider border border-amber-500/30 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
              MEGA CONTEST
            </span>
            <span className="flex items-center gap-1 text-[11px] text-slate-300 font-medium">
              <Clock className="w-3 h-3 text-slate-400" />
              {contest.matchTime}
            </span>
          </div>

          <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            100% Guaranteed
          </span>
        </div>

        {/* Prize Pool Display */}
        <div className="flex items-baseline justify-between py-1 relative z-10">
          <div>
            <span className="text-[11px] text-slate-400 font-medium block">Total Guaranteed Prize Pool</span>
            <span className="text-3xl font-sports font-black tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-500">
              {contest.prizePool}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[11px] text-slate-400 block">1st Prize</span>
            <span className="text-sm font-extrabold text-amber-300">{contest.firstPrize}</span>
          </div>
        </div>

        {/* Progress Bar of Spots Filled */}
        <div className="my-2.5 relative z-10">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 mb-1">
            <span>{contest.filledSpots.toLocaleString()} spots filled</span>
            <span className="text-amber-400 font-bold">{percentFilled}% Full</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-800/90 overflow-hidden p-0.5">
            <div 
              style={{ width: `${percentFilled}%` }} 
              className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-500"
            ></div>
          </div>
          <div className="flex justify-between text-[10px] text-slate-500 mt-1">
            <span>{(contest.totalSpots - contest.filledSpots).toLocaleString()} spots left</span>
            <span>Max 20 Teams</span>
          </div>
        </div>

        {/* Action Button: Fantasy Cricket Button */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-2">
            <span className="line-through text-xs text-slate-500 font-medium">₹{contest.entryFee}</span>
            <div className="flex items-center gap-1">
              <span className="text-lg font-sports font-bold text-emerald-400">₹{contest.discountedFee}</span>
              <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 text-[9px] font-bold rounded">
                50% OFF
              </span>
            </div>
          </div>

          <button
            id="fantasy-cricket-join-btn"
            onClick={() => onOpenFantasy('fantasy-cricket')}
            className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 active:scale-95 transition-all"
          >
            <Trophy className="w-4 h-4 text-slate-950" />
            <span>Fantasy Cricket • Join Now</span>
          </button>
        </div>
      </div>
    </section>
  );
}
