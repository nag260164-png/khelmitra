import React, { useState } from 'react';
import { 
  Users, Search, ShieldAlert, ShieldCheck, Star, 
  Ban, CheckCircle, Award, Coins, Flame, ChevronDown, 
  ChevronUp, Plus, Minus, Filter, Activity, Clock
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { MasterOwnerUser } from '../../../types';

export default function UserManagementTab() {
  const [users, setUsers] = useState<MasterOwnerUser[]>(masterOwnerService.getUsers());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'blocked' | 'vip'>('all');
  const [expandedUserId, setExpandedUserId] = useState<string | null>(null);
  const [adjustCoinAmount, setAdjustCoinAmount] = useState<number>(500);
  const [adjustReason, setAdjustReason] = useState<string>('Loyalty Reward');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const refreshUsers = () => {
    setUsers([...masterOwnerService.getUsers()]);
  };

  const showNotification = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  const handleStatusChange = (userId: string, newStatus: 'active' | 'blocked' | 'vip') => {
    masterOwnerService.toggleUserStatus(userId, newStatus);
    refreshUsers();
    showNotification(`User status updated to ${newStatus.toUpperCase()}`);
  };

  const handleTogglePermission = (
    userId: string, 
    permKey: keyof MasterOwnerUser['permissions'], 
    currentVal: boolean
  ) => {
    masterOwnerService.updateUserPermissions(userId, { [permKey]: !currentVal });
    refreshUsers();
    showNotification(`User permission updated`);
  };

  const handleAdjustCoins = (userId: string, delta: number) => {
    masterOwnerService.adjustUserCoins(userId, delta, adjustReason);
    refreshUsers();
    showNotification(`${delta > 0 ? 'Granted' : 'Deducted'} ${Math.abs(delta)} virtual coins`);
  };

  // Filter and search
  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.phone.includes(searchQuery) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = 
      statusFilter === 'all' ? true : user.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  // Metrics
  const totalUsers = users.length;
  const activeCount = users.filter(u => u.status === 'active' || u.status === 'vip').length;
  const blockedCount = users.filter(u => u.status === 'blocked').length;
  const vipCount = users.filter(u => u.status === 'vip').length;
  const totalCoinsInCirculation = users.reduce((acc, u) => acc + u.coins, 0);

  return (
    <div className="space-y-4">
      {/* Toast */}
      {successToast && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-4 gap-2">
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Users</span>
          <span className="text-base font-black text-white font-mono">{totalUsers}</span>
        </div>
        <div className="p-2.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-center">
          <span className="text-[10px] text-emerald-400 uppercase font-bold block">Active</span>
          <span className="text-base font-black text-emerald-300 font-mono">{activeCount}</span>
        </div>
        <div className="p-2.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 text-center">
          <span className="text-[10px] text-amber-400 uppercase font-bold block">VIP Club</span>
          <span className="text-base font-black text-amber-300 font-mono">{vipCount}</span>
        </div>
        <div className="p-2.5 rounded-2xl bg-red-950/40 border border-red-500/30 text-center">
          <span className="text-[10px] text-red-400 uppercase font-bold block">Blocked</span>
          <span className="text-base font-black text-red-300 font-mono">{blockedCount}</span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col gap-2">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, username, mobile or ID..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 focus:border-amber-400 text-xs text-white placeholder:text-slate-600 focus:outline-none"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[10px] text-slate-400 font-bold uppercase flex items-center gap-1 pr-1">
            <Filter className="w-3 h-3 text-slate-500" /> Filter:
          </span>
          {(['all', 'active', 'vip', 'blocked'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setStatusFilter(filter)}
              className={`px-3 py-1 rounded-lg text-xs font-bold capitalize transition-all ${
                statusFilter === filter
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Users List */}
      <div className="space-y-2">
        {filteredUsers.length === 0 ? (
          <div className="p-8 text-center bg-slate-950 rounded-2xl border border-slate-800 text-slate-500 text-xs">
            No matching users found in directory.
          </div>
        ) : (
          filteredUsers.map((user) => {
            const isExpanded = expandedUserId === user.id;

            return (
              <div
                key={user.id}
                className="rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all overflow-hidden shadow-sm"
              >
                {/* Header Row */}
                <div
                  className="p-3 flex items-center justify-between cursor-pointer"
                  onClick={() => setExpandedUserId(isExpanded ? null : user.id)}
                >
                  <div className="flex items-center gap-2.5">
                    <div className="relative">
                      <img
                        src={user.avatarUrl}
                        alt={user.name}
                        className="w-9 h-9 rounded-xl object-cover border border-slate-700"
                        referrerPolicy="no-referrer"
                      />
                      {user.status === 'blocked' ? (
                        <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-red-500 border border-[#070b14] flex items-center justify-center">
                          <Ban className="w-2.5 h-2.5 text-white" />
                        </div>
                      ) : user.status === 'vip' ? (
                        <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-500 border border-[#070b14] flex items-center justify-center">
                          <Star className="w-2.5 h-2.5 text-slate-950 fill-slate-950" />
                        </div>
                      ) : (
                        <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-500 border border-[#070b14]"></div>
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">{user.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">@{user.username}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400">
                        <span className="text-amber-400 font-bold font-mono">🪙 {user.coins.toLocaleString()}</span>
                        <span>•</span>
                        <span>Win: {user.winRate}</span>
                        <span>•</span>
                        <span>Lvl {user.level}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Status badge */}
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                        user.status === 'active'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : user.status === 'vip'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-red-500/20 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {user.status}
                    </span>

                    {/* Expand Chevron */}
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </div>

                {/* Expanded Details Panel */}
                {isExpanded && (
                  <div className="p-3.5 pt-1 border-t border-slate-800/80 bg-slate-950/60 space-y-3 animate-in fade-in duration-150">
                    {/* Activity & Risk Score Grid */}
                    <div className="grid grid-cols-3 gap-2 text-[11px]">
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="text-slate-500 text-[10px] block">Matches Played</span>
                        <span className="font-bold text-white font-mono">{user.matchesPlayed} games</span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="text-slate-500 text-[10px] block">Risk Score</span>
                        <span className={`font-bold font-mono ${user.riskScore > 50 ? 'text-red-400' : 'text-emerald-400'}`}>
                          {user.riskScore}% {user.riskScore > 50 ? '⚠️ High' : '✓ Clean'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="text-slate-500 text-[10px] block">Last Active</span>
                        <span className="font-bold text-slate-300">{user.lastActive}</span>
                      </div>
                    </div>

                    {/* Contact details */}
                    <div className="text-[11px] text-slate-400 flex flex-wrap gap-3 p-2 rounded-xl bg-slate-900/50 border border-slate-800/60">
                      <div><span className="text-slate-500">Phone:</span> <span className="text-slate-300 font-mono">{user.phone}</span></div>
                      <div><span className="text-slate-500">Email:</span> <span className="text-slate-300">{user.email}</span></div>
                      <div><span className="text-slate-500">Joined:</span> <span className="text-slate-300">{user.joinDate}</span></div>
                    </div>

                    {/* Permissions Toggles */}
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        User Permissions & Capabilities
                      </span>
                      <div className="grid grid-cols-3 gap-1.5">
                        <button
                          onClick={() => handleTogglePermission(user.id, 'canPlayGames', user.permissions.canPlayGames)}
                          className={`p-1.5 rounded-lg border text-[11px] font-semibold flex items-center justify-between ${
                            user.permissions.canPlayGames
                              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                              : 'bg-red-950/30 border-red-500/30 text-red-400'
                          }`}
                        >
                          <span>Play Games</span>
                          <span>{user.permissions.canPlayGames ? '✓' : '✕'}</span>
                        </button>

                        <button
                          onClick={() => handleTogglePermission(user.id, 'canJoinContests', user.permissions.canJoinContests)}
                          className={`p-1.5 rounded-lg border text-[11px] font-semibold flex items-center justify-between ${
                            user.permissions.canJoinContests
                              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                              : 'bg-red-950/30 border-red-500/30 text-red-400'
                          }`}
                        >
                          <span>Join Contests</span>
                          <span>{user.permissions.canJoinContests ? '✓' : '✕'}</span>
                        </button>

                        <button
                          onClick={() => handleTogglePermission(user.id, 'canChatSupport', user.permissions.canChatSupport)}
                          className={`p-1.5 rounded-lg border text-[11px] font-semibold flex items-center justify-between ${
                            user.permissions.canChatSupport
                              ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                              : 'bg-red-950/30 border-red-500/30 text-red-400'
                          }`}
                        >
                          <span>Chat/Care</span>
                          <span>{user.permissions.canChatSupport ? '✓' : '✕'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Status Management Buttons */}
                    <div className="flex items-center gap-2 pt-1">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Set Status:</span>
                      <button
                        onClick={() => handleStatusChange(user.id, 'active')}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                          user.status === 'active'
                            ? 'bg-emerald-500 text-slate-950'
                            : 'bg-slate-800 text-slate-300 hover:text-white'
                        }`}
                      >
                        Active
                      </button>
                      <button
                        onClick={() => handleStatusChange(user.id, 'vip')}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                          user.status === 'vip'
                            ? 'bg-amber-500 text-slate-950'
                            : 'bg-slate-800 text-slate-300 hover:text-white'
                        }`}
                      >
                        ⭐ VIP
                      </button>
                      <button
                        onClick={() => handleStatusChange(user.id, user.status === 'blocked' ? 'active' : 'blocked')}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                          user.status === 'blocked'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-red-600/90 text-white hover:bg-red-500'
                        }`}
                      >
                        {user.status === 'blocked' ? 'Unblock User' : '🚫 Block User'}
                      </button>
                    </div>

                    {/* Adjust Virtual Coins */}
                    <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1">
                          <Coins className="w-3.5 h-3.5" /> Direct Coins Adjustment
                        </span>
                        <span className="text-[10px] text-slate-400">Current: {user.coins.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleAdjustCoins(user.id, 500)}
                          className="flex-1 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold"
                        >
                          +500 Coins
                        </button>
                        <button
                          onClick={() => handleAdjustCoins(user.id, 1000)}
                          className="flex-1 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold"
                        >
                          +1,000 Coins
                        </button>
                        <button
                          onClick={() => handleAdjustCoins(user.id, -500)}
                          className="flex-1 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-300 text-xs font-bold"
                        >
                          -500 Coins
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
