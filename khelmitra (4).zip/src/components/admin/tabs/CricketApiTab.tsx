import React, { useState, useEffect } from 'react';
import { 
  Radio, RefreshCw, Activity, AlertTriangle, ShieldCheck, 
  CheckCircle2, Play, Pause, Zap, ArrowRight, Server, Key, Eye 
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { cricketLiveService } from '../../../services/cricketLiveService';
import { MasterCricketApiConfig, LiveMatch } from '../../../types';

export default function CricketApiTab() {
  const [apiConfig, setApiConfig] = useState<MasterCricketApiConfig>(masterOwnerService.getCricketApiConfig());
  const [matches, setMatches] = useState<LiveMatch[]>(cricketLiveService.getMatches());
  const [isErrorState, setIsErrorState] = useState(cricketLiveService.isErrorState());
  const [autoPolling, setAutoPolling] = useState(cricketLiveService.isAutoRefreshActive());
  const [countdown, setCountdown] = useState(cricketLiveService.getCountdown());
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  useEffect(() => {
    const unsub = cricketLiveService.subscribe((updatedMatches, isErr) => {
      setMatches([...updatedMatches]);
      setIsErrorState(isErr);
      setApiConfig(masterOwnerService.getCricketApiConfig());
      setCountdown(cricketLiveService.getCountdown());
      setAutoPolling(cricketLiveService.isAutoRefreshActive());
    });
    return () => unsub();
  }, []);

  const showNotice = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 3000);
  };

  const handleManualBallTick = () => {
    masterOwnerService.triggerCricketNextBall();
    showNotice('Manual score telemetry tick triggered: next ball recorded!');
  };

  const handleToggleAutoPolling = () => {
    const active = masterOwnerService.toggleCricketAutoPolling();
    setAutoPolling(active);
    showNotice(`API Auto-Polling ${active ? 'Resumed' : 'Paused'}`);
  };

  const handleToggleSimulatedError = () => {
    masterOwnerService.toggleCricketSimulatedError();
    setIsErrorState(cricketLiveService.isErrorState());
    showNotice(cricketLiveService.isErrorState() ? 'Simulated API Error triggered' : 'API Health restored');
  };

  const liveMatches = matches.filter(m => m.status === 'LIVE');
  const upcomingMatches = matches.filter(m => m.status === 'UPCOMING');

  return (
    <div className="space-y-4">
      {/* Toast Notice */}
      {actionNotice && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionNotice}</span>
        </div>
      )}

      {/* 1. API Health & Telemetry Status Grid */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${isErrorState ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Live Cricket Score Telemetry API</h4>
              <span className="text-[10px] text-slate-400">High-throughput ball-by-ball sports data engine</span>
            </div>
          </div>

          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
            isErrorState 
              ? 'bg-red-500/20 text-red-400 border border-red-500/40' 
              : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${isErrorState ? 'bg-red-400 animate-ping' : 'bg-emerald-400 animate-pulse'}`}></span>
            {isErrorState ? 'Error State' : 'Operational'}
          </span>
        </div>

        {/* Status Metrics */}
        <div className="grid grid-cols-4 gap-2 text-center text-xs">
          <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Latency</span>
            <span className="text-sm font-black text-emerald-400 font-mono mt-0.5 block">{apiConfig.latencyMs}ms</span>
          </div>

          <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Uptime / SLA</span>
            <span className="text-sm font-black text-emerald-400 font-mono mt-0.5 block">{apiConfig.successRate}%</span>
          </div>

          <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Next Poll</span>
            <span className="text-sm font-black text-amber-400 font-mono mt-0.5 block">
              {autoPolling ? `${countdown}s` : 'Paused'}
            </span>
          </div>

          <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Requests</span>
            <span className="text-sm font-black text-white font-mono mt-0.5 block">14.2k</span>
          </div>
        </div>

        {/* API Endpoint & Security Masking */}
        <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/90 text-xs space-y-1.5">
          <div className="flex items-center justify-between text-slate-400 text-[11px]">
            <span className="flex items-center gap-1.5 font-bold text-slate-300">
              <Server className="w-3.5 h-3.5 text-blue-400" /> Internal Feed Gateway:
            </span>
            <span className="text-[10px] text-slate-500 font-mono">v2.4 Telemetry</span>
          </div>
          <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800/80 font-mono text-[10px] text-slate-300 truncate">
            {apiConfig.apiEndpoint}
          </div>

          <div className="flex items-center justify-between pt-1 text-[11px]">
            <span className="flex items-center gap-1.5 text-slate-400">
              <Key className="w-3.5 h-3.5 text-amber-400" /> Server Secret Token:
            </span>
            <span className="font-mono text-[10px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              {apiConfig.apiMaskedKey}
            </span>
          </div>
        </div>
      </div>

      {/* 2. API Operations Control Box */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-amber-400" />
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">
            Owner Telemetry Operations
          </h4>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleManualBallTick}
            className="p-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs active:scale-95 transition-all shadow-md flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Force Next Ball Tick</span>
          </button>

          <button
            onClick={handleToggleAutoPolling}
            className={`p-3 rounded-xl border text-xs font-black active:scale-95 transition-all flex items-center justify-center gap-2 ${
              autoPolling
                ? 'bg-slate-950 border-slate-700 text-slate-200 hover:border-amber-400'
                : 'bg-amber-500/20 border-amber-500/40 text-amber-300'
            }`}
          >
            {autoPolling ? (
              <>
                <Pause className="w-4 h-4 text-amber-400" />
                <span>Pause Auto-Poll</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 text-emerald-400" />
                <span>Resume Auto-Poll</span>
              </>
            )}
          </button>

          <button
            onClick={handleToggleSimulatedError}
            className={`p-2.5 rounded-xl border text-xs font-bold col-span-2 active:scale-95 transition-all flex items-center justify-center gap-2 ${
              isErrorState
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                : 'bg-red-950/40 hover:bg-red-900/50 border-red-500/40 text-red-300'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>
              {isErrorState ? 'Recover API to 100% Operational' : 'Simulate API Network Failure (Test App Recovery)'}
            </span>
          </button>
        </div>
      </div>

      {/* 3. Match Management & Feed Inspector */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-red-400 animate-pulse" />
            <h4 className="text-xs font-bold text-white">Active Match Feed Inspector ({matches.length} Matches)</h4>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">Auto-Synced</span>
        </div>

        <div className="space-y-2">
          {matches.map((match) => (
            <div
              key={match.id}
              className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className={`px-1.5 py-0.2 rounded text-[9px] font-black uppercase font-mono ${
                    match.status === 'LIVE' ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {match.status}
                  </span>
                  <span className="font-bold text-white">
                    {match.team1.shortName} vs {match.team2.shortName}
                  </span>
                  <span className="text-[10px] text-slate-400">({match.tournament})</span>
                </div>
                <div className="text-[10px] text-slate-400 flex items-center gap-2">
                  <span>{match.team1.shortName}: {match.team1.score} ({match.team1.overs} ov)</span>
                  <span>•</span>
                  <span>{match.team2.shortName}: {match.team2.score} ({match.team2.overs} ov)</span>
                </div>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-bold text-amber-400 block">
                  {match.status === 'LIVE' ? match.statusText : 'Scheduled'}
                </span>
                <span className="text-[9px] text-slate-500">{match.venue}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
