import React, { useState, useEffect } from 'react';
import { 
  Activity, Users, Gamepad2, Radio, Gift, Tv, Settings, 
  ShieldCheck, AlertTriangle, ArrowUpRight, CheckCircle, 
  Coins, Flame, Trophy, Lock, Bell, Sparkles, RefreshCw,
  ExternalLink, Zap
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { MasterOwnerTabType } from '../MasterOwnerControlPanel';

interface DashboardOverviewTabProps {
  onNavigateTab: (tab: MasterOwnerTabType) => void;
}

export default function DashboardOverviewTab({ onNavigateTab }: DashboardOverviewTabProps) {
  const [overview, setOverview] = useState(masterOwnerService.getDashboardOverview());
  const [recentAudits, setRecentAudits] = useState(masterOwnerService.getAuditLogs().slice(0, 5));
  const users = masterOwnerService.getUsers();
  const appConfig = masterOwnerService.getAppConfig();
  const adsConfig = masterOwnerService.getAdsConfig();

  useEffect(() => {
    const unsub = masterOwnerService.subscribe(() => {
      setOverview(masterOwnerService.getDashboardOverview());
      setRecentAudits(masterOwnerService.getAuditLogs().slice(0, 5));
    });
    return () => unsub();
  }, []);

  const handleRefresh = () => {
    setOverview(masterOwnerService.getDashboardOverview());
    setRecentAudits(masterOwnerService.getAuditLogs().slice(0, 5));
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Top Banner / System Health Bar */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/40 border border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black text-white">Master Owner System Health</h3>
              <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-[10px] text-emerald-300 font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                {overview.serverHealth}
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Role: <span className="text-amber-300 font-bold">{overview.currentRole}</span> • SLA Uptime: <span className="text-white font-mono">{overview.uptimeSla}</span>
            </p>
          </div>
        </div>

        <button
          onClick={handleRefresh}
          className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-all active:scale-95"
          title="Refresh Telemetry"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* 1. Core Platform KPI Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div 
          onClick={() => onNavigateTab('users')}
          className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Total Users</span>
            <Users className="w-3.5 h-3.5 text-blue-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-black text-white font-mono">{overview.totalUsers}</span>
            <span className="text-[10px] text-emerald-400 font-bold">+{overview.activeUsers} Active</span>
          </div>
          <div className="mt-1 flex items-center justify-between text-[9px] text-slate-400">
            <span>VIP: {overview.vipUsers}</span>
            <span className="text-red-400">Blocked: {overview.blockedUsers}</span>
          </div>
        </div>

        <div 
          onClick={() => onNavigateTab('games')}
          className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Games Active</span>
            <Gamepad2 className="w-3.5 h-3.5 text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-black text-emerald-300 font-mono">{overview.activeGamesCount} / 6</span>
            <span className="text-[10px] text-slate-400 font-medium">All Running</span>
          </div>
          <div className="mt-1 text-[9px] text-slate-400">
            {overview.totalGamesPlayed} total matches played
          </div>
        </div>

        <div 
          onClick={() => onNavigateTab('cricket')}
          className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-blue-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Live Cricket API</span>
            <Radio className="w-3.5 h-3.5 text-red-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-black text-white">{overview.cricketStatus}</span>
          </div>
          <div className="mt-1 text-[9px] text-emerald-400 flex items-center gap-1 font-mono">
            <Zap className="w-2.5 h-2.5" /> 32ms Latency
          </div>
        </div>

        <div 
          onClick={() => onNavigateTab('rewards')}
          className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Virtual Economy</span>
            <Coins className="w-3.5 h-3.5 text-amber-400 group-hover:translate-x-0.5 transition-transform" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-lg font-black text-amber-300 font-mono">
              {(overview.totalCirculatingCoins / 1000).toFixed(1)}k
            </span>
            <span className="text-[10px] text-slate-400">Coins</span>
          </div>
          <div className="mt-1 text-[9px] text-slate-400">
            Zero real money • Skill only
          </div>
        </div>
      </div>

      {/* 2. Game Statistics Matrix */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Trophy className="w-3.5 h-3.5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Skill Games Statistics & Activity</h4>
              <span className="text-[10px] text-slate-400">Real-time table occupancy & player engagement</span>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('games')}
            className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-0.5"
          >
            <span>Manage</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
          {/* Call Break */}
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                <span className="font-bold text-white">Call Break</span>
              </div>
              <span className="text-[10px] text-slate-400 block font-mono">182 Games • 4-Player</span>
            </div>
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
              appConfig.enabledGames.callBreak
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-red-500/20 text-red-300 border-red-500/40'
            }`}>
              {appConfig.enabledGames.callBreak ? 'Online' : 'Disabled'}
            </span>
          </div>

          {/* Teen Patti */}
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                <span className="font-bold text-white">Teen Patti</span>
              </div>
              <span className="text-[10px] text-slate-400 block font-mono">245 Games • 100 Boot</span>
            </div>
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
              appConfig.enabledGames.teenPatti
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-red-500/20 text-red-300 border-red-500/40'
            }`}>
              {appConfig.enabledGames.teenPatti ? 'Online' : 'Disabled'}
            </span>
          </div>

          {/* Ludo */}
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                <span className="font-bold text-white">Ludo Classic</span>
              </div>
              <span className="text-[10px] text-slate-400 block font-mono">112 Games • 30s Turn</span>
            </div>
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
              appConfig.enabledGames.ludo
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-red-500/20 text-red-300 border-red-500/40'
            }`}>
              {appConfig.enabledGames.ludo ? 'Online' : 'Disabled'}
            </span>
          </div>

          {/* Rummy */}
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-purple-400"></span>
                <span className="font-bold text-white">Indian Rummy</span>
              </div>
              <span className="text-[10px] text-slate-400 block font-mono">94 Games • 13 Cards</span>
            </div>
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
              appConfig.enabledGames.rummy
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-red-500/20 text-red-300 border-red-500/40'
            }`}>
              {appConfig.enabledGames.rummy ? 'Online' : 'Disabled'}
            </span>
          </div>

          {/* Fantasy Cricket */}
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
                <span className="font-bold text-white">Fantasy 11</span>
              </div>
              <span className="text-[10px] text-slate-400 block font-mono">3 Active Contests</span>
            </div>
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
              appConfig.enabledGames.fantasyCricket
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-red-500/20 text-red-300 border-red-500/40'
            }`}>
              {appConfig.enabledGames.fantasyCricket ? 'Online' : 'Disabled'}
            </span>
          </div>

          {/* Quiz & Brain Teaser */}
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                <span className="font-bold text-white">Cricket Quiz</span>
              </div>
              <span className="text-[10px] text-slate-400 block font-mono">160 Rounds Played</span>
            </div>
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
              appConfig.enabledGames.quizGames
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : 'bg-red-500/20 text-red-300 border-red-500/40'
            }`}>
              {appConfig.enabledGames.quizGames ? 'Online' : 'Disabled'}
            </span>
          </div>
        </div>
      </div>

      {/* 2B. Daily Mission & Reward System Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {/* Daily Mission Telemetry */}
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <Gift className="w-3.5 h-3.5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Daily Missions Analytics</h4>
                <span className="text-[10px] text-slate-400">Player quest engagement & claim rates</span>
              </div>
            </div>
            <button
              onClick={() => onNavigateTab('rewards')}
              className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-0.5"
            >
              <span>Config</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">Completion Rate</span>
              <span className="text-base font-black text-emerald-400 font-mono">78.4%</span>
              <span className="text-[9px] text-slate-500 block">1,420 quests completed today</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">Top Claimed Quest</span>
              <span className="text-xs font-bold text-amber-300 truncate block">Cricket Watcher</span>
              <span className="text-[9px] text-slate-500 block">580 player claims (40.8%)</span>
            </div>
          </div>

          <div className="p-2 rounded-xl bg-slate-950/40 border border-slate-800 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">7-Day Streak Ladder:</span>
            <span className="font-mono text-white font-bold">342 Active Streaks</span>
          </div>
        </div>

        {/* Reward Statistics & Compliance */}
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Coins className="w-3.5 h-3.5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Reward Economy & Abuse Defense</h4>
                <span className="text-[10px] text-slate-400">Zero real money • Free-to-play points</span>
              </div>
            </div>
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[9px] font-bold">
              Fair Play
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">Free Points Issued</span>
              <span className="text-base font-black text-amber-300 font-mono">148.2k</span>
              <span className="text-[9px] text-slate-500 block">Avg: 2,460 coins / user</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] text-slate-400 block font-medium">Abuse Bot Thwarted</span>
              <span className="text-base font-black text-red-400 font-mono">18 Blocks</span>
              <span className="text-[9px] text-slate-500 block">Emulator / Multi-farm guards</span>
            </div>
          </div>

          <div className="p-2 rounded-xl bg-emerald-950/20 border border-emerald-500/30 flex items-center justify-between text-[10px]">
            <span className="text-emerald-300 font-semibold flex items-center gap-1">
              <CheckCircle className="w-3 h-3 text-emerald-400" /> Free-to-Play Points Certified
            </span>
            <span className="text-slate-400">No Cash-Outs</span>
          </div>
        </div>
      </div>

      {/* 2C. Live API System & Network Telemetry */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <Radio className="w-3.5 h-3.5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">API System Status & Telemetry</h4>
              <span className="text-[10px] text-slate-400">Real-time health of Live Cricket API & Database</span>
            </div>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono font-bold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            ALL SERVICES HEALTHY
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Cricket Score API</span>
            <span className="font-bold text-white block mt-0.5">Live Sync (10s)</span>
            <span className="text-[9px] text-emerald-400 font-mono">Latency: 32ms</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">RBAC Security Guard</span>
            <span className="font-bold text-emerald-300 block mt-0.5">Enforced</span>
            <span className="text-[9px] text-slate-400">Role: Super Owner</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">Database Rules</span>
            <span className="font-bold text-blue-300 block mt-0.5">Firestore Locked</span>
            <span className="text-[9px] text-slate-400">Owner-only write</span>
          </div>
          <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800">
            <span className="text-[10px] text-slate-400 block">App SLA Availability</span>
            <span className="font-bold text-amber-300 font-mono block mt-0.5">99.98%</span>
            <span className="text-[9px] text-slate-400">0 critical incidents</span>
          </div>
        </div>
      </div>

      {/* 3. Quick Action Jump Center */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
          Master Operational Controls
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => onNavigateTab('users')}
            className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-95"
          >
            <Users className="w-4 h-4 text-blue-400 mb-1" />
            <span className="text-xs font-bold text-white block">User Moderation</span>
            <span className="text-[10px] text-slate-400">Block, Unblock & Coins</span>
          </button>

          <button
            onClick={() => onNavigateTab('cricket')}
            className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-95"
          >
            <Radio className="w-4 h-4 text-red-400 mb-1" />
            <span className="text-xs font-bold text-white block">Cricket Engine</span>
            <span className="text-[10px] text-slate-400">Score Telemetry & Sync</span>
          </button>

          <button
            onClick={() => onNavigateTab('rewards')}
            className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-95"
          >
            <Gift className="w-4 h-4 text-amber-400 mb-1" />
            <span className="text-xs font-bold text-white block">Reward System</span>
            <span className="text-[10px] text-slate-400">Daily Missions & Abuse</span>
          </button>

          <button
            onClick={() => onNavigateTab('ads')}
            className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-95"
          >
            <Tv className="w-4 h-4 text-purple-400 mb-1" />
            <span className="text-xs font-bold text-white block">Ads Monetization</span>
            <span className="text-[10px] text-slate-400">Rewarded Video & eCPM</span>
          </button>

          <button
            onClick={() => onNavigateTab('appControl')}
            className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-95"
          >
            <Bell className="w-4 h-4 text-yellow-400 mb-1" />
            <span className="text-xs font-bold text-white block">Broadcast Notice</span>
            <span className="text-[10px] text-slate-400">Maintenance & Banners</span>
          </button>

          <button
            onClick={() => onNavigateTab('security')}
            className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-left transition-all active:scale-95"
          >
            <Lock className="w-4 h-4 text-emerald-400 mb-1" />
            <span className="text-xs font-bold text-white block">Security & Rules</span>
            <span className="text-[10px] text-slate-400">Backend RBAC & Firestore</span>
          </button>
        </div>
      </div>

      {/* 4. Live Admin Activity Logs Preview */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <Activity className="w-3.5 h-3.5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Recent Admin Activity Trail</h4>
              <span className="text-[10px] text-slate-400">Chronological tamper-evident audit events</span>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('security')}
            className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-0.5"
          >
            <span>Full Audit Log</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        <div className="space-y-2">
          {recentAudits.map((log) => (
            <div 
              key={log.id} 
              className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs flex items-start justify-between gap-3"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono font-bold text-amber-400 px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
                    {log.action}
                  </span>
                  <span className="text-[11px] text-slate-400 font-semibold">{log.category}</span>
                </div>
                <p className="text-[11px] text-slate-300 line-clamp-1">{log.details}</p>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] text-slate-500 block font-mono">{log.timestamp}</span>
                <span className="text-[9px] text-slate-400 font-medium">{log.operatorName}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
