import React, { useState, useEffect } from 'react';
import { 
  Gift, Coins, Award, Sparkles, ShieldAlert, CheckCircle, 
  Calendar, Trash2, History, AlertTriangle, Lock, ShieldCheck,
  RefreshCw, Clock, Flame
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { MasterRewardItem, MasterRewardAbuseConfig } from '../../../types';
import { DAILY_LOGIN_REWARDS, DEFAULT_MISSIONS_DEF } from '../../../services/dailyMissionService';

export default function RewardsTab() {
  const [rewardsLedger, setRewardsLedger] = useState<MasterRewardItem[]>(masterOwnerService.getRewardsLedger());
  const [abuseConfig, setAbuseConfig] = useState<MasterRewardAbuseConfig>(masterOwnerService.getRewardAbuseConfig());
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    const unsub = masterOwnerService.subscribe(() => {
      setRewardsLedger([...masterOwnerService.getRewardsLedger()]);
      setAbuseConfig({ ...masterOwnerService.getRewardAbuseConfig() });
    });
    return () => unsub();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleClearLedger = () => {
    masterOwnerService.clearRewardsLedger();
    setRewardsLedger([]);
    showToast('Reward distribution ledger cleared');
  };

  const handleUpdateAbuseConfig = (updates: Partial<MasterRewardAbuseConfig>) => {
    masterOwnerService.updateRewardAbuseConfig(updates);
    setAbuseConfig({ ...masterOwnerService.getRewardAbuseConfig() });
    showToast('Reward abuse policies updated successfully');
  };

  // Metrics
  const totalRewardedToday = rewardsLedger.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Toast Notice */}
      {toastMessage && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Rewards System Summary KPIs */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Distributed In Ledger</span>
          <span className="text-base font-black text-amber-300 font-mono">+{totalRewardedToday} Coins</span>
        </div>
        <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-center">
          <span className="text-[10px] text-emerald-400 font-bold uppercase block">Daily Abuse Limit</span>
          <span className="text-base font-black text-emerald-300 font-mono">{abuseConfig.maxDailyRewardCoins} Coins</span>
        </div>
        <div className="p-3 rounded-2xl bg-blue-950/40 border border-blue-500/30 text-center">
          <span className="text-[10px] text-blue-400 font-bold uppercase block">Claim Cooldown</span>
          <span className="text-base font-black text-blue-300 font-mono">{abuseConfig.cooldownBetweenClaimsSeconds}s Delay</span>
        </div>
      </div>

      {/* 1. Daily Login Streak Rewards Ladder */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Daily Check-in Streak Ladder (7 Days)</h4>
            <span className="text-[10px] text-slate-400">Progression rewards distributed to players checking in daily</span>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1.5 text-center">
          {DAILY_LOGIN_REWARDS.map((r) => (
            <div
              key={r.day}
              className={`p-2 rounded-xl border flex flex-col items-center justify-between ${
                r.isMega 
                  ? 'bg-amber-500/15 border-amber-500/50 shadow-sm' 
                  : 'bg-slate-950/70 border-slate-800'
              }`}
            >
              <span className="text-[9px] font-bold text-slate-400">{r.label}</span>
              <Coins className={`w-3.5 h-3.5 my-1 ${r.isMega ? 'text-amber-400' : 'text-amber-500/70'}`} />
              <span className="text-[11px] font-mono font-black text-amber-300">+{r.coins}</span>
            </div>
          ))}
        </div>
        <p className="text-[10px] text-slate-400 italic">
          *Streaks automatically reset if a player misses 2 consecutive days without a streak freeze shield.
        </p>
      </div>

      {/* 2. Active Daily Missions Engine */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Daily Quests & Mission Configuration</h4>
              <span className="text-[10px] text-slate-400">Target tasks assigned to all registered players</span>
            </div>
          </div>
          <span className="text-[10px] text-slate-400 font-mono">
            {DEFAULT_MISSIONS_DEF.length} Active Missions
          </span>
        </div>

        <div className="space-y-2">
          {DEFAULT_MISSIONS_DEF.map((m) => (
            <div 
              key={m.id}
              className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3 text-xs"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-white">{m.title}</span>
                  <span className="text-[9px] font-mono uppercase px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700">
                    {m.category}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{m.description}</p>
              </div>

              <div className="text-right shrink-0">
                <span className="text-xs font-mono font-black text-amber-300 block">
                  +{m.rewardCoins} Coins
                </span>
                <span className="text-[10px] text-slate-500">Target: {m.targetProgress}x</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. Reward Abuse Prevention Configuration */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <div className="w-7 h-7 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Reward Abuse Prevention Engine</h4>
            <span className="text-[10px] text-slate-400">Automated guards to prevent auto-farming & spam claims</span>
          </div>
        </div>

        <div className="space-y-3 text-xs">
          {/* Max Daily Cap */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/50 border border-slate-800">
            <div>
              <span className="font-bold text-white block">Maximum Daily Reward Cap</span>
              <span className="text-[10px] text-slate-400">Total free coins a single player can claim per 24 hours</span>
            </div>
            <select
              value={abuseConfig.maxDailyRewardCoins}
              onChange={(e) => handleUpdateAbuseConfig({ maxDailyRewardCoins: Number(e.target.value) })}
              className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-amber-300 font-mono"
            >
              <option value="1500">1,500 Coins</option>
              <option value="2500">2,500 Coins (Default)</option>
              <option value="5000">5,000 Coins</option>
              <option value="10000">10,000 Coins (VIP Max)</option>
            </select>
          </div>

          {/* Claim Cooldown */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/50 border border-slate-800">
            <div>
              <span className="font-bold text-white block">Claim Cooldown Timer</span>
              <span className="text-[10px] text-slate-400">Minimum seconds required between consecutive mission claims</span>
            </div>
            <select
              value={abuseConfig.cooldownBetweenClaimsSeconds}
              onChange={(e) => handleUpdateAbuseConfig({ cooldownBetweenClaimsSeconds: Number(e.target.value) })}
              className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-blue-300 font-mono"
            >
              <option value="10">10 Seconds</option>
              <option value="30">30 Seconds (Default)</option>
              <option value="60">60 Seconds</option>
              <option value="120">120 Seconds</option>
            </select>
          </div>

          {/* Toggle Switches */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleUpdateAbuseConfig({ requireDeviceIntegrityCheck: !abuseConfig.requireDeviceIntegrityCheck })}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                abuseConfig.requireDeviceIntegrityCheck
                  ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-950/50 border-slate-800 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-xs">Device Integrity Check</span>
                <span className="text-[10px] font-mono uppercase">{abuseConfig.requireDeviceIntegrityCheck ? 'ON' : 'OFF'}</span>
              </div>
              <span className="text-[10px] opacity-80 block">Blocks emulators & rooted multi-instance bots</span>
            </button>

            <button
              onClick={() => handleUpdateAbuseConfig({ autoFlagSuspiciousAccounts: !abuseConfig.autoFlagSuspiciousAccounts })}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                abuseConfig.autoFlagSuspiciousAccounts
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-300'
                  : 'bg-slate-950/50 border-slate-800 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-xs">Auto-Flag Suspicious Accounts</span>
                <span className="text-[10px] font-mono uppercase">{abuseConfig.autoFlagSuspiciousAccounts ? 'ON' : 'OFF'}</span>
              </div>
              <span className="text-[10px] opacity-80 block">Flags accounts with &gt;90% bot telemetry score</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4. Reward Distribution History Ledger */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Platform Reward Distribution Ledger</h4>
              <span className="text-[10px] text-slate-400">Audited transaction records of virtual coins credited</span>
            </div>
          </div>

          {rewardsLedger.length > 0 && (
            <button
              onClick={handleClearLedger}
              className="text-[10px] text-red-400 hover:text-red-300 flex items-center gap-1 font-bold"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear Log</span>
            </button>
          )}
        </div>

        {rewardsLedger.length === 0 ? (
          <div className="text-center py-6 text-slate-500 text-xs">
            No reward transactions recorded in current ledger.
          </div>
        ) : (
          <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
            {rewardsLedger.map((item) => (
              <div
                key={item.id}
                className="p-2 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-[10px]">
                    +
                  </div>
                  <div>
                    <span className="font-bold text-white block leading-tight">{item.userName}</span>
                    <span className="text-[10px] text-slate-400">{item.notes}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-mono font-black text-amber-300 block">+{item.amount}</span>
                  <span className="text-[9px] text-slate-500">{item.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
