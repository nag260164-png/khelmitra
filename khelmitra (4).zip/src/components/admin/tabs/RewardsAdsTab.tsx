import React, { useState } from 'react';
import { 
  Gift, Coins, Award, Sparkles, PlayCircle, Eye, 
  CheckCircle, ToggleLeft, ToggleRight, History, Calendar, Trash2 
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { MasterRewardItem } from '../../../types';
import { DAILY_LOGIN_REWARDS } from '../../../services/dailyMissionService';

export default function RewardsAdsTab() {
  const [rewardsLedger, setRewardsLedger] = useState<MasterRewardItem[]>(masterOwnerService.getRewardsLedger());
  const [adsEnabled, setAdsEnabled] = useState(true);
  const [adFrequency, setAdFrequency] = useState<number>(2);
  const [sponsorBanners, setSponsorBanners] = useState(true);
  const [simulatingAd, setSimulatingAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(5);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleClearLedger = () => {
    masterOwnerService.clearRewardsLedger();
    setRewardsLedger([]);
    showToast('Reward history ledger cleared');
  };

  const handleSimulateAd = () => {
    setSimulatingAd(true);
    setAdCountdown(5);
    const interval = setInterval(() => {
      setAdCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setSimulatingAd(false);
          // Award simulated reward
          masterOwnerService.addRewardRecord({
            userName: 'Test Player (Simulator)',
            userId: 'user-sim-1',
            type: 'MISSION_COMPLETE',
            amount: 100,
            notes: 'Sponsor Ad Clip Watched (Simulated Payout)'
          });
          setRewardsLedger([...masterOwnerService.getRewardsLedger()]);
          showToast('Sponsor ad completed: +100 Coins recorded to ledger!');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="space-y-4">
      {/* Toast Notice */}
      {toastMessage && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. Daily Login Streak Rewards Matrix */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Daily Check-in Streak Rewards</h4>
            <span className="text-[10px] text-slate-400">7-day progression ladder for active players</span>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-1.5 text-center">
          {DAILY_LOGIN_REWARDS.map((r) => (
            <div
              key={r.day}
              className={`p-2 rounded-xl border flex flex-col items-center justify-center ${
                r.isMega
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                  : 'bg-slate-950 border-slate-800 text-slate-300'
              }`}
            >
              <span className="text-[9px] font-bold uppercase text-slate-400">D{r.day}</span>
              <span className="text-xs font-black font-mono my-0.5">+{r.coins}</span>
              <span className="text-[8px] text-amber-400 font-bold">Coins</span>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Advertisement & Monetization Simulator Settings */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
            <PlayCircle className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Advertisement & Sponsor Clips</h4>
            <span className="text-[10px] text-slate-400">Control ad frequency, sponsor banners and test ads</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Master Ads Toggle */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between col-span-2">
            <div>
              <span className="text-xs font-bold text-white block">Rewarded Video Sponsor Ads</span>
              <span className="text-[10px] text-slate-400">Players watch short video clips for bonus coins</span>
            </div>
            <button
              onClick={() => {
                setAdsEnabled(!adsEnabled);
                showToast(`Ads ${!adsEnabled ? 'Enabled' : 'Disabled'}`);
              }}
              className="text-amber-400"
            >
              {adsEnabled ? <ToggleRight className="w-7 h-7 text-emerald-400" /> : <ToggleLeft className="w-7 h-7 text-slate-600" />}
            </button>
          </div>

          {/* Ad Frequency */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">
              Ad Interstitial Frequency
            </span>
            <div className="grid grid-cols-3 gap-1">
              {[1, 2, 3].map((f) => (
                <button
                  key={f}
                  onClick={() => {
                    setAdFrequency(f);
                    showToast(`Ad frequency set to every ${f} games`);
                  }}
                  className={`py-1 rounded-md text-[11px] font-bold ${
                    adFrequency === f
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {f} Game{f > 1 ? 's' : ''}
                </button>
              ))}
            </div>
          </div>

          {/* Sponsor Banners */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-white block">Sponsor Banners</span>
              <span className="text-[9px] text-slate-400">Show brand banners</span>
            </div>
            <button
              onClick={() => setSponsorBanners(!sponsorBanners)}
              className="text-amber-400"
            >
              {sponsorBanners ? <ToggleRight className="w-6 h-6 text-emerald-400" /> : <ToggleLeft className="w-6 h-6 text-slate-600" />}
            </button>
          </div>

          {/* Test Ad Simulator Button */}
          <div className="col-span-2">
            <button
              onClick={handleSimulateAd}
              disabled={simulatingAd}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <PlayCircle className="w-4 h-4" />
              <span>{simulatingAd ? `Playing Sponsor Ad (${adCountdown}s remaining)...` : 'Launch Test Video Ad Simulator'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Real-Time Reward Distribution History Ledger */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-amber-400" />
            <div>
              <h4 className="text-xs font-bold text-white">Platform Reward Distribution Ledger</h4>
              <span className="text-[10px] text-slate-400">Live transaction history of all virtual coins granted</span>
            </div>
          </div>

          {rewardsLedger.length > 0 && (
            <button
              onClick={handleClearLedger}
              className="text-[10px] text-red-400 hover:text-red-300 font-bold flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" /> Clear
            </button>
          )}
        </div>

        <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
          {rewardsLedger.length === 0 ? (
            <div className="p-4 text-center text-xs text-slate-500 bg-slate-950 rounded-xl">
              No reward transactions recorded yet.
            </div>
          ) : (
            rewardsLedger.map((item) => (
              <div
                key={item.id}
                className="p-2 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{item.userName}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/15 text-amber-300 font-bold uppercase">
                      {item.type.replace('_', ' ')}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400">{item.notes}</span>
                </div>

                <div className="text-right">
                  <span className="text-xs font-black text-emerald-400 font-mono block">
                    +{item.amount.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-slate-500">{item.timestamp}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
