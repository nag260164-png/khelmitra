import React, { useState, useEffect } from 'react';
import { 
  Tv, PlayCircle, Eye, CheckCircle, ToggleLeft, ToggleRight, 
  BarChart3, DollarSign, Sparkles, AlertCircle, RefreshCw, Zap
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { MasterAdsConfig } from '../../../types';

export default function AdsManagementTab() {
  const [adsConfig, setAdsConfig] = useState<MasterAdsConfig>(masterOwnerService.getAdsConfig());
  const [simulatingAd, setSimulatingAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(5);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    const unsub = masterOwnerService.subscribe(() => {
      setAdsConfig({ ...masterOwnerService.getAdsConfig() });
    });
    return () => unsub();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleToggleEnable = () => {
    const updated = !adsConfig.enabled;
    masterOwnerService.updateAdsConfig({ enabled: updated });
    setAdsConfig({ ...masterOwnerService.getAdsConfig() });
    showToast(`Monetization Ads Engine ${updated ? 'ENABLED' : 'DISABLED'}`);
  };

  const handleUpdateConfig = (updates: Partial<MasterAdsConfig>) => {
    masterOwnerService.updateAdsConfig(updates);
    setAdsConfig({ ...masterOwnerService.getAdsConfig() });
    showToast('Ads parameters saved successfully');
  };

  const handleSimulateAd = () => {
    setSimulatingAd(true);
    setAdCountdown(5);
    const interval = setInterval(() => {
      setAdCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setSimulatingAd(false);
          masterOwnerService.simulateAdImpression(true);
          setAdsConfig({ ...masterOwnerService.getAdsConfig() });
          showToast(`Sponsor ad completed! +${adsConfig.rewardedCoinsAmount} Coins credited to ledger.`);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Toast Notice */}
      {toastMessage && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Ad Telemetry KPIs */}
      <div className="grid grid-cols-4 gap-2">
        <div className="p-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 font-bold uppercase block">Ad Status</span>
          <span className={`text-xs font-black uppercase font-mono ${adsConfig.enabled ? 'text-emerald-400' : 'text-red-400'}`}>
            {adsConfig.enabled ? 'Operational' : 'Paused'}
          </span>
        </div>
        <div className="p-2.5 rounded-2xl bg-purple-950/40 border border-purple-500/30 text-center">
          <span className="text-[10px] text-purple-400 font-bold uppercase block">Impressions</span>
          <span className="text-base font-black text-purple-300 font-mono">{adsConfig.todayImpressions}</span>
        </div>
        <div className="p-2.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-center">
          <span className="text-[10px] text-emerald-400 font-bold uppercase block">Est. eCPM</span>
          <span className="text-base font-black text-emerald-300 font-mono">${adsConfig.estimatedEcpm}</span>
        </div>
        <div className="p-2.5 rounded-2xl bg-blue-950/40 border border-blue-500/30 text-center">
          <span className="text-[10px] text-blue-400 font-bold uppercase block">Fill Rate</span>
          <span className="text-base font-black text-blue-300 font-mono">98.4%</span>
        </div>
      </div>

      {/* 1. Global Ads Engine Master Switch */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <Tv className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Ads Configuration & Monetization</h4>
              <span className="text-[10px] text-slate-400">Integrated AdMob / Native ad server engine</span>
            </div>
          </div>

          <button
            onClick={handleToggleEnable}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-all ${
              adsConfig.enabled
                ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                : 'bg-red-500/20 border-red-500 text-red-300'
            }`}
          >
            {adsConfig.enabled ? <ToggleRight className="w-4 h-4 text-emerald-400" /> : <ToggleLeft className="w-4 h-4 text-red-400" />}
            <span>{adsConfig.enabled ? 'Ads Active' : 'Ads Disabled'}</span>
          </button>
        </div>

        <div className="space-y-3 text-xs">
          {/* Ad Provider */}
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">Ad Gateway Provider</span>
            <div className="flex items-center justify-between">
              <span className="font-mono text-white text-xs">{adsConfig.adProvider}</span>
              <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                SDK Verified
              </span>
            </div>
          </div>

          {/* Interstitial Frequency */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/50 border border-slate-800">
            <div>
              <span className="font-bold text-white block">Interstitial Ad Frequency</span>
              <span className="text-[10px] text-slate-400">Display full-screen sponsor break between skill matches</span>
            </div>
            <select
              value={adsConfig.interstitialFrequency}
              onChange={(e) => handleUpdateConfig({ interstitialFrequency: Number(e.target.value) })}
              className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-purple-300 font-mono"
            >
              <option value="1">Every 1 Match (Aggressive)</option>
              <option value="2">Every 2 Matches (Balanced)</option>
              <option value="3">Every 3 Matches (Light)</option>
              <option value="0">Disabled (Zero Interstitials)</option>
            </select>
          </div>

          {/* Sponsor Banners Switch */}
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/50 border border-slate-800">
            <div>
              <span className="font-bold text-white block">In-Game Sponsor Banners</span>
              <span className="text-[10px] text-slate-400">Show subtle native banner cards at bottom of scorecards</span>
            </div>
            <button
              onClick={() => handleUpdateConfig({ sponsorBanners: !adsConfig.sponsorBanners })}
              className={`px-3 py-1 rounded-lg border text-[11px] font-bold transition-all ${
                adsConfig.sponsorBanners
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              {adsConfig.sponsorBanners ? 'Enabled' : 'Disabled'}
            </button>
          </div>
        </div>
      </div>

      {/* 2. Rewarded Video Ads Configuration */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <PlayCircle className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">Rewarded Video Ads Settings</h4>
            <span className="text-[10px] text-slate-400">Player-initiated video watching for free virtual coins</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
            <span className="font-bold text-white block">Coin Reward per Video</span>
            <select
              value={adsConfig.rewardedCoinsAmount}
              onChange={(e) => handleUpdateConfig({ rewardedCoinsAmount: Number(e.target.value) })}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-amber-300 font-mono"
            >
              <option value="50">50 Coins</option>
              <option value="100">100 Coins</option>
              <option value="150">150 Coins (Default)</option>
              <option value="250">250 Coins</option>
              <option value="500">500 Coins</option>
            </select>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
            <span className="font-bold text-white block">Daily Cap per Player</span>
            <select
              value={adsConfig.dailyRewardedAdCap}
              onChange={(e) => handleUpdateConfig({ dailyRewardedAdCap: Number(e.target.value) })}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-blue-300 font-mono"
            >
              <option value="5">5 Videos / Day</option>
              <option value="10">10 Videos / Day (Default)</option>
              <option value="15">15 Videos / Day</option>
              <option value="20">20 Videos / Day</option>
            </select>
          </div>
        </div>
      </div>

      {/* 3. Interactive Rewarded Video Ad Test Simulator */}
      <div className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 to-purple-950/30 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center">
              <Eye className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Live Ad Engine Test Simulator</h4>
              <span className="text-[10px] text-slate-400">Trigger simulated video ad playback to test payouts & telemetry</span>
            </div>
          </div>
        </div>

        {simulatingAd ? (
          <div className="p-5 rounded-2xl bg-black border border-purple-500/50 flex flex-col items-center text-center gap-2 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-full bg-purple-500/20 border border-purple-400/40 flex items-center justify-center text-purple-400 animate-spin">
              <PlayCircle className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-white">Simulating 15s Sponsor Video Clip...</span>
            <span className="text-2xl font-black text-amber-400 font-mono">{adCountdown}s remaining</span>
            <span className="text-[10px] text-slate-400">Coins will be automatically credited upon completion</span>
          </div>
        ) : (
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <div className="space-y-0.5">
              <span className="text-xs font-bold text-white">Interactive Test Watch</span>
              <span className="text-[10px] text-slate-400 block">
                Simulates 5s rewarded playback and credits +{adsConfig.rewardedCoinsAmount} test coins to ledger
              </span>
            </div>
            <button
              onClick={handleSimulateAd}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/20 active:scale-95 transition-all flex items-center gap-1.5"
            >
              <PlayCircle className="w-3.5 h-3.5" />
              <span>Simulate Ad</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
