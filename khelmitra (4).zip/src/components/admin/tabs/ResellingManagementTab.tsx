import { useState, useEffect } from 'react';
import { 
  ShoppingBag, Building2, Package, DollarSign, 
  CheckCircle2, XCircle, Clock, Truck, ShieldAlert, 
  Sliders, Plus, Edit2, AlertCircle, RefreshCw, Eye 
} from 'lucide-react';
import { resellingService } from '../../../services/resellingService';
import { SupplierProfile, ResellerProduct, ResellerOrder, MarketplaceConfig, OrderStatus } from '../../../types';
import { audioEffectsService } from '../../../services/audioEffectsService';

export default function ResellingManagementTab() {
  const [suppliers, setSuppliers] = useState<SupplierProfile[]>(resellingService.getSuppliers());
  const [orders, setOrders] = useState<ResellerOrder[]>(resellingService.getOrders());
  const [products, setProducts] = useState<ResellerProduct[]>(resellingService.getProducts());
  const [config, setConfig] = useState<MarketplaceConfig>(resellingService.getMarketplaceConfig());
  const [activeSubTab, setActiveSubTab] = useState<'suppliers' | 'orders' | 'products' | 'config'>('suppliers');
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsub = resellingService.subscribe(() => {
      setSuppliers([...resellingService.getSuppliers()]);
      setOrders([...resellingService.getOrders()]);
      setProducts([...resellingService.getProducts()]);
      setConfig({ ...resellingService.getMarketplaceConfig() });
    });
    return unsub;
  }, []);

  const handleSupplierDecision = (supplierId: string, status: 'approved' | 'rejected') => {
    audioEffectsService.playClick();
    resellingService.updateSupplierStatus(supplierId, status);
    setStatusMsg(`Supplier #${supplierId} successfully marked as ${status.toUpperCase()}!`);
    setTimeout(() => setStatusMsg(null), 3000);
  };

  const handleOrderStatusChange = (orderId: string, newStatus: OrderStatus) => {
    audioEffectsService.playClick();
    resellingService.updateOrderStatus(orderId, newStatus);
    setStatusMsg(`Order #${orderId} progressed to status: ${newStatus}`);
    setTimeout(() => setStatusMsg(null), 3000);
  };

  const handleToggleProduct = (productId: string) => {
    audioEffectsService.playClick();
    resellingService.toggleProductStock(productId);
  };

  const stats = resellingService.getMarketplaceStats();

  return (
    <div className="space-y-4 text-xs">
      {/* Top Marketplace Aggregate Stats */}
      <div className="grid grid-cols-4 gap-2">
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-pink-400 font-bold block uppercase">Total GMV</span>
          <span className="text-base font-black text-white">₹{stats.gmv.toLocaleString()}</span>
          <span className="text-[9px] text-slate-500 block">{stats.totalOrders} Orders</span>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-emerald-400 font-bold block uppercase">Margin Paid</span>
          <span className="text-base font-black text-emerald-400">₹{stats.totalMarginsPaid.toLocaleString()}</span>
          <span className="text-[9px] text-slate-500 block">UPI Transfers</span>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-amber-400 font-bold block uppercase">Suppliers</span>
          <span className="text-base font-black text-amber-400">{stats.activeSuppliers}</span>
          <span className="text-[9px] text-slate-500 block">Surat & Jaipur</span>
        </div>

        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-[10px] text-blue-400 font-bold block uppercase">Products</span>
          <span className="text-base font-black text-blue-400">{stats.totalProducts}</span>
          <span className="text-[9px] text-slate-500 block">Live Catalogue</span>
        </div>
      </div>

      {statusMsg && (
        <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Sub Navigation */}
      <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800 font-bold">
        <button
          onClick={() => setActiveSubTab('suppliers')}
          className={`py-2 rounded-lg transition-all ${
            activeSubTab === 'suppliers' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Suppliers ({suppliers.length})
        </button>
        <button
          onClick={() => setActiveSubTab('orders')}
          className={`py-2 rounded-lg transition-all ${
            activeSubTab === 'orders' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Orders ({orders.length})
        </button>
        <button
          onClick={() => setActiveSubTab('products')}
          className={`py-2 rounded-lg transition-all ${
            activeSubTab === 'products' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Catalog ({products.length})
        </button>
        <button
          onClick={() => setActiveSubTab('config')}
          className={`py-2 rounded-lg transition-all ${
            activeSubTab === 'config' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Settings
        </button>
      </div>

      {/* 1. SUPPLIER APPLICATIONS REVIEW */}
      {activeSubTab === 'suppliers' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-white">Wholesale Manufacturers & Mills</h4>
            <span className="text-[10px] text-amber-400">Master Owner Authority</span>
          </div>

          <div className="space-y-2">
            {suppliers.map((sup) => (
              <div
                key={sup.id}
                className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-xs">{sup.businessName}</span>
                    <span className={`px-2 py-0.2 rounded text-[9px] font-bold uppercase border ${
                      sup.status === 'approved'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : sup.status === 'pending'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : 'bg-red-500/20 text-red-300 border-red-500/30'
                    }`}>
                      {sup.status}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1 flex gap-3">
                    <span>Prop: {sup.ownerName}</span>
                    <span>City: {sup.city}</span>
                    <span>Phone: {sup.phone}</span>
                    {sup.gstOrPan && <span>GST: {sup.gstOrPan}</span>}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {sup.status !== 'approved' && (
                    <button
                      onClick={() => handleSupplierDecision(sup.id, 'approved')}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold active:scale-95"
                    >
                      Approve
                    </button>
                  )}
                  {sup.status !== 'rejected' && (
                    <button
                      onClick={() => handleSupplierDecision(sup.id, 'rejected')}
                      className="px-2.5 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 text-[10px] font-bold active:scale-95"
                    >
                      Reject
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. RESELLER ORDERS OVERSIGHT */}
      {activeSubTab === 'orders' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-white">All Platform Customer Orders</h4>
            <span className="text-[10px] text-slate-400">Total: {orders.length}</span>
          </div>

          <div className="space-y-2">
            {orders.map((ord) => (
              <div key={ord.id} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-mono font-bold text-white">{ord.orderNumber}</span>
                  <span className="text-emerald-400 font-black">Margin: ₹{ord.resellerMargin}</span>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span>Product: {ord.productTitle.slice(0, 30)}...</span>
                  <span className="font-bold text-white">COD: ₹{ord.finalCustomerPrice}</span>
                </div>

                <div className="text-[10px] text-slate-400">
                  Customer: <strong>{ord.customerName}</strong> ({ord.city}, {ord.pincode}) • Tel: {ord.customerPhone}
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-800 text-[10px]">
                  <span className="text-slate-500">Current: {ord.status}</span>
                  <div className="flex gap-1">
                    {(['Placed', 'Dispatched', 'Out for Delivery', 'Delivered'] as OrderStatus[]).map((s) => (
                      <button
                        key={s}
                        onClick={() => handleOrderStatusChange(ord.id, s)}
                        className={`px-2 py-0.5 rounded text-[9px] font-bold transition-all ${
                          ord.status === s
                            ? 'bg-amber-500 text-slate-950'
                            : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. CATALOGUE PRODUCTS */}
      {activeSubTab === 'products' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-white">Marketplace Wholesale Inventory</h4>
            <span className="text-[10px] text-pink-400">{products.length} Active Items</span>
          </div>

          <div className="space-y-2">
            {products.map((p) => (
              <div key={p.id} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <img src={p.images[0]} alt="" className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0" referrerPolicy="no-referrer" />
                  <div className="min-w-0">
                    <span className="text-[9px] text-pink-400 font-bold uppercase">{p.category}</span>
                    <h5 className="font-bold text-white text-xs truncate">{p.title}</h5>
                    <span className="text-[10px] text-amber-400 font-mono">Wholesale: ₹{p.supplierPrice} • Stock: {p.stock}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleToggleProduct(p.id)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition-all shrink-0 ${
                    p.inStock
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      : 'bg-red-500/20 text-red-300 border-red-500/30'
                  }`}
                >
                  {p.inStock ? 'Enabled' : 'Disabled'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. MARKETPLACE SETTINGS */}
      {activeSubTab === 'config' && (
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
          <h4 className="font-bold text-white">Marketplace & Reseller Rules</h4>

          <div className="space-y-2">
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400">Platform Commission (%)</label>
              <input
                type="number"
                value={config.platformCommissionPercent}
                onChange={(e) => resellingService.updateMarketplaceConfig({ platformCommissionPercent: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              />
            </div>

            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400">Maximum Reseller Margin Cap (₹)</label>
              <input
                type="number"
                value={config.maxMarginCap}
                onChange={(e) => resellingService.updateMarketplaceConfig({ maxMarginCap: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
              />
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <span className="font-bold text-white block">Auto-Approve Suppliers</span>
                <span className="text-[10px] text-slate-400">Allow new mills to list without manual review</span>
              </div>
              <input
                type="checkbox"
                checked={config.supplierAutoApproval}
                onChange={(e) => resellingService.updateMarketplaceConfig({ supplierAutoApproval: e.target.checked })}
                className="w-4 h-4 accent-amber-500"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
