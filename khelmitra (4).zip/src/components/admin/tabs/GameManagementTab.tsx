import React, { useState } from 'react';
import { 
  Gamepad2, Settings, ShieldCheck, ToggleLeft, ToggleRight, 
  Clock, Sliders, Edit3, CheckCircle, AlertTriangle, Sparkles, Trophy 
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { 
  MasterLudoSettings, 
  MasterTeenPattiSettings, 
  MasterFantasySettings, 
  MasterGameRulesConfig 
} from '../../../types';

export default function GameManagementTab() {
  const [enabledGames, setEnabledGames] = useState(masterOwnerService.getEnabledGames());
  const [ludo, setLudo] = useState<MasterLudoSettings>(masterOwnerService.getLudoSettings());
  const [teenPatti, setTeenPatti] = useState<MasterTeenPattiSettings>(masterOwnerService.getTeenPattiSettings());
  const [fantasy, setFantasy] = useState<MasterFantasySettings>(masterOwnerService.getFantasySettings());
  const [rules, setRules] = useState<MasterGameRulesConfig>(masterOwnerService.getGameRules());
  const [selectedRuleGame, setSelectedRuleGame] = useState<keyof MasterGameRulesConfig>('callBreak');
  const [editingRuleText, setEditingRuleText] = useState<string>(rules.callBreak);
  const [savedToast, setSavedToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setSavedToast(msg);
    setTimeout(() => setSavedToast(null), 3000);
  };

  const handleToggleGame = (gameKey: keyof typeof enabledGames) => {
    masterOwnerService.toggleGameEnabled(gameKey);
    setEnabledGames({ ...masterOwnerService.getEnabledGames() });
    showToast(`Toggled ${gameKey.toUpperCase()} game status`);
  };

  const handleUpdateLudo = (partial: Partial<MasterLudoSettings>) => {
    masterOwnerService.updateLudoSettings(partial);
    setLudo(masterOwnerService.getLudoSettings());
    showToast('Ludo settings updated');
  };

  const handleUpdateTeenPatti = (partial: Partial<MasterTeenPattiSettings>) => {
    masterOwnerService.updateTeenPattiSettings(partial);
    setTeenPatti(masterOwnerService.getTeenPattiSettings());
    showToast('Teen Patti settings updated');
  };

  const handleUpdateFantasy = (partial: Partial<MasterFantasySettings>) => {
    masterOwnerService.updateFantasySettings(partial);
    setFantasy(masterOwnerService.getFantasySettings());
    showToast('Fantasy Cricket engine updated');
  };

  const handleSelectRuleGame = (key: keyof MasterGameRulesConfig) => {
    setSelectedRuleGame(key);
    setEditingRuleText(rules[key]);
  };

  const handleSaveRule = () => {
    masterOwnerService.updateGameRule(selectedRuleGame, editingRuleText);
    setRules(masterOwnerService.getGameRules());
    showToast(`Updated official rules for ${selectedRuleGame}`);
  };

  return (
    <div className="space-y-4">
      {/* Toast */}
      {savedToast && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{savedToast}</span>
        </div>
      )}

      {/* 1. Global Game Kill-Switches / Enable-Disable Hub */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Gamepad2 className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Games Availability & Maintenance Switch
              </h4>
              <span className="text-[10px] text-slate-400">
                Disable games anytime for emergency upgrades or server maintenance
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {([
            { key: 'callBreak', name: 'Call Break', icon: '♠️' },
            { key: 'teenPatti', name: 'Teen Patti', icon: '🃏' },
            { key: 'ludo', name: 'Ludo Classic', icon: '🎲' },
            { key: 'rummy', name: 'Indian Rummy', icon: '🂠' },
            { key: 'fantasyCricket', name: 'Fantasy 11', icon: '🏏' },
            { key: 'quizGames', name: 'Cricket Quizzes', icon: '⚡' },
          ] as const).map((item) => {
            const isEnabled = enabledGames[item.key];

            return (
              <div
                key={item.key}
                className={`p-2.5 rounded-xl border flex items-center justify-between transition-all ${
                  isEnabled
                    ? 'bg-slate-950/80 border-slate-800'
                    : 'bg-red-950/20 border-red-500/40'
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs">{item.icon}</span>
                    <span className="text-xs font-bold text-white">{item.name}</span>
                  </div>
                  <span
                    className={`text-[9px] font-bold block ${
                      isEnabled ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {isEnabled ? '● Active Live' : '● Maintenance'}
                  </span>
                </div>

                <button
                  onClick={() => handleToggleGame(item.key)}
                  className={`p-1 rounded-lg transition-all ${
                    isEnabled
                      ? 'text-emerald-400 hover:text-emerald-300'
                      : 'text-red-400 hover:text-red-300'
                  }`}
                  title={isEnabled ? 'Disable Game' : 'Enable Game'}
                >
                  {isEnabled ? (
                    <ToggleRight className="w-6 h-6" />
                  ) : (
                    <ToggleLeft className="w-6 h-6" />
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 2. Ludo Game Specific Settings */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <span className="text-base">🎲</span>
          <div>
            <h4 className="text-xs font-bold text-white">Ludo Classic Engine Settings</h4>
            <span className="text-[10px] text-slate-400">Timers, Token release rules and AI difficulty</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Turn Timer */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">
              Player Turn Timer
            </span>
            <div className="grid grid-cols-3 gap-1">
              {([15, 30, 45] as const).map((sec) => (
                <button
                  key={sec}
                  onClick={() => handleUpdateLudo({ turnTimerSeconds: sec })}
                  className={`py-1 rounded-md text-[11px] font-bold ${
                    ludo.turnTimerSeconds === sec
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {sec}s
                </button>
              ))}
            </div>
          </div>

          {/* Bot Difficulty */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">
              Bot AI Difficulty
            </span>
            <div className="grid grid-cols-3 gap-1">
              {(['easy', 'balanced', 'expert'] as const).map((diff) => (
                <button
                  key={diff}
                  onClick={() => handleUpdateLudo({ botDifficulty: diff })}
                  className={`py-1 rounded-md text-[10px] font-bold capitalize ${
                    ludo.botDifficulty === diff
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {diff}
                </button>
              ))}
            </div>
          </div>

          {/* Strict 6 to Open */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between col-span-2">
            <div>
              <span className="text-xs font-bold text-white block">Strict Six (6) to Release Token</span>
              <span className="text-[10px] text-slate-400">Tokens only leave base when rolling exact 6</span>
            </div>
            <button
              onClick={() => handleUpdateLudo({ strictSixToOpen: !ludo.strictSixToOpen })}
              className="text-amber-400"
            >
              {ludo.strictSixToOpen ? <ToggleRight className="w-6 h-6" /> : <ToggleLeft className="w-6 h-6 text-slate-500" />}
            </button>
          </div>
        </div>
      </div>

      {/* 3. Teen Patti Game Settings */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <span className="text-base">🃏</span>
          <div>
            <h4 className="text-xs font-bold text-white">Teen Patti Table & Pot Rules</h4>
            <span className="text-[10px] text-slate-400">Boot amounts, blind rounds and virtual caps</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {/* Boot Amount */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">
              Default Boot Coin Amount
            </span>
            <div className="grid grid-cols-3 gap-1">
              {[50, 100, 250].map((amt) => (
                <button
                  key={amt}
                  onClick={() => handleUpdateTeenPatti({ bootAmount: amt })}
                  className={`py-1 rounded-md text-[11px] font-bold ${
                    teenPatti.bootAmount === amt
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {amt}
                </button>
              ))}
            </div>
          </div>

          {/* Max Blind Rounds */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1">
            <span className="text-[10px] text-slate-400 font-bold uppercase block">
              Max Blind Rounds
            </span>
            <div className="grid grid-cols-3 gap-1">
              {[2, 4, 6].map((rounds) => (
                <button
                  key={rounds}
                  onClick={() => handleUpdateTeenPatti({ maxBlindRounds: rounds })}
                  className={`py-1 rounded-md text-[11px] font-bold ${
                    teenPatti.maxBlindRounds === rounds
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  {rounds}
                </button>
              ))}
            </div>
          </div>

          {/* Pot Cap */}
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between col-span-2">
            <div>
              <span className="text-xs font-bold text-white block">Maximum Virtual Pot Cap</span>
              <span className="text-[10px] text-slate-400">Limits max betting inflation on single hands</span>
            </div>
            <span className="text-xs font-black text-amber-300 font-mono">
              {teenPatti.maxPotCap.toLocaleString()} Coins
            </span>
          </div>
        </div>
      </div>

      {/* 4. Fantasy Cricket Engine Settings */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <span className="text-base">🏏</span>
          <div>
            <h4 className="text-xs font-bold text-white">Fantasy Cricket Scoring Multipliers</h4>
            <span className="text-[10px] text-slate-400">Captain/Vice-Captain boosts & squad transfer limits</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 font-bold block">Captain Multiplier</span>
            <span className="text-sm font-black text-amber-400 font-mono mt-1 block">
              {fantasy.maxCaptainMult}x Points
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 font-bold block">VC Multiplier</span>
            <span className="text-sm font-black text-amber-400 font-mono mt-1 block">
              {fantasy.viceCaptainMult}x Points
            </span>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-center">
            <span className="text-[10px] text-slate-400 font-bold block">Deadline Window</span>
            <span className="text-sm font-black text-white font-mono mt-1 block">
              {fantasy.transferDeadlineMinutes}m before
            </span>
          </div>
        </div>
      </div>

      {/* 5. Game Rules Management & Official Policy Editor */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Edit3 className="w-4 h-4 text-amber-400" />
            <div>
              <h4 className="text-xs font-bold text-white">Game Rules & Fair Play Policy Editor</h4>
              <span className="text-[10px] text-slate-400">Update official rules shown to players</span>
            </div>
          </div>
        </div>

        {/* Game Selector for Rules */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {(['callBreak', 'teenPatti', 'ludo', 'rummy', 'fantasyCricket'] as const).map((key) => (
            <button
              key={key}
              onClick={() => handleSelectRuleGame(key)}
              className={`px-3 py-1 rounded-lg text-[11px] font-bold capitalize whitespace-nowrap transition-all ${
                selectedRuleGame === key
                  ? 'bg-amber-500 text-slate-950 shadow-sm'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {key === 'callBreak' ? 'Call Break' : key === 'teenPatti' ? 'Teen Patti' : key === 'ludo' ? 'Ludo' : key === 'rummy' ? 'Rummy' : 'Fantasy 11'}
            </button>
          ))}
        </div>

        {/* Textarea */}
        <div className="space-y-2">
          <textarea
            value={editingRuleText}
            onChange={(e) => setEditingRuleText(e.target.value)}
            rows={3}
            className="w-full p-2.5 bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-xl text-xs text-white placeholder:text-slate-600 focus:outline-none leading-relaxed"
          />
          <button
            onClick={handleSaveRule}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs active:scale-95 transition-all flex items-center gap-1.5 ml-auto"
          >
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Save Rules for {selectedRuleGame}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
