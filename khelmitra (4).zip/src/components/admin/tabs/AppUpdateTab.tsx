import React, { useState } from 'react';
import { 
  Bell, AlertOctagon, Smartphone, Sliders, ToggleLeft, 
  ToggleRight, CheckCircle, Send, Sparkles, ShieldAlert, 
  RefreshCw, Info, Edit 
} from 'lucide-react';
import { masterOwnerService } from '../../../services/masterOwnerService';
import { MasterAppConfig } from '../../../types';

export default function AppUpdateTab() {
  const [config, setConfig] = useState<MasterAppConfig>(masterOwnerService.getAppConfig());
  const [annTitle, setAnnTitle] = useState(config.announcement.title);
  const [annMessage, setAnnMessage] = useState(config.announcement.message);
  const [annLevel, setAnnLevel] = useState(config.announcement.level);
  const [annActive, setAnnActive] = useState(config.announcement.active);
  const [maintMessage, setMaintMessage] = useState(config.maintenanceMessage);
  const [maintReturn, setMaintReturn] = useState(config.maintenanceEstimatedReturn);
  const [versionCurrent, setVersionCurrent] = useState(config.version.current);
  const [forceUpdate, setForceUpdate] = useState(config.version.forceUpdate);
  const [savedToast, setSavedToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setSavedToast(msg);
    setTimeout(() => setSavedToast(null), 3000);
  };

  const handleSaveAnnouncement = () => {
    masterOwnerService.updateAnnouncement({
      title: annTitle,
      message: annMessage,
      level: annLevel,
      active: annActive
    });
    setConfig(masterOwnerService.getAppConfig());
    showToast('Broadcast Announcement published live to all users!');
  };

  const handleToggleMaintenance = () => {
    const isMaint = masterOwnerService.toggleMaintenanceMode();
    masterOwnerService.updateMaintenanceDetails(maintMessage, maintReturn);
    setConfig(masterOwnerService.getAppConfig());
    showToast(`Maintenance Mode ${isMaint ? 'ENABLED' : 'DISABLED'}`);
  };

  const handleToggleFeature = (featKey: keyof MasterAppConfig['enabledFeatures']) => {
    masterOwnerService.toggleFeature(featKey);
    setConfig(masterOwnerService.getAppConfig());
    showToast(`Toggled ${featKey} feature state`);
  };

  const handleSaveVersion = () => {
    masterOwnerService.updateVersionInfo({
      current: versionCurrent,
      forceUpdate: forceUpdate
    });
    setConfig(masterOwnerService.getAppConfig());
    showToast('Version information and release policies saved');
  };

  return (
    <div className="space-y-4">
      {/* Toast Notice */}
      {savedToast && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{savedToast}</span>
        </div>
      )}

      {/* 1. App Announcement Live Broadcaster */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Live App Announcement Broadcaster</h4>
              <span className="text-[10px] text-slate-400">Pushes announcement banner across app home screen</span>
            </div>
          </div>

          <button
            onClick={() => setAnnActive(!annActive)}
            className="flex items-center gap-1.5 text-xs font-bold"
          >
            <span className={annActive ? 'text-emerald-400' : 'text-slate-500'}>
              {annActive ? 'Broadcast Active' : 'Broadcast Off'}
            </span>
            {annActive ? <ToggleRight className="w-6 h-6 text-emerald-400" /> : <ToggleLeft className="w-6 h-6 text-slate-600" />}
          </button>
        </div>

        <div className="space-y-2 text-xs">
          {/* Headline */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Announcement Headline
            </label>
            <input
              type="text"
              value={annTitle}
              onChange={(e) => setAnnTitle(e.target.value)}
              placeholder="e.g. 🏆 Weekend Festival Live!"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-xl text-white text-xs placeholder:text-slate-600 focus:outline-none"
            />
          </div>

          {/* Message */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Message Details
            </label>
            <textarea
              value={annMessage}
              onChange={(e) => setAnnMessage(e.target.value)}
              rows={2}
              placeholder="Enter announcement description..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-xl text-white text-xs placeholder:text-slate-600 focus:outline-none"
            />
          </div>

          {/* Level & Publish */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5">
              {(['info', 'promo', 'alert', 'critical'] as const).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setAnnLevel(lvl)}
                  className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase transition-all ${
                    annLevel === lvl
                      ? lvl === 'critical'
                        ? 'bg-red-500 text-white'
                        : lvl === 'alert'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-blue-500 text-white'
                      : 'bg-slate-950 text-slate-400 border border-slate-800'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleSaveAnnouncement}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs active:scale-95 transition-all flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Broadcast Now</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Maintenance Mode Master Switch */}
      <div className={`p-3.5 rounded-2xl border space-y-3 transition-all ${
        config.maintenanceMode 
          ? 'bg-red-950/30 border-red-500/50' 
          : 'bg-slate-900/90 border-slate-800'
      }`}>
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${
              config.maintenanceMode ? 'bg-red-500/20 text-red-400' : 'bg-slate-800 text-slate-400'
            }`}>
              <AlertOctagon className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">System Maintenance Mode</h4>
              <span className="text-[10px] text-slate-400">Temporarily locks non-owner app access for updates</span>
            </div>
          </div>

          <button
            onClick={handleToggleMaintenance}
            className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              config.maintenanceMode
                ? 'bg-red-600 text-white shadow-md animate-pulse'
                : 'bg-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            <span>{config.maintenanceMode ? 'MAINTENANCE ON' : 'MAINTENANCE OFF'}</span>
          </button>
        </div>

        <div className="space-y-2 text-xs">
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
              Maintenance Screen Message
            </label>
            <input
              type="text"
              value={maintMessage}
              onChange={(e) => setMaintMessage(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs"
            />
          </div>

          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
              Estimated Return Time Notice
            </label>
            <input
              type="text"
              value={maintReturn}
              onChange={(e) => setMaintReturn(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs"
            />
          </div>
        </div>
      </div>

      {/* 3. Feature Enable / Disable Flags */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <Sliders className="w-4 h-4 text-amber-400" />
          <div>
            <h4 className="text-xs font-bold text-white">Global Feature Flags</h4>
            <span className="text-[10px] text-slate-400">Toggle individual modules across KhelMitra</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          {([
            { key: 'luckyWheel', label: 'Lucky Spin Wheel' },
            { key: 'customerCare', label: 'Customer Care & FAQs' },
            { key: 'inviteReferrals', label: 'Invite Friends / Referral' },
            { key: 'fantasyContests', label: 'Fantasy 11 Contests' },
            { key: 'apkDownloads', label: 'Android APK Download Hub' },
            { key: 'audioEffects', label: 'Dynamic Sound Synthesizer' },
          ] as const).map((feat) => {
            const isEnabled = config.enabledFeatures[feat.key];

            return (
              <div
                key={feat.key}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between"
              >
                <span className="text-xs font-bold text-white">{feat.label}</span>
                <button
                  onClick={() => handleToggleFeature(feat.key)}
                  className="text-amber-400"
                >
                  {isEnabled ? (
                    <ToggleRight className="w-6 h-6 text-emerald-400" />
                  ) : (
                    <ToggleLeft className="w-6 h-6 text-slate-600" />
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. App Version & Release Policies */}
      <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <div>
            <h4 className="text-xs font-bold text-white">Version & Mandatory Update Policies</h4>
            <span className="text-[10px] text-slate-400">Control APK distribution version tags and update prompts</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <label className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
              Current Live App Version
            </label>
            <input
              type="text"
              value={versionCurrent}
              onChange={(e) => setVersionCurrent(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white text-xs font-mono"
            />
          </div>

          <div className="flex flex-col justify-end">
            <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-white block">Force Update</span>
                <span className="text-[9px] text-slate-400">Prompt APK download</span>
              </div>
              <button
                onClick={() => setForceUpdate(!forceUpdate)}
                className="text-amber-400"
              >
                {forceUpdate ? <ToggleRight className="w-6 h-6 text-emerald-400" /> : <ToggleLeft className="w-6 h-6 text-slate-600" />}
              </button>
            </div>
          </div>

          <div className="col-span-2 pt-1">
            <button
              onClick={handleSaveVersion}
              className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs active:scale-95 transition-all flex items-center gap-1.5 ml-auto"
            >
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Save Version Information</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
