import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Lock, Key, AlertTriangle, Eye, EyeOff, 
  Sparkles, CheckCircle2, ChevronRight, X, ShieldAlert 
} from 'lucide-react';
import { masterOwnerService } from '../../services/masterOwnerService';
import { MasterOwnerRole } from '../../types';

interface MasterOwnerAuthModalProps {
  onSuccess: () => void;
  onClose: () => void;
}

export default function MasterOwnerAuthModal({ onSuccess, onClose }: MasterOwnerAuthModalProps) {
  const [passcode, setPasscode] = useState('');
  const [showPasscode, setShowPasscode] = useState(false);
  const [role, setRole] = useState<MasterOwnerRole>('SUPER_OWNER');
  const [error, setError] = useState<string | null>(null);
  const [lockoutRemaining, setLockoutRemaining] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const updateLockout = () => {
      const remaining = masterOwnerService.getLockoutRemainingSeconds();
      setLockoutRemaining(remaining);
    };
    updateLockout();
    const interval = setInterval(updateLockout, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode.trim()) {
      setError('Please enter master authorization passcode');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const result = await masterOwnerService.loginOwnerAsync(passcode, role);
      setIsSubmitting(false);

      if (result.success) {
        onSuccess();
      } else {
        setError(result.message);
        setLockoutRemaining(masterOwnerService.getLockoutRemainingSeconds());
      }
    } catch {
      setIsSubmitting(false);
      setError('Authentication server error. Please try again.');
    }
  };

  const handleQuickFillPin = () => {
    setPasscode('khelmitra2025');
    setError(null);
  };

  return (
    <div 
      id="master-owner-auth-overlay" 
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="master-owner-auth-card" 
        className="w-full max-w-sm bg-[#0a0f1d] border border-amber-500/40 rounded-3xl p-5 shadow-[0_0_50px_rgba(245,158,11,0.15)] relative flex flex-col gap-4 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-7 h-7 rounded-full bg-slate-800/80 text-slate-400 hover:text-white flex items-center justify-center text-xs"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Security Shield Icon & Header */}
        <div className="flex flex-col items-center text-center pt-2">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500/20 to-red-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.2)] mb-2">
            <Lock className="w-7 h-7 text-amber-400" />
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-3 h-3 text-amber-400" />
            <span>Restricted Master Access</span>
          </div>
          <h2 className="text-lg font-black text-white tracking-wide">
            Master Owner Control Panel
          </h2>
          <p className="text-xs text-slate-400 max-w-[260px] mt-0.5">
            Authenticate with your authorized owner credentials to manage users, games, APIs & security.
          </p>
        </div>

        {/* Lockout Warning if applicable */}
        {lockoutRemaining > 0 && (
          <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-red-400 shrink-0" />
            <div>
              <span className="font-bold block">Security Lockdown Active</span>
              <span>Wait {lockoutRemaining}s before attempting next authorization.</span>
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-3">
          {/* Role Selection */}
          <div>
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
              Admin Authority Level
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => setRole('SUPER_OWNER')}
                className={`p-2 rounded-xl border text-left text-xs font-semibold transition-all ${
                  role === 'SUPER_OWNER'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span className="block font-bold">Super Owner</span>
                <span className="text-[10px] text-slate-400">Full System Control</span>
              </button>

              <button
                type="button"
                onClick={() => setRole('OPERATIONS_ADMIN')}
                className={`p-2 rounded-xl border text-left text-xs font-semibold transition-all ${
                  role === 'OPERATIONS_ADMIN'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-sm'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <span className="block font-bold">Operations Admin</span>
                <span className="text-[10px] text-slate-400">Games & Users</span>
              </button>
            </div>
          </div>

          {/* Passcode Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                Master Security Passcode / Owner ID
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setPasscode('nag260164@gmail.com');
                    setError(null);
                  }}
                  className="text-[10px] text-emerald-400 hover:text-emerald-300 font-semibold underline underline-offset-2"
                >
                  Owner Email
                </button>
                <button
                  type="button"
                  onClick={handleQuickFillPin}
                  className="text-[10px] text-amber-400 hover:text-amber-300 font-semibold underline underline-offset-2"
                >
                  Autofill PIN
                </button>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                <Key className="w-4 h-4" />
              </div>
              <input
                type={showPasscode ? 'text' : 'password'}
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Enter master PIN or owner email"
                disabled={lockoutRemaining > 0 || isSubmitting}
                className="w-full pl-9 pr-10 py-2.5 bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl text-white text-sm placeholder:text-slate-600 focus:outline-none transition-colors font-mono"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShowPasscode(!showPasscode)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white"
              >
                {showPasscode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1">
              <span>Owner: <code className="text-emerald-400 font-mono">nag260164@gmail.com</code></span>
              <span>PIN: <code className="text-amber-400 font-mono">khelmitra2025</code></span>
            </div>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-red-400 text-xs flex items-center gap-2 animate-in fade-in">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={lockoutRemaining > 0 || isSubmitting}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-amber-500/20 active:scale-98 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <span>Authenticating...</span>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4 text-slate-950" />
                <span>Authorize & Unlock Control Panel</span>
              </>
            )}
          </button>
        </form>

        {/* Security Compliance Note */}
        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>256-bit AES Token Guard</span>
          </div>
          <span className="text-slate-500">Device ID: KM-OWNER-SEC-81</span>
        </div>
      </div>
    </div>
  );
}
