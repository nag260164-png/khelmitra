import React, { useState, useEffect } from 'react';
import { 
  X, ShieldCheck, LayoutDashboard, Users, Gamepad2, Radio, Gift, 
  Tv, Bell, Lock, LogOut, Sparkles, Sliders, Sun, Moon, UserCheck, 
  Key, Server, CheckCircle, ShieldAlert, Copy, Check
} from 'lucide-react';
import { masterOwnerService } from '../../services/masterOwnerService';
import MasterOwnerAuthModal from './MasterOwnerAuthModal';
import DashboardOverviewTab from './tabs/DashboardOverviewTab';
import UserManagementTab from './tabs/UserManagementTab';
import GameManagementTab from './tabs/GameManagementTab';
import CricketApiTab from './tabs/CricketApiTab';
import RewardsTab from './tabs/RewardsTab';
import AdsManagementTab from './tabs/AdsManagementTab';
import AppUpdateTab from './tabs/AppUpdateTab';
import SecurityTab from './tabs/SecurityTab';
import ResellingManagementTab from './tabs/ResellingManagementTab';
import { ShoppingBag } from 'lucide-react';

interface MasterOwnerControlPanelProps {
  onClose: () => void;
}

export type MasterOwnerTabType = 
  | 'dashboard' 
  | 'users' 
  | 'games' 
  | 'rewards' 
  | 'appControl' 
  | 'cricket' 
  | 'ads' 
  | 'security'
  | 'reselling';

export default function MasterOwnerControlPanel({ onClose }: MasterOwnerControlPanelProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(masterOwnerService.isOwnerAuthenticated());
  const [activeTab, setActiveTab] = useState<MasterOwnerTabType>('dashboard');
  const [isLightMode, setIsLightMode] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [copiedToken, setCopiedToken] = useState(false);

  useEffect(() => {
    const unsub = masterOwnerService.subscribe(() => {
      setIsAuthenticated(masterOwnerService.isOwnerAuthenticated());
    });
    return () => unsub();
  }, []);

  const handleLogout = () => {
    masterOwnerService.logoutOwner();
    setIsAuthenticated(false);
    setShowProfileModal(false);
  };

  const handleCopySessionToken = () => {
    navigator.clipboard?.writeText('KM-SUPER-ROOT-9988-AUTH');
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  // If not authenticated, display secure owner login gate
  if (!isAuthenticated) {
    return (
      <MasterOwnerAuthModal 
        onSuccess={() => setIsAuthenticated(true)}
        onClose={onClose}
      />
    );
  }

  const role = masterOwnerService.getCurrentRole();

  const TABS: { id: MasterOwnerTabType; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'users', label: 'User Control', icon: Users },
    { id: 'games', label: 'Game Control', icon: Gamepad2 },
    { id: 'rewards', label: 'Rewards & Missions', icon: Gift },
    { id: 'appControl', label: 'App Update', icon: Bell },
    { id: 'cricket', label: 'Live Cricket', icon: Radio },
    { id: 'ads', label: 'Ads Engine', icon: Tv },
    { id: 'reselling', label: 'Reselling & Suppliers', icon: ShoppingBag },
    { id: 'security', label: 'Security & RBAC', icon: Lock },
  ];

  return (
    <div 
      id="master-owner-panel-overlay" 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end justify-center animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="master-owner-panel-sheet"
        className={`w-full max-w-md h-[95vh] rounded-t-3xl flex flex-col shadow-[0_0_60px_rgba(245,158,11,0.25)] overflow-hidden animate-in slide-in-from-bottom-5 duration-300 transition-colors ${
          isLightMode 
            ? 'bg-slate-100 text-slate-900 border-t-2 border-amber-500' 
            : 'bg-[#070b14] text-slate-100 border-t border-amber-500/40'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className={`pt-3 pb-2.5 px-4 border-b flex items-center justify-between transition-colors ${
          isLightMode 
            ? 'bg-white border-slate-200 shadow-sm' 
            : 'bg-slate-950/90 border-slate-800'
        }`}>
          {/* Owner Badge & Profile Trigger */}
          <button 
            onClick={() => setShowProfileModal(true)}
            className="flex items-center gap-2 text-left group hover:opacity-90 transition-opacity"
            title="View Master Owner Profile"
          >
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shadow-sm">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className={`text-sm font-black tracking-wide ${isLightMode ? 'text-slate-900' : 'text-white'}`}>
                  Master Owner Panel
                </h3>
                <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-600 dark:text-amber-300 text-[9px] font-black uppercase font-mono border border-amber-500/30">
                  {role}
                </span>
              </div>
              <span className={`text-[10px] flex items-center gap-1 ${isLightMode ? 'text-slate-500' : 'text-slate-400'}`}>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                nag260164@gmail.com • Profile
              </span>
            </div>
          </button>

          {/* Action Tools: Dark/Light Mode, Profile, Lock/Logout & Close */}
          <div className="flex items-center gap-1.5">
            {/* Theme Toggle (Dark / Light) */}
            <button
              onClick={() => setIsLightMode(!isLightMode)}
              className={`p-1.5 rounded-xl border text-xs font-bold flex items-center gap-1 active:scale-95 transition-all ${
                isLightMode 
                  ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200' 
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
              }`}
              title={isLightMode ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            >
              {isLightMode ? <Moon className="w-4 h-4 text-slate-700" /> : <Sun className="w-4 h-4 text-amber-400" />}
            </button>

            {/* Quick Profile View */}
            <button
              onClick={() => setShowProfileModal(true)}
              className={`p-1.5 rounded-xl border text-xs font-bold flex items-center gap-1 active:scale-95 transition-all ${
                isLightMode 
                  ? 'bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100' 
                  : 'bg-slate-900 border-slate-800 text-amber-400 hover:text-amber-300'
              }`}
              title="Master Owner Profile"
            >
              <UserCheck className="w-4 h-4" />
            </button>

            {/* Quick Logout */}
            <button
              onClick={handleLogout}
              className={`px-2 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1 active:scale-95 transition-all ${
                isLightMode
                  ? 'bg-red-50 border-red-200 text-red-600 hover:bg-red-100'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-red-400'
              }`}
              title="Lock & Log Out Master Session"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="text-[10px]">Lock</span>
            </button>

            {/* Close Modal */}
            <button
              onClick={onClose}
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs transition-colors ${
                isLightMode 
                  ? 'bg-slate-200 hover:bg-slate-300 text-slate-700' 
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Close Panel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Pill Bar */}
        <div className={`px-3 pt-2 pb-1.5 border-b overflow-x-auto transition-colors ${
          isLightMode 
            ? 'bg-slate-50 border-slate-200' 
            : 'bg-slate-950/70 border-slate-800/80'
        }`}>
          <div className="flex items-center gap-1.5 min-w-max">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;

              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : isLightMode
                      ? 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 shadow-sm'
                      : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800/80'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : isLightMode ? 'text-slate-500' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Content Container */}
        <div className={`flex-1 overflow-y-auto p-4 space-y-4 ${
          isLightMode ? 'bg-slate-100 text-slate-900' : 'bg-transparent text-slate-100'
        }`}>
          {activeTab === 'dashboard' && <DashboardOverviewTab onNavigateTab={(t) => setActiveTab(t)} />}
          {activeTab === 'users' && <UserManagementTab />}
          {activeTab === 'games' && <GameManagementTab />}
          {activeTab === 'rewards' && <RewardsTab />}
          {activeTab === 'appControl' && <AppUpdateTab />}
          {activeTab === 'cricket' && <CricketApiTab />}
          {activeTab === 'ads' && <AdsManagementTab />}
          {activeTab === 'reselling' && <ResellingManagementTab />}
          {activeTab === 'security' && <SecurityTab />}
        </div>
      </div>

      {/* Owner Profile Modal Dialog */}
      {showProfileModal && (
        <div 
          className="fixed inset-0 z-60 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
          onClick={() => setShowProfileModal(false)}
        >
          <div 
            className="w-full max-w-sm rounded-3xl bg-slate-900 border border-amber-500/40 p-5 shadow-2xl text-slate-100 space-y-4 animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 font-black text-base">
                  MO
                </div>
                <div>
                  <h4 className="text-sm font-black text-white">Master Owner Profile</h4>
                  <span className="text-[10px] text-amber-300 font-mono">Tier-0 Root Authority</span>
                </div>
              </div>
              <button 
                onClick={() => setShowProfileModal(false)}
                className="w-7 h-7 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-500">Authorized Owner Email</span>
                <p className="text-white font-mono font-bold text-xs flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  nag260164@gmail.com
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[9px] uppercase font-bold text-slate-500 block">RBAC Role</span>
                  <span className="text-amber-400 font-mono font-black text-xs">SUPER_OWNER</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[9px] uppercase font-bold text-slate-500 block">Status</span>
                  <span className="text-emerald-400 font-bold text-xs flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    Live / Guarded
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold text-slate-500">Master Session Token</span>
                  <button 
                    onClick={handleCopySessionToken}
                    className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                  >
                    {copiedToken ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedToken ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-slate-400 font-mono text-[11px] truncate">
                  KM-SUPER-ROOT-9988-AUTH
                </p>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-950/40 border border-slate-800 text-[10px] text-slate-400 space-y-1">
                <div className="flex items-center justify-between">
                  <span>Brute-force Lockout Shield:</span>
                  <span className="text-emerald-400 font-bold">Armed (60s)</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>API Key Leakage Shield:</span>
                  <span className="text-emerald-400 font-bold">100% Guarded</span>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-2">
              <button
                onClick={handleLogout}
                className="flex-1 py-2.5 rounded-2xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Lock Session & Log Out</span>
              </button>
              <button
                onClick={() => setShowProfileModal(false)}
                className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

