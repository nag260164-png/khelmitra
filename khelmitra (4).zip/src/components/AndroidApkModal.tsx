import { useState, useEffect } from 'react';
import { 
  X, Download, Smartphone, Terminal, CheckCircle2, ShieldCheck, 
  ExternalLink, Copy, Check, Sparkles, FolderArchive, ArrowRight, 
  Zap, Info, HelpCircle, Cloud, AlertCircle, PlayCircle 
} from 'lucide-react';
import { audioEffectsService } from '../services/audioEffectsService';

interface AndroidApkModalProps {
  onClose: () => void;
}

export default function AndroidApkModal({ onClose }: AndroidApkModalProps) {
  const [activeTab, setActiveTab] = useState<'downloads' | 'studio' | 'github' | 'terminal' | 'checklist'>('downloads');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [installStatus, setInstallStatus] = useState<'ready' | 'installed' | 'unsupported'>('ready');

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setInstallStatus('ready');
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    window.addEventListener('appinstalled', () => {
      setInstallStatus('installed');
      setDeferredPrompt(null);
    });

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallPWA = async () => {
    audioEffectsService.playClick();
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setInstallStatus('installed');
      }
      setDeferredPrompt(null);
    } else {
      alert('To install directly on Android:\n1. Open this app in Chrome on your phone\n2. Tap the three dots (⋮) in the top-right\n3. Tap "Install app" or "Add to Home screen"\n4. KhelMitra will install with a native app icon and fullscreen display!');
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    audioEffectsService.playClick();
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div 
      id="android-apk-modal-overlay" 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="android-apk-modal-content"
        className="w-full max-w-md max-h-[92vh] bg-[#070b14] border border-slate-800 rounded-t-3xl sm:rounded-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300 text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Android Badge */}
        <div className="px-5 py-4 bg-[#0a1020] border-b border-slate-800/90 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-base font-black tracking-wide text-white uppercase font-mono">
                  Android APK Center
                </h3>
                <span className="px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                  Ready
                </span>
              </div>
              <p className="text-xs text-slate-400">Production Build & APK Distribution</p>
            </div>
          </div>
          <button
            onClick={() => {
              audioEffectsService.playClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all active:scale-95"
            title="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-[#080d1a] px-2 pt-2 gap-1 text-xs font-bold overflow-x-auto no-scrollbar">
          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('downloads');
            }}
            className={`pb-2 px-2.5 border-b-2 whitespace-nowrap transition-all flex items-center gap-1 text-[11px] ${
              activeTab === 'downloads' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-3 h-3" />
            <span>Downloads</span>
          </button>
          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('studio');
            }}
            className={`pb-2 px-2.5 border-b-2 whitespace-nowrap transition-all flex items-center gap-1 text-[11px] ${
              activeTab === 'studio' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderArchive className="w-3 h-3" />
            <span>Android Studio</span>
          </button>
          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('github');
            }}
            className={`pb-2 px-2.5 border-b-2 whitespace-nowrap transition-all flex items-center gap-1 text-[11px] ${
              activeTab === 'github' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cloud className="w-3 h-3" />
            <span>Free Cloud Build</span>
          </button>
          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('terminal');
            }}
            className={`pb-2 px-2.5 border-b-2 whitespace-nowrap transition-all flex items-center gap-1 text-[11px] ${
              activeTab === 'terminal' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3 h-3" />
            <span>CLI</span>
          </button>
          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('checklist');
            }}
            className={`pb-2 px-2.5 border-b-2 whitespace-nowrap transition-all flex items-center gap-1 text-[11px] ${
              activeTab === 'checklist' 
                ? 'border-emerald-500 text-emerald-400' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <CheckCircle2 className="w-3 h-3" />
            <span>Checklist</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 text-xs">
          {/* TAB 1: DOWNLOADS */}
          {activeTab === 'downloads' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              {/* Environment Feasibility Status Notice */}
              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-blue-400" />
                    <span>APK Build Environment Check</span>
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[9px] font-bold border border-emerald-500/30">
                    Project Synced
                  </span>
                </div>
                <div className="space-y-1 text-[11px] text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Container Environment:</span>
                    <span className="text-emerald-400 font-bold">Linux Node.js / Vite</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Native Android Project:</span>
                    <span className="text-emerald-400 font-bold">Capacitor 6.2 (Ready)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Direct In-Container .apk output:</span>
                    <span className="text-amber-400 font-bold">Requires Android SDK</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Free 1-Click APK Solutions:</span>
                    <span className="text-white font-bold">3 Free Methods Available</span>
                  </div>
                </div>
              </div>

              {/* Standalone Android PWA Quick Install */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-900 to-emerald-950/40 border border-emerald-500/40 flex items-center justify-between">
                <div className="space-y-0.5 pr-2">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-sm">
                    <Smartphone className="w-4 h-4" />
                    <span>Instant Install on Android (PWA)</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Direct installation to phone home screen with fullscreen standalone mode & offline caching.
                  </p>
                </div>
                <button
                  onClick={handleInstallPWA}
                  className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shrink-0 transition-all active:scale-95 shadow-lg shadow-emerald-500/20"
                >
                  {installStatus === 'installed' ? 'Installed ✓' : 'Install Now'}
                </button>
              </div>

              {/* Download Studio Project ZIP */}
              <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-bold text-white flex items-center gap-1.5">
                      <FolderArchive className="w-4 h-4 text-amber-400" />
                      <span>Android Studio Project (.zip)</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Real native Android Gradle project with compiled assets & Capacitor plugins. Ready to open in Android Studio.
                    </p>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-mono">
                    16 MB
                  </span>
                </div>
                <a
                  href="/khelmitra-android-project.zip"
                  download="khelmitra-android-project.zip"
                  onClick={() => audioEffectsService.playWin()}
                  className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-amber-500/20 text-xs"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Full Project ZIP (16 MB)</span>
                </a>
              </div>

              {/* Download Tarball (.tar.gz) */}
              <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-200">
                    Linux / Mac Archive (.tar.gz)
                  </div>
                  <div className="text-[10px] text-slate-400">
                    For terminal and automated CI/CD pipelines
                  </div>
                </div>
                <a
                  href="/khelmitra-android-build.tar.gz"
                  download="khelmitra-android-build.tar.gz"
                  onClick={() => audioEffectsService.playClick()}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-semibold flex items-center gap-1.5 border border-slate-700 text-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>tar.gz (16 MB)</span>
                </a>
              </div>

              {/* Native App Specifications */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5 text-[11px]">
                <div className="text-slate-400 font-semibold uppercase tracking-wider text-[9px]">
                  Android Specifications & Compliance
                </div>
                <div className="grid grid-cols-2 gap-2 text-slate-300">
                  <div>Package ID: <span className="font-mono text-emerald-400 font-bold">com.khelmitra.gaming</span></div>
                  <div>Min Android SDK: <span className="text-white font-bold">API 26 (Android 8.0)</span></div>
                  <div>Target SDK: <span className="text-white font-bold">API 35 (Android 15)</span></div>
                  <div>Economy: <span className="text-amber-400 font-bold">100% Free Virtual Coins</span></div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ANDROID STUDIO INSTRUCTIONS */}
          {activeTab === 'studio' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px]">1</span>
                  <span>Extract Project ZIP</span>
                </div>
                <p className="text-[11px] text-slate-400 pl-6">
                  Download and unzip <code className="bg-slate-950 px-1.5 py-0.5 rounded text-amber-300">khelmitra-android-project.zip</code> on your Mac, Windows, or Linux PC.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px]">2</span>
                  <span>Open in Android Studio (Free)</span>
                </div>
                <p className="text-[11px] text-slate-400 pl-6">
                  Launch <strong className="text-white">Android Studio</strong>, click <strong className="text-white">Open</strong>, and select the unzipped <code className="bg-slate-950 px-1.5 py-0.5 rounded text-emerald-300">android/</code> directory. Gradle sync will run automatically in 30 seconds.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="font-bold text-white flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px]">3</span>
                  <span>Build APK File</span>
                </div>
                <p className="text-[11px] text-slate-400 pl-6">
                  In top menu, click: <strong className="text-white">Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.
                </p>
                <div className="pl-6 pt-1 text-[11px] text-emerald-400">
                  ✓ Generated APK output location: <br />
                  <code className="bg-slate-950 px-2 py-1 rounded block mt-1 font-mono text-[10px] break-all text-slate-200">
                    android/app/build/outputs/apk/debug/app-debug.apk
                  </code>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: GITHUB ACTIONS FREE CLOUD BUILD */}
          {activeTab === 'github' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              <div className="p-3 rounded-xl bg-gradient-to-br from-blue-950/40 via-slate-900 to-indigo-950/30 border border-blue-500/30 space-y-2">
                <div className="flex items-center gap-2 text-blue-300 font-bold">
                  <Cloud className="w-4 h-4" />
                  <span>100% Free Cloud Build (No Android Studio needed!)</span>
                </div>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  You can build the APK on GitHub's cloud servers completely free without installing Android SDK or Java on your computer.
                </p>
              </div>

              <div className="space-y-2">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5">
                  <span className="font-bold text-white">How it works:</span>
                  <ol className="list-decimal list-inside space-y-1 text-[11px] text-slate-300">
                    <li>Push this project to a free GitHub repository.</li>
                    <li>We've pre-configured <code className="text-amber-300 bg-slate-950 px-1 py-0.5 rounded">.github/workflows/android-build.yml</code>.</li>
                    <li>Go to the <strong className="text-white">Actions</strong> tab in GitHub and click <strong>Run workflow</strong>.</li>
                    <li>In ~2 minutes, download the compiled <strong className="text-emerald-400">app-debug.apk</strong> from the artifacts section!</li>
                  </ol>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Pre-configured GitHub Actions Workflow:</span>
                    <button
                      onClick={() => copyToClipboard('name: Build KhelMitra Android APK\non: [push, workflow_dispatch]\njobs:\n  build-apk:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-java@v4\n        with: { java-version: 17, distribution: temurin }\n      - uses: android-actions/setup-android@v3\n      - run: cd android && ./gradlew assembleDebug', 99)}
                      className="text-emerald-400 hover:underline flex items-center gap-1"
                    >
                      {copiedIndex === 99 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedIndex === 99 ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <pre className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[10px] text-slate-300 overflow-x-auto">
.github/workflows/android-build.yml (Included in project)
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: TERMINAL COMMANDS */}
          {activeTab === 'terminal' && (
            <div className="space-y-3 animate-in fade-in duration-200">
              <p className="text-slate-300">
                Commands to compile the APK from your computer's terminal:
              </p>

              {/* Step 1 */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>1. Assemble Debug APK with Gradle:</span>
                  <button
                    onClick={() => copyToClipboard('cd android && ./gradlew assembleDebug', 1)}
                    className="flex items-center gap-1 text-emerald-400 hover:underline"
                  >
                    {copiedIndex === 1 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 1 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-amber-300 overflow-x-auto">
cd android && ./gradlew assembleDebug
                </pre>
              </div>

              {/* Step 2 */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>2. Run on connected USB Android device:</span>
                  <button
                    onClick={() => copyToClipboard('npx cap run android', 2)}
                    className="flex items-center gap-1 text-emerald-400 hover:underline"
                  >
                    {copiedIndex === 2 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 2 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-amber-300 overflow-x-auto">
npx cap run android
                </pre>
              </div>

              {/* Step 3 */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>3. Re-sync Web Assets after modifying code:</span>
                  <button
                    onClick={() => copyToClipboard('npm run build && npx cap sync android', 3)}
                    className="flex items-center gap-1 text-emerald-400 hover:underline"
                  >
                    {copiedIndex === 3 ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIndex === 3 ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-amber-300 overflow-x-auto">
npm run build && npx cap sync android
                </pre>
              </div>
            </div>
          )}

          {/* TAB 5: PRODUCTION VERIFICATION CHECKLIST */}
          {activeTab === 'checklist' && (
            <div className="space-y-2 animate-in fade-in duration-200">
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 space-y-2">
                <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Production Readiness Certified</span>
                </div>
                <div className="space-y-1.5 text-[11px] text-slate-300">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span><strong>4 Real Skill Games:</strong> Call Break, Teen Patti, Ludo & Rummy</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span><strong>Working Notification Center:</strong> Missions, Rewards, Games, Support, Invites & Cricket</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span><strong>Live Cricket Score API:</strong> 10-second polling & ball-by-ball active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span><strong>Virtual Coins Only:</strong> 100% free legal virtual economy</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span><strong>Android Permissions:</strong> INTERNET, ACCESS_NETWORK_STATE, VIBRATE</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span><strong>Installable on Android:</strong> PWA standalone manifest & service worker ready</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-3 bg-[#080d1a] border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>KhelMitra Mobile Arena</span>
          <button
            onClick={() => {
              audioEffectsService.playClick();
              onClose();
            }}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
