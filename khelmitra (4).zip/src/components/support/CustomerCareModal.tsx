import React, { useState } from 'react';
import { 
  X, Headphones, MessageCircle, HelpCircle, AlertTriangle, 
  Send, CheckCircle2, ChevronDown, ChevronUp, Copy, Check, 
  Search, ShieldCheck, Phone, ArrowUpRight, Sparkles, Clock, MessageSquare
} from 'lucide-react';
import { customerSupportService, FAQ_LIST, FAQItem, SupportTicket, ChatMessage } from '../../services/customerSupportService';
import { audioEffectsService } from '../../services/audioEffectsService';

interface CustomerCareModalProps {
  onClose: () => void;
}

type TabType = 'faq' | 'chat' | 'whatsapp' | 'report';

export default function CustomerCareModal({ onClose }: CustomerCareModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('faq');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFaqCategory, setSelectedFaqCategory] = useState<string>('ALL');
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>('faq-1');

  // WhatsApp Support State
  const [copiedPhone, setCopiedPhone] = useState(false);
  const supportPhone = '+91 98765 43210';
  const waUrl = 'https://wa.me/919876543210?text=Hi%20KhelMitra%20Support%2C%20I%20need%20help%20with%20my%20gaming%20app.';

  // Report Problem State
  const [reportCategory, setReportCategory] = useState<SupportTicket['category']>('Gameplay Issue');
  const [reportSeverity, setReportSeverity] = useState<SupportTicket['severity']>('Medium');
  const [reportEmail, setReportEmail] = useState('');
  const [reportDesc, setReportDesc] = useState('');
  const [hasAttachment, setHasAttachment] = useState(false);
  const [ticketSuccess, setTicketSuccess] = useState<string | null>(null);
  const [ticketsList, setTicketsList] = useState<SupportTicket[]>(customerSupportService.getTickets());

  // Chatbot State
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'bot',
      text: 'Namaste! Welcome to KhelMitra 24/7 Player Support. How can I assist you with Call Break, Teen Patti, Ludo, Rummy, or your free virtual coins today?',
      timestamp: 'Just now',
    },
  ]);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(supportPhone);
    setCopiedPhone(true);
    audioEffectsService.playClick();
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleSendChat = (textToSend?: string) => {
    const text = (textToSend || chatInput).trim();
    if (!text) return;

    audioEffectsService.playClick();
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: 'Just now',
    };

    const botResponseText = customerSupportService.getBotResponse(text);
    const botMsg: ChatMessage = {
      id: `b-${Date.now() + 1}`,
      sender: 'bot',
      text: botResponseText,
      timestamp: 'Just now',
    };

    setChatMessages((prev) => [...prev, userMsg, botMsg]);
    if (!textToSend) setChatInput('');
  };

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportDesc.trim()) return;

    audioEffectsService.playWin();
    const { ticket } = customerSupportService.createTicket(
      reportCategory,
      reportSeverity,
      reportDesc.trim(),
      reportEmail.trim()
    );

    setTicketSuccess(ticket.id);
    setReportDesc('');
    setHasAttachment(false);
    setTicketsList(customerSupportService.getTickets());
  };

  const filteredFaqs = FAQ_LIST.filter((f) => {
    const matchesCat = selectedFaqCategory === 'ALL' || f.category === selectedFaqCategory;
    const matchesSearch =
      f.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div
      id="customer-care-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md"
    >
      <div className="relative w-full max-w-lg max-h-[92vh] bg-slate-900 border border-slate-700/80 rounded-3xl flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-blue-950/80 via-slate-900 to-indigo-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-500/20 border border-blue-500/40 text-blue-400 flex items-center justify-center shadow-inner">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white tracking-wide">Customer Care</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  24/7 Live
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Help, FAQs, Live Support & Problem Reporting</p>
            </div>
          </div>
          <button
            id="close-customer-care-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-4 p-1.5 bg-slate-950 border-b border-slate-800 text-xs font-bold">
          <button
            id="tab-care-faq"
            onClick={() => setActiveTab('faq')}
            className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
              activeTab === 'faq'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span className="text-[11px]">FAQs</span>
          </button>

          <button
            id="tab-care-chat"
            onClick={() => setActiveTab('chat')}
            className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
              activeTab === 'chat'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="text-[11px]">Live Chat</span>
          </button>

          <button
            id="tab-care-whatsapp"
            onClick={() => setActiveTab('whatsapp')}
            className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
              activeTab === 'whatsapp'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400 group-hover:text-emerald-300" />
            <span className="text-[11px]">WhatsApp</span>
          </button>

          <button
            id="tab-care-report"
            onClick={() => setActiveTab('report')}
            className={`py-2 px-1 rounded-xl flex flex-col items-center gap-1 transition-all ${
              activeTab === 'report'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px]">Report Bug</span>
          </button>
        </div>

        {/* Content Area */}
        <div className="p-4 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: FAQs */}
          {activeTab === 'faq' && (
            <div className="space-y-3">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search questions (e.g. Call Break, Coins, Rummy)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                />
              </div>

              {/* Category Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {['ALL', 'Games & Rules', 'Virtual Coins', 'Referrals & Social', 'Android APK & Tech'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedFaqCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-bold whitespace-nowrap transition-colors ${
                      selectedFaqCategory === cat
                        ? 'bg-blue-500 text-white'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* FAQ Accordion List */}
              <div className="space-y-2 pt-1">
                {filteredFaqs.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400 bg-slate-950 rounded-2xl">
                    No FAQs matched your search. You can ask directly in Live Chat or contact us on WhatsApp!
                  </div>
                ) : (
                  filteredFaqs.map((faq) => {
                    const isExpanded = expandedFaqId === faq.id;
                    return (
                      <div
                        key={faq.id}
                        className="rounded-2xl border border-slate-800 bg-slate-950/70 overflow-hidden transition-all"
                      >
                        <button
                          onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                          className="w-full p-3 text-left flex items-center justify-between gap-2 hover:bg-slate-900/50 transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 shrink-0" />
                            <span className="text-xs font-bold text-slate-200">{faq.question}</span>
                          </div>
                          {isExpanded ? (
                            <ChevronUp className="w-4 h-4 text-blue-400 shrink-0" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                          )}
                        </button>
                        {isExpanded && (
                          <div className="p-3 pt-0 text-xs text-slate-400 leading-relaxed border-t border-slate-900 bg-slate-900/30">
                            <p className="mt-2 text-slate-300">{faq.answer}</p>
                            <span className="inline-block mt-2 px-2 py-0.5 rounded text-[9px] font-semibold bg-slate-800 text-slate-400">
                              Category: {faq.category}
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 2: LIVE CHAT & BOT */}
          {activeTab === 'chat' && (
            <div className="space-y-3 flex flex-col h-full">
              {/* Quick Prompt Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
                {[
                  'How to get free coins?',
                  'Call Break Rules',
                  'Ludo Safe Spots',
                  'Install Android APK',
                ].map((prompt) => (
                  <button
                    key={prompt}
                    onClick={() => handleSendChat(prompt)}
                    className="px-2.5 py-1 rounded-full text-[10px] font-semibold bg-slate-800 hover:bg-blue-600/30 hover:text-blue-300 text-slate-300 border border-slate-700 whitespace-nowrap transition-colors"
                  >
                    {prompt}
                  </button>
                ))}
              </div>

              {/* Chat Stream */}
              <div className="space-y-2.5 max-h-[300px] overflow-y-auto p-2 bg-slate-950 rounded-2xl border border-slate-800/80">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.sender === 'user' ? 'items-end' : 'items-start'
                    }`}
                  >
                    <div
                      className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${
                        msg.sender === 'user'
                          ? 'bg-blue-600 text-white rounded-tr-none'
                          : 'bg-slate-900 text-slate-200 border border-slate-800 rounded-tl-none'
                      }`}
                    >
                      {msg.text}
                    </div>
                    <span className="text-[9px] text-slate-500 mt-1 px-1">{msg.timestamp}</span>
                  </div>
                ))}
              </div>

              {/* Chat Input Bar */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="text"
                  placeholder="Type your question..."
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                  className="flex-1 px-3 py-2.5 text-xs bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
                <button
                  id="send-chat-msg-btn"
                  onClick={() => handleSendChat()}
                  className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white active:scale-95 transition-all flex items-center justify-center shadow-md"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: WHATSAPP DIRECT SUPPORT */}
          {activeTab === 'whatsapp' && (
            <div className="space-y-4">
              {/* WhatsApp Hero Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/70 via-slate-900 to-emerald-900/30 border border-emerald-500/40 text-left space-y-3 shadow-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
                      <MessageCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-white">Official WhatsApp Helpline</h3>
                      <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-bold">
                        <Clock className="w-3 h-3" />
                        <span>Replies usually in &lt; 3 mins</span>
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-black uppercase">
                    ACTIVE
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  Chat directly with our human gaming specialists on WhatsApp for game rules, virtual coins assistance, bug inquiries, or VIP feedback.
                </p>

                {/* Direct Action Buttons */}
                <div className="pt-1 space-y-2">
                  <a
                    id="open-whatsapp-link-btn"
                    href={waUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 active:scale-95 transition-all"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Open WhatsApp Chat</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </a>

                  {/* Copy Phone Number Card */}
                  <div className="p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-xs font-mono font-bold text-white">{supportPhone}</span>
                    </div>
                    <button
                      onClick={handleCopyPhone}
                      className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold flex items-center gap-1 transition-colors"
                    >
                      {copiedPhone ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Safe Gaming Guarantee */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/90 flex items-center gap-2.5 text-[11px] text-slate-400">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>Zero real-money transactions required. Our support team will never ask for your banking passwords or OTPs.</span>
              </div>
            </div>
          )}

          {/* TAB 4: REPORT A PROBLEM / TICKET */}
          {activeTab === 'report' && (
            <div className="space-y-4">
              {ticketSuccess ? (
                <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-center space-y-2.5">
                  <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-sm font-black text-white">Ticket Submitted Successfully!</h3>
                  <p className="text-xs text-slate-300">
                    Your Reference ID is <span className="font-mono font-bold text-emerald-400">{ticketSuccess}</span>.
                    Our technical support engineers are reviewing your log.
                  </p>
                  <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-300 text-[11px] font-bold flex items-center justify-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>+50 Bonus Coins credited for your report!</span>
                  </div>
                  <button
                    onClick={() => setTicketSuccess(null)}
                    className="mt-2 px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white transition-colors"
                  >
                    Submit Another Report
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmitTicket} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-300">Issue Category</label>
                    <select
                      value={reportCategory}
                      onChange={(e) => setReportCategory(e.target.value as any)}
                      className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="Gameplay Issue">Gameplay Issue (Cards, Dice, Turn Freeze)</option>
                      <option value="Virtual Coins">Virtual Coins / Missing Bonus</option>
                      <option value="App Crash / Bug">App Crash / Audio Glitch</option>
                      <option value="Account / Profile">Account / Profile Settings</option>
                      <option value="Feature Suggestion">Feature Suggestion for Next Update</option>
                      <option value="Other">Other Inquiry</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-300">Urgency</label>
                      <select
                        value={reportSeverity}
                        onChange={(e) => setReportSeverity(e.target.value as any)}
                        className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-white focus:outline-none focus:border-blue-500"
                      >
                        <option value="Low">Low - Minor cosmetic</option>
                        <option value="Medium">Medium - Gameplay hindrance</option>
                        <option value="High">High - Crash / Freezing</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-bold text-slate-300">Contact Email</label>
                      <input
                        type="email"
                        placeholder="yourname@domain.com"
                        value={reportEmail}
                        onChange={(e) => setReportEmail(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-bold text-slate-300">Problem Description</label>
                    <textarea
                      rows={3}
                      placeholder="Please provide details of what occurred, which game you were playing, etc..."
                      value={reportDesc}
                      onChange={(e) => setReportDesc(e.target.value)}
                      required
                      className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  {/* Simulated Attachment */}
                  <div
                    onClick={() => setHasAttachment(!hasAttachment)}
                    className="p-2.5 rounded-xl border border-dashed border-slate-700 bg-slate-950/60 flex items-center justify-between cursor-pointer hover:border-slate-500 transition-colors"
                  >
                    <span className="text-[11px] text-slate-400">
                      {hasAttachment ? '📎 Screenshot attached (game_screen.png)' : '📎 Attach screenshot / logs (Optional)'}
                    </span>
                    <span className="text-[10px] font-bold text-blue-400">
                      {hasAttachment ? 'Remove' : 'Upload'}
                    </span>
                  </div>

                  <button
                    id="submit-support-ticket-btn"
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs active:scale-95 transition-all shadow-md shadow-amber-950/30 flex items-center justify-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Submit Ticket & Claim 50 Coins</span>
                  </button>
                </form>
              )}

              {/* Previous Tickets */}
              {ticketsList.length > 0 && (
                <div className="pt-2 space-y-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-slate-400 block">
                    Your Ticket History ({ticketsList.length})
                  </span>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto">
                    {ticketsList.map((t) => (
                      <div
                        key={t.id}
                        className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-blue-400">{t.id}</span>
                            <span className="text-slate-300 font-medium">{t.category}</span>
                          </div>
                          <span className="text-[10px] text-slate-500">{t.timestamp}</span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                            t.status === 'Resolved'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {t.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
