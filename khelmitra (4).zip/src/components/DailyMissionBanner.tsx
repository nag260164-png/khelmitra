import { useState, useEffect } from 'react';
import { Gift, Sparkles, CheckCircle2, ChevronRight, Flame, Clock, PlayCircle } from 'lucide-react';
import { dailyMissionService } from '../services/dailyMissionService';
import { DailyMissionState, ActiveSheetType } from '../types';

interface DailyMissionBannerProps {
  onOpenMissions: (sheet: ActiveSheetType) => void;
}

export default function DailyMissionBanner({ onOpenMissions }: DailyMissionBannerProps) {
  const [missionState, setMissionState] = useState<DailyMissionState>(dailyMissionService.getState());
  const [countdown, setCountdown] = useState<string>(dailyMissionService.getTimeUntilMidnight());

  useEffect(() => {
    const unsub = dailyMissionService.subscribe((state) => {
      setMissionState(state);
    });

    const timer = setInterval(() => {
      setCountdown(dailyMissionService.getTimeUntilMidnight());
    }, 1000);

    return () => {
      unsub();
      clearInterval(timer);
    };
  }, []);

  const missionsList = dailyMissionService.getMissionsList();
  const completedCount = missionsList.filter((m) => m.isCompleted).length;
  const totalCount = missionsList.length;
  const unclaimedCount = missionsList.filter((m) => m.isCompleted && !m.isClaimed).length;
  const todayReward = dailyMissionService.getLoginRewardForToday();

  return (
    <section id="daily-missions-home-banner" className="px-4 py-1">
      <div 
        onClick={() => onOpenMissions('daily-missions')}
        className="group relative cursor-pointer overflow-hidden rounded-2xl bg-gradient-to-r from-amber-950/70 via-[#101529] to-slate-900 border border-amber-500/40 p-3.5 shadow-lg shadow-amber-950/20 hover:border-amber-400/70 transition-all active:scale-[0.99]"
      >
        {/* Ambient golden glow */}
        <div className="absolute top-0 right-0 w-36 h-full bg-gradient-to-l from-amber-500/10 to-transparent pointer-events-none"></div>

        <div className="relative z-10 flex items-center justify-between gap-2.5">
          <div className="flex items-center gap-3">
            {/* Left Icon Badge */}
            <div className="relative w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-slate-950 shadow-md shadow-amber-500/30 shrink-0 group-hover:scale-105 transition-transform">
              <Gift className="w-6 h-6 fill-slate-950" />
              {unclaimedCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 border-2 border-[#0a0f1d] text-[9px] font-black text-white flex items-center justify-center animate-bounce">
                  {unclaimedCount}
                </span>
              )}
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-white group-hover:text-amber-300 transition-colors">
                  Daily Missions & Rewards
                </span>
                <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] font-bold flex items-center gap-0.5">
                  <Flame className="w-2.5 h-2.5 text-orange-400" />
                  Day {((missionState.dailyStreak - 1) % 7) + 1}
                </span>
              </div>

              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[11px] text-slate-300 font-medium">
                  {unclaimedCount > 0
                    ? `${unclaimedCount} reward${unclaimedCount > 1 ? 's' : ''} ready to claim!`
                    : missionState.loginClaimed
                    ? `Day ${((missionState.dailyStreak - 1) % 7) + 1} checked in • ${completedCount}/${totalCount} tasks completed`
                    : `Claim today's +${todayReward.coins} login bonus!`}
                </span>
              </div>
            </div>
          </div>

          {/* Right Action Pill */}
          <div className="flex items-center gap-2 shrink-0">
            {!missionState.loginClaimed ? (
              <span className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xs shadow-md shadow-amber-500/25 flex items-center gap-1 animate-pulse">
                <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
                <span>Claim</span>
              </span>
            ) : unclaimedCount > 0 ? (
              <span className="px-3 py-1.5 rounded-xl bg-amber-500 text-slate-950 font-black text-xs shadow-md shadow-amber-500/20 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
                <span>Claim</span>
              </span>
            ) : (
              <div className="w-7 h-7 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300 group-hover:bg-amber-500 group-hover:text-slate-950 transition-colors">
                <ChevronRight className="w-4 h-4" />
              </div>
            )}
          </div>
        </div>

        {/* Mini bottom progress strip */}
        <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>Progress: {completedCount}/{totalCount} completed</span>
          </div>

          <div className="flex items-center gap-1 text-slate-400 font-mono">
            <Clock className="w-2.5 h-2.5 text-amber-400" />
            <span>Reset in {countdown}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
