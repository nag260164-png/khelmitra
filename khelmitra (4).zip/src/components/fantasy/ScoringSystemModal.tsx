import { X, Award, ShieldCheck, Zap, Info, ExternalLink, BookOpen } from 'lucide-react';
import { DEMO_SCORING_SYSTEM } from '../../services/fantasyTeamService';

interface ScoringSystemModalProps {
  onClose: () => void;
  onOpenFullRules?: () => void;
}

export default function ScoringSystemModal({ onClose, onOpenFullRules }: ScoringSystemModalProps) {
  return (
    <div
      id="scoring-system-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="scoring-system-modal-dialog"
        className="w-full max-w-md max-h-[85vh] bg-[#0c1220] border border-slate-700 rounded-3xl flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-slate-900 via-[#0e1628] to-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white tracking-wide">
                Demo Fantasy Scoring System
              </h3>
              <p className="text-[11px] text-slate-400">
                Transparent rules for free demo points calculation
              </p>
            </div>
          </div>
          <button
            id="close-scoring-modal-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Responsible Gaming / Free Demo Badge */}
        <div className="p-3 bg-emerald-950/40 border-b border-emerald-500/20 px-4 flex items-center gap-2.5">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <div className="text-[11px] text-emerald-300">
            <strong>100% Free Demo Platform:</strong> No real-money wagering, no entry fees, and no betting. Fantasy points are solely for sports skill rankings.
          </div>
        </div>

        {/* Scoring Rules List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
          {DEMO_SCORING_SYSTEM.map((cat, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800/80 space-y-2.5"
            >
              <h4 className="text-xs font-black text-amber-400 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" />
                {cat.category}
              </h4>

              <div className="space-y-1.5">
                {cat.items.map((item, itemIdx) => (
                  <div
                    key={itemIdx}
                    className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/60 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="font-bold text-white block">{item.action}</span>
                      <span className="text-[10px] text-slate-400">{item.description}</span>
                    </div>
                    <span className="px-2 py-1 rounded-lg bg-amber-500/10 text-amber-300 font-mono font-black text-xs border border-amber-500/20 shrink-0">
                      {item.points}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Captain Multipliers Callout */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-950 border border-amber-500/30 flex items-start gap-2.5 text-xs text-slate-300">
            <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-amber-400 block mb-0.5">Captain & Vice-Captain Rules</span>
              <p className="text-[11px] leading-relaxed text-slate-300">
                Your designated Captain receives <strong>2x points</strong> for all actions. Vice-Captain receives <strong>1.5x points</strong>. They must be distinct players in your 11-player squad.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-900/90 border-t border-slate-800 flex items-center gap-2">
          {onOpenFullRules && (
            <button
              id="open-full-interactive-rules-btn"
              onClick={() => {
                onClose();
                onOpenFullRules();
              }}
              className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-md shadow-amber-500/20"
            >
              <BookOpen className="w-3.5 h-3.5 text-slate-950" />
              <span>Full Rules & Calculator</span>
            </button>
          )}

          <button
            onClick={onClose}
            className={`${
              onOpenFullRules ? 'w-24' : 'w-full'
            } py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs active:scale-95 transition-all`}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
