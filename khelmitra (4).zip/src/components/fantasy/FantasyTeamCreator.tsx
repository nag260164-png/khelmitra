import { useState, useMemo } from 'react';
import {
  X,
  Users,
  Award,
  ChevronRight,
  ChevronLeft,
  Info,
  CheckCircle2,
  AlertCircle,
  Eye,
  Plus,
  Minus,
  Sparkles,
  HelpCircle,
  Layers,
} from 'lucide-react';
import { FantasyPlayer, FantasyPlayerRole, LiveMatch, UserTeam } from '../../types';
import {
  fantasyTeamService,
  getAvailablePlayersForMatch,
} from '../../services/fantasyTeamService';
import { dailyMissionService } from '../../services/dailyMissionService';
import TeamLogoBadge from '../cricket/TeamLogoBadge';
import TeamPitchPreview from './TeamPitchPreview';
import ScoringSystemModal from './ScoringSystemModal';
import PlayerDetailsModal from '../player/PlayerDetailsModal';
import PlayerPhoto from '../player/PlayerPhoto';

interface FantasyTeamCreatorProps {
  initialMatchId?: string;
  editingTeam?: UserTeam | null;
  onClose: () => void;
  onSaved: (team: UserTeam) => void;
  onOpenRulesPage?: () => void;
}

export default function FantasyTeamCreator({
  initialMatchId = 'match-live-1',
  editingTeam,
  onClose,
  onSaved,
  onOpenRulesPage,
}: FantasyTeamCreatorProps) {
  const matches = useMemo(() => fantasyTeamService.getMatchesList(), []);
  const [selectedMatchId, setSelectedMatchId] = useState<string>(
    editingTeam?.matchId || initialMatchId
  );
  const [showMatchPicker, setShowMatchPicker] = useState<boolean>(false);

  // Current active step: 'players' (Step 1: 11 selection) or 'captains' (Step 2: C & VC)
  const [currentStep, setCurrentStep] = useState<'players' | 'captains'>('players');

  // Role Tab in Step 1
  const [selectedRoleTab, setSelectedRoleTab] = useState<FantasyPlayerRole>('WK');

  // Selected players list
  const [selectedPlayers, setSelectedPlayers] = useState<FantasyPlayer[]>(() => {
    if (editingTeam?.players && editingTeam.players.length > 0) {
      return [...editingTeam.players];
    }
    return [];
  });

  // Captain & Vice Captain
  const [captainId, setCaptainId] = useState<string | null>(() => editingTeam?.captainId || null);
  const [viceCaptainId, setViceCaptainId] = useState<string | null>(() => editingTeam?.viceCaptainId || null);

  // Modals
  const [showPitchPreview, setShowPitchPreview] = useState<boolean>(false);
  const [showScoringModal, setShowScoringModal] = useState<boolean>(false);
  const [selectedPlayerForModal, setSelectedPlayerForModal] = useState<FantasyPlayer | null>(null);
  const [actionNotice, setActionNotice] = useState<string | null>(null);

  const [pendingMatchSwitch, setPendingMatchSwitch] = useState<string | null>(null);

  // Available players for currently selected match
  const availablePlayers = useMemo(() => {
    return getAvailablePlayersForMatch(selectedMatchId);
  }, [selectedMatchId]);

  // Current Match Object
  const currentMatch: LiveMatch = useMemo(() => {
    return matches.find((m) => m.id === selectedMatchId) || matches[0];
  }, [matches, selectedMatchId]);

  // Run team validation
  const validation = useMemo(() => {
    return fantasyTeamService.validateTeamComposition(selectedPlayers, captainId, viceCaptainId);
  }, [selectedPlayers, captainId, viceCaptainId]);

  // Handle Match Change
  const handleSelectMatch = (newMatchId: string) => {
    if (newMatchId === selectedMatchId) {
      setShowMatchPicker(false);
      return;
    }
    if (selectedPlayers.length > 0) {
      setPendingMatchSwitch(newMatchId);
      return;
    }
    setSelectedMatchId(newMatchId);
    setSelectedPlayers([]);
    setCaptainId(null);
    setViceCaptainId(null);
    setShowMatchPicker(false);
  };

  const confirmSwitchMatch = () => {
    if (pendingMatchSwitch) {
      setSelectedMatchId(pendingMatchSwitch);
      setSelectedPlayers([]);
      setCaptainId(null);
      setViceCaptainId(null);
      setPendingMatchSwitch(null);
      setShowMatchPicker(false);
    }
  };

  // Toggle player selection
  const handleTogglePlayer = (player: FantasyPlayer) => {
    const isSelected = selectedPlayers.some((p) => p.id === player.id);

    if (isSelected) {
      // Remove player
      setSelectedPlayers((prev) => prev.filter((p) => p.id !== player.id));
      if (captainId === player.id) setCaptainId(null);
      if (viceCaptainId === player.id) setViceCaptainId(null);
      return;
    }

    // Add Player - check constraints
    if (selectedPlayers.length >= 11) {
      showNotice('Maximum 11 players reached! Deselect someone to swap.');
      return;
    }

    // Check credits constraint
    if (validation.creditsLeft < player.credits) {
      showNotice(`Not enough credits! Only ${validation.creditsLeft} Cr remaining.`);
      return;
    }

    // Check max 7 players per team
    const teamCount = selectedPlayers.filter((p) => p.teamShortName === player.teamShortName).length;
    if (teamCount >= 7) {
      showNotice(`Maximum 7 players allowed from ${player.teamShortName}!`);
      return;
    }

    setSelectedPlayers((prev) => [...prev, player]);
  };

  const showNotice = (msg: string) => {
    setActionNotice(msg);
    setTimeout(() => setActionNotice(null), 3000);
  };

  // Handle Step Navigation
  const handleProceedToCaptains = () => {
    if (selectedPlayers.length !== 11) {
      showNotice(`Select exactly 11 players (${selectedPlayers.length}/11 chosen)`);
      return;
    }
    if (validation.roleCounts.wk < 1) {
      showNotice('You need at least 1 Wicketkeeper (WK)!');
      return;
    }
    if (validation.roleCounts.bat < 1) {
      showNotice('You need at least 1 Batter (BAT)!');
      return;
    }
    if (validation.roleCounts.ar < 1) {
      showNotice('You need at least 1 All-Rounder (AR)!');
      return;
    }
    if (validation.roleCounts.bowl < 1) {
      showNotice('You need at least 1 Bowler (BOWL)!');
      return;
    }
    if (validation.totalCredits > 100) {
      showNotice('Your squad exceeds the 100.0 credit limit!');
      return;
    }

    // Auto assign C and VC if not set
    if (!captainId && selectedPlayers.length > 0) {
      setCaptainId(selectedPlayers[0].id);
    }
    if (!viceCaptainId && selectedPlayers.length > 1) {
      setViceCaptainId(selectedPlayers[1].id);
    }

    setCurrentStep('captains');
  };

  // Handle Save Fantasy Team
  const handleSaveTeam = () => {
    if (!validation.isValid) {
      showNotice(validation.errors[0] || 'Team composition does not meet rules');
      return;
    }

    const captainPlayer = selectedPlayers.find((p) => p.id === captainId);
    const viceCaptainPlayer = selectedPlayers.find((p) => p.id === viceCaptainId);

    const team1Short = currentMatch.team1.shortName;
    const team2Short = currentMatch.team2.shortName;
    const team1Cnt = selectedPlayers.filter((p) => p.teamShortName === team1Short).length;
    const team2Cnt = selectedPlayers.filter((p) => p.teamShortName === team2Short).length;

    const newTeam: UserTeam = {
      id: editingTeam?.id || `team-${Date.now()}`,
      name: editingTeam?.name || `${currentMatch.team1.shortName} vs ${currentMatch.team2.shortName} Lineup`,
      match: `${currentMatch.team1.shortName} vs ${currentMatch.team2.shortName} • ${currentMatch.tournament.split('•')[0].trim()}`,
      matchId: currentMatch.id,
      captain: `${captainPlayer?.name || 'Captain'} (2x Pts)`,
      captainId: captainPlayer?.id,
      viceCaptain: `${viceCaptainPlayer?.name || 'Vice-Captain'} (1.5x Pts)`,
      viceCaptainId: viceCaptainPlayer?.id,
      wicketKeepers: validation.roleCounts.wk,
      batsmen: validation.roleCounts.bat,
      allRounders: validation.roleCounts.ar,
      bowlers: validation.roleCounts.bowl,
      totalPoints: editingTeam?.totalPoints || 0,
      rank: editingTeam?.rank || 0,
      status: editingTeam?.status || 'Ready',
      players: selectedPlayers,
      team1Count: team1Cnt,
      team2Count: team2Cnt,
      team1ShortName: team1Short,
      team2ShortName: team2Short,
      totalCreditsUsed: validation.totalCredits,
    };

    fantasyTeamService.saveTeam(newTeam);
    dailyMissionService.incrementProgress('mission-fantasy-draft', 1);
    onSaved(newTeam);
  };

  // Players filtered by the active role tab
  const playersInRole = availablePlayers.filter((p) => p.role === selectedRoleTab);

  return (
    <div
      id="fantasy-team-creator"
      className="flex flex-col h-full bg-[#070b14] text-slate-100 relative"
    >
      {/* Top Header */}
      <div className="p-3.5 bg-gradient-to-r from-slate-950 via-[#0d1424] to-slate-950 border-b border-slate-800/80 sticky top-0 z-20 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <button
              id="back-btn"
              onClick={currentStep === 'captains' ? () => setCurrentStep('players') : onClose}
              className="p-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div>
              <h2 className="text-sm font-black text-white tracking-wide flex items-center gap-1.5">
                {editingTeam ? 'Edit Fantasy Team' : 'Create Fantasy Team'}
                <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-black uppercase">
                  {currentStep === 'players' ? 'Step 1 of 2' : 'Step 2 of 2'}
                </span>
              </h2>
              <p className="text-[10px] text-slate-400">
                {currentStep === 'players' ? 'Select exactly 11 players under 100 Cr' : 'Assign Captain (2x) & Vice-Captain (1.5x)'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Rules Button */}
            <button
              id="open-scoring-rules-btn"
              onClick={() => setShowScoringModal(true)}
              className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[10px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
            >
              <HelpCircle className="w-3 h-3" />
              Scoring Rules
            </button>

            {/* Close Button */}
            <button
              id="close-creator-btn"
              onClick={onClose}
              className="w-7 h-7 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Match Selector Strip */}
        <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center gap-2">
            <div className="flex items-center -space-x-1.5">
              <TeamLogoBadge code={currentMatch.team1.logoCode || currentMatch.team1.shortName} name={currentMatch.team1.name} size="sm" />
              <TeamLogoBadge code={currentMatch.team2.logoCode || currentMatch.team2.shortName} name={currentMatch.team2.name} size="sm" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">
                {currentMatch.team1.shortName} vs {currentMatch.team2.shortName}
              </span>
              <span className="text-[10px] text-slate-400 block truncate max-w-[170px]">
                {currentMatch.tournament}
              </span>
            </div>
          </div>

          {!editingTeam && (
            <button
              id="switch-match-btn"
              onClick={() => setShowMatchPicker(!showMatchPicker)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-[11px] border border-slate-700"
            >
              Change Match
            </button>
          )}
        </div>

        {/* Dropdown for Match Picker */}
        {showMatchPicker && (
          <div className="mt-2 p-2 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl space-y-1.5 animate-in slide-in-from-top-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block px-1">
              Select Cricket Match for Lineup:
            </span>
            {matches.map((m) => (
              <button
                key={m.id}
                onClick={() => handleSelectMatch(m.id)}
                className={`w-full p-2 rounded-lg text-left flex items-center justify-between transition-all ${
                  m.id === selectedMatchId
                    ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300'
                    : 'bg-slate-950/80 hover:bg-slate-800 text-slate-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold">
                    {m.team1.shortName} vs {m.team2.shortName}
                  </span>
                  <span className="text-[10px] text-slate-400">({m.matchType})</span>
                </div>
                {m.status === 'LIVE' && (
                  <span className="text-[9px] font-black text-red-400 animate-pulse">● LIVE</span>
                )}
                {m.status === 'UPCOMING' && (
                  <span className="text-[9px] font-bold text-amber-400">UPCOMING</span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Team Composition HUD Tracker */}
      <div className="p-3 bg-[#090f1d] border-b border-slate-800/80 space-y-2 shrink-0">
        {/* Progress Bar & Counters */}
        <div className="flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-400 text-[11px]">Players: </span>
            <strong className="text-white text-sm font-sports">
              {selectedPlayers.length}
            </strong>
            <span className="text-slate-500 text-xs"> / 11</span>
          </div>

          {/* Team Ratio */}
          <div className="flex items-center gap-1.5">
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] font-bold text-slate-300">
              {currentMatch.team1.shortName}:{' '}
              <strong className="text-amber-400">
                {selectedPlayers.filter((p) => p.teamShortName === currentMatch.team1.shortName).length}
              </strong>
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[11px] font-bold text-slate-300">
              {currentMatch.team2.shortName}:{' '}
              <strong className="text-amber-400">
                {selectedPlayers.filter((p) => p.teamShortName === currentMatch.team2.shortName).length}
              </strong>
            </span>
          </div>

          {/* Credits Left */}
          <div>
            <span className="text-slate-400 text-[11px]">Credits: </span>
            <strong
              className={`text-sm font-mono font-bold ${
                validation.creditsLeft < 0 ? 'text-red-400' : 'text-emerald-400'
              }`}
            >
              {validation.creditsLeft}
            </strong>
            <span className="text-slate-500 text-[10px]"> Cr</span>
          </div>
        </div>

        {/* 11 Player Visual Progress Segments */}
        <div className="grid grid-cols-11 gap-1">
          {Array.from({ length: 11 }).map((_, idx) => {
            const player = selectedPlayers[idx];
            return (
              <div
                key={idx}
                className={`h-2 rounded-full transition-all ${
                  player
                    ? player.teamShortName === currentMatch.team1.shortName
                      ? 'bg-amber-400'
                      : 'bg-blue-500'
                    : 'bg-slate-800'
                }`}
              />
            );
          })}
        </div>

        {/* Inline validation alerts / warnings if any */}
        {validation.errors.length > 0 && selectedPlayers.length > 0 && (
          <div className="flex items-center gap-1.5 text-[11px] text-amber-300/90 font-medium">
            <Info className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">{validation.errors[0]}</span>
          </div>
        )}
      </div>

      {/* Floating Action Notice */}
      {actionNotice && (
        <div className="absolute top-36 left-4 right-4 z-30 p-2.5 rounded-xl bg-red-950/90 border border-red-500/50 text-white text-xs font-bold text-center shadow-2xl animate-in zoom-in-95">
          {actionNotice}
        </div>
      )}

      {/* ================= STEP 1: PLAYER SELECTION ================= */}
      {currentStep === 'players' && (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Role Filter Tabs (WK | BAT | AR | BOWL) */}
          <div className="grid grid-cols-4 bg-[#0a101f] border-b border-slate-800 text-xs shrink-0">
            {(
              [
                { role: 'WK', label: 'WK', sub: 'Keeper' },
                { role: 'BAT', label: 'BAT', sub: 'Batter' },
                { role: 'AR', label: 'AR', sub: 'All-Round' },
                { role: 'BOWL', label: 'BOWL', sub: 'Bowler' },
              ] as { role: FantasyPlayerRole; label: string; sub: string }[]
            ).map((tab) => {
              const countInRole = selectedPlayers.filter((p) => p.role === tab.role).length;
              const isActive = selectedRoleTab === tab.role;

              return (
                <button
                  key={tab.role}
                  id={`tab-role-${tab.role.toLowerCase()}`}
                  onClick={() => setSelectedRoleTab(tab.role)}
                  className={`py-2.5 text-center relative transition-all border-b-2 ${
                    isActive
                      ? 'border-amber-400 bg-amber-500/10 text-white'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="text-xs font-bold block">
                    {tab.label} ({countInRole})
                  </span>
                  <span className="text-[9px] text-slate-500 block uppercase">
                    {tab.sub}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Role Rule Helper Pill */}
          <div className="px-4 py-1.5 bg-[#060a12] border-b border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
            <span>
              Pick 1 - 8 {selectedRoleTab === 'WK' ? 'Wicket-Keepers' : selectedRoleTab === 'BAT' ? 'Batters' : selectedRoleTab === 'AR' ? 'All-Rounders' : 'Bowlers'}
            </span>
            <span className="text-slate-500 font-mono">
              Available: {playersInRole.length}
            </span>
          </div>

          {/* Player Cards List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2 no-scrollbar">
            {playersInRole.map((player) => {
              const isSelected = selectedPlayers.some((p) => p.id === player.id);

              return (
                <div
                  key={player.id}
                  id={`player-card-${player.id}`}
                  className={`p-3 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-gradient-to-r from-amber-500/15 via-slate-900 to-amber-500/5 border-amber-400 shadow-md shadow-amber-500/10'
                      : 'bg-slate-900/70 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  {/* Left: Avatar & Info - Clicking opens full Player Details modal */}
                  <div
                    className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                    onClick={() => setSelectedPlayerForModal(player)}
                    title="Click to view player stats & performance"
                  >
                    <div className="relative">
                      <PlayerPhoto
                        name={player.name}
                        role={player.role}
                        teamShortName={player.teamShortName}
                        flagColor={player.flagColor}
                        size="md"
                      />
                      {isSelected && (
                        <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center font-bold text-[9px] shadow">
                          ✓
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-white leading-tight hover:text-amber-400 transition-colors">
                          {player.name}
                        </span>
                        <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 text-[9px] font-bold">
                          {player.teamShortName}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5 truncate">
                        {player.battingStyle || player.bowlingStyle}
                      </span>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[9px] text-slate-500 font-mono">
                          Sel by {player.selectedByPercent}% • {player.points} pts
                        </span>
                        <span className="text-[9px] text-amber-400/90 font-bold hover:underline flex items-center gap-0.5">
                          <Info className="w-2.5 h-2.5" /> Stats
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Credits & Selection Toggle Button */}
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-amber-300 block">
                        {player.credits}
                      </span>
                      <span className="text-[9px] text-slate-500 uppercase block">
                        Credits
                      </span>
                    </div>

                    <button
                      id={`select-btn-${player.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTogglePlayer(player);
                      }}
                      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-95 ${
                        isSelected
                          ? 'bg-amber-400 text-slate-950 shadow-md'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                      title={isSelected ? 'Remove from squad' : 'Add to squad'}
                    >
                      {isSelected ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ================= STEP 2: CAPTAIN & VICE-CAPTAIN SELECTION ================= */}
      {currentStep === 'captains' && (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="p-3 bg-amber-500/10 border-b border-amber-500/30 text-xs text-amber-300 flex items-start gap-2">
            <Award className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block">Assign Multipliers:</span>
              <p className="text-[11px] text-slate-300">
                Captain gets <strong>2x points</strong>. Vice-Captain gets <strong>1.5x points</strong>. They must be different players.
              </p>
            </div>
          </div>

          {/* Selected 11 Players List for C & VC assignment */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2 no-scrollbar">
            {selectedPlayers.map((player) => {
              const isC = captainId === player.id;
              const isVC = viceCaptainId === player.id;

              return (
                <div
                  key={player.id}
                  id={`captain-row-${player.id}`}
                  className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5">
                    <TeamLogoBadge
                      code={player.teamShortName}
                      name={player.teamName}
                      size="sm"
                    />
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-bold text-white">
                          {player.name}
                        </span>
                        <span className="px-1 py-0.2 rounded bg-slate-800 text-slate-400 text-[9px] font-bold">
                          {player.role}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {player.teamShortName} • {player.credits} Cr
                      </span>
                    </div>
                  </div>

                  {/* C and VC action pills */}
                  <div className="flex items-center gap-2">
                    {/* Captain Button */}
                    <button
                      id={`set-cap-${player.id}`}
                      onClick={() => {
                        setCaptainId(player.id);
                        if (viceCaptainId === player.id) setViceCaptainId(null);
                      }}
                      className={`w-9 h-9 rounded-xl font-sports text-xs font-bold transition-all border flex items-center justify-center ${
                        isC
                          ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-md shadow-amber-400/20'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      C
                    </button>

                    {/* Vice-Captain Button */}
                    <button
                      id={`set-vc-${player.id}`}
                      onClick={() => {
                        setViceCaptainId(player.id);
                        if (captainId === player.id) setCaptainId(null);
                      }}
                      className={`w-9 h-9 rounded-xl font-sports text-xs font-bold transition-all border flex items-center justify-center ${
                        isVC
                          ? 'bg-slate-200 text-slate-950 border-white shadow-md'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      VC
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom Sticky Action Bar */}
      <div className="p-3.5 bg-slate-950/95 border-t border-slate-800 flex items-center justify-between gap-2.5 shrink-0">
        {/* Preview on Pitch Button */}
        <button
          id="preview-team-pitch-btn"
          onClick={() => setShowPitchPreview(true)}
          className="py-3 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 active:scale-95 transition-all"
        >
          <Eye className="w-4 h-4 text-emerald-400" />
          <span>Pitch Preview</span>
        </button>

        {currentStep === 'players' ? (
          <button
            id="proceed-to-captains-btn"
            onClick={handleProceedToCaptains}
            disabled={selectedPlayers.length !== 11}
            className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 ${
              selectedPlayers.length === 11
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-amber-500/20'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <span>Next: Choose C & VC</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            id="save-fantasy-team-btn"
            onClick={handleSaveTeam}
            disabled={!validation.isValid}
            className={`flex-1 py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 ${
              validation.isValid
                ? 'bg-gradient-to-r from-emerald-500 to-green-600 text-white shadow-emerald-600/30'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{editingTeam ? 'Update Fantasy Team' : 'Save Fantasy Team'}</span>
          </button>
        )}
      </div>

      {/* Team Pitch Ground Modal Preview */}
      {showPitchPreview && (
        <TeamPitchPreview
          teamName={editingTeam?.name || 'Lineup Preview'}
          matchTitle={`${currentMatch.team1.shortName} vs ${currentMatch.team2.shortName}`}
          players={selectedPlayers}
          captainId={captainId}
          viceCaptainId={viceCaptainId}
          onClose={() => setShowPitchPreview(false)}
        />
      )}

      {/* Demo Scoring Rules Modal */}
      {showScoringModal && (
        <ScoringSystemModal
          onClose={() => setShowScoringModal(false)}
          onOpenFullRules={onOpenRulesPage}
        />
      )}

      {/* Professional Player Details & Performance Modal */}
      {selectedPlayerForModal && (
        <PlayerDetailsModal
          isOpen={!!selectedPlayerForModal}
          onClose={() => setSelectedPlayerForModal(null)}
          playerId={selectedPlayerForModal.id}
          playerName={selectedPlayerForModal.name}
          isSelected={selectedPlayers.some((p) => p.id === selectedPlayerForModal.id)}
          canSelect={
            selectedPlayers.some((p) => p.id === selectedPlayerForModal.id) ||
            (selectedPlayers.length < 11 && validation.creditsLeft >= selectedPlayerForModal.credits)
          }
          selectionDisabledReason={
            selectedPlayers.length >= 11
              ? 'Maximum 11 players selected'
              : `Insufficient credits (${validation.creditsLeft} Cr left)`
          }
          onToggleSelect={() => {
            handleTogglePlayer(selectedPlayerForModal);
          }}
        />
      )}

      {/* Switch Match Confirmation Modal (iframe-safe alternative to window.confirm) */}
      {pendingMatchSwitch && (
        <div 
          id="confirm-match-switch-modal"
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="bg-[#0e1424] border border-slate-700 p-5 rounded-2xl max-w-xs w-full text-center space-y-3 shadow-2xl">
            <h4 className="text-sm font-bold text-white">Switch Match?</h4>
            <p className="text-xs text-slate-300">
              Switching matches will reset your current 11 player draft selections.
            </p>
            <div className="flex gap-2 justify-center pt-2">
              <button
                id="cancel-match-switch-btn"
                onClick={() => setPendingMatchSwitch(null)}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all"
              >
                Cancel
              </button>
              <button
                id="confirm-match-switch-btn"
                onClick={confirmSwitchMatch}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition-all shadow-md shadow-amber-500/20"
              >
                Reset & Switch
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
