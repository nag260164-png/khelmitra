import { useState, useEffect } from 'react';
import {
  Users,
  Plus,
  Shield,
  Award,
  Edit2,
  Trash2,
  Eye,
  HelpCircle,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { UserTeam } from '../../types';
import { fantasyTeamService } from '../../services/fantasyTeamService';
import TeamPitchPreview from './TeamPitchPreview';
import ScoringSystemModal from './ScoringSystemModal';

interface MyFantasyTeamsHubProps {
  onOpenCreateTeam: (teamToEdit?: UserTeam) => void;
  onOpenRulesPage?: () => void;
  onClose?: () => void;
}

export default function MyFantasyTeamsHub({
  onOpenCreateTeam,
  onOpenRulesPage,
  onClose,
}: MyFantasyTeamsHubProps) {
  const [teams, setTeams] = useState<UserTeam[]>(() => fantasyTeamService.getTeams());
  const [previewTeam, setPreviewTeam] = useState<UserTeam | null>(null);
  const [showScoringModal, setShowScoringModal] = useState<boolean>(false);
  const [deleteConfirmTeam, setDeleteConfirmTeam] = useState<UserTeam | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = fantasyTeamService.subscribe((updated) => {
      setTeams(updated);
    });
    return () => unsubscribe();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDeleteTeam = (team: UserTeam) => {
    fantasyTeamService.deleteTeam(team.id);
    setDeleteConfirmTeam(null);
    showToast(`Team "${team.name}" has been deleted.`);
  };

  const totalPointsAll = teams.reduce((acc, t) => acc + t.totalPoints, 0);

  return (
    <div id="my-fantasy-teams-hub" className="space-y-3 relative">
      {/* Header bar */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-slate-300 block">
            {teams.length} Fantasy Squad{teams.length !== 1 ? 's' : ''} Created
          </span>
          <span className="text-[11px] text-amber-400 font-medium">
            Demo Points: {totalPointsAll.toFixed(1)} Pts
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            id="hub-rules-btn"
            onClick={() => setShowScoringModal(true)}
            className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[10px] font-bold text-slate-300 hover:text-white flex items-center gap-1"
          >
            <HelpCircle className="w-3 h-3 text-amber-400" />
            Rules
          </button>

          <button
            id="hub-create-team-btn"
            onClick={() => onOpenCreateTeam()}
            className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1 shadow-md shadow-blue-600/20 active:scale-95 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Team</span>
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {toastMessage && (
        <div className="p-2.5 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Teams List */}
      {teams.length === 0 ? (
        <div className="p-8 text-center rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">No Fantasy Teams Yet</h4>
            <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1">
              Select an upcoming or live cricket match to draft your 11-player squad, pick Captain & Vice-Captain!
            </p>
          </div>
          <button
            onClick={() => onOpenCreateTeam()}
            className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs inline-flex items-center gap-1.5 shadow-md shadow-blue-600/30"
          >
            <Plus className="w-3.5 h-3.5" />
            Create Your First Team
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {teams.map((t) => (
            <div
              key={t.id}
              id={`team-card-${t.id}`}
              className="p-3.5 rounded-2xl bg-gradient-to-br from-slate-900 via-[#0a101d] to-slate-950 border border-slate-800 hover:border-slate-700 space-y-3 transition-all shadow-md shadow-black/40"
            >
              {/* Header: Name, Match & Points */}
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 flex items-center justify-center font-black text-xs font-mono">
                    {t.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white leading-tight">
                        {t.name}
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 text-[9px] font-extrabold border border-emerald-500/30">
                        {t.status}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block mt-0.5">{t.match}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-sm font-sports font-bold text-amber-400 block">
                    {t.totalPoints} PTS
                  </span>
                  <span className="text-[10px] text-slate-500">
                    {t.rank ? `Rank #${t.rank}` : 'Free Demo'}
                  </span>
                </div>
              </div>

              {/* Captain & Vice-Captain Strip */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-amber-400 block">
                      Captain (2x)
                    </span>
                    <span className="font-bold text-white text-[11px] truncate block max-w-[120px]">
                      {t.captain.replace('(2x Pts)', '').trim()}
                    </span>
                  </div>
                  <span className="px-1.5 py-0.5 rounded bg-amber-400 text-slate-950 text-[10px] font-black">
                    2x
                  </span>
                </div>

                <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] uppercase font-bold text-slate-400 block">
                      Vice-Captain (1.5x)
                    </span>
                    <span className="font-bold text-white text-[11px] truncate block max-w-[120px]">
                      {t.viceCaptain.replace('(1.5x Pts)', '').trim()}
                    </span>
                  </div>
                  <span className="px-1.5 py-0.5 rounded bg-slate-200 text-slate-950 text-[10px] font-black">
                    1.5x
                  </span>
                </div>
              </div>

              {/* Composition row */}
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 pt-1 border-t border-slate-800/70">
                <span>
                  WK: <strong className="text-slate-200">{t.wicketKeepers}</strong> • BAT:{' '}
                  <strong className="text-slate-200">{t.batsmen}</strong> • AR:{' '}
                  <strong className="text-slate-200">{t.allRounders}</strong> • BOWL:{' '}
                  <strong className="text-slate-200">{t.bowlers}</strong>
                </span>
                {t.totalCreditsUsed && (
                  <span className="text-emerald-400 font-mono text-[10px]">
                    {t.totalCreditsUsed} / 100 Cr
                  </span>
                )}
              </div>

              {/* Action Buttons: Preview, Edit, Delete */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                {/* Preview Button */}
                <button
                  id={`preview-team-btn-${t.id}`}
                  onClick={() => setPreviewTeam(t)}
                  className="py-2 px-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 font-bold text-[11px] flex items-center justify-center gap-1.5 active:scale-95 transition-all border border-slate-700/60"
                >
                  <Eye className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Preview</span>
                </button>

                {/* Edit Button */}
                <button
                  id={`edit-team-btn-${t.id}`}
                  onClick={() => onOpenCreateTeam(t)}
                  className="py-2 px-2.5 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 font-bold text-[11px] flex items-center justify-center gap-1.5 active:scale-95 transition-all border border-blue-500/30"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit Team</span>
                </button>

                {/* Delete Button */}
                <button
                  id={`delete-team-btn-${t.id}`}
                  onClick={() => setDeleteConfirmTeam(t)}
                  className="py-2 px-2.5 rounded-xl bg-red-950/40 hover:bg-red-950/70 text-red-400 font-bold text-[11px] flex items-center justify-center gap-1.5 active:scale-95 transition-all border border-red-500/30"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          ))}

          {/* Bottom create another team button */}
          <button
            id="sheet-create-another-team-btn"
            onClick={() => onOpenCreateTeam()}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Create Another Lineup (Team {teams.length + 1})</span>
          </button>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmTeam && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
          <div className="w-full max-w-xs bg-slate-900 border border-slate-700 rounded-2xl p-4 space-y-3 text-center shadow-2xl">
            <div className="w-10 h-10 mx-auto rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Delete Fantasy Team?</h4>
              <p className="text-xs text-slate-400 mt-1">
                Are you sure you want to remove <strong>"{deleteConfirmTeam.name}"</strong>? This cannot be undone.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmTeam(null)}
                className="py-2 px-3 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                id="confirm-delete-btn"
                onClick={() => handleDeleteTeam(deleteConfirmTeam)}
                className="py-2 px-3 rounded-xl bg-red-600 text-white font-bold text-xs hover:bg-red-500 shadow-md shadow-red-600/20"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Team Pitch Ground Modal Preview */}
      {previewTeam && (
        <TeamPitchPreview
          teamName={previewTeam.name}
          matchTitle={previewTeam.match}
          players={previewTeam.players || []}
          captainId={previewTeam.captainId}
          viceCaptainId={previewTeam.viceCaptainId}
          onClose={() => setPreviewTeam(null)}
        />
      )}

      {/* Demo Scoring System Modal */}
      {showScoringModal && (
        <ScoringSystemModal
          onClose={() => setShowScoringModal(false)}
          onOpenFullRules={onOpenRulesPage}
        />
      )}
    </div>
  );
}
