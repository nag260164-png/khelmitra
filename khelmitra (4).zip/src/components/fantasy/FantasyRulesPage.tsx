import { useState, useMemo } from 'react';
import {
  X,
  BookOpen,
  Award,
  Zap,
  ShieldCheck,
  CheckCircle2,
  Users,
  Target,
  Sliders,
  RotateCcw,
  Sparkles,
  Info,
  ChevronRight,
  TrendingUp,
  Search,
  SlidersHorizontal,
} from 'lucide-react';
import {
  DEFAULT_DEMO_SCORING_CONFIG,
  DemoScoringConfig,
  FANTASY_RULES_DOCUMENTATION,
  SIMULATOR_PRESET_PLAYERS,
  calculatePlayerDemoPoints,
  calculateTeamTotalPoints,
  PlayerPerformanceStats,
} from '../../services/fantasyScoringEngine';
import { COMPREHENSIVE_MATCHES } from '../../data/cricketData';
import { getAvailablePlayersForMatch } from '../../services/fantasyTeamService';

interface FantasyRulesPageProps {
  onClose: () => void;
  onNavigateToCreateTeam?: () => void;
}

type TabType = 'rules' | 'points-table' | 'player-calculator' | 'team-points';

export default function FantasyRulesPage({
  onClose,
  onNavigateToCreateTeam,
}: FantasyRulesPageProps) {
  const [activeTab, setActiveTab] = useState<TabType>('rules');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeRuleSection, setActiveRuleSection] = useState<string>('all');

  // Player Calculator State (Feature 10: Player Performance Details)
  const [selectedPresetIdx, setSelectedPresetIdx] = useState<number>(0);
  const [customStats, setCustomStats] = useState<PlayerPerformanceStats>(
    SIMULATOR_PRESET_PLAYERS[0].stats
  );
  const [selectedRoleMultiplier, setSelectedRoleMultiplier] = useState<
    'captain' | 'viceCaptain' | 'none'
  >('captain');

  // Configurable Scoring state (allows testing customized scoring rules)
  const [config, setConfig] = useState<DemoScoringConfig>(DEFAULT_DEMO_SCORING_CONFIG);
  const [showConfigDrawer, setShowConfigDrawer] = useState(false);

  // Team Points Calculator State (Feature 9: Total Team Points)
  const sampleMatchPlayers = useMemo(() => {
    return getAvailablePlayersForMatch('match-live-1').slice(0, 11);
  }, []);

  const [teamCaptainId, setTeamCaptainId] = useState<string>(
    sampleMatchPlayers[1]?.id || ''
  );
  const [teamViceCaptainId, setTeamViceCaptainId] = useState<string>(
    sampleMatchPlayers[4]?.id || ''
  );

  // Live calculation for single player
  const playerCalcResult = useMemo(() => {
    return calculatePlayerDemoPoints(customStats, selectedRoleMultiplier, config);
  }, [customStats, selectedRoleMultiplier, config]);

  // Live calculation for team total points
  const teamCalcResult = useMemo(() => {
    return calculateTeamTotalPoints(
      sampleMatchPlayers,
      teamCaptainId,
      teamViceCaptainId,
      config
    );
  }, [sampleMatchPlayers, teamCaptainId, teamViceCaptainId, config]);

  const handleSelectPreset = (idx: number) => {
    setSelectedPresetIdx(idx);
    setCustomStats({ ...SIMULATOR_PRESET_PLAYERS[idx].stats });
  };

  const handleUpdateStat = (key: keyof PlayerPerformanceStats, val: number | boolean | string) => {
    setCustomStats((prev) => ({
      ...prev,
      [key]: val,
    }));
  };

  // Filtered rules documentation
  const filteredRuleSections = useMemo(() => {
    return FANTASY_RULES_DOCUMENTATION.map((section) => {
      if (activeRuleSection !== 'all' && section.id !== activeRuleSection) {
        return null;
      }
      if (!searchQuery.trim()) return section;

      const q = searchQuery.toLowerCase();
      const matchSection =
        section.title.toLowerCase().includes(q) ||
        section.subtitle.toLowerCase().includes(q);

      const matchingItems = section.items.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.description.toLowerCase().includes(q) ||
          (item.points && item.points.toLowerCase().includes(q))
      );

      if (matchSection || matchingItems.length > 0) {
        return {
          ...section,
          items: matchSection ? section.items : matchingItems,
        };
      }
      return null;
    }).filter(Boolean) as typeof FANTASY_RULES_DOCUMENTATION;
  }, [searchQuery, activeRuleSection]);

  return (
    <div
      id="fantasy-rules-page"
      className="flex flex-col h-full bg-[#070b14] text-slate-100 overflow-hidden"
    >
      {/* 1. Header with Back/Close and Brand Badge */}
      <header className="p-4 bg-gradient-to-r from-slate-900 via-[#0a101d] to-slate-900 border-b border-slate-800/90 flex items-center justify-between shrink-0 shadow-md">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-slate-950 font-black shadow-md shadow-amber-500/20">
            <Award className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-black text-white tracking-wide">
                Fantasy Cricket Rules
              </h1>
              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-black border border-amber-500/30">
                DEMO POINTS
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Official scoring engine, selection criteria & live point calculations
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            id="toggle-scoring-config-btn"
            onClick={() => setShowConfigDrawer(!showConfigDrawer)}
            className="p-2 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1"
            title="Configure Scoring Rules"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Settings</span>
          </button>

          <button
            id="close-fantasy-rules-page-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center hover:bg-slate-700 transition-colors"
            aria-label="Close Rules"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* 2. Platform Free-Play & Variance Notice Disclaimer */}
      <div className="px-4 py-2 bg-gradient-to-r from-emerald-950/60 via-slate-900 to-emerald-950/40 border-b border-emerald-500/20 flex items-center justify-between text-[11px] text-emerald-300">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>100% Free Demo Simulator:</strong> No real-money rewards or betting. Actual rules may vary across commercial platforms.
          </span>
        </div>
      </div>

      {/* 3. Category Navigation Tabs */}
      <nav
        id="fantasy-rules-tabs"
        className="flex items-center px-4 pt-2.5 pb-1 gap-1 border-b border-slate-800/80 bg-[#080d1a]/80 overflow-x-auto no-scrollbar shrink-0"
      >
        <button
          id="tab-rules-guide"
          onClick={() => setActiveTab('rules')}
          className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeTab === 'rules'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Rules & Guidelines</span>
        </button>

        <button
          id="tab-points-table"
          onClick={() => setActiveTab('points-table')}
          className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeTab === 'points-table'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Demo Points Table</span>
        </button>

        <button
          id="tab-player-calculator"
          onClick={() => setActiveTab('player-calculator')}
          className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeTab === 'player-calculator'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          <span>Player Points Calculator</span>
        </button>

        <button
          id="tab-team-points"
          onClick={() => setActiveTab('team-points')}
          className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 whitespace-nowrap transition-all ${
            activeTab === 'team-points'
              ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Total Team Points</span>
        </button>
      </nav>

      {/* 4. Configurable Scoring Drawer (if toggled) */}
      {showConfigDrawer && (
        <div className="p-3 bg-slate-900 border-b border-amber-500/30 text-xs space-y-2 animate-in slide-in-from-top duration-200">
          <div className="flex items-center justify-between">
            <span className="font-black text-amber-400 flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5" />
              Configurable Scoring Engine Settings
            </span>
            <button
              onClick={() => setConfig(DEFAULT_DEMO_SCORING_CONFIG)}
              className="text-[10px] text-slate-400 hover:text-amber-300 flex items-center gap-0.5"
            >
              <RotateCcw className="w-3 h-3" />
              Reset Defaults
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <label className="flex items-center gap-1.5 bg-slate-950 p-2 rounded-lg border border-slate-800">
              <input
                type="checkbox"
                checked={config.batting.stackMilestones}
                onChange={(e) =>
                  setConfig((prev) => ({
                    ...prev,
                    batting: { ...prev.batting, stackMilestones: e.target.checked },
                  }))
                }
                className="rounded accent-amber-500"
              />
              <span className="text-slate-300">Stack 50 & 100 Run Bonuses</span>
            </label>

            <label className="flex items-center gap-1.5 bg-slate-950 p-2 rounded-lg border border-slate-800">
              <input
                type="checkbox"
                checked={config.bowling.stackHaulBonuses}
                onChange={(e) =>
                  setConfig((prev) => ({
                    ...prev,
                    bowling: { ...prev.bowling, stackHaulBonuses: e.target.checked },
                  }))
                }
                className="rounded accent-amber-500"
              />
              <span className="text-slate-300">Stack 3 & 5 Wicket Hauls</span>
            </label>
          </div>
          <p className="text-[10px] text-slate-400">
            * By default, milestone and haul bonuses are deduplicated in compliance with standard fantasy cricket rules.
          </p>
        </div>
      )}

      {/* Main Tab Views Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {/* =========================================================================
            TAB 1: RULES & GUIDELINES (Feature 1, 2, 3)
           ========================================================================= */}
        {activeTab === 'rules' && (
          <div className="space-y-4">
            {/* Search & Section Filter Pills */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search rules, captain multipliers, roles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5 text-[11px]">
                <button
                  onClick={() => setActiveRuleSection('all')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    activeRuleSection === 'all'
                      ? 'bg-slate-700 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setActiveRuleSection('player-selection')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    activeRuleSection === 'player-selection'
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  Player Selection
                </button>
                <button
                  onClick={() => setActiveRuleSection('captain-vice-captain')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    activeRuleSection === 'captain-vice-captain'
                      ? 'bg-amber-600 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  Captain (2x) & VC (1.5x)
                </button>
                <button
                  onClick={() => setActiveRuleSection('deduplication-policy')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    activeRuleSection === 'deduplication-policy'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-900 text-slate-400 hover:text-white'
                  }`}
                >
                  Fair Play & Anti-Duplication
                </button>
              </div>
            </div>

            {/* Render Rule Sections */}
            {filteredRuleSections.map((sec) => (
              <div
                key={sec.id}
                className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-[#0a101d] to-slate-950 border border-slate-800/90 shadow-md space-y-3"
              >
                <div className="flex items-start justify-between border-b border-slate-800/80 pb-2.5">
                  <div>
                    <h2 className="text-sm font-black text-white flex items-center gap-1.5">
                      <BookOpen className="w-4 h-4 text-amber-400" />
                      {sec.title}
                    </h2>
                    <p className="text-[11px] text-slate-400 mt-0.5">{sec.subtitle}</p>
                  </div>
                  {sec.badge && (
                    <span className="px-2 py-0.5 rounded-lg bg-amber-500/15 text-amber-300 font-mono font-black text-[9px] border border-amber-500/30 shrink-0">
                      {sec.badge}
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  {sec.items.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/70 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-200">{item.title}</span>
                        {item.points && (
                          <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-black text-[11px]">
                            {item.points}
                          </span>
                        )}
                        {item.badge && (
                          <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 text-[10px] font-bold">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 leading-relaxed">
                        {item.description}
                      </p>
                      {item.example && (
                        <div className="p-2 mt-1 rounded-lg bg-slate-900/90 text-amber-300/90 text-[10px] font-mono whitespace-pre-line border-l-2 border-amber-500">
                          {item.example}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}

            {/* CTA to Fantasy Team Creator */}
            {onNavigateToCreateTeam && (
              <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/50 via-slate-900 to-blue-900/30 border border-blue-500/40 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white block">Ready to pick your 11?</span>
                  <span className="text-[11px] text-slate-400">
                    Apply these rules and draft under 100 credits
                  </span>
                </div>
                <button
                  onClick={onNavigateToCreateTeam}
                  className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1 shadow-md shadow-blue-600/30"
                >
                  <span>Build Lineup</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
            TAB 2: DEMO POINTS TABLE (Features 4, 5, 6, 7, 8)
           ========================================================================= */}
        {activeTab === 'points-table' && (
          <div className="space-y-4">
            {/* Quick Summary Pill Box */}
            <div className="grid grid-cols-3 gap-2">
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-mono">BATTING RUN</span>
                <span className="text-base font-black text-amber-400 font-sports">+1 PT</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-mono">WICKET</span>
                <span className="text-base font-black text-amber-400 font-sports">+25 PTS</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-400 block font-mono">CATCH</span>
                <span className="text-base font-black text-amber-400 font-sports">+8 PTS</span>
              </div>
            </div>

            {/* 1. Batting Points (Feature 5) */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase font-mono text-amber-400 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" />
                  1. Batting Demo Points
                </h3>
                <span className="text-[10px] text-slate-400">Official Scoring</span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Run scored (off bat)</span>
                  <span className="font-black text-amber-300 font-mono">+1 pt</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Boundary Bonus (Four / 4)</span>
                  <span className="font-black text-emerald-400 font-mono">+1 bonus pt</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Six Bonus (Six / 6)</span>
                  <span className="font-black text-emerald-400 font-mono">+2 bonus pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <div>
                    <span className="text-slate-200 block">Half-Century (50-99 runs)</span>
                    <span className="text-[10px] text-slate-400">Awarded for reaching 50 runs</span>
                  </div>
                  <span className="font-black text-amber-400 font-mono">+8 bonus pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <div>
                    <span className="text-slate-200 block">Century (100+ runs)</span>
                    <span className="text-[10px] text-slate-400">Deduplicated: Replaces 50-run bonus</span>
                  </div>
                  <span className="font-black text-amber-400 font-mono">+16 bonus pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Dismissal for Duck (BAT, WK, AR)</span>
                  <span className="font-black text-rose-400 font-mono">-2 pts</span>
                </div>
              </div>
            </div>

            {/* 2. Bowling Points (Feature 6) */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase font-mono text-amber-400 flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5" />
                  2. Bowling Demo Points
                </h3>
                <span className="text-[10px] text-slate-400">Official Scoring</span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <div>
                    <span className="text-slate-200 block">Wicket (Excluding Run Out)</span>
                    <span className="text-[10px] text-slate-400">Bowled, Caught, LBW, Stumped, Hit Wkt</span>
                  </div>
                  <span className="font-black text-amber-300 font-mono">+25 pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Maiden Over (0 runs conceded)</span>
                  <span className="font-black text-amber-300 font-mono">+8 pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <div>
                    <span className="text-slate-200 block">3-Wicket Haul Bonus</span>
                    <span className="text-[10px] text-slate-400">Claiming 3 or 4 wickets</span>
                  </div>
                  <span className="font-black text-emerald-400 font-mono">+8 bonus pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <div>
                    <span className="text-slate-200 block">5-Wicket Haul Bonus</span>
                    <span className="text-[10px] text-slate-400">Deduplicated: Replaces 3-wicket bonus</span>
                  </div>
                  <span className="font-black text-emerald-400 font-mono">+16 bonus pts</span>
                </div>
              </div>
            </div>

            {/* 3. Fielding Points (Feature 7) */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase font-mono text-amber-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  3. Fielding Demo Points
                </h3>
                <span className="text-[10px] text-slate-400">Official Scoring</span>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Catch Taken</span>
                  <span className="font-black text-amber-300 font-mono">+8 pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Stumping (Wicketkeeper)</span>
                  <span className="font-black text-amber-300 font-mono">+12 pts</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <div>
                    <span className="text-slate-200 block">Run Out Dismissal</span>
                    <span className="text-[10px] text-slate-400">Direct hit or catcher/thrower combo</span>
                  </div>
                  <span className="font-black text-amber-300 font-mono">+6 pts</span>
                </div>
              </div>
            </div>

            {/* 4. Multipliers & Starting XI (Features 3 & 8) */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase font-mono text-amber-400 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  4. Multipliers & Starting XI Points
                </h3>
              </div>

              <div className="space-y-1.5 text-xs">
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-amber-300 block">Captain (C)</span>
                    <span className="text-[10px] text-slate-400">Doubles all base demo points earned</span>
                  </div>
                  <span className="font-black text-amber-300 text-sm font-mono">2.0x Multiplier</span>
                </div>

                <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-blue-300 block">Vice-Captain (VC)</span>
                    <span className="text-[10px] text-slate-400">Adds 50% bonus to base points earned</span>
                  </div>
                  <span className="font-black text-blue-300 text-sm font-mono">1.5x Multiplier</span>
                </div>

                <div className="p-2 rounded-xl bg-slate-950 flex items-center justify-between">
                  <span className="text-slate-200">Playing XI Starting Announcement</span>
                  <span className="font-black text-amber-300 font-mono">+4 pts</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 3: PLAYER POINTS CALCULATOR / PERFORMANCE DETAILS (Feature 10)
           ========================================================================= */}
        {activeTab === 'player-calculator' && (
          <div className="space-y-4">
            {/* Presets Bar */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-slate-400 block">
                Load Star Player Performance Preset:
              </label>
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
                {SIMULATOR_PRESET_PLAYERS.map((preset, idx) => (
                  <button
                    key={preset.name}
                    onClick={() => handleSelectPreset(idx)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                      selectedPresetIdx === idx
                        ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                        : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    <span>{preset.name}</span>
                    <span className="text-[9px] px-1 py-0.2 rounded bg-black/20 font-mono">
                      {preset.team} • {preset.role}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Multiplier Selector Pill */}
            <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">Assign Role Multiplier:</span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setSelectedRoleMultiplier('captain')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-black transition-all ${
                    selectedRoleMultiplier === 'captain'
                      ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  C (2.0x)
                </button>
                <button
                  onClick={() => setSelectedRoleMultiplier('viceCaptain')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-black transition-all ${
                    selectedRoleMultiplier === 'viceCaptain'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  VC (1.5x)
                </button>
                <button
                  onClick={() => setSelectedRoleMultiplier('none')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                    selectedRoleMultiplier === 'none'
                      ? 'bg-slate-700 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  Standard (1.0x)
                </button>
              </div>
            </div>

            {/* Interactive Stat Sliders / Modifiers */}
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-xs font-black uppercase tracking-wider text-amber-400 font-mono">
                  Live Stat Inputs: {customStats.playerName || 'Player'}
                </h3>
                <span className="text-[10px] text-slate-400">Modify stats to simulate</span>
              </div>

              {/* Batting Inputs */}
              <div className="grid grid-cols-3 gap-2">
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Runs Scored</span>
                  <input
                    type="number"
                    min="0"
                    max="300"
                    value={customStats.runs || 0}
                    onChange={(e) => handleUpdateStat('runs', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Fours (4s)</span>
                  <input
                    type="number"
                    min="0"
                    max="30"
                    value={customStats.fours || 0}
                    onChange={(e) => handleUpdateStat('fours', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Sixes (6s)</span>
                  <input
                    type="number"
                    min="0"
                    max="20"
                    value={customStats.sixes || 0}
                    onChange={(e) => handleUpdateStat('sixes', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
              </div>

              {/* Bowling Inputs */}
              <div className="grid grid-cols-2 gap-2">
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Wickets Taken (+25)</span>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    value={customStats.wickets || 0}
                    onChange={(e) => handleUpdateStat('wickets', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Maidens Bowled (+8)</span>
                  <input
                    type="number"
                    min="0"
                    max="4"
                    value={customStats.maidens || 0}
                    onChange={(e) => handleUpdateStat('maidens', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
              </div>

              {/* Fielding Inputs */}
              <div className="grid grid-cols-3 gap-2">
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Catches (+8)</span>
                  <input
                    type="number"
                    min="0"
                    max="6"
                    value={customStats.catches || 0}
                    onChange={(e) => handleUpdateStat('catches', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Stumpings (+12)</span>
                  <input
                    type="number"
                    min="0"
                    max="5"
                    value={customStats.stumpings || 0}
                    onChange={(e) => handleUpdateStat('stumpings', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 block">Run Outs (+6)</span>
                  <input
                    type="number"
                    min="0"
                    max="4"
                    value={customStats.runOuts || 0}
                    onChange={(e) => handleUpdateStat('runOuts', e.target.value)}
                    className="w-full bg-transparent text-white font-bold text-sm focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Calculated Result Card with Full Breakdown */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#0c1628] via-slate-900 to-[#0e172a] border border-amber-500/40 shadow-xl space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-bold text-white">
                      {playerCalcResult.playerName}
                    </span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono font-bold">
                      {selectedRoleMultiplier === 'captain'
                        ? 'CAPTAIN (2x)'
                        : selectedRoleMultiplier === 'viceCaptain'
                        ? 'VICE-CAPTAIN (1.5x)'
                        : 'STANDARD (1x)'}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Base Points: {playerCalcResult.basePoints} pts • Multiplier: {playerCalcResult.multiplier}x
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block font-mono">TOTAL DEMO POINTS</span>
                  <span className="text-2xl font-sports font-black text-amber-400">
                    {playerCalcResult.totalDemoPoints}
                  </span>
                </div>
              </div>

              {/* Deduplication Notices (if applicable) */}
              {playerCalcResult.deduplicationNotes.length > 0 && (
                <div className="p-2 rounded-xl bg-blue-950/40 border border-blue-500/30 text-[11px] text-blue-300 space-y-0.5">
                  <div className="flex items-center gap-1 font-bold text-blue-200">
                    <Info className="w-3.5 h-3.5 text-blue-400" />
                    <span>Anti-Duplication Protection:</span>
                  </div>
                  {playerCalcResult.deduplicationNotes.map((note, nIdx) => (
                    <p key={nIdx} className="text-[10px] text-blue-300/90 pl-4">
                      • {note}
                    </p>
                  ))}
                </div>
              )}

              {/* Itemized Line Items */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">
                  Detailed Itemized Calculation:
                </span>

                {playerCalcResult.lineItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-2 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-white">{item.label}</span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 font-mono">
                          {item.category}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        {item.count} count × ({item.rate})
                      </span>
                    </div>

                    <span
                      className={`font-mono font-black ${
                        item.points < 0 ? 'text-rose-400' : 'text-amber-400'
                      }`}
                    >
                      {item.points > 0 ? `+${item.points}` : item.points} pts
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TAB 4: TOTAL TEAM POINTS CALCULATOR & SQUAD BREAKDOWN (Feature 9)
           ========================================================================= */}
        {activeTab === 'team-points' && (
          <div className="space-y-4">
            {/* Explanatory Formula Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-950 border border-amber-500/30 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                <TrendingUp className="w-4 h-4" />
                <span>Total Team Points Formula:</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200">
                Team Total = Sum of All 11 Base Points + (Captain Base × 1.0) + (Vice-Captain Base × 0.5)
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Captain earns an extra +100% (+1.0x) and Vice-Captain earns an extra +50% (+0.5x) on top of their base score.
              </p>
            </div>

            {/* Team Captain & VC Selectors */}
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
              <span className="text-xs font-bold text-white block">
                Assign Leadership for Sample 11-Player Lineup:
              </span>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-[10px] text-amber-400 font-bold block mb-1">
                    Captain (2.0x Pts):
                  </label>
                  <select
                    value={teamCaptainId}
                    onChange={(e) => setTeamCaptainId(e.target.value)}
                    className="w-full p-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs font-bold focus:outline-none focus:border-amber-500"
                  >
                    {sampleMatchPlayers.map((p) => (
                      <option key={p.id} value={p.id} disabled={p.id === teamViceCaptainId}>
                        {p.name} ({p.role} • {p.points} pts)
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-blue-400 font-bold block mb-1">
                    Vice-Captain (1.5x Pts):
                  </label>
                  <select
                    value={teamViceCaptainId}
                    onChange={(e) => setTeamViceCaptainId(e.target.value)}
                    className="w-full p-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs font-bold focus:outline-none focus:border-blue-500"
                  >
                    {sampleMatchPlayers.map((p) => (
                      <option key={p.id} value={p.id} disabled={p.id === teamCaptainId}>
                        {p.name} ({p.role} • {p.points} pts)
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Team Score Summary Display */}
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-950/40 via-slate-900 to-slate-950 border border-blue-500/40 shadow-xl space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
                <div>
                  <span className="text-xs font-bold text-slate-300 block">
                    Squad Demo Score (11 Players)
                  </span>
                  <span className="text-[10px] text-slate-400">
                    WK: {teamCalcResult.roleCounts.wk} | BAT: {teamCalcResult.roleCounts.bat} | AR:{' '}
                    {teamCalcResult.roleCounts.ar} | BOWL: {teamCalcResult.roleCounts.bowl}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block font-mono">TOTAL TEAM POINTS</span>
                  <span className="text-2xl font-sports font-black text-amber-400">
                    {teamCalcResult.teamTotalPoints.toFixed(1)}
                  </span>
                </div>
              </div>

              {/* Breakdown metrics */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block">Base 11 Total</span>
                  <span className="font-bold text-slate-200">
                    {teamCalcResult.totalBasePoints.toFixed(1)}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] text-amber-400 block">Captain (2x)</span>
                  <span className="font-bold text-amber-400">
                    +{teamCalcResult.totalCaptainBonus.toFixed(1)}
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] text-blue-400 block">Vice-Cap (1.5x)</span>
                  <span className="font-bold text-blue-400">
                    +{teamCalcResult.totalViceCaptainBonus.toFixed(1)}
                  </span>
                </div>
              </div>

              {/* 11 Players Points Roster */}
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block font-mono">
                  Squad Points Roster:
                </span>
                {teamCalcResult.playerResults.map((pr) => (
                  <div
                    key={pr.playerName}
                    className={`p-2 rounded-xl border flex items-center justify-between text-xs ${
                      pr.multiplierType === 'captain'
                        ? 'bg-amber-500/10 border-amber-500/40'
                        : pr.multiplierType === 'viceCaptain'
                        ? 'bg-blue-500/10 border-blue-500/40'
                        : 'bg-slate-950/70 border-slate-800/80'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-5 h-5 rounded-md flex items-center justify-center font-bold text-[9px] ${
                          pr.multiplierType === 'captain'
                            ? 'bg-amber-500 text-slate-950'
                            : pr.multiplierType === 'viceCaptain'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {pr.multiplierType === 'captain'
                          ? 'C'
                          : pr.multiplierType === 'viceCaptain'
                          ? 'VC'
                          : pr.role}
                      </span>
                      <div>
                        <span className="font-bold text-white block">{pr.playerName}</span>
                        <span className="text-[10px] text-slate-400">
                          Base: {pr.basePoints} pts {pr.multiplier > 1 && `(×${pr.multiplier})`}
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-bold font-mono text-amber-400 text-xs">
                        {pr.totalDemoPoints} PTS
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 5. Footer with Quick Nav */}
      <footer className="p-3 bg-slate-900/95 border-t border-slate-800 flex items-center justify-between shrink-0">
        <div className="text-[11px] text-slate-400">
          Official KhelMitra Demo Rules v2.4
        </div>

        <div className="flex items-center gap-2">
          {onNavigateToCreateTeam && (
            <button
              onClick={onNavigateToCreateTeam}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 active:scale-95 transition-all"
            >
              Draft Lineup
            </button>
          )}

          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs active:scale-95 transition-all"
          >
            Close Rules
          </button>
        </div>
      </footer>
    </div>
  );
}
