import { useState } from 'react';
import { X, Shield, Award, Sparkles } from 'lucide-react';
import { FantasyPlayer } from '../../types';
import PlayerDetailsModal from '../player/PlayerDetailsModal';

interface TeamPitchPreviewProps {
  teamName?: string;
  matchTitle?: string;
  players: FantasyPlayer[];
  captainId?: string | null;
  viceCaptainId?: string | null;
  onClose: () => void;
}

export default function TeamPitchPreview({
  teamName = 'Team Preview',
  matchTitle = 'Match Preview',
  players,
  captainId,
  viceCaptainId,
  onClose,
}: TeamPitchPreviewProps) {
  const [selectedPlayer, setSelectedPlayer] = useState<FantasyPlayer | null>(null);

  // Group players by role
  const wicketKeepers = players.filter((p) => p.role === 'WK');
  const batters = players.filter((p) => p.role === 'BAT');
  const allRounders = players.filter((p) => p.role === 'AR');
  const bowlers = players.filter((p) => p.role === 'BOWL');

  // Calculate team distribution
  const team1ShortName = players[0]?.teamShortName || 'Team 1';
  const team1Count = players.filter((p) => p.teamShortName === team1ShortName).length;
  const team2ShortName = players.find((p) => p.teamShortName !== team1ShortName)?.teamShortName || 'Team 2';
  const team2Count = players.filter((p) => p.teamShortName === team2ShortName).length;
  const totalCredits = players.reduce((sum, p) => sum + p.credits, 0);

  const renderPlayer = (player: FantasyPlayer) => {
    const isCap = captainId === player.id || player.isCaptain;
    const isVc = viceCaptainId === player.id || player.isViceCaptain;

    return (
      <div
        key={player.id}
        onClick={() => setSelectedPlayer(player)}
        className="flex flex-col items-center group transition-transform active:scale-95 cursor-pointer"
        title={`View stats for ${player.name}`}
      >
        {/* Player Badge / Jersey */}
        <div className="relative flex items-center justify-center">
          {/* Captain / Vice-Captain Badge floating on top */}
          {isCap && (
            <span className="absolute -top-2.5 -right-2 z-10 px-1.5 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black border border-white shadow-md flex items-center gap-0.5">
              <Award className="w-2.5 h-2.5" />
              C
            </span>
          )}
          {isVc && (
            <span className="absolute -top-2.5 -right-2 z-10 px-1.5 py-0.5 rounded-full bg-slate-200 text-slate-950 text-[10px] font-black border border-white shadow-md flex items-center gap-0.5">
              VC
            </span>
          )}

          {/* Jersey Shape / Circle */}
          <div
            className={`w-11 h-11 rounded-2xl flex flex-col items-center justify-center shadow-lg border-2 transition-all ${
              isCap
                ? 'bg-gradient-to-br from-amber-500 to-yellow-600 border-amber-300 shadow-amber-500/30'
                : isVc
                ? 'bg-gradient-to-br from-slate-300 to-slate-400 border-slate-100 text-slate-950'
                : 'bg-gradient-to-br from-slate-900 via-[#131d33] to-slate-950 border-slate-700/80 text-white'
            }`}
          >
            <Shield
              className={`w-5 h-5 ${
                isCap ? 'text-slate-950 fill-slate-950' : isVc ? 'text-slate-900 fill-slate-900' : 'text-slate-300'
              }`}
            />
          </div>
        </div>

        {/* Name pill */}
        <div className="mt-1 flex flex-col items-center">
          <span className="px-2 py-0.5 rounded-md bg-slate-950/90 text-white text-[11px] font-bold tracking-tight shadow-md border border-slate-800/80 truncate max-w-[84px] text-center">
            {player.name.split(' ').slice(-1)[0]}
          </span>
          <span className="text-[10px] font-medium text-emerald-300 bg-black/60 px-1.5 rounded mt-0.5">
            {player.teamShortName} • {player.credits} Cr
          </span>
        </div>
      </div>
    );
  };

  return (
    <div
      id="pitch-preview-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        id="pitch-preview-modal-dialog"
        className="w-full max-w-md h-[92vh] max-h-[850px] bg-[#070c16] border border-slate-700/90 rounded-3xl flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top App Bar */}
        <div className="p-3.5 bg-gradient-to-r from-slate-950 via-[#0a1120] to-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-black text-white">{teamName}</span>
              <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold">
                PITCH VIEW
              </span>
            </div>
            <span className="text-[11px] text-slate-400 block">{matchTitle}</span>
          </div>

          <button
            id="close-pitch-preview-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stadium Grass Pitch Viewport */}
        <div className="flex-1 relative overflow-hidden bg-gradient-to-b from-[#113a21] via-[#0d2e1a] to-[#081e11] p-3 flex flex-col justify-between select-none">
          {/* Pitch markings: center pitch strip */}
          <div className="absolute inset-x-12 inset-y-6 border border-white/10 rounded-[60px] pointer-events-none"></div>
          <div className="absolute left-1/2 -translate-x-1/2 top-10 bottom-10 w-24 bg-gradient-to-b from-[#244326]/60 via-[#2f5532]/40 to-[#244326]/60 border-x border-dashed border-white/15 pointer-events-none flex flex-col justify-between py-6">
            {/* Bowling Crease 1 */}
            <div className="w-full h-0.5 bg-white/30"></div>
            {/* Center Turf Circle */}
            <div className="w-12 h-12 mx-auto rounded-full border border-white/20"></div>
            {/* Bowling Crease 2 */}
            <div className="w-full h-0.5 bg-white/30"></div>
          </div>

          {/* Row 1: WICKET-KEEPERS */}
          <div className="relative z-10 py-1 flex flex-col items-center">
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-200/60 font-mono mb-1">
              Wicket-Keepers ({wicketKeepers.length})
            </span>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              {wicketKeepers.length > 0 ? (
                wicketKeepers.map(renderPlayer)
              ) : (
                <span className="text-[11px] text-emerald-300/40 italic">No WK selected</span>
              )}
            </div>
          </div>

          {/* Row 2: BATTERS */}
          <div className="relative z-10 py-1 flex flex-col items-center">
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-200/60 font-mono mb-1">
              Batters ({batters.length})
            </span>
            <div className="flex items-center justify-center gap-3 flex-wrap">
              {batters.length > 0 ? (
                batters.map(renderPlayer)
              ) : (
                <span className="text-[11px] text-emerald-300/40 italic">No Batters selected</span>
              )}
            </div>
          </div>

          {/* Row 3: ALL-ROUNDERS */}
          <div className="relative z-10 py-1 flex flex-col items-center">
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-200/60 font-mono mb-1">
              All-Rounders ({allRounders.length})
            </span>
            <div className="flex items-center justify-center gap-3 flex-wrap">
              {allRounders.length > 0 ? (
                allRounders.map(renderPlayer)
              ) : (
                <span className="text-[11px] text-emerald-300/40 italic">No All-Rounders selected</span>
              )}
            </div>
          </div>

          {/* Row 4: BOWLERS */}
          <div className="relative z-10 py-1 flex flex-col items-center">
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-200/60 font-mono mb-1">
              Bowlers ({bowlers.length})
            </span>
            <div className="flex items-center justify-center gap-3 flex-wrap">
              {bowlers.length > 0 ? (
                bowlers.map(renderPlayer)
              ) : (
                <span className="text-[11px] text-emerald-300/40 italic">No Bowlers selected</span>
              )}
            </div>
          </div>
        </div>

        {/* Bottom HUD: Team distribution & summary */}
        <div className="p-3 bg-[#0a101d] border-t border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <div className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
              <span className="font-bold text-white">{team1ShortName}:</span> {team1Count}
            </div>
            <div className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
              <span className="font-bold text-white">{team2ShortName}:</span> {team2Count}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block leading-none">Credits</span>
              <span className="text-xs font-mono font-bold text-amber-400">
                {Math.round(totalCredits * 10) / 10} / 100
              </span>
            </div>

            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
            >
              Close
            </button>
          </div>
        </div>
      </div>

      {/* Player Details Modal from Pitch Preview */}
      {selectedPlayer && (
        <PlayerDetailsModal
          isOpen={!!selectedPlayer}
          onClose={() => setSelectedPlayer(null)}
          playerId={selectedPlayer.id}
          playerName={selectedPlayer.name}
          isSelected={true}
          canSelect={true}
        />
      )}
    </div>
  );
}
