import React, { useState, useEffect } from 'react';
import { 
  Bell, X, CheckCheck, Trash2, Radio, Trophy, Gift, 
  Gamepad2, Headphones, UserPlus, Sparkles, ChevronRight, 
  RefreshCw, Check, Zap, ExternalLink 
} from 'lucide-react';
import { 
  notificationService, 
  AppNotification, 
  NotificationCategory 
} from '../../services/notificationService';
import { ActiveSheetType } from '../../types';
import { audioEffectsService } from '../../services/audioEffectsService';

interface NotificationCenterModalProps {
  onClose: () => void;
  onSwitchSheet: (sheet: ActiveSheetType) => void;
}

type TabType = 'all' | NotificationCategory;

export default function NotificationCenterModal({ 
  onClose, 
  onSwitchSheet 
}: NotificationCenterModalProps) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [activeTab, setActiveTab] = useState<TabType>('all');
  const [simulating, setSimulating] = useState(false);

  useEffect(() => {
    const unsub = notificationService.subscribe(setNotifications);
    return () => unsub();
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const filteredNotifications = notifications.filter(n => {
    if (activeTab === 'all') return true;
    return n.category === activeTab;
  });

  const handleNotificationClick = (notif: AppNotification) => {
    audioEffectsService.playClick();
    notificationService.markAsRead(notif.id);
    if (notif.actionSheet) {
      onClose();
      onSwitchSheet(notif.actionSheet);
    }
  };

  const handleMarkAllRead = () => {
    audioEffectsService.playClick();
    notificationService.markAllAsRead();
  };

  const handleClearAll = () => {
    audioEffectsService.playClick();
    notificationService.clearAll();
  };

  const handleSimulateAlert = (type: 'cricket' | 'reward' | 'mission' | 'referral') => {
    audioEffectsService.playWin();
    setSimulating(true);
    notificationService.triggerSimulatedNotification(type);
    setTimeout(() => setSimulating(false), 500);
  };

  const getCategoryIcon = (category: NotificationCategory) => {
    switch (category) {
      case 'cricket':
        return <Radio className="w-4 h-4 text-rose-400" />;
      case 'missions':
        return <Trophy className="w-4 h-4 text-amber-400" />;
      case 'rewards':
        return <Gift className="w-4 h-4 text-emerald-400" />;
      case 'games':
        return <Gamepad2 className="w-4 h-4 text-purple-400" />;
      case 'support':
        return <Headphones className="w-4 h-4 text-blue-400" />;
      case 'referral':
        return <UserPlus className="w-4 h-4 text-amber-400" />;
      default:
        return <Bell className="w-4 h-4 text-slate-400" />;
    }
  };

  const getCategoryBadge = (category: NotificationCategory) => {
    switch (category) {
      case 'cricket':
        return { label: 'Live Cricket', bg: 'bg-rose-500/20 text-rose-300 border-rose-500/30' };
      case 'missions':
        return { label: 'Daily Mission', bg: 'bg-amber-500/20 text-amber-300 border-amber-500/30' };
      case 'rewards':
        return { label: 'Rewards', bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' };
      case 'games':
        return { label: 'Game Update', bg: 'bg-purple-500/20 text-purple-300 border-purple-500/30' };
      case 'support':
        return { label: 'Customer Care', bg: 'bg-blue-500/20 text-blue-300 border-blue-500/30' };
      case 'referral':
        return { label: 'Invite Friends', bg: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' };
    }
  };

  return (
    <div 
      id="notification-center-modal-overlay" 
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="notification-center-modal-content"
        className="w-full max-w-md max-h-[92vh] bg-[#070b14] border border-slate-800 rounded-t-3xl sm:rounded-3xl flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300 text-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 bg-[#0a1020] border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="relative w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-red-500 text-white text-[10px] font-extrabold flex items-center justify-center border-2 border-[#0a1020] animate-pulse">
                  {unreadCount}
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black tracking-wide text-white font-mono">
                  Notification Center
                </h3>
                {unreadCount > 0 && (
                  <span className="px-1.5 py-0.2 rounded-md bg-red-500/20 text-red-400 text-[10px] font-bold border border-red-500/30">
                    {unreadCount} New
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">Missions, Cricket, Games, Rewards & Care</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {unreadCount > 0 && (
              <button
                id="mark-all-read-btn"
                onClick={handleMarkAllRead}
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-emerald-400 hover:border-emerald-500/40 transition-all active:scale-95 text-xs flex items-center gap-1"
                title="Mark all as read"
              >
                <CheckCheck className="w-4 h-4" />
              </button>
            )}
            <button
              id="close-notifications-btn"
              onClick={() => {
                audioEffectsService.playClick();
                onClose();
              }}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all active:scale-95"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Category Filter Chips Bar */}
        <div className="px-3 py-2 bg-[#080d1a] border-b border-slate-800/80 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0 text-xs">
          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('all');
            }}
            className={`px-3 py-1.5 rounded-full whitespace-nowrap font-bold transition-all text-[11px] ${
              activeTab === 'all'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All ({notifications.length})
          </button>

          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('cricket');
            }}
            className={`px-2.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all text-[11px] flex items-center gap-1 ${
              activeTab === 'cricket'
                ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-rose-300 border border-slate-800'
            }`}
          >
            <Radio className="w-3 h-3 text-rose-400" />
            <span>Cricket</span>
          </button>

          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('missions');
            }}
            className={`px-2.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all text-[11px] flex items-center gap-1 ${
              activeTab === 'missions'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-amber-300 border border-slate-800'
            }`}
          >
            <Trophy className="w-3 h-3 text-amber-400" />
            <span>Missions</span>
          </button>

          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('rewards');
            }}
            className={`px-2.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all text-[11px] flex items-center gap-1 ${
              activeTab === 'rewards'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-emerald-300 border border-slate-800'
            }`}
          >
            <Gift className="w-3 h-3 text-emerald-400" />
            <span>Rewards</span>
          </button>

          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('games');
            }}
            className={`px-2.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all text-[11px] flex items-center gap-1 ${
              activeTab === 'games'
                ? 'bg-purple-500 text-white shadow-md shadow-purple-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-purple-300 border border-slate-800'
            }`}
          >
            <Gamepad2 className="w-3 h-3 text-purple-400" />
            <span>Games</span>
          </button>

          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('support');
            }}
            className={`px-2.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all text-[11px] flex items-center gap-1 ${
              activeTab === 'support'
                ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-blue-300 border border-slate-800'
            }`}
          >
            <Headphones className="w-3 h-3 text-blue-400" />
            <span>Support</span>
          </button>

          <button
            onClick={() => {
              audioEffectsService.playClick();
              setActiveTab('referral');
            }}
            className={`px-2.5 py-1.5 rounded-full whitespace-nowrap font-bold transition-all text-[11px] flex items-center gap-1 ${
              activeTab === 'referral'
                ? 'bg-yellow-500 text-slate-950 shadow-md shadow-yellow-500/20'
                : 'bg-slate-900 text-slate-400 hover:text-yellow-300 border border-slate-800'
            }`}
          >
            <UserPlus className="w-3 h-3 text-yellow-400" />
            <span>Invites</span>
          </button>
        </div>

        {/* Notifications List Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {filteredNotifications.length === 0 ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500">
                <Bell className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">No notifications here</p>
                <p className="text-xs text-slate-400 mt-0.5">
                  You're all caught up in this category.
                </p>
              </div>
              <button
                onClick={() => notificationService.resetToDefault()}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-all active:scale-95"
              >
                Restore Default Alerts
              </button>
            </div>
          ) : (
            filteredNotifications.map((notif) => {
              const badge = getCategoryBadge(notif.category);
              return (
                <div
                  key={notif.id}
                  onClick={() => handleNotificationClick(notif)}
                  className={`relative p-3.5 rounded-2xl border transition-all cursor-pointer active:scale-[0.99] group ${
                    notif.read
                      ? 'bg-slate-900/60 border-slate-800/80 hover:border-slate-700'
                      : 'bg-gradient-to-r from-slate-900 via-[#0a1020] to-slate-900 border-amber-500/40 hover:border-amber-400 shadow-md shadow-amber-950/20'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Category Icon */}
                    <div className="w-9 h-9 rounded-xl bg-slate-800/80 border border-slate-700/60 flex items-center justify-center shrink-0 mt-0.5 group-hover:scale-105 transition-transform">
                      {getCategoryIcon(notif.category)}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded border ${badge.bg}`}>
                            {badge.label}
                          </span>
                          {!notif.read && (
                            <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0 animate-ping"></span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 whitespace-nowrap font-mono">
                          {notif.timeAgo}
                        </span>
                      </div>

                      <h4 className={`text-xs font-bold leading-tight ${notif.read ? 'text-slate-200' : 'text-white'}`}>
                        {notif.title}
                      </h4>

                      <p className="text-[11px] text-slate-300 leading-relaxed line-clamp-2">
                        {notif.message}
                      </p>

                      {/* Action Button Link */}
                      {notif.actionLabel && (
                        <div className="pt-1 flex items-center justify-between">
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400 group-hover:text-amber-300 group-hover:underline">
                            <span>{notif.actionLabel}</span>
                            <ChevronRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                          </span>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              audioEffectsService.playClick();
                              notificationService.removeNotification(notif.id);
                            }}
                            className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors opacity-60 group-hover:opacity-100"
                            title="Dismiss notification"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}

          {/* Quick Simulation Bar for Testing Live Updates */}
          <div className="mt-4 p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-400" />
                <span>Test Live Notification Feed</span>
              </span>
              <span className="text-[9px] text-emerald-400 font-mono">Real-time simulator</span>
            </div>

            <div className="grid grid-cols-2 gap-1.5 text-[10px]">
              <button
                onClick={() => handleSimulateAlert('cricket')}
                className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-rose-300 font-bold flex items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <span>🏏 + Cricket Alert</span>
              </button>
              <button
                onClick={() => handleSimulateAlert('mission')}
                className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-amber-300 font-bold flex items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <span>🎯 + Mission Alert</span>
              </button>
              <button
                onClick={() => handleSimulateAlert('reward')}
                className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-emerald-300 font-bold flex items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <span>🎡 + Reward Alert</span>
              </button>
              <button
                onClick={() => handleSimulateAlert('referral')}
                className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-yellow-300 font-bold flex items-center justify-center gap-1 active:scale-95 transition-all"
              >
                <span>🎁 + Referral Alert</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-4 py-3 bg-[#0a1020] border-t border-slate-800 flex items-center justify-between shrink-0">
          <button
            onClick={handleClearAll}
            disabled={notifications.length === 0}
            className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 transition-colors disabled:opacity-40"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>

          <button
            onClick={() => {
              audioEffectsService.playClick();
              onClose();
            }}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs active:scale-95 transition-all"
          >
            Back to App
          </button>
        </div>
      </div>
    </div>
  );
}
