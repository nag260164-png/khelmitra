import { useState, useEffect } from 'react';
import { 
  X, UserPlus, Gift, Copy, Check, Share2, 
  MessageCircle, Send, Users, Sparkles, Award, 
  CheckCircle2, ArrowRight 
} from 'lucide-react';
import { referralService, ReferredFriend, ReferralStats } from '../../services/referralService';
import { demoPointsService } from '../../services/demoPointsService';
import { audioEffectsService } from '../../services/audioEffectsService';

interface InviteFriendsModalProps {
  onClose: () => void;
}

export default function InviteFriendsModal({ onClose }: InviteFriendsModalProps) {
  const [stats, setStats] = useState<ReferralStats>(referralService.getStats());
  const [friendsList, setFriendsList] = useState<ReferredFriend[]>(referralService.getFriends());
  const [userCoins, setUserCoins] = useState(demoPointsService.getPoints());

  // Copy states
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Redeem Friend's Code state
  const [inputFriendCode, setInputFriendCode] = useState('');
  const [redeemFeedback, setRedeemFeedback] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    const unsubRef = referralService.subscribe(() => {
      setStats(referralService.getStats());
      setFriendsList(referralService.getFriends());
    });
    const unsubCoins = demoPointsService.subscribe(setUserCoins);
    return () => {
      unsubRef();
      unsubCoins();
    };
  }, []);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(stats.userCode);
    setCopiedCode(true);
    audioEffectsService.playClick();
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralService.getShareUrl());
    setCopiedLink(true);
    audioEffectsService.playClick();
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleNativeShare = async () => {
    audioEffectsService.playClick();
    const shareData = {
      title: 'Join me on KhelMitra Gaming!',
      text: referralService.getShareMessage(),
      url: referralService.getShareUrl(),
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        // User dismissed share dialog
      }
    } else {
      handleCopyLink();
    }
  };

  const handleWhatsAppShare = () => {
    audioEffectsService.playClick();
    const text = encodeURIComponent(referralService.getShareMessage());
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleTelegramShare = () => {
    audioEffectsService.playClick();
    const url = encodeURIComponent(referralService.getShareUrl());
    const text = encodeURIComponent(referralService.getShareMessage());
    window.open(`https://t.me/share/url?url=${url}&text=${text}`, '_blank');
  };

  const handleRedeemCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputFriendCode.trim()) return;

    const res = referralService.redeemCode(inputFriendCode);
    setRedeemFeedback(res);
    if (res.success) {
      audioEffectsService.playWin();
      setInputFriendCode('');
    } else {
      audioEffectsService.playError();
    }
  };

  const handleSimulateInvite = () => {
    audioEffectsService.playWin();
    referralService.simulateNewFriendJoin();
  };

  return (
    <div
      id="invite-friends-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md"
    >
      <div className="relative w-full max-w-lg max-h-[92vh] bg-slate-900 border border-slate-700/80 rounded-3xl flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-amber-950/80 via-slate-900 to-orange-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center shadow-inner">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white tracking-wide">Invite Friends & Earn</h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold">
                  +1,000 Coins / Friend
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Share your referral link for free virtual coins</p>
            </div>
          </div>
          <button
            id="close-invite-friends-btn"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Invited Friends
              </span>
              <span className="text-lg font-black text-white font-mono mt-0.5 block">
                {stats.totalInvited}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-950 border border-amber-500/30 text-center bg-gradient-to-b from-amber-500/10 to-transparent">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block">
                Coins Earned
              </span>
              <span className="text-lg font-black text-amber-300 font-mono mt-0.5 block">
                +{stats.totalCoinsEarned.toLocaleString()}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-center">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                Wallet Balance
              </span>
              <span className="text-lg font-black text-emerald-400 font-mono mt-0.5 block">
                {userCoins.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Referral Code Card */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-950/60 via-slate-900 to-amber-950/40 border border-amber-500/40 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Your Unique Referral Code
              </span>
              <span className="text-[10px] text-slate-400">Share anywhere</span>
            </div>

            {/* Code Box */}
            <div className="p-3 rounded-xl bg-slate-950 border border-amber-500/30 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-base font-mono font-black text-white tracking-widest">
                  {stats.userCode}
                </span>
              </div>
              <button
                id="copy-referral-code-btn"
                onClick={handleCopyCode}
                className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black flex items-center gap-1.5 active:scale-95 transition-all shadow"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-slate-950" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Social Share Buttons */}
            <div className="grid grid-cols-3 gap-2 pt-1">
              <button
                id="share-whatsapp-btn"
                onClick={handleWhatsAppShare}
                className="py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-md"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>

              <button
                id="share-telegram-btn"
                onClick={handleTelegramShare}
                className="py-2.5 px-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-md"
              >
                <Send className="w-4 h-4" />
                <span>Telegram</span>
              </button>

              <button
                id="share-native-btn"
                onClick={handleNativeShare}
                className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all border border-slate-700 shadow-md"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                <span>{copiedLink ? 'Copied' : 'Share Link'}</span>
              </button>
            </div>
          </div>

          {/* How Referral Rewards Work */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/90 space-y-2.5">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-amber-400" />
              How Referral Rewards Work
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-amber-400 font-bold block">YOU RECEIVE</span>
                <span className="text-sm font-black text-white mt-0.5 block">+1,000 Coins</span>
                <span className="text-[10px] text-slate-400">Credited instantly when friend signs up</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-emerald-400 font-bold block">FRIEND RECEIVES</span>
                <span className="text-sm font-black text-white mt-0.5 block">+500 Coins</span>
                <span className="text-[10px] text-slate-400">Welcome gift on entering your code</span>
              </div>
            </div>

            {/* Milestones */}
            <div className="p-2.5 rounded-xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-purple-950/30 border border-purple-500/20 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-purple-400" />
                <span className="text-slate-300 font-medium">Milestone Bonus: Reach 5 Invites</span>
              </div>
              <span className="font-bold text-purple-300">+5,000 Bonus</span>
            </div>
          </div>

          {/* Have a Friend's Code? Redeem here */}
          <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2.5">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              Have a Friend&apos;s Referral Code?
            </span>

            {stats.hasRedeemedBonus ? (
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>You redeemed code <strong className="font-mono">{stats.redeemedCode}</strong> and received 500 Free Coins!</span>
              </div>
            ) : (
              <form onSubmit={handleRedeemCode} className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="e.g. KHELM-ROHIT99"
                  value={inputFriendCode}
                  onChange={(e) => setInputFriendCode(e.target.value.toUpperCase())}
                  className="flex-1 px-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded-xl text-white font-mono placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <button
                  id="redeem-friend-code-btn"
                  type="submit"
                  className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs active:scale-95 transition-all shadow"
                >
                  Claim 500
                </button>
              </form>
            )}

            {redeemFeedback && (
              <p
                className={`text-[11px] font-medium ${
                  redeemFeedback.success ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {redeemFeedback.message}
              </p>
            )}
          </div>

          {/* Referral History List */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Users className="w-4 h-4 text-blue-400" />
                Referred Friends ({friendsList.length})
              </span>
              <button
                onClick={handleSimulateInvite}
                className="text-[10px] text-amber-400 font-bold hover:underline flex items-center gap-1"
              >
                <span>+ Simulate New Friend</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-1.5">
              {friendsList.map((friend) => (
                <div
                  key={friend.id}
                  className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <img
                      src={friend.avatar}
                      alt={friend.name}
                      className="w-9 h-9 rounded-xl object-cover border border-slate-700"
                    />
                    <div>
                      <span className="text-xs font-bold text-white block">{friend.name}</span>
                      <span className="text-[10px] text-slate-400">
                        @{friend.username} • {friend.joinedDate}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-black text-amber-400 font-mono block">
                      +{friend.rewardCoins}
                    </span>
                    <span className="text-[9px] font-bold text-emerald-400 uppercase">
                      {friend.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
