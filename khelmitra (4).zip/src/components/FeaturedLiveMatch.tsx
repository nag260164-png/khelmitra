import { useState, useEffect } from 'react';
import { Radio, RefreshCw, AlertCircle, ChevronRight, Zap } from 'lucide-react';
import { LiveMatch, ActiveSheetType } from '../types';
import { cricketLiveService } from '../services/cricketLiveService';
import TeamLogoBadge from './cricket/TeamLogoBadge';

interface FeaturedLiveMatchProps {
  match?: LiveMatch;
  onOpenLiveCricket: (action: ActiveSheetType) => void;
}

export default function FeaturedLiveMatch({ onOpenLiveCricket }: FeaturedLiveMatchProps) {
  const [liveMatch, setLiveMatch] = useState<LiveMatch>(
    cricketLiveService.getMatchById('match-live-1') || cricketLiveService.getMatches()[0]
  );
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [lastUpdated, setLastUpdated] = useState('Just now');

  useEffect(() => {
    const unsubscribe = cricketLiveService.subscribe((matches, isErr) => {
      const match = matches.find((m) => m.id === 'match-live-1') || matches[0];
      if (match) setLiveMatch({ ...match });
      setHasError(isErr);
      setLastUpdated(cricketLiveService.getLastUpdatedText());
    });
    return () => unsubscribe();
  }, []);

  const handleRefresh = async () => {
    setIsLoading(true);
    setHasError(false);
    await cricketLiveService.refreshMatchesNow();
    setTimeout(() => {
      setIsLoading(false);
      setLastUpdated('Updated just now');
    }, 400);
  };

  const handleSimulateError = () => {
    cricketLiveService.triggerErrorSimulation();
  };

  const handleRetry = () => {
    cricketLiveService.clearErrorState();
  };

  return (
    <section id="featured-live-cricket-section" className="px-4 py-2">
      {/* Header bar */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
          <h2 className="text-xs uppercase font-extrabold tracking-wider text-slate-200 font-mono">
            Live Cricket Score
          </h2>
          <span className="text-[10px] text-slate-400 font-mono">• {lastUpdated}</span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Refresh / Sync Button */}
          <button
            id="refresh-live-score-btn"
            onClick={handleRefresh}
            disabled={isLoading}
            title="Sync Live Score"
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white active:scale-95 disabled:opacity-50 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-amber-400' : ''}`} />
          </button>

          {/* Simulate error test trigger */}
          <button
            id="simulate-error-btn"
            onClick={hasError ? handleRetry : handleSimulateError}
            title={hasError ? "Reset to live score" : "Test error state"}
            className="px-2 py-1 rounded-lg bg-slate-900/80 border border-slate-800/80 text-[10px] font-semibold text-slate-400 hover:text-slate-300"
          >
            {hasError ? "Reset" : "Test State"}
          </button>

          <button
            id="see-all-live-cricket-btn"
            onClick={() => onOpenLiveCricket('live-cricket')}
            className="text-xs font-bold text-red-400 hover:text-red-300 flex items-center gap-0.5 ml-1"
          >
            Full Scorecard
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ERROR STATE */}
      {hasError ? (
        <div
          id="live-score-error-state"
          className="rounded-2xl bg-gradient-to-br from-[#1a0f12] via-[#120a0d] to-[#0d0709] border border-red-900/60 p-5 text-center shadow-lg"
        >
          <div className="w-11 h-11 rounded-full bg-red-500/20 border border-red-500/40 flex items-center justify-center mx-auto mb-2.5 text-red-400">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-white mb-1">Live Telemetry Feed Interrupted</h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto mb-3.5">
            Unable to connect to stadium pitch sensor stream. Check your network or retry live sync.
          </p>
          <button
            id="retry-live-sync-btn"
            onClick={handleRetry}
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs shadow-md shadow-red-700/30 active:scale-95 transition-all inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry Connection</span>
          </button>
        </div>
      ) : isLoading ? (
        /* LOADING STATE SKELETON */
        <div
          id="live-score-loading-skeleton"
          className="rounded-2xl bg-[#0d1322] border border-slate-800/80 p-4 shadow-xl animate-pulse space-y-4"
        >
          <div className="flex justify-between items-center pb-3 border-b border-slate-800/60">
            <div className="h-4 w-28 bg-slate-800 rounded"></div>
            <div className="h-3 w-20 bg-slate-800 rounded"></div>
          </div>
          <div className="grid grid-cols-5 items-center py-2">
            <div className="col-span-2 space-y-2">
              <div className="h-6 w-16 bg-slate-800 rounded"></div>
              <div className="h-4 w-24 bg-slate-800/60 rounded"></div>
            </div>
            <div className="col-span-1 flex justify-center">
              <div className="w-8 h-8 rounded-full bg-slate-800"></div>
            </div>
            <div className="col-span-2 space-y-2 flex flex-col items-end">
              <div className="h-6 w-16 bg-slate-800 rounded"></div>
              <div className="h-4 w-24 bg-slate-800/60 rounded"></div>
            </div>
          </div>
          <div className="h-10 bg-slate-800/50 rounded-xl"></div>
          <div className="text-center text-xs text-amber-400 font-semibold flex items-center justify-center gap-1.5 py-1">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            Syncing ball-by-ball pitch radar...
          </div>
        </div>
      ) : (
        /* NORMAL PROFESSIONAL STADIUM CARD */
        <div
          id="live-match-stadium-card"
          onClick={() => onOpenLiveCricket('live-cricket')}
          className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0e1424] via-[#0b101c] to-[#070b14] border border-slate-800/90 shadow-xl shadow-black/60 p-4 cursor-pointer hover:border-slate-700 transition-all group"
        >
          {/* Subtle field turf ambient background */}
          <div className="absolute -top-16 -right-16 w-44 h-44 rounded-full bg-red-600/10 blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-16 -left-16 w-44 h-44 rounded-full bg-blue-600/10 blur-3xl pointer-events-none"></div>

          {/* Top tournament badge & venue */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 text-[10px] font-black uppercase tracking-wider flex items-center gap-1">
                <Radio className="w-3 h-3 text-red-500 animate-pulse" />
                LIVE INNINGS 2
              </span>
              <span className="text-[11px] font-semibold text-slate-300 truncate max-w-[150px]">
                {liveMatch.tournament}
              </span>
            </div>
            <span className="text-[10px] text-slate-500 font-medium">{(liveMatch.venue || '').split(',')[0]}</span>
          </div>

          {/* Teams & Scores */}
          <div className="grid grid-cols-5 items-center py-3.5">
            {/* Team 1: AUS */}
            <div className="col-span-2 flex items-center gap-2.5">
              <TeamLogoBadge
                code={liveMatch.team1?.logoCode || liveMatch.team1?.shortName || 'T1'}
                name={liveMatch.team1?.name || 'Team 1'}
                size="md"
              />
              <div>
                <span className="text-sm font-bold text-slate-200 block">{liveMatch.team1?.shortName}</span>
                <span className="text-lg font-sports font-bold tracking-wider text-slate-400 block -mt-1">
                  {liveMatch.team1?.score}
                </span>
                <span className="text-[10px] text-slate-500 block -mt-1">
                  ({liveMatch.team1?.overs} ov)
                </span>
              </div>
            </div>

            {/* VS / Status Pill */}
            <div className="col-span-1 flex flex-col items-center justify-center text-center">
              <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] font-bold text-slate-400">
                VS
              </div>
              <span className="text-[9px] font-extrabold text-amber-400 mt-1 uppercase leading-tight">
                {liveMatch.requiredRuns || 'LIVE'}
              </span>
            </div>

            {/* Team 2: IND (Batting) */}
            <div className="col-span-2 flex items-center justify-end gap-2.5 text-right">
              <div>
                <div className="flex items-center justify-end gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  <span className="text-sm font-bold text-white block">{liveMatch.team2?.shortName}</span>
                </div>
                <span className="text-2xl font-sports font-bold tracking-wider text-amber-400 block -mt-1">
                  {liveMatch.team2?.score}
                </span>
                <span className="text-[10px] text-slate-400 block -mt-1">
                  ({liveMatch.team2?.overs} ov) {liveMatch.team2?.crr ? `• CRR ${liveMatch.team2.crr}` : ''}
                </span>
              </div>
              <TeamLogoBadge
                code={liveMatch.team2?.logoCode || liveMatch.team2?.shortName || 'T2'}
                name={liveMatch.team2?.name || 'Team 2'}
                size="md"
              />
            </div>
          </div>

          {/* Current Match Equation / Status Banner */}
          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <Zap className="w-3.5 h-3.5 fill-amber-400 shrink-0" />
              <span className="truncate">{liveMatch.statusText}</span>
            </div>
            {liveMatch.requiredRuns && (
              <span className="font-mono text-slate-400 text-[11px] shrink-0 font-semibold">
                RRR: <strong className="text-amber-300">{liveMatch.requiredRunRate || '10.5'}</strong>
              </span>
            )}
          </div>

          {/* Batsmen & Bowler Live Telemetry */}
          <div className="grid grid-cols-2 gap-2 mt-2.5 pt-2.5 border-t border-slate-800/70 text-xs">
            {/* Batsman */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/60 border border-slate-800/60">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase font-mono">Batsman</span>
                <span className="font-bold text-white flex items-center gap-1">
                  {liveMatch.currentBatsman?.name || 'Batsman'} <span className="text-amber-400 text-[9px]">*</span>
                </span>
              </div>
              <span className="font-mono font-bold text-amber-400 text-sm">
                {liveMatch.currentBatsman?.runs ?? 0}
                <span className="text-[10px] text-slate-400 font-normal">({liveMatch.currentBatsman?.balls ?? 0})</span>
              </span>
            </div>

            {/* Bowler */}
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/60 border border-slate-800/60">
              <div>
                <span className="text-[10px] text-slate-500 block uppercase font-mono">Bowler</span>
                <span className="font-bold text-slate-200">
                  {liveMatch.currentBowler?.name || 'Bowler'}
                </span>
              </div>
              <span className="font-mono font-bold text-emerald-400 text-xs">
                {liveMatch.currentBowler?.wickets ?? 0}/{liveMatch.currentBowler?.runs ?? 0}
                <span className="text-[10px] text-slate-400 font-normal block text-right">
                  {liveMatch.currentBowler?.overs || '0.0'} ov
                </span>
              </span>
            </div>
          </div>

          {/* Recent balls ticker & Tap to open callout */}
          <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-800/50">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-400 font-mono">This Over:</span>
              <div className="flex items-center gap-1">
                {(liveMatch.recentBalls || []).map((ball, idx) => (
                  <span
                    key={idx}
                    className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      ball === 'W'
                        ? 'bg-red-600 text-white'
                        : ball === '6'
                        ? 'bg-purple-600 text-white'
                        : ball === '4'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {ball}
                  </span>
                ))}
              </div>
            </div>

            <span className="text-[11px] font-bold text-red-400 flex items-center gap-0.5 group-hover:text-red-300 transition-colors">
              Open Full Scorecard
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </span>
          </div>
        </div>
      )}
    </section>
  );
}
