export type ActiveSheetType = 
  | 'none' 
  | 'live-cricket' 
  | 'fantasy-cricket' 
  | 'create-team'
  | 'my-teams' 
  | 'fantasy-rules'
  | 'games' 
  | 'daily-missions'
  | 'profile' 
  | 'wallet' 
  | 'notifications'
  | 'call-break'
  | 'teen-patti'
  | 'ludo'
  | 'rummy'
  | 'game-history'
  | 'settings'
  | 'leaderboard'
  | 'rewards'
  | 'apk-download'
  | 'customer-care'
  | 'invite-friends'
  | 'master-owner'
  | 'product-detail'
  | 'reseller-dashboard'
  | 'supplier-portal'
  | 'order-tracking'
  | 'cart-checkout';

export type SuperAppMode = 'gaming' | 'reselling';

export interface CricketTeam {
  name: string;
  shortName: string;
  score: string;
  overs: string;
  flagColor: string;
  crr?: string;
  logoCode: string;
  wickets?: number;
  runs?: number;
}

export interface BattingEntry {
  id: string;
  name: string;
  isCaptain?: boolean;
  isWicketKeeper?: boolean;
  dismissal: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  strikeRate: number;
  isStriker?: boolean;
  isNonStriker?: boolean;
  isNotOut?: boolean;
}

export interface BowlingEntry {
  id: string;
  name: string;
  overs: string;
  maidens: number;
  runs: number;
  wickets: number;
  economy: number;
  dots?: number;
  isCurrentBowler?: boolean;
}

export interface FallOfWicket {
  wicket: number;
  score: number;
  over: string;
  player: string;
}

export interface InningsScorecard {
  teamName: string;
  teamShortName: string;
  inningNumber: 1 | 2;
  runs: number;
  wickets: number;
  overs: string;
  runRate: string;
  batting: BattingEntry[];
  bowling: BowlingEntry[];
  fallOfWickets: FallOfWicket[];
  extras: { total: number; b: number; lb: number; wd: number; nb: number; p: number };
  didNotBat?: string[];
}

export interface BallCommentary {
  id: string;
  over: string;
  ballNumber: number;
  runs: number;
  ballType: 'dot' | 'run' | 'four' | 'six' | 'wicket' | 'wide' | 'no-ball';
  text: string;
  bowler: string;
  batsman: string;
  scoreSnapshot: string;
  timestamp?: string;
}

export interface PlayerProfile {
  id: string;
  name: string;
  role: 'Batter' | 'Bowler' | 'All-Rounder' | 'Wicket-Keeper';
  battingStyle?: string;
  bowlingStyle?: string;
  isCaptain?: boolean;
  isWk?: boolean;
}

export interface PlayerBattingStats {
  matches: number;
  innings: number;
  runs: number;
  highestScore: string;
  average: number;
  strikeRate: number;
  hundreds: number;
  fifties: number;
  fours: number;
  sixes: number;
  ducks: number;
  notOuts: number;
}

export interface PlayerBowlingStats {
  matches: number;
  innings: number;
  overs: string;
  balls: number;
  maidens: number;
  runsConceded: number;
  wickets: number;
  bestBowling: string;
  economyRate: number;
  bowlingAverage: number;
  strikeRate: number;
  threeWickets: number;
  fiveWickets: number;
}

export interface PlayerFieldingStats {
  catches: number;
  stumpings: number;
  runOuts: number;
}

export interface PlayerRecentMatchPerformance {
  matchId: string;
  matchTitle: string;
  opponent: string;
  opponentShort: string;
  opponentFlag?: string;
  date: string;
  format: 'T20' | 'ODI' | 'TEST';
  result: string;
  // Batting
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  isNotOut?: boolean;
  strikeRate: number;
  // Bowling
  overs: string;
  maidens: number;
  runsConceded: number;
  wickets: number;
  economy: number;
  // Fielding
  catches: number;
  stumpings: number;
  runOuts: number;
  // Demo Fantasy points
  demoPoints: number;
  breakdownSummary?: string;
}

export interface PlayerDetailedProfile {
  id: string;
  name: string;
  shortName: string;
  teamName: string;
  teamShortName: string;
  flagColor?: string;
  role: 'Batter' | 'Bowler' | 'All-Rounder' | 'Wicket-Keeper';
  fantasyRole: 'WK' | 'BAT' | 'AR' | 'BOWL';
  battingStyle: string;
  bowlingStyle: string;
  photoUrl?: string;
  jerseyNumber?: number;
  born?: string;
  age?: number;
  nationality?: string;
  isCaptain?: boolean;
  isViceCaptain?: boolean;
  isWk?: boolean;
  credits: number;
  selectedByPercent: number;
  totalDemoPoints: number;
  averageDemoPoints: number;
  battingStats: PlayerBattingStats;
  bowlingStats: PlayerBowlingStats;
  fieldingStats: PlayerFieldingStats;
  recentMatches: PlayerRecentMatchPerformance[];
  isLiveNow?: boolean;
  currentLiveMatchId?: string;
}

export interface MatchInfo {
  series: string;
  matchNo: string;
  date: string;
  time: string;
  venue: string;
  city: string;
  toss: string;
  umpires: string;
  thirdUmpire: string;
  matchReferee: string;
  pitchReport?: string;
  weather?: string;
}

export interface LiveMatch {
  id: string;
  tournament: string;
  matchType: string;
  format?: 'T20' | 'ODI' | 'TEST';
  status: 'LIVE' | 'UPCOMING' | 'COMPLETED';
  statusText: string;
  result?: string;
  team1: CricketTeam;
  team2: CricketTeam;
  venue: string;
  target?: number;
  requiredRuns?: string;
  requiredRunRate?: string;
  currentBatsman: { name: string; runs: number; balls: number; fours: number; sixes: number };
  nonStriker?: { name: string; runs: number; balls: number; fours: number; sixes: number };
  currentBowler: { name: string; overs: string; maidens: number; runs: number; wickets: number; economy?: number };
  recentBalls: string[];
  winProbability?: { team1: number; team2: number };
  innings1?: InningsScorecard;
  innings2?: InningsScorecard;
  commentary?: BallCommentary[];
  matchInfo?: MatchInfo;
  playingXI?: { team1: PlayerProfile[]; team2: PlayerProfile[] };
  keyPartnership?: { runs: number; balls: number; player1: string; player1Runs: number; player2: string; player2Runs: number };
  playerOfTheMatch?: { name: string; team: string; performance: string };
  startTime?: string;
  countdown?: string;
}

export interface UpcomingMatch {
  id: string;
  tournament: string;
  matchType: string;
  startTime: string;
  countdown: string;
  team1: { name: string; shortName: string; flagColor: string; code: string };
  team2: { name: string; shortName: string; flagColor: string; code: string };
  venue: string;
  megaContestPrize: string;
  entryFee: number;
}

export interface FantasyContest {
  id: string;
  title: string;
  matchName: string;
  matchTime: string;
  prizePool: string;
  entryFee: number;
  discountedFee?: number;
  firstPrize: string;
  totalSpots: number;
  filledSpots: number;
  guaranteed: boolean;
  maxTeamsPerUser: number;
}

export type FantasyPlayerRole = 'WK' | 'BAT' | 'AR' | 'BOWL';

export interface FantasyPlayer {
  id: string;
  name: string;
  shortName?: string;
  teamName: string;
  teamShortName: string;
  role: FantasyPlayerRole;
  credits: number;
  points: number;
  selectedByPercent: number;
  isCaptain?: boolean;
  isViceCaptain?: boolean;
  battingStyle?: string;
  bowlingStyle?: string;
  recentScores?: number[];
  flagColor?: string;
}

export interface UserTeam {
  id: string;
  name: string;
  match: string;
  matchId?: string;
  captain: string;
  captainId?: string;
  viceCaptain: string;
  viceCaptainId?: string;
  wicketKeepers: number;
  batsmen: number;
  allRounders: number;
  bowlers: number;
  totalPoints: number;
  rank: number;
  status: 'In Contest' | 'Ready' | 'Completed';
  players?: FantasyPlayer[];
  team1Count?: number;
  team2Count?: number;
  team1ShortName?: string;
  team2ShortName?: string;
  totalCreditsUsed?: number;
  updatedAt?: string;
}

export interface GameItem {
  id: string;
  title: string;
  category: string;
  tag: string;
  prizePool: string;
  playersCount: string;
  bgGradient: string;
  iconName: string;
  description: string;
}

export interface UserProfile {
  name: string;
  username: string;
  level: number;
  tier: string;
  totalCash: number;
  bonusCash: number;
  coins: number;
  matchesPlayed: number;
  winRate: string;
  avatarUrl: string;
}

export interface DailyMission {
  id: string;
  title: string;
  description: string;
  rewardCoins: number;
  category: 'login' | 'ad' | 'quiz' | 'fantasy' | 'puzzle' | 'all';
  currentProgress: number;
  targetProgress: number;
  isCompleted: boolean;
  isClaimed: boolean;
  actionSheet?: ActiveSheetType;
  actionLabel?: string;
  iconName?: string;
}

export interface DailyMissionState {
  date: string; // YYYY-MM-DD
  dailyStreak: number;
  loginClaimed: boolean;
  adsWatchedToday: number;
  maxDailyAds: number;
  missions: Record<string, {
    progress: number;
    isClaimed: boolean;
    claimedAt?: string;
  }>;
  totalMissionsCompleted: number;
  megaBonusClaimed: boolean;
}

// ================= MASTER OWNER CONTROL PANEL TYPES =================
export type MasterOwnerRole = 
  | 'SUPER_OWNER' 
  | 'OPERATIONS_ADMIN' 
  | 'CRICKET_MANAGER' 
  | 'REWARDS_OFFICER';

export interface MasterOwnerUser {
  id: string;
  name: string;
  username: string;
  email: string;
  phone: string;
  avatarUrl: string;
  level: number;
  coins: number;
  matchesPlayed: number;
  winRate: string;
  status: 'active' | 'blocked' | 'vip';
  riskScore: number; // 0-100%
  joinDate: string;
  lastActive: string;
  permissions: {
    canPlayGames: boolean;
    canJoinContests: boolean;
    canChatSupport: boolean;
    isVip: boolean;
  };
}

export interface MasterLudoSettings {
  turnTimerSeconds: 15 | 30 | 45 | 60;
  strictSixToOpen: boolean;
  botDifficulty: 'easy' | 'balanced' | 'expert';
  boardTheme: 'classic' | 'cyberpunk' | 'royal-gold';
  winMultiplier: number;
}

export interface MasterTeenPattiSettings {
  bootAmount: number;
  maxBlindRounds: number;
  maxPotCap: number;
  cardAnimationSpeed: 'normal' | 'fast';
  commissionRate: number; // 0% strictly virtual
}

export interface MasterFantasySettings {
  maxCaptainMult: number;
  viceCaptainMult: number;
  transferDeadlineMinutes: number;
  maxTeamEdits: number;
  creditBudget: number;
}

export interface MasterGameRulesConfig {
  callBreak: string;
  teenPatti: string;
  ludo: string;
  rummy: string;
  fantasyCricket: string;
}

export interface MasterCricketApiConfig {
  apiStatus: 'active' | 'degraded' | 'simulated_error';
  autoPolling: boolean;
  pollIntervalSeconds: number;
  featuredMatchId: string;
  latencyMs: number;
  successRate: number;
  apiEndpoint: string;
  apiMaskedKey: string;
  totalRequestsToday: number;
  lastSyncTimestamp: string;
}

export interface MasterRewardItem {
  id: string;
  timestamp: string;
  userName: string;
  userId: string;
  type: 'DAILY_STREAK' | 'LUCKY_WHEEL' | 'MISSION_COMPLETE' | 'REFERRAL_BONUS' | 'ADMIN_GRANT';
  amount: number;
  notes: string;
}

export interface MasterAppAnnouncement {
  active: boolean;
  title: string;
  message: string;
  level: 'info' | 'promo' | 'alert' | 'critical';
  updatedAt: string;
}

export interface MasterAppConfig {
  maintenanceMode: boolean;
  maintenanceMessage: string;
  maintenanceEstimatedReturn: string;
  announcement: MasterAppAnnouncement;
  version: {
    current: string;
    minimumRequired: string;
    forceUpdate: boolean;
    releaseNotes: string;
  };
  enabledFeatures: {
    luckyWheel: boolean;
    customerCare: boolean;
    inviteReferrals: boolean;
    fantasyContests: boolean;
    apkDownloads: boolean;
    audioEffects: boolean;
  };
  enabledGames: {
    callBreak: boolean;
    teenPatti: boolean;
    ludo: boolean;
    rummy: boolean;
    fantasyCricket: boolean;
    quizGames: boolean;
  };
}

export interface MasterAdsConfig {
  enabled: boolean;
  interstitialFrequency: number;
  rewardedCoinsAmount: number;
  dailyRewardedAdCap: number;
  sponsorBanners: boolean;
  adProvider: string;
  todayImpressions: number;
  estimatedEcpm: number;
}

export interface MasterRewardAbuseConfig {
  maxDailyRewardCoins: number;
  cooldownBetweenClaimsSeconds: number;
  requireDeviceIntegrityCheck: boolean;
  autoFlagSuspiciousAccounts: boolean;
  maxStreakFreezeAllowance: number;
}

export interface SecurityAuditEntry {
  id: string;
  timestamp: string;
  action: string;
  category: 'AUTH' | 'USER_MANAGEMENT' | 'GAME_SETTINGS' | 'CRICKET_API' | 'REWARDS_ADS' | 'APP_UPDATE' | 'SECURITY';
  details: string;
  operatorRole: MasterOwnerRole;
  operatorName: string;
  ipAddress: string;
}

// ----------------------------------------------------
// RESELLING MARKETPLACE MODE INTERFACES
// ----------------------------------------------------
export type ResellerCategory = 
  | 'Ladies Kurti' 
  | 'Saree' 
  | 'Dress' 
  | 'Beauty Products' 
  | 'Home Products' 
  | 'Accessories';

export interface ResellerProduct {
  id: string;
  title: string;
  category: ResellerCategory;
  description: string;
  images: string[];
  supplierPrice: number; // Wholesale cost to reseller
  suggestedMrp: number; // Market MRP
  minMargin: number;
  maxMargin: number;
  stock: number;
  fabric?: string;
  sizes: string[];
  rating: number;
  reviewsCount: number;
  supplierId: string;
  supplierName: string;
  inStock: boolean;
  tags: string[];
  featured?: boolean;
}

export type OrderStatus = 
  | 'Placed' 
  | 'Confirmed' 
  | 'Dispatched' 
  | 'Out for Delivery' 
  | 'Delivered' 
  | 'Cancelled';

export interface OrderTrackingStep {
  title: OrderStatus;
  timestamp: string;
  description: string;
  completed: boolean;
}

export interface ResellerOrder {
  id: string;
  orderNumber: string;
  productId: string;
  productTitle: string;
  productImage: string;
  category: ResellerCategory;
  size: string;
  quantity: number;
  supplierPrice: number;
  resellerMargin: number; // Margin profit earned by reseller
  finalCustomerPrice: number; // supplierPrice * quantity + resellerMargin
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  pincode: string;
  city: string;
  state: string;
  paymentMethod: 'COD' | 'Online';
  status: OrderStatus;
  trackingNumber: string;
  courierName: string;
  createdAt: string;
  estimatedDelivery: string;
  resellerId: string;
  resellerName: string;
  supplierId: string;
  supplierName: string;
}

export interface SupplierProfile {
  id: string;
  businessName: string;
  ownerName: string;
  phone: string;
  email: string;
  city: string;
  state: string;
  categories: ResellerCategory[];
  status: 'pending' | 'approved' | 'rejected';
  totalProducts: number;
  totalOrders: number;
  rating: number;
  createdAt: string;
  gstOrPan?: string;
}

export interface ResellerEarnings {
  totalMarginEarned: number;
  pendingPayout: number;
  withdrawnAmount: number;
  deliveredOrdersCount: number;
  totalOrdersCount: number;
  upiId: string;
  bankAccountHolder: string;
  bankAccountNumber: string;
  bankIfsc: string;
}

export interface MarketplaceConfig {
  platformCommissionPercent: number;
  codFee: number;
  freeShippingThreshold: number;
  maxMarginCap: number;
  supplierAutoApproval: boolean;
}


