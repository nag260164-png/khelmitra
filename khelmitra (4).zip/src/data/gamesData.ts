// KhelMitra Free-to-Play Games Registry and Data
// 100% Free Demo Gaming - No Real Money, No Cash, No Gambling

export type GameCategory = 'all' | 'fantasy' | 'quiz' | 'puzzle' | 'arcade' | 'coming-soon';

export interface GameDefinition {
  id: string;
  title: string;
  category: GameCategory;
  categoryLabel: string;
  tag: string;
  tagColor: string;
  demoPointsReward: string;
  pointsAmount: number;
  playersCount: string;
  bgGradient: string;
  borderHoverColor: string;
  icon: string; // Lucide icon name or identifier
  description: string;
  isPlayable: boolean;
  comingSoonDate?: string;
  features: string[];
}

export const KHELM_GAMES: GameDefinition[] = [
  {
    id: 'call-break',
    title: 'Call Break Master',
    category: 'arcade',
    categoryLabel: 'Card Strategy',
    tag: 'POPULAR',
    tagColor: 'bg-amber-500/20 text-amber-400 border-amber-500/40',
    demoPointsReward: '+500 Virtual Coins',
    pointsAmount: 500,
    playersCount: '42.1k players',
    bgGradient: 'from-amber-700/30 via-slate-900 to-amber-950/40',
    borderHoverColor: 'hover:border-amber-500/60',
    icon: 'Sparkles',
    description: '4-player tactical trick-taking game. Spades are always trump. Make accurate bids to win virtual coins!',
    isPlayable: true,
    features: ['5 Rounds Format', 'Live Scorecard', 'Spades Trump Rule', 'Smart AI Seats'],
  },
  {
    id: 'teen-patti',
    title: 'Teen Patti Royal',
    category: 'arcade',
    categoryLabel: 'Indian Poker',
    tag: 'HOT',
    tagColor: 'bg-red-500/20 text-red-400 border-red-500/40',
    demoPointsReward: '+1,000 Virtual Coins',
    pointsAmount: 1000,
    playersCount: '58.3k players',
    bgGradient: 'from-red-700/30 via-slate-900 to-rose-950/40',
    borderHoverColor: 'hover:border-red-500/60',
    icon: 'Flame',
    description: '3-card Indian poker table. Play Blind or Seen, place virtual coin bets, request showdowns and collect the pot!',
    isPlayable: true,
    features: ['4-Player Live Table', 'Blind & Chaal Bets', 'Hand Ranking System', '100% Demo Coins'],
  },
  {
    id: 'ludo',
    title: 'Khel Ludo Classic',
    category: 'arcade',
    categoryLabel: 'Board Game',
    tag: 'FAMILY FAVORITE',
    tagColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
    demoPointsReward: '+600 Virtual Coins',
    pointsAmount: 600,
    playersCount: '64.7k players',
    bgGradient: 'from-emerald-700/30 via-slate-900 to-teal-950/40',
    borderHoverColor: 'hover:border-emerald-500/60',
    icon: 'Trophy',
    description: 'Roll the 3D dice, release tokens with a 6, navigate safe star squares, capture opponents and race to Home!',
    isPlayable: true,
    features: ['2P & 4P Modes', 'Safe Star Spots', 'Token Capturing', '3D Rolling Dice'],
  },
  {
    id: 'rummy',
    title: '13-Card Indian Rummy',
    category: 'arcade',
    categoryLabel: 'Classic Rummy',
    tag: 'SKILL GAME',
    tagColor: 'bg-blue-500/20 text-blue-400 border-blue-500/40',
    demoPointsReward: '+800 Virtual Coins',
    pointsAmount: 800,
    playersCount: '37.9k players',
    bgGradient: 'from-blue-700/30 via-slate-900 to-indigo-950/40',
    borderHoverColor: 'hover:border-blue-500/60',
    icon: 'Award',
    description: '13 cards per hand. Meld pure sequences, sets, draw from open or closed piles, and declare for victory!',
    isPlayable: true,
    features: ['Auto-Sort by Suit', 'Closed & Discard Piles', 'Wild Joker Indicator', 'Pure Sequence Checker'],
  },
  {
    id: 'fantasy-cricket',
    title: 'Fantasy Cricket 11',
    category: 'fantasy',
    categoryLabel: 'Fantasy Sports',
    tag: 'FEATURED',
    tagColor: 'bg-amber-500/20 text-amber-400 border-amber-500/40',
    demoPointsReward: '+500 Demo Pts',
    pointsAmount: 500,
    playersCount: '28.4k players',
    bgGradient: 'from-amber-600/25 via-orange-950/40 to-slate-900',
    borderHoverColor: 'hover:border-amber-500/60',
    icon: 'Trophy',
    description: 'Draft your dream 11 squad, pick Captain (2x) & Vice-Captain (1.5x) and earn leaderboard demo points!',
    isPlayable: true,
    features: ['100 Credits Budget', '7 Players Per Team Limit', '2x Captain Boost', 'Demo Leaderboard'],
  },
  {
    id: 'cricket-quiz',
    title: 'Cricket Master Quiz',
    category: 'quiz',
    categoryLabel: 'Cricket Trivia',
    tag: 'HOT',
    tagColor: 'bg-red-500/20 text-red-400 border-red-500/40',
    demoPointsReward: '+150 Demo Pts',
    pointsAmount: 150,
    playersCount: '19.8k players',
    bgGradient: 'from-red-600/25 via-rose-950/40 to-slate-900',
    borderHoverColor: 'hover:border-red-500/60',
    icon: 'Radio',
    description: 'Test your IPL, World Cup, and historic cricket match knowledge with 5 timed trivia questions!',
    isPlayable: true,
    features: ['5 Timed Questions', '15s Per Question', 'Streak Bonus Pts', 'Detailed Explanations'],
  },
  {
    id: 'gk-quiz',
    title: 'General Knowledge IQ',
    category: 'quiz',
    categoryLabel: 'Brain Trivia',
    tag: 'POPULAR',
    tagColor: 'bg-blue-500/20 text-blue-400 border-blue-500/40',
    demoPointsReward: '+150 Demo Pts',
    pointsAmount: 150,
    playersCount: '14.2k players',
    bgGradient: 'from-blue-600/25 via-indigo-950/40 to-slate-900',
    borderHoverColor: 'hover:border-blue-500/60',
    icon: 'Sparkles',
    description: 'Challenge your mind across science, geography, history, and current world facts in 5 exciting rounds.',
    isPlayable: true,
    features: ['Multi-topic Questions', 'Timer Challenge', 'Instant Feedback', 'Earn Demo Coins'],
  },
  {
    id: 'puzzle-game',
    title: 'Cricket Word & Logic Puzzle',
    category: 'puzzle',
    categoryLabel: 'Logic & Words',
    tag: 'SKILL',
    tagColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
    demoPointsReward: '+200 Demo Pts',
    pointsAmount: 200,
    playersCount: '11.5k players',
    bgGradient: 'from-emerald-600/25 via-teal-950/40 to-slate-900',
    borderHoverColor: 'hover:border-emerald-500/60',
    icon: 'Gamepad2',
    description: 'Unscramble famous cricket terminology, legendary cricketers, and match equipment with clues!',
    isPlayable: true,
    features: ['5 Progressive Levels', 'Clues & Hints', 'Combo Multipliers', 'Instant Demo Rewards'],
  },
  {
    id: 'memory-game',
    title: 'Cricket Memory Match',
    category: 'puzzle',
    categoryLabel: 'Memory Arcade',
    tag: 'FUN',
    tagColor: 'bg-purple-500/20 text-purple-400 border-purple-500/40',
    demoPointsReward: '+180 Demo Pts',
    pointsAmount: 180,
    playersCount: '16.9k players',
    bgGradient: 'from-purple-600/25 via-fuchsia-950/40 to-slate-900',
    borderHoverColor: 'hover:border-purple-500/60',
    icon: 'Flame',
    description: 'Flip and match 6 pairs of cricket gear, trophies, and stadiums in fewest turns against the clock.',
    isPlayable: true,
    features: ['12 Card Grid', 'Flip Animations', 'Turns & Time Tracking', 'Star Rating Rating'],
  },
  {
    id: 'super-striker',
    title: 'Cricket Super Striker',
    category: 'coming-soon',
    categoryLabel: 'Action Arcade',
    tag: 'COMING SOON',
    tagColor: 'bg-slate-700/60 text-slate-300 border-slate-600/50',
    demoPointsReward: '+250 Demo Pts',
    pointsAmount: 250,
    playersCount: 'Launching soon',
    bgGradient: 'from-slate-800/40 via-slate-900 to-slate-950',
    borderHoverColor: 'hover:border-slate-600',
    icon: 'Zap',
    description: 'Fast-paced batting timing arcade game. Time your stroke to clear the boundary ropes and hit 6s!',
    isPlayable: false,
    comingSoonDate: 'Season 2026',
    features: ['Boundary Timing Engine', 'Pace & Spin Bowlers', 'Leaderboard Ranks', 'Free Arcade Play'],
  },
  {
    id: 'bowling-master',
    title: 'Bowling Precision Master',
    category: 'coming-soon',
    categoryLabel: 'Skill Sports',
    tag: 'COMING SOON',
    tagColor: 'bg-slate-700/60 text-slate-300 border-slate-600/50',
    demoPointsReward: '+250 Demo Pts',
    pointsAmount: 250,
    playersCount: 'Launching soon',
    bgGradient: 'from-slate-800/40 via-slate-900 to-slate-950',
    borderHoverColor: 'hover:border-slate-600',
    icon: 'Target',
    description: 'Aim for the top of off-stump, bowl yorkers and deceive batsmen with subtle swing and spin.',
    isPlayable: false,
    comingSoonDate: 'Season 2026',
    features: ['Target Accuracy Meter', 'Swing & Seam Controls', 'Wicket Celebrations', 'Target Challenges'],
  },
  {
    id: 'match-predictor',
    title: 'Live Match Demo Predictor',
    category: 'coming-soon',
    categoryLabel: 'Prediction Pool',
    tag: 'COMING SOON',
    tagColor: 'bg-slate-700/60 text-slate-300 border-slate-600/50',
    demoPointsReward: '+300 Demo Pts',
    pointsAmount: 300,
    playersCount: 'Launching soon',
    bgGradient: 'from-slate-800/40 via-slate-900 to-slate-950',
    borderHoverColor: 'hover:border-slate-600',
    icon: 'Award',
    description: 'Predict match winner, top batsman, and total sixes in live games using free demo coins only.',
    isPlayable: false,
    comingSoonDate: 'Tournament Stage',
    features: ['100% Free Demo Pool', 'No Real Money', 'Community Consensus', 'Live Over Predictions'],
  },
];

// GK Quiz Questions
export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  category?: string;
}

export const GK_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Which planet in our solar system has the most prominent and visible ring system?",
    options: ["Jupiter", "Saturn", "Uranus", "Neptune"],
    correctIndex: 1,
    explanation: "Saturn has the most extensive and stunning planetary ring system, made predominantly of ice and rock particles.",
    category: "Science & Space",
  },
  {
    id: 2,
    question: "What is the capital city of Australia?",
    options: ["Sydney", "Melbourne", "Canberra", "Brisbane"],
    correctIndex: 2,
    explanation: "Canberra was chosen as the compromise capital of Australia between rivals Sydney and Melbourne in 1908.",
    category: "Geography",
  },
  {
    id: 3,
    question: "Who is known as the inventor of the World Wide Web (WWW)?",
    options: ["Bill Gates", "Tim Berners-Lee", "Steve Jobs", "Vint Cerf"],
    correctIndex: 1,
    explanation: "Sir Tim Berners-Lee invented the World Wide Web in 1989 while working at CERN in Switzerland.",
    category: "Technology",
  },
  {
    id: 4,
    question: "Which chemical element has the symbol 'Fe' on the periodic table?",
    options: ["Fluorine", "Francium", "Iron", "Lead"],
    correctIndex: 2,
    explanation: "'Fe' comes from the Latin word 'Ferrum', which denotes Iron.",
    category: "Chemistry",
  },
  {
    id: 5,
    question: "Which is the highest mountain peak in the world above sea level?",
    options: ["K2", "Mount Everest", "Kangchenjunga", "Lhotse"],
    correctIndex: 1,
    explanation: "Mount Everest stands at 8,848.86 meters above sea level in the Himalayas on the border of Nepal and China.",
    category: "Geography",
  },
];

// Cricket Quiz Questions
export const CRICKET_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Who holds the historic record for the highest individual score in Men's One Day Internationals (ODI)?",
    options: ["Sachin Tendulkar (200*)", "Martin Guptill (237*)", "Rohit Sharma (264)", "Chris Gayle (215)"],
    correctIndex: 2,
    explanation: "Rohit Sharma smashed an astonishing 264 runs off 173 balls against Sri Lanka at Eden Gardens, Kolkata in 2014.",
    category: "ODI Records",
  },
  {
    id: 2,
    question: "Which cricket ground is known worldwide as the 'Home of Cricket'?",
    options: ["Melbourne Cricket Ground (MCG)", "Lord's, London", "Eden Gardens, Kolkata", "The Oval, London"],
    correctIndex: 1,
    explanation: "Lord's Cricket Ground in St John's Wood, London, owned by the MCC, is revered globally as the Home of Cricket.",
    category: "Cricket History",
  },
  {
    id: 3,
    question: "Which bowler has taken the most wickets in international Test cricket history?",
    options: ["Shane Warne", "James Anderson", "Anil Kumble", "Muttiah Muralitharan"],
    correctIndex: 3,
    explanation: "Sri Lankan spin wizard Muttiah Muralitharan took an unbeatable 800 wickets in 133 Test matches.",
    category: "Test Milestones",
  },
  {
    id: 4,
    question: "Who was the first batsman to score a double century (200) in Men's ODI cricket history?",
    options: ["Virender Sehwag", "Sachin Tendulkar", "Rohit Sharma", "Sanath Jayasuriya"],
    correctIndex: 1,
    explanation: "Sachin Tendulkar made history on February 24, 2010 against South Africa in Gwalior by scoring 200*.",
    category: "Legendary Feats",
  },
  {
    id: 5,
    question: "In standard cricket rules, how many dismissals can a batsman suffer in a single innings?",
    options: ["One", "Two", "Three", "As many as wickets fall"],
    correctIndex: 0,
    explanation: "Once a batsman is dismissed by any legal method (bowled, caught, LBW, run-out, etc.), their individual innings terminates.",
    category: "Cricket Rules",
  },
];

// Cricket Word Scramble / Logic Puzzle Levels
export interface PuzzleLevel {
  id: number;
  scrambledWord: string;
  originalWord: string;
  clue: string;
  category: string;
  hint: string;
}

export const PUZZLE_LEVELS: PuzzleLevel[] = [
  {
    id: 1,
    scrambledWord: "NOIDH",
    originalWord: "DHONI",
    clue: "Legendary captain who sealed the 2011 ICC World Cup with an iconic six at Wankhede Stadium.",
    category: "Cricket Legend",
    hint: "Known as 'Captain Cool' and jersey number 7.",
  },
  {
    id: 2,
    scrambledWord: "KERYOR",
    originalWord: "YORKER",
    clue: "A devastating delivery pitched right at the batsman's toes at full pace.",
    category: "Bowling Art",
    hint: "Bumrah and Malinga's deadliest weapon.",
  },
  {
    id: 3,
    scrambledWord: "GYOOLG",
    originalWord: "GOOGLY",
    clue: "A deception ball bowled by a leg-spinner that spins back into a right-handed batsman.",
    category: "Spin Bowling",
    hint: "Also known as the 'wrong'un'.",
  },
  {
    id: 4,
    scrambledWord: "PMSTUS",
    originalWord: "STUMPS",
    clue: "The trio of upright wooden posts supporting two bails at each end of the cricket pitch.",
    category: "Cricket Equipment",
    hint: "Target of every fast bowler.",
  },
  {
    id: 5,
    scrambledWord: "RABUYDNO",
    originalWord: "BOUNDARY",
    clue: "The outer perimeter rope marking four or six runs when crossed by the ball.",
    category: "Match Field",
    hint: "Fours and sixes cross this line.",
  },
];

// Memory Game Cards
export interface MemoryCardDef {
  id: string;
  type: string;
  name: string;
  iconName: string;
  color: string;
}

export const MEMORY_CARD_TYPES: Omit<MemoryCardDef, 'id'>[] = [
  { type: 'bat', name: 'Willow Bat', iconName: 'Flame', color: 'text-amber-400 bg-amber-500/20' },
  { type: 'ball', name: 'Leather Ball', iconName: 'Radio', color: 'text-red-400 bg-red-500/20' },
  { type: 'trophy', name: 'Cup Trophy', iconName: 'Trophy', color: 'text-yellow-400 bg-yellow-500/20' },
  { type: 'stumps', name: 'Wicket Stumps', iconName: 'Target', color: 'text-emerald-400 bg-emerald-500/20' },
  { type: 'helmet', name: 'Batting Helmet', iconName: 'Shield', color: 'text-sky-400 bg-sky-500/20' },
  { type: 'gloves', name: 'Catching Gloves', iconName: 'Zap', color: 'text-purple-400 bg-purple-500/20' },
];
