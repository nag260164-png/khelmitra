import { ResellerCategory, ResellerProduct, ResellerOrder, SupplierProfile, ResellerEarnings, MarketplaceConfig } from '../types';

export const RESELLER_CATEGORIES: { id: ResellerCategory; label: string; icon: string; tag: string; bgGradient: string }[] = [
  { id: 'Ladies Kurti', label: 'Ladies Kurti', icon: '👗', tag: 'High Margin', bgGradient: 'from-pink-500/20 to-rose-500/10' },
  { id: 'Saree', label: 'Saree', icon: '🥻', tag: 'Festive Bestseller', bgGradient: 'from-amber-500/20 to-orange-500/10' },
  { id: 'Dress', label: 'Dress', icon: '✨', tag: 'Trending Styles', bgGradient: 'from-purple-500/20 to-indigo-500/10' },
  { id: 'Beauty Products', label: 'Beauty', icon: '💄', tag: '100% Herbal', bgGradient: 'from-emerald-500/20 to-teal-500/10' },
  { id: 'Home Products', label: 'Home Decor', icon: '🏡', tag: 'Daily Utility', bgGradient: 'from-cyan-500/20 to-blue-500/10' },
  { id: 'Accessories', label: 'Accessories', icon: '💍', tag: 'Quick Sell', bgGradient: 'from-yellow-500/20 to-amber-500/10' },
];

export const INITIAL_PRODUCTS: ResellerProduct[] = [
  // 1. Ladies Kurti
  {
    id: 'prod-kurti-001',
    title: 'Jaipuri Pure Cotton Floral Anarkali Kurti with Pant Set',
    category: 'Ladies Kurti',
    description: 'Exquisite 100% breathable cambric cotton Anarkali flared kurti featuring authentic Rajasthani sanganeri print, matching straight pants, and gota-patti border work. Perfect for festive casuals and daily comfort.',
    images: [
      'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 349,
    suggestedMrp: 899,
    minMargin: 50,
    maxMargin: 550,
    stock: 145,
    fabric: '100% Pure Cambric Cotton 60x60',
    sizes: ['M (38)', 'L (40)', 'XL (42)', 'XXL (44)'],
    rating: 4.8,
    reviewsCount: 320,
    supplierId: 'sup-101',
    supplierName: 'Jaipur Cotton Mills & Tex',
    inStock: true,
    tags: ['Best Seller', 'Free COD', 'Easy Returns'],
    featured: true,
  },
  {
    id: 'prod-kurti-002',
    title: 'Lucknowi Chikankari Hand-Embroidered Straight Georgette Kurti',
    category: 'Ladies Kurti',
    description: 'Graceful Lucknowi hand-crafted Chikankari straight kurti with inner lining. Intricate shadow and bakhiya stitch work along neck and sleeves.',
    images: [
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1596704017254-9b121068fb31?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 420,
    suggestedMrp: 1199,
    minMargin: 70,
    maxMargin: 700,
    stock: 88,
    fabric: 'Soft Faux Georgette with Cotton Lining',
    sizes: ['S (36)', 'M (38)', 'L (40)', 'XL (42)'],
    rating: 4.9,
    reviewsCount: 195,
    supplierId: 'sup-102',
    supplierName: 'Awadh Chikan Artisans',
    inStock: true,
    tags: ['Handcrafted', 'Festive Edit'],
    featured: true,
  },

  // 2. Saree
  {
    id: 'prod-saree-001',
    title: 'Surat Rich Kanjivaram Jacquard Soft Silk Saree with Blouse Piece',
    category: 'Saree',
    description: 'Traditional heritage weave rich Kanjivaram soft silk saree boasting opulent golden zari pallu, peacock motif border, and matching unstitched blouse piece.',
    images: [
      'https://images.unsplash.com/photo-1610030469857-410515155f69?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 499,
    suggestedMrp: 1499,
    minMargin: 100,
    maxMargin: 900,
    stock: 220,
    fabric: 'High Density Jacquard Art Silk',
    sizes: ['Free Size (5.5m + 0.8m Blouse)'],
    rating: 4.7,
    reviewsCount: 540,
    supplierId: 'sup-103',
    supplierName: 'Surat Silk Wholesale Hub',
    inStock: true,
    tags: ['Wedding Collection', 'Heavy Pallu', '5-Star Rated'],
    featured: true,
  },
  {
    id: 'prod-saree-002',
    title: 'Varanasi Organza Pastel Floral Printed Saree with Cutwork Border',
    category: 'Saree',
    description: 'Ultra-lightweight trendy organza saree decorated with delicate digital blooming floral motifs and hand-cut scallop zari border.',
    images: [
      'https://images.unsplash.com/photo-1609357605129-26f69add5d6e?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 380,
    suggestedMrp: 999,
    minMargin: 50,
    maxMargin: 600,
    stock: 110,
    fabric: 'Pure Semi-Organza Fabric',
    sizes: ['Free Size (6.3m with Blouse)'],
    rating: 4.6,
    reviewsCount: 160,
    supplierId: 'sup-104',
    supplierName: 'Banaras Weavers Guild',
    inStock: true,
    tags: ['Trending on Reels', 'Lightweight'],
    featured: false,
  },

  // 3. Dress
  {
    id: 'prod-dress-001',
    title: 'Boho Tiered Floral Georgette Western Maxi Dress',
    category: 'Dress',
    description: 'Flattering western tiered maxi gown dress with ruffled flutter sleeves, elasticated waist belt, and breathable crepe lining.',
    images: [
      'https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 390,
    suggestedMrp: 1050,
    minMargin: 60,
    maxMargin: 600,
    stock: 75,
    fabric: 'Premium Poly-Georgette with Soft Lining',
    sizes: ['S', 'M', 'L', 'XL'],
    rating: 4.7,
    reviewsCount: 230,
    supplierId: 'sup-105',
    supplierName: 'Delhi Fashion Loft',
    inStock: true,
    tags: ['Party Wear', 'Vacation Ready'],
    featured: true,
  },

  // 4. Beauty Products
  {
    id: 'prod-beauty-001',
    title: 'Ayurvedic Kumkumadi Radiance Facial Oil & Pure Rose Mist Combo',
    category: 'Beauty Products',
    description: '100% certified organic Ayurvedic glow elixir infused with Kashmiri saffron, sandalwood, and steam-distilled Kannauj rose petals for spotless glass skin.',
    images: [
      'https://images.unsplash.com/photo-1608248597359-2e118939c631?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 220,
    suggestedMrp: 699,
    minMargin: 40,
    maxMargin: 450,
    stock: 310,
    fabric: '30ml Facial Oil + 100ml Pure Mist',
    sizes: ['Combo Pack (2 Units)'],
    rating: 4.9,
    reviewsCount: 680,
    supplierId: 'sup-106',
    supplierName: 'Vedic Herbs Botanicals',
    inStock: true,
    tags: ['No Chemicals', 'Ayush Approved'],
    featured: true,
  },

  // 5. Home Products
  {
    id: 'prod-home-001',
    title: 'Jaipuri Block Printed 100% Pure Cotton King Size Bed Sheet (with 2 Pillows)',
    category: 'Home Products',
    description: 'Heavy 300 Thread Count breathable cotton king bedsheet (108x108 inches) with fast-color traditional ethnic geometric prints and 2 zippered pillow covers.',
    images: [
      'https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 320,
    suggestedMrp: 899,
    minMargin: 60,
    maxMargin: 500,
    stock: 190,
    fabric: '100% Pure Cotton 300 TC (Fast Color)',
    sizes: ['King Size 108" x 108"'],
    rating: 4.8,
    reviewsCount: 410,
    supplierId: 'sup-101',
    supplierName: 'Jaipur Cotton Mills & Tex',
    inStock: true,
    tags: ['Fast Color', 'Machine Washable'],
    featured: true,
  },

  // 6. Accessories
  {
    id: 'prod-acc-001',
    title: 'Kundan Choker Bridal Necklace Set with Jhumka Earrings & Maang Tikka',
    category: 'Accessories',
    description: 'High quality gold-plated Kundan stone necklace set featuring green pearl droplets and adjustable dori. Lightweight for all-day wedding wear.',
    images: [
      'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80'
    ],
    supplierPrice: 280,
    suggestedMrp: 799,
    minMargin: 50,
    maxMargin: 500,
    stock: 140,
    fabric: 'Brass Alloy with 24K Micron Gold Plating',
    sizes: ['Free Size (Adjustable Dori)'],
    rating: 4.7,
    reviewsCount: 290,
    supplierId: 'sup-107',
    supplierName: 'Meenakari Jewels Co.',
    inStock: true,
    tags: ['Wedding Special', 'Gift Box Included'],
    featured: true,
  }
];

export const INITIAL_SUPPLIERS: SupplierProfile[] = [
  {
    id: 'sup-101',
    businessName: 'Jaipur Cotton Mills & Tex',
    ownerName: 'Ghanshyam Agarwal',
    phone: '+91 98290 12345',
    email: 'jaipur.cotton@example.com',
    city: 'Jaipur',
    state: 'Rajasthan',
    categories: ['Ladies Kurti', 'Home Products'],
    status: 'approved',
    totalProducts: 42,
    totalOrders: 1840,
    rating: 4.9,
    createdAt: '12 Jan 2025',
    gstOrPan: '08AAACJ1234F1Z5'
  },
  {
    id: 'sup-102',
    businessName: 'Awadh Chikan Artisans',
    ownerName: 'Shabnam Begum',
    phone: '+91 94150 98765',
    email: 'awadh.chikan@example.com',
    city: 'Lucknow',
    state: 'Uttar Pradesh',
    categories: ['Ladies Kurti'],
    status: 'approved',
    totalProducts: 28,
    totalOrders: 960,
    rating: 4.8,
    createdAt: '18 Feb 2025',
    gstOrPan: '09AAKFA4321D1ZQ'
  },
  {
    id: 'sup-103',
    businessName: 'Surat Silk Wholesale Hub',
    ownerName: 'Kishorebhai Patel',
    phone: '+91 98795 33445',
    email: 'surat.silk@example.com',
    city: 'Surat',
    state: 'Gujarat',
    categories: ['Saree'],
    status: 'approved',
    totalProducts: 65,
    totalOrders: 3120,
    rating: 4.9,
    createdAt: '05 Jan 2025',
    gstOrPan: '24AAFPS9988C1ZR'
  },
  {
    id: 'sup-108',
    businessName: 'Agra Leather Craftworks',
    ownerName: 'Dharmendra Yadav',
    phone: '+91 98370 77889',
    email: 'agra.crafts@example.com',
    city: 'Agra',
    state: 'Uttar Pradesh',
    categories: ['Accessories'],
    status: 'pending',
    totalProducts: 14,
    totalOrders: 0,
    rating: 4.5,
    createdAt: 'Yesterday',
    gstOrPan: '09AABFA8899B1ZP'
  }
];

export const INITIAL_ORDERS: ResellerOrder[] = [
  {
    id: 'ord-1001',
    orderNumber: 'KM-RES-84920',
    productId: 'prod-kurti-001',
    productTitle: 'Jaipuri Pure Cotton Floral Anarkali Kurti with Pant Set',
    productImage: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=400&q=80',
    category: 'Ladies Kurti',
    size: 'XL (42)',
    quantity: 1,
    supplierPrice: 349,
    resellerMargin: 200,
    finalCustomerPrice: 549,
    customerName: 'Anjali Deshmukh',
    customerPhone: '+91 98220 54321',
    customerAddress: 'Flat 402, Sai Shraddha Heights, Shivaji Nagar',
    pincode: '411005',
    city: 'Pune',
    state: 'Maharashtra',
    paymentMethod: 'COD',
    status: 'Out for Delivery',
    trackingNumber: 'DEL-IN-889921',
    courierName: 'Delhivery Express',
    createdAt: '18 Sep 2026, 02:40 PM',
    estimatedDelivery: 'Today by 06:00 PM',
    resellerId: 'usr-current',
    resellerName: 'Arjun Verma (You)',
    supplierId: 'sup-101',
    supplierName: 'Jaipur Cotton Mills & Tex'
  },
  {
    id: 'ord-1002',
    orderNumber: 'KM-RES-84812',
    productId: 'prod-saree-001',
    productTitle: 'Surat Rich Kanjivaram Jacquard Soft Silk Saree',
    productImage: 'https://images.unsplash.com/photo-1610030469857-410515155f69?auto=format&fit=crop&w=400&q=80',
    category: 'Saree',
    size: 'Free Size',
    quantity: 1,
    supplierPrice: 499,
    resellerMargin: 350,
    finalCustomerPrice: 849,
    customerName: 'Sunita Sharma',
    customerPhone: '+91 97110 33441',
    customerAddress: 'House 14B, Green Park Main',
    pincode: '110016',
    city: 'New Delhi',
    state: 'Delhi',
    paymentMethod: 'COD',
    status: 'Delivered',
    trackingNumber: 'BLUEDART-55421',
    courierName: 'Blue Dart Surface',
    createdAt: '14 Sep 2026, 11:15 AM',
    estimatedDelivery: 'Delivered on 17 Sep',
    resellerId: 'usr-current',
    resellerName: 'Arjun Verma (You)',
    supplierId: 'sup-103',
    supplierName: 'Surat Silk Wholesale Hub'
  }
];

export const INITIAL_EARNINGS: ResellerEarnings = {
  totalMarginEarned: 2450,
  pendingPayout: 200,
  withdrawnAmount: 2250,
  deliveredOrdersCount: 7,
  totalOrdersCount: 9,
  upiId: 'arjun.verma@okhdfcbank',
  bankAccountHolder: 'Arjun Verma',
  bankAccountNumber: 'XXXX XXXX 4920',
  bankIfsc: 'HDFC0001242'
};

export const DEFAULT_MARKETPLACE_CONFIG: MarketplaceConfig = {
  platformCommissionPercent: 5,
  codFee: 0,
  freeShippingThreshold: 0, // 100% Free Shipping for Resellers
  maxMarginCap: 1500,
  supplierAutoApproval: false
};
