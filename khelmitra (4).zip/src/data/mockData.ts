import { LiveMatch, FantasyContest, UserTeam, GameItem, UserProfile, UpcomingMatch } from '../types';

export const CURRENT_USER: UserProfile = {
  name: "Arjun Verma",
  username: "arjun_striker",
  level: 18,
  tier: "Gold Pro Gamer",
  totalCash: 3450,
  bonusCash: 850,
  coins: 12400,
  matchesPlayed: 142,
  winRate: "68.4%",
  avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80"
};

export const LIVE_MATCHES: LiveMatch[] = [
  {
    id: "match-1",
    tournament: "T20 Super League - Final",
    matchType: "T20 • Final",
    status: "LIVE",
    statusText: "IND need 28 runs in 16 balls to win",
    team1: {
      name: "Australia",
      shortName: "AUS",
      score: "192/6",
      overs: "20.0",
      flagColor: "from-amber-500 to-yellow-600",
      logoCode: "AUS"
    },
    team2: {
      name: "India",
      shortName: "IND",
      score: "165/4",
      overs: "17.2",
      crr: "9.52",
      flagColor: "from-blue-600 to-sky-500",
      logoCode: "IND"
    },
    venue: "Melbourne Cricket Ground",
    requiredRuns: "28 off 16",
    currentBatsman: {
      name: "Virat (c)",
      runs: 74,
      balls: 42,
      fours: 6,
      sixes: 4
    },
    currentBowler: {
      name: "Starc",
      overs: "3.2",
      maidens: 0,
      runs: 31,
      wickets: 2
    },
    recentBalls: ["1", "4", "6", "W", "2", "4"],
    winProbability: {
      team1: 42,
      team2: 58
    }
  },
  {
    id: "match-2",
    tournament: "Asia Champions Cup",
    matchType: "T20 • Match 14",
    status: "LIVE",
    statusText: "ENG batting, 2nd Innings",
    team1: {
      name: "South Africa",
      shortName: "SA",
      score: "178/8",
      overs: "20.0",
      flagColor: "from-emerald-600 to-green-500",
      logoCode: "SA"
    },
    team2: {
      name: "England",
      shortName: "ENG",
      score: "112/3",
      overs: "12.4",
      crr: "8.84",
      flagColor: "from-rose-600 to-red-500",
      logoCode: "ENG"
    },
    venue: "Lord's, London",
    requiredRuns: "67 off 44",
    currentBatsman: {
      name: "Buttler",
      runs: 56,
      balls: 34,
      fours: 5,
      sixes: 3
    },
    currentBowler: {
      name: "Rabada",
      overs: "2.4",
      maidens: 0,
      runs: 22,
      wickets: 1
    },
    recentBalls: ["0", "1", "4", "1", "2", "6"],
    winProbability: {
      team1: 49,
      team2: 51
    }
  }
];

export const FANTASY_CONTESTS: FantasyContest[] = [
  {
    id: "contest-1",
    title: "Mega Jackpot Contest",
    matchName: "IND vs AUS • T20 Final",
    matchTime: "Live Now",
    prizePool: "₹25,00,00,000",
    entryFee: 49,
    discountedFee: 24,
    firstPrize: "₹1.5 Crore + Sports Car",
    totalSpots: 500000,
    filledSpots: 462100,
    guaranteed: true,
    maxTeamsPerUser: 20
  },
  {
    id: "contest-2",
    title: "Head-to-Head Duel",
    matchName: "IND vs AUS • T20 Final",
    matchTime: "Live Now",
    prizePool: "₹10,000",
    entryFee: 575,
    firstPrize: "₹10,000",
    totalSpots: 2,
    filledSpots: 1,
    guaranteed: true,
    maxTeamsPerUser: 1
  },
  {
    id: "contest-3",
    title: "Triple Chance Hot Contest",
    matchName: "ENG vs SA • Asia Champions",
    matchTime: "Today, 7:30 PM",
    prizePool: "₹50,00,000",
    entryFee: 99,
    firstPrize: "₹10 Lakhs",
    totalSpots: 75000,
    filledSpots: 61400,
    guaranteed: true,
    maxTeamsPerUser: 10
  }
];

export const USER_TEAMS: UserTeam[] = [
  {
    id: "team-1",
    name: "KhelMaster 11 (T1)",
    match: "IND vs AUS • Final",
    captain: "Virat K. (2x Pts)",
    viceCaptain: "Travis H. (1.5x Pts)",
    wicketKeepers: 1,
    batsmen: 4,
    allRounders: 3,
    bowlers: 3,
    totalPoints: 642.5,
    rank: 1420,
    status: "In Contest"
  },
  {
    id: "team-2",
    name: "Thunder Strike (T2)",
    match: "IND vs AUS • Final",
    captain: "Hardik P. (2x Pts)",
    viceCaptain: "G. Maxwell (1.5x Pts)",
    wicketKeepers: 2,
    batsmen: 3,
    allRounders: 4,
    bowlers: 2,
    totalPoints: 588.0,
    rank: 5120,
    status: "In Contest"
  },
  {
    id: "team-3",
    name: "Lords Invincibles (T1)",
    match: "ENG vs SA • Match 14",
    captain: "J. Buttler (2x Pts)",
    viceCaptain: "K. Rabada (1.5x Pts)",
    wicketKeepers: 1,
    batsmen: 4,
    allRounders: 2,
    bowlers: 4,
    totalPoints: 0,
    rank: 0,
    status: "Ready"
  }
];

export const GAMES_LIST: GameItem[] = [
  {
    id: "fantasy-cricket",
    title: "Fantasy Cricket 11",
    category: "Fantasy Sports",
    tag: "FEATURED",
    prizePool: "+500 Demo Pts",
    playersCount: "28.4k players",
    bgGradient: "from-amber-600/30 to-orange-600/20",
    iconName: "Flame",
    description: "Draft your dream 11 squad with 2x Captain multiplier and top the demo leaderboard!"
  },
  {
    id: "cricket-quiz",
    title: "Cricket Master Quiz",
    category: "Trivia & IQ",
    tag: "HOT",
    prizePool: "+150 Demo Pts",
    playersCount: "19.8k players",
    bgGradient: "from-red-600/30 to-rose-600/20",
    iconName: "Radio",
    description: "5 fast-paced cricket history & match trivia questions with instant explanations!"
  },
  {
    id: "gk-quiz",
    title: "General Knowledge IQ",
    category: "Trivia & IQ",
    tag: "POPULAR",
    prizePool: "+150 Demo Pts",
    playersCount: "14.2k players",
    bgGradient: "from-blue-600/30 to-indigo-600/20",
    iconName: "Sparkles",
    description: "Test your brain across science, geography, technology and world records!"
  },
  {
    id: "puzzle-game",
    title: "Cricket Logic Puzzle",
    category: "Logic & Words",
    tag: "SKILL",
    prizePool: "+200 Demo Pts",
    playersCount: "11.5k players",
    bgGradient: "from-emerald-600/30 to-teal-600/20",
    iconName: "Award",
    description: "Unscramble iconic cricket legends, deliveries, and match equipment with clues!"
  },
  {
    id: "memory-game",
    title: "Cricket Memory Match",
    category: "Memory Arcade",
    tag: "FUN",
    prizePool: "+180 Demo Pts",
    playersCount: "16.9k players",
    bgGradient: "from-purple-600/30 to-fuchsia-600/20",
    iconName: "Zap",
    description: "Flip and match 6 pairs of cricket trophies, gear, and stumps in fewest turns!"
  }
];

export const UPCOMING_MATCHES: UpcomingMatch[] = [
  {
    id: "upcoming-1",
    tournament: "ICC Champions Trophy • Super 4",
    matchType: "ODI",
    startTime: "Today, 7:30 PM",
    countdown: "Starts in 2h 45m",
    team1: {
      name: "India",
      shortName: "IND",
      flagColor: "from-blue-600 to-sky-500",
      code: "IND"
    },
    team2: {
      name: "Pakistan",
      shortName: "PAK",
      flagColor: "from-emerald-700 to-green-600",
      code: "PAK"
    },
    venue: "Dubai International Stadium",
    megaContestPrize: "₹30,00,00,000",
    entryFee: 39
  },
  {
    id: "upcoming-2",
    tournament: "Indian T20 League • Match 28",
    matchType: "T20",
    startTime: "Tomorrow, 7:30 PM",
    countdown: "Tomorrow",
    team1: {
      name: "Chennai Super",
      shortName: "CSK",
      flagColor: "from-yellow-500 to-amber-600",
      code: "CSK"
    },
    team2: {
      name: "Mumbai Indians",
      shortName: "MI",
      flagColor: "from-blue-700 to-indigo-600",
      code: "MI"
    },
    venue: "Wankhede Stadium, Mumbai",
    megaContestPrize: "₹18,00,00,000",
    entryFee: 49
  },
  {
    id: "upcoming-3",
    tournament: "South Africa Tour of England",
    matchType: "T20",
    startTime: "Friday, 6:00 PM",
    countdown: "In 2 Days",
    team1: {
      name: "England",
      shortName: "ENG",
      flagColor: "from-rose-600 to-red-500",
      code: "ENG"
    },
    team2: {
      name: "South Africa",
      shortName: "SA",
      flagColor: "from-emerald-600 to-green-500",
      code: "SA"
    },
    venue: "The Oval, London",
    megaContestPrize: "₹8,00,00,000",
    entryFee: 29
  }
];

