// ============================================================================
// KhelMitra Fantasy Cricket Rules & Configurable Demo Points Engine
// 100% Free Demo Scoring Platform • No Real Money • No Betting • Skill-Only
// ============================================================================

import { FantasyPlayer } from '../types';

/**
 * Configurable Demo Scoring Rules Interface
 * Allows administrators and users to customize or test different scoring setups.
 */
export interface DemoScoringConfig {
  batting: {
    run: number;               // 1 point per run
    fourBonus: number;         // 1 bonus point per 4
    sixBonus: number;          // 2 bonus points per 6
    halfCenturyBonus: number;  // 8 bonus points for score >= 50
    centuryBonus: number;      // 16 bonus points for score >= 100
    duckPenalty: number;       // -2 points for dismissal on 0 (BAT, WK, AR)
    stackMilestones: boolean;  // false: Century replaces 50 bonus to prevent duplication
  };
  bowling: {
    wicket: number;            // 25 points per wicket (excluding run-outs)
    maidenOver: number;        // 8 points per maiden over bowled
    threeWicketsBonus: number; // 8 bonus points for 3 wickets in match
    fiveWicketsBonus: number;  // 16 bonus points for 5+ wickets in match
    stackHaulBonuses: boolean; // false: 5-wicket haul replaces 3-wicket bonus
  };
  fielding: {
    catch: number;             // 8 points per catch
    stumping: number;          // 12 points per stumping dismissal
    runOut: number;            // 6 points per run-out (direct/thrower/catcher)
    threeCatchesBonus: number; // 4 bonus points for 3 catches in match
  };
  multipliers: {
    captain: number;           // 2.0x demo points multiplier
    viceCaptain: number;       // 1.5x demo points multiplier
    standard: number;          // 1.0x standard points
  };
  match: {
    playingXIAnnouncement: number; // 4 demo points for being in starting XI
  };
}

/**
 * Official KhelMitra Demo Scoring Configuration
 * Batting:
 * - Run: 1 point
 * - Four: 1 bonus point
 * - Six: 2 bonus points
 * - Half-century: 8 bonus points
 * - Century: 16 bonus points
 * 
 * Bowling:
 * - Wicket: 25 points
 * - Maiden Over: 8 points
 * - 3 Wickets: 8 bonus points
 * - 5 Wickets: 16 bonus points
 * 
 * Fielding:
 * - Catch: 8 points
 * - Stumping: 12 points
 * - Run Out: 6 points
 * 
 * Multipliers:
 * - Captain: 2x demo points
 * - Vice-Captain: 1.5x demo points
 */
export const DEFAULT_DEMO_SCORING_CONFIG: DemoScoringConfig = {
  batting: {
    run: 1,
    fourBonus: 1,
    sixBonus: 2,
    halfCenturyBonus: 8,
    centuryBonus: 16,
    duckPenalty: -2,
    stackMilestones: false, // Standard fantasy rule: Century bonus replaces 50 bonus
  },
  bowling: {
    wicket: 25,
    maidenOver: 8,
    threeWicketsBonus: 8,
    fiveWicketsBonus: 16,
    stackHaulBonuses: false, // Standard fantasy rule: 5-wicket haul replaces 3-wicket bonus
  },
  fielding: {
    catch: 8,
    stumping: 12,
    runOut: 6,
    threeCatchesBonus: 4,
  },
  multipliers: {
    captain: 2.0,
    viceCaptain: 1.5,
    standard: 1.0,
  },
  match: {
    playingXIAnnouncement: 4,
  },
};

/**
 * Player Performance Input Stats Interface
 * Handles partial / missing data gracefully with defensive sanitation.
 */
export interface PlayerPerformanceStats {
  playerName?: string;
  role?: 'WK' | 'BAT' | 'AR' | 'BOWL';
  inPlayingXI?: boolean;
  // Batting
  runs?: number;
  ballsFaced?: number;
  fours?: number;
  sixes?: number;
  isDismissed?: boolean;
  dismissalType?: string;
  // Bowling
  oversBowled?: number;
  maidens?: number;
  wickets?: number;
  runsConceded?: number;
  // Fielding
  catches?: number;
  stumpings?: number;
  runOuts?: number;
}

export interface SanitizedPlayerPerformanceStats {
  playerName: string;
  role: 'WK' | 'BAT' | 'AR' | 'BOWL';
  inPlayingXI: boolean;
  runs: number;
  ballsFaced: number;
  fours: number;
  sixes: number;
  isDismissed: boolean;
  dismissalType: string;
  oversBowled: number;
  maidens: number;
  wickets: number;
  runsConceded: number;
  catches: number;
  stumpings: number;
  runOuts: number;
}

export interface CalculationLineItem {
  id: string;
  category: 'Batting' | 'Bowling' | 'Fielding' | 'Match' | 'Multiplier';
  label: string;
  count: number;
  rate: number | string;
  points: number;
  isBonus?: boolean;
  note?: string;
}

export interface PlayerPointsCalculationResult {
  playerName: string;
  role: string;
  basePoints: number;
  battingPoints: number;
  bowlingPoints: number;
  fieldingPoints: number;
  matchPoints: number;
  multiplier: number;
  multiplierType: 'captain' | 'viceCaptain' | 'none';
  multiplierBonusPoints: number;
  totalDemoPoints: number;
  lineItems: CalculationLineItem[];
  deduplicationNotes: string[];
}

export interface TeamPointsCalculationResult {
  teamTotalPoints: number;
  totalBasePoints: number;
  totalCaptainBonus: number;
  totalViceCaptainBonus: number;
  captainName: string;
  viceCaptainName: string;
  playerCount: number;
  playerResults: PlayerPointsCalculationResult[];
  roleCounts: { wk: number; bat: number; ar: number; bowl: number };
}

/**
 * Pure, safe calculation of demo points for an individual player performance
 * - Defends against undefined/null/NaN values
 * - Strictly avoids duplicate points through explicit deduplication logic
 * - Supports custom configurable scoring setups
 */
export function calculatePlayerDemoPoints(
  stats: Partial<PlayerPerformanceStats> | null | undefined,
  roleMultiplier: 'captain' | 'viceCaptain' | 'none' = 'none',
  config: DemoScoringConfig = DEFAULT_DEMO_SCORING_CONFIG
): PlayerPointsCalculationResult {
  // Safe default fallbacks
  const safeStats: SanitizedPlayerPerformanceStats = {
    playerName: stats?.playerName || 'Player',
    role: stats?.role || 'BAT',
    inPlayingXI: stats?.inPlayingXI !== undefined ? Boolean(stats.inPlayingXI) : true,
    runs: Math.max(0, Math.floor(Number(stats?.runs) || 0)),
    ballsFaced: Math.max(0, Math.floor(Number(stats?.ballsFaced) || 0)),
    fours: Math.max(0, Math.floor(Number(stats?.fours) || 0)),
    sixes: Math.max(0, Math.floor(Number(stats?.sixes) || 0)),
    isDismissed: Boolean(stats?.isDismissed),
    dismissalType: stats?.dismissalType || '',
    oversBowled: Math.max(0, Number(stats?.oversBowled) || 0),
    maidens: Math.max(0, Math.floor(Number(stats?.maidens) || 0)),
    wickets: Math.max(0, Math.floor(Number(stats?.wickets) || 0)),
    runsConceded: Math.max(0, Math.floor(Number(stats?.runsConceded) || 0)),
    catches: Math.max(0, Math.floor(Number(stats?.catches) || 0)),
    stumpings: Math.max(0, Math.floor(Number(stats?.stumpings) || 0)),
    runOuts: Math.max(0, Math.floor(Number(stats?.runOuts) || 0)),
  };

  const lineItems: CalculationLineItem[] = [];
  const deduplicationNotes: string[] = [];

  let battingPoints = 0;
  let bowlingPoints = 0;
  let fieldingPoints = 0;
  let matchPoints = 0;

  // 1. MATCH RESULT / STARTING XI POINTS
  if (safeStats.inPlayingXI && config.match.playingXIAnnouncement > 0) {
    const pts = config.match.playingXIAnnouncement;
    matchPoints += pts;
    lineItems.push({
      id: 'xi-announcement',
      category: 'Match',
      label: 'Starting XI Announcement',
      count: 1,
      rate: `+${pts} pts`,
      points: pts,
      note: 'Awarded to all 11 players confirmed in starting lineup',
    });
  }

  // 2. BATTING POINTS
  // Runs: 1 pt per run
  if (safeStats.runs > 0) {
    const runsPts = safeStats.runs * config.batting.run;
    battingPoints += runsPts;
    lineItems.push({
      id: 'bat-runs',
      category: 'Batting',
      label: 'Runs Scored',
      count: safeStats.runs,
      rate: `+${config.batting.run} pt/run`,
      points: runsPts,
    });
  }

  // Fours: 1 bonus point per 4
  if (safeStats.fours > 0) {
    const foursPts = safeStats.fours * config.batting.fourBonus;
    battingPoints += foursPts;
    lineItems.push({
      id: 'bat-fours',
      category: 'Batting',
      label: 'Boundary Bonus (4s)',
      count: safeStats.fours,
      rate: `+${config.batting.fourBonus} bonus pt`,
      points: foursPts,
      isBonus: true,
    });
  }

  // Sixes: 2 bonus points per 6
  if (safeStats.sixes > 0) {
    const sixesPts = safeStats.sixes * config.batting.sixBonus;
    battingPoints += sixesPts;
    lineItems.push({
      id: 'bat-sixes',
      category: 'Batting',
      label: 'Six Bonus (6s)',
      count: safeStats.sixes,
      rate: `+${config.batting.sixBonus} bonus pts`,
      points: sixesPts,
      isBonus: true,
    });
  }

  // Milestone Bonuses with Anti-Duplication Handling
  if (safeStats.runs >= 100) {
    // Century: 16 bonus points
    const centuryPts = config.batting.centuryBonus;
    battingPoints += centuryPts;
    lineItems.push({
      id: 'bat-century',
      category: 'Batting',
      label: 'Century Bonus (100+ Runs)',
      count: 1,
      rate: `+${centuryPts} bonus pts`,
      points: centuryPts,
      isBonus: true,
      note: 'Deduplicated: Century milestone replaces half-century bonus',
    });

    if (config.batting.stackMilestones) {
      // If configured to stack
      const halfPts = config.batting.halfCenturyBonus;
      battingPoints += halfPts;
      lineItems.push({
        id: 'bat-half-century-stacked',
        category: 'Batting',
        label: 'Half-Century Bonus (Stacked)',
        count: 1,
        rate: `+${halfPts} bonus pts`,
        points: halfPts,
        isBonus: true,
      });
    } else {
      deduplicationNotes.push(
        'Century achieved (100+): +16 pts awarded. Half-century (+8 pts) is not double-counted.'
      );
    }
  } else if (safeStats.runs >= 50) {
    // Half-century: 8 bonus points
    const halfPts = config.batting.halfCenturyBonus;
    battingPoints += halfPts;
    lineItems.push({
      id: 'bat-half-century',
      category: 'Batting',
      label: 'Half-Century Bonus (50-99 Runs)',
      count: 1,
      rate: `+${halfPts} bonus pts`,
      points: halfPts,
      isBonus: true,
    });
  }

  // Duck Penalty: -2 pts for BAT, WK, AR dismissed for 0
  if (
    safeStats.isDismissed &&
    safeStats.runs === 0 &&
    safeStats.ballsFaced > 0 &&
    safeStats.role !== 'BOWL' &&
    config.batting.duckPenalty !== 0
  ) {
    battingPoints += config.batting.duckPenalty;
    lineItems.push({
      id: 'bat-duck',
      category: 'Batting',
      label: 'Duck Dismissal Penalty',
      count: 1,
      rate: `${config.batting.duckPenalty} pts`,
      points: config.batting.duckPenalty,
      note: 'Applicable to Batters, Wicketkeepers & All-Rounders out for 0',
    });
  }

  // 3. BOWLING POINTS
  // Wickets: 25 points per wicket
  if (safeStats.wickets > 0) {
    const wktPts = safeStats.wickets * config.bowling.wicket;
    bowlingPoints += wktPts;
    lineItems.push({
      id: 'bowl-wickets',
      category: 'Bowling',
      label: 'Wickets Taken',
      count: safeStats.wickets,
      rate: `+${config.bowling.wicket} pts/wicket`,
      points: wktPts,
      note: 'Bowled, Caught, LBW, Stumped, Hit Wicket',
    });
  }

  // Maiden Overs: 8 points per maiden
  if (safeStats.maidens > 0) {
    const maidenPts = safeStats.maidens * config.bowling.maidenOver;
    bowlingPoints += maidenPts;
    lineItems.push({
      id: 'bowl-maidens',
      category: 'Bowling',
      label: 'Maiden Overs',
      count: safeStats.maidens,
      rate: `+${config.bowling.maidenOver} pts/maiden`,
      points: maidenPts,
    });
  }

  // Wicket Haul Bonuses with Anti-Duplication
  if (safeStats.wickets >= 5) {
    // 5 Wickets: 16 bonus points
    const fiveWktPts = config.bowling.fiveWicketsBonus;
    bowlingPoints += fiveWktPts;
    lineItems.push({
      id: 'bowl-5w-haul',
      category: 'Bowling',
      label: '5-Wicket Haul Bonus',
      count: 1,
      rate: `+${fiveWktPts} bonus pts`,
      points: fiveWktPts,
      isBonus: true,
      note: 'Deduplicated: 5-wicket haul replaces 3-wicket bonus',
    });

    if (config.bowling.stackHaulBonuses) {
      const threeWktPts = config.bowling.threeWicketsBonus;
      bowlingPoints += threeWktPts;
      lineItems.push({
        id: 'bowl-3w-haul-stacked',
        category: 'Bowling',
        label: '3-Wicket Haul (Stacked)',
        count: 1,
        rate: `+${threeWktPts} bonus pts`,
        points: threeWktPts,
        isBonus: true,
      });
    } else {
      deduplicationNotes.push(
        '5-Wicket Haul achieved: +16 pts awarded. 3-Wicket bonus (+8 pts) is not double-counted.'
      );
    }
  } else if (safeStats.wickets >= 3) {
    // 3 Wickets: 8 bonus points
    const threeWktPts = config.bowling.threeWicketsBonus;
    bowlingPoints += threeWktPts;
    lineItems.push({
      id: 'bowl-3w-haul',
      category: 'Bowling',
      label: '3-Wicket Haul Bonus',
      count: 1,
      rate: `+${threeWktPts} bonus pts`,
      points: threeWktPts,
      isBonus: true,
    });
  }

  // 4. FIELDING POINTS
  // Catch: 8 points
  if (safeStats.catches > 0) {
    const catchPts = safeStats.catches * config.fielding.catch;
    fieldingPoints += catchPts;
    lineItems.push({
      id: 'field-catches',
      category: 'Fielding',
      label: 'Catches Taken',
      count: safeStats.catches,
      rate: `+${config.fielding.catch} pts/catch`,
      points: catchPts,
    });

    // 3 Catches Bonus: +4 bonus points if 3+ catches taken
    if (safeStats.catches >= 3 && config.fielding.threeCatchesBonus > 0) {
      fieldingPoints += config.fielding.threeCatchesBonus;
      lineItems.push({
        id: 'field-3-catches-bonus',
        category: 'Fielding',
        label: '3-Catch Milestone Bonus',
        count: 1,
        rate: `+${config.fielding.threeCatchesBonus} bonus pts`,
        points: config.fielding.threeCatchesBonus,
        isBonus: true,
      });
    }
  }

  // Stumping: 12 points
  if (safeStats.stumpings > 0) {
    const stumpPts = safeStats.stumpings * config.fielding.stumping;
    fieldingPoints += stumpPts;
    lineItems.push({
      id: 'field-stumpings',
      category: 'Fielding',
      label: 'Stumpings (WK)',
      count: safeStats.stumpings,
      rate: `+${config.fielding.stumping} pts/stumping`,
      points: stumpPts,
    });
  }

  // Run Out: 6 points
  if (safeStats.runOuts > 0) {
    const roPts = safeStats.runOuts * config.fielding.runOut;
    fieldingPoints += roPts;
    lineItems.push({
      id: 'field-runouts',
      category: 'Fielding',
      label: 'Run Out Dismissals',
      count: safeStats.runOuts,
      rate: `+${config.fielding.runOut} pts/run-out`,
      points: roPts,
      note: 'Credited to thrower and/or catcher involved in dismissal',
    });
  }

  // SUBTOTAL BASE POINTS
  const basePoints = battingPoints + bowlingPoints + fieldingPoints + matchPoints;

  // 5. CAPTAIN / VICE-CAPTAIN MULTIPLIERS
  let multiplier = config.multipliers.standard;
  let multiplierBonusPoints = 0;

  if (roleMultiplier === 'captain') {
    multiplier = config.multipliers.captain; // 2.0x
    multiplierBonusPoints = basePoints * (multiplier - 1.0); // +100% of base points
    lineItems.push({
      id: 'multiplier-captain',
      category: 'Multiplier',
      label: 'Captain Multiplier (2.0x)',
      count: 1,
      rate: '2.0x Total Demo Points',
      points: Math.round(multiplierBonusPoints * 10) / 10,
      note: 'Captain earns 2x demo points (Base points doubled)',
    });
  } else if (roleMultiplier === 'viceCaptain') {
    multiplier = config.multipliers.viceCaptain; // 1.5x
    multiplierBonusPoints = basePoints * (multiplier - 1.0); // +50% of base points
    lineItems.push({
      id: 'multiplier-vice-captain',
      category: 'Multiplier',
      label: 'Vice-Captain Multiplier (1.5x)',
      count: 1,
      rate: '1.5x Total Demo Points',
      points: Math.round(multiplierBonusPoints * 10) / 10,
      note: 'Vice-Captain earns 1.5x demo points (+50% bonus)',
    });
  }

  const totalDemoPoints = Math.round((basePoints * multiplier) * 10) / 10;

  return {
    playerName: safeStats.playerName,
    role: safeStats.role,
    basePoints: Math.round(basePoints * 10) / 10,
    battingPoints: Math.round(battingPoints * 10) / 10,
    bowlingPoints: Math.round(bowlingPoints * 10) / 10,
    fieldingPoints: Math.round(fieldingPoints * 10) / 10,
    matchPoints: Math.round(matchPoints * 10) / 10,
    multiplier,
    multiplierType: roleMultiplier,
    multiplierBonusPoints: Math.round(multiplierBonusPoints * 10) / 10,
    totalDemoPoints,
    lineItems,
    deduplicationNotes,
  };
}

/**
 * Calculates total demo points for an entire fantasy squad of 11 players
 * Total Team Points Formula:
 * Team Total = Sum of All 11 Base Points + (Captain Base Points * 1.0) + (Vice-Captain Base Points * 0.5)
 */
export function calculateTeamTotalPoints(
  players: FantasyPlayer[],
  captainId?: string | null,
  viceCaptainId?: string | null,
  config: DemoScoringConfig = DEFAULT_DEMO_SCORING_CONFIG
): TeamPointsCalculationResult {
  let totalBasePoints = 0;
  let totalCaptainBonus = 0;
  let totalViceCaptainBonus = 0;

  let captainName = 'Not Selected';
  let viceCaptainName = 'Not Selected';

  const roleCounts = { wk: 0, bat: 0, ar: 0, bowl: 0 };
  const playerResults: PlayerPointsCalculationResult[] = [];

  players.forEach((p) => {
    if (p.role === 'WK') roleCounts.wk++;
    else if (p.role === 'BAT') roleCounts.bat++;
    else if (p.role === 'AR') roleCounts.ar++;
    else if (p.role === 'BOWL') roleCounts.bowl++;

    const isCap = Boolean(captainId && (p.id === captainId || p.isCaptain));
    const isVc = Boolean(viceCaptainId && (p.id === viceCaptainId || p.isViceCaptain));

    if (isCap) captainName = p.name;
    if (isVc) viceCaptainName = p.name;

    const multiplierType = isCap ? 'captain' : isVc ? 'viceCaptain' : 'none';

    // Approximate performance from points if detailed performance stats aren't attached
    const simulatedStats: PlayerPerformanceStats = {
      playerName: p.name,
      role: p.role,
      inPlayingXI: true,
      // Derive baseline stats from player demo points
      runs: p.role === 'BAT' || p.role === 'WK' ? Math.floor(p.points * 0.65) : Math.floor(p.points * 0.2),
      fours: p.role === 'BAT' ? Math.floor(p.points / 18) : 1,
      sixes: p.role === 'BAT' ? Math.floor(p.points / 28) : 0,
      wickets: p.role === 'BOWL' ? Math.max(1, Math.floor(p.points / 30)) : p.role === 'AR' ? 1 : 0,
      maidens: p.role === 'BOWL' && p.points > 60 ? 1 : 0,
      catches: 1,
      stumpings: p.role === 'WK' ? 1 : 0,
      runOuts: 0,
    };

    const calc = calculatePlayerDemoPoints(simulatedStats, multiplierType, config);
    // Use player's stored points as base if available for consistency
    const playerBase = p.points > 0 ? p.points : calc.basePoints;
    totalBasePoints += playerBase;

    let finalPts = playerBase;
    if (isCap) {
      const capBonus = playerBase; // 2x means +1x bonus
      totalCaptainBonus += capBonus;
      finalPts += capBonus;
    } else if (isVc) {
      const vcBonus = Math.round(playerBase * 0.5 * 10) / 10; // 1.5x means +0.5x bonus
      totalViceCaptainBonus += vcBonus;
      finalPts += vcBonus;
    }

    playerResults.push({
      ...calc,
      basePoints: playerBase,
      multiplier: isCap ? 2.0 : isVc ? 1.5 : 1.0,
      multiplierType,
      multiplierBonusPoints: isCap ? playerBase : isVc ? Math.round(playerBase * 0.5 * 10) / 10 : 0,
      totalDemoPoints: Math.round(finalPts * 10) / 10,
    });
  });

  const teamTotalPoints =
    Math.round((totalBasePoints + totalCaptainBonus + totalViceCaptainBonus) * 10) / 10;

  return {
    teamTotalPoints,
    totalBasePoints: Math.round(totalBasePoints * 10) / 10,
    totalCaptainBonus: Math.round(totalCaptainBonus * 10) / 10,
    totalViceCaptainBonus: Math.round(totalViceCaptainBonus * 10) / 10,
    captainName,
    viceCaptainName,
    playerCount: players.length,
    playerResults,
    roleCounts,
  };
}

// ============================================================================
// Structured Rules Documentation & Explanations for UI Display
// ============================================================================

export interface RuleSection {
  id: string;
  title: string;
  subtitle: string;
  badge?: string;
  items: {
    title: string;
    points?: string;
    description: string;
    badge?: string;
    example?: string;
  }[];
}

export const FANTASY_RULES_DOCUMENTATION: RuleSection[] = [
  {
    id: 'player-selection',
    title: 'Player Selection Rules',
    subtitle: 'Official squad composition criteria for every 11-player lineup',
    badge: '11 PLAYERS • 100 CREDITS',
    items: [
      {
        title: 'Exactly 11 Players Required',
        description:
          'Your fantasy squad must contain exactly 11 active players selected from the two competing teams in the match.',
        badge: 'MANDATORY',
      },
      {
        title: 'Squad Role Balance (WK, BAT, AR, BOWL)',
        description:
          'To ensure realistic cricket strategy, your 11 players must satisfy the following role brackets:',
        example: '• Wicket-Keeper (WK): 1 to 4\n• Batsmen (BAT): 3 to 6\n• All-Rounders (AR): 1 to 4\n• Bowlers (BOWL): 3 to 6',
      },
      {
        title: 'Maximum 7 Players Per Team',
        description:
          'You cannot select more than 7 players from a single real-world team. Balanced team representation ensures fair tactical gameplay.',
        badge: 'MAX 7/11',
      },
      {
        title: '100 Credits Salary Cap',
        description:
          'Every player has an assigned credit cost (e.g., 8.0 to 10.5 credits). The total cost of all 11 selected players cannot exceed 100.0 credits.',
        badge: '≤ 100.0 CR',
      },
      {
        title: 'Official Toss & Lineup Deadline',
        description:
          'Squad modifications lock at the official match toss when the verified Playing 11 is released. Any player announced in the starting 11 gets +4 demo points.',
      },
    ],
  },
  {
    id: 'captain-vice-captain',
    title: 'Captain & Vice-Captain Rules',
    subtitle: 'Multiply your scoring leverage with tactical leadership picks',
    badge: '2.0x & 1.5x MULTIPLIER',
    items: [
      {
        title: 'Captain (C) — 2.0x Demo Points',
        points: '2.0x Multiplier',
        description:
          'Your designated Captain receives double (200%) of their earned demo points across batting, bowling, and fielding.',
        example: 'If your Captain scores 85 base points, your squad earns 170.0 demo points from them!',
      },
      {
        title: 'Vice-Captain (VC) — 1.5x Demo Points',
        points: '1.5x Multiplier',
        description:
          'Your designated Vice-Captain receives 150% (1.5x) of their total demo points earned during the match.',
        example: 'If your Vice-Captain scores 60 base points, your squad earns 90.0 demo points from them.',
      },
      {
        title: 'Distinct Players Mandate',
        description:
          'Captain and Vice-Captain cannot be the same player. Both roles must be assigned to different players in your 11.',
        badge: 'DISTINCT',
      },
      {
        title: 'Negative Points Multiplication',
        description:
          'Multipliers also apply to penalties: if your Captain incurs a duck penalty (-2 pts), it doubles to -4 demo points.',
      },
    ],
  },
  {
    id: 'batting-points',
    title: 'Batting Demo Points',
    subtitle: 'Points awarded for runs, boundaries, and milestone achievements',
    badge: 'RUNS & BOUNDARIES',
    items: [
      {
        title: 'Run Scored',
        points: '+1 pt',
        description: 'Every individual run scored off the bat by the batsman.',
      },
      {
        title: 'Boundary Bonus (Four)',
        points: '+1 bonus pt',
        description: 'Awarded for every boundary (4) hit in addition to the 4 run points.',
        example: 'Hitting a 4 earns 4 (runs) + 1 (bonus) = 5 total demo points.',
      },
      {
        title: 'Six Bonus',
        points: '+2 bonus pts',
        description: 'Awarded for every six hit in addition to the 6 run points.',
        example: 'Hitting a 6 earns 6 (runs) + 2 (bonus) = 8 total demo points.',
      },
      {
        title: 'Half-Century (50 Runs)',
        points: '+8 bonus pts',
        description: 'Awarded once a batsman crosses 50 runs in an innings (50 to 99 runs).',
      },
      {
        title: 'Century (100 Runs)',
        points: '+16 bonus pts',
        description: 'Awarded once a batsman reaches 100 runs. Deduplicated: replaces 50-run bonus.',
      },
      {
        title: 'Duck Dismissal Penalty',
        points: '-2 pts',
        description: 'Deducted if a Batter, Wicketkeeper, or All-Rounder is dismissed for 0 runs (balls faced > 0).',
      },
    ],
  },
  {
    id: 'bowling-points',
    title: 'Bowling Demo Points',
    subtitle: 'Points awarded for dismissals, maiden overs, and multi-wicket hauls',
    badge: 'WICKETS & HAULS',
    items: [
      {
        title: 'Wicket Taken',
        points: '+25 pts',
        description: 'Awarded for every wicket (Bowled, Caught, LBW, Stumped, Hit Wicket). Run outs excluded.',
      },
      {
        title: 'Maiden Over',
        points: '+8 pts',
        description: 'Awarded for every completed over in which zero runs are conceded off the bat or extras.',
      },
      {
        title: '3-Wicket Haul Bonus',
        points: '+8 bonus pts',
        description: 'Awarded when a bowler claims 3 or 4 wickets in a single match.',
      },
      {
        title: '5-Wicket Haul Bonus',
        points: '+16 bonus pts',
        description: 'Awarded when a bowler claims 5 or more wickets in a match. Deduplicated: replaces 3-wicket bonus.',
      },
    ],
  },
  {
    id: 'fielding-points',
    title: 'Fielding Demo Points',
    subtitle: 'Points awarded for catches, stumpings, and direct/indirect run outs',
    badge: 'CATCHES & STUMPINGS',
    items: [
      {
        title: 'Catch Taken',
        points: '+8 pts',
        description: 'Awarded to any fielder or wicketkeeper who completes a legal catch resulting in dismissal.',
      },
      {
        title: 'Stumping Dismissal',
        points: '+12 pts',
        description: 'Awarded exclusively to the active Wicketkeeper executing a stumping dismissal.',
      },
      {
        title: 'Run Out Dismissal',
        points: '+6 pts',
        description: 'Awarded to fielders executing a run out dismissal (thrower and/or catcher involved).',
      },
    ],
  },
  {
    id: 'match-results',
    title: 'Match Result & Starting XI Points',
    subtitle: 'Points for official team sheet confirmation and match participation',
    badge: 'STARTING XI',
    items: [
      {
        title: 'Playing XI Announcement',
        points: '+4 pts',
        description: 'Awarded to every selected player who is officially named in the confirmed match Starting XI.',
      },
      {
        title: 'Substitute / Impact Player',
        points: 'Active Play Only',
        description: 'Concussion or tactical substitutes earn points only for physical actions completed on the field.',
      },
      {
        title: 'Super Over Exclusion',
        points: 'No Points',
        description: 'In accordance with standard fantasy sports guidelines, runs and wickets in a Super Over do not count towards match fantasy points.',
      },
    ],
  },
  {
    id: 'deduplication-policy',
    title: 'Anti-Duplication & Fair Play Policy',
    subtitle: 'How KhelMitra guarantees transparent, non-duplicate calculations',
    badge: '100% FAIR PLAY',
    items: [
      {
        title: 'Milestone Bonus Deduplication',
        description:
          'To prevent inflating scores, when a player scores 100+ runs, only the Century bonus (+16 pts) applies. The Half-Century bonus (+8 pts) is not double-counted.',
        badge: 'NO DOUBLE DIP',
      },
      {
        title: 'Haul Bonus Deduplication',
        description:
          'When a bowler claims 5+ wickets, the 5-Wicket Haul bonus (+16 pts) replaces the 3-Wicket bonus (+8 pts).',
        badge: 'NO DOUBLE DIP',
      },
      {
        title: '100% Free Demo Platform',
        description:
          'KhelMitra is strictly a free-to-play sports fan simulation app. No real-money wagers, no cash entry fees, and no sports betting.',
        badge: 'FREE DEMO',
      },
      {
        title: 'Platform Scoring Variance Notice',
        description:
          'Actual fantasy cricket rules and scoring weights may vary between commercial fantasy operators (Dream11, MPL, My11Circle). KhelMitra follows clean demo rules.',
        badge: 'NOTICE',
      },
    ],
  },
];

// Presets for instant interactive testing in simulator
export const SIMULATOR_PRESET_PLAYERS: {
  name: string;
  role: 'WK' | 'BAT' | 'AR' | 'BOWL';
  team: string;
  stats: PlayerPerformanceStats;
}[] = [
  {
    name: 'Virat Kohli',
    role: 'BAT',
    team: 'IND',
    stats: {
      playerName: 'Virat Kohli',
      role: 'BAT',
      inPlayingXI: true,
      runs: 74,
      ballsFaced: 42,
      fours: 6,
      sixes: 4,
      isDismissed: true,
      oversBowled: 0,
      maidens: 0,
      wickets: 0,
      runsConceded: 0,
      catches: 1,
      stumpings: 0,
      runOuts: 0,
    },
  },
  {
    name: 'Jasprit Bumrah',
    role: 'BOWL',
    team: 'IND',
    stats: {
      playerName: 'Jasprit Bumrah',
      role: 'BOWL',
      inPlayingXI: true,
      runs: 4,
      ballsFaced: 3,
      fours: 0,
      sixes: 0,
      isDismissed: false,
      oversBowled: 4.0,
      maidens: 1,
      wickets: 3,
      runsConceded: 18,
      catches: 0,
      stumpings: 0,
      runOuts: 0,
    },
  },
  {
    name: 'Travis Head',
    role: 'BAT',
    team: 'AUS',
    stats: {
      playerName: 'Travis Head',
      role: 'BAT',
      inPlayingXI: true,
      runs: 108,
      ballsFaced: 58,
      fours: 11,
      sixes: 5,
      isDismissed: true,
      oversBowled: 1.0,
      maidens: 0,
      wickets: 0,
      runsConceded: 9,
      catches: 0,
      stumpings: 0,
      runOuts: 0,
    },
  },
  {
    name: 'Hardik Pandya',
    role: 'AR',
    team: 'IND',
    stats: {
      playerName: 'Hardik Pandya',
      role: 'AR',
      inPlayingXI: true,
      runs: 38,
      ballsFaced: 20,
      fours: 3,
      sixes: 2,
      isDismissed: false,
      oversBowled: 3.0,
      maidens: 0,
      wickets: 2,
      runsConceded: 24,
      catches: 1,
      stumpings: 0,
      runOuts: 1,
    },
  },
  {
    name: 'Rishabh Pant',
    role: 'WK',
    team: 'IND',
    stats: {
      playerName: 'Rishabh Pant',
      role: 'WK',
      inPlayingXI: true,
      runs: 42,
      ballsFaced: 28,
      fours: 4,
      sixes: 1,
      isDismissed: true,
      oversBowled: 0,
      maidens: 0,
      wickets: 0,
      runsConceded: 0,
      catches: 2,
      stumpings: 1,
      runOuts: 0,
    },
  },
  {
    name: 'Mitchell Starc',
    role: 'BOWL',
    team: 'AUS',
    stats: {
      playerName: 'Mitchell Starc',
      role: 'BOWL',
      inPlayingXI: true,
      runs: 12,
      ballsFaced: 8,
      fours: 1,
      sixes: 1,
      isDismissed: false,
      oversBowled: 4.0,
      maidens: 1,
      wickets: 5,
      runsConceded: 28,
      catches: 0,
      stumpings: 0,
      runOuts: 0,
    },
  },
];
