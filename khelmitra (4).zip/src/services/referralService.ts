import { demoPointsService } from './demoPointsService';

export interface ReferredFriend {
  id: string;
  name: string;
  username: string;
  avatar: string;
  joinedDate: string;
  rewardCoins: number;
  status: 'CLAIMED' | 'PENDING';
}

export interface ReferralStats {
  userCode: string;
  totalInvited: number;
  totalCoinsEarned: number;
  redeemedCode: string | null;
  hasRedeemedBonus: boolean;
}

const REFERRAL_STORAGE_KEY = 'khelmitra_referrals_v1';
const REDEEMED_STORAGE_KEY = 'khelmitra_redeemed_code_v1';
const USER_REFERRAL_CODE = 'KHELM-ARJUN77';

const INITIAL_FRIENDS: ReferredFriend[] = [
  {
    id: 'ref-1',
    name: 'Rahul Sharma',
    username: 'rahul_cricketer',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=120&auto=format&fit=crop&q=80',
    joinedDate: 'Yesterday',
    rewardCoins: 1000,
    status: 'CLAIMED',
  },
  {
    id: 'ref-2',
    name: 'Pooja Nair',
    username: 'pooja_queen',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&auto=format&fit=crop&q=80',
    joinedDate: '3 days ago',
    rewardCoins: 1000,
    status: 'CLAIMED',
  },
  {
    id: 'ref-3',
    name: 'Vikas Patel',
    username: 'vikas_teenpatti',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=120&auto=format&fit=crop&q=80',
    joinedDate: '5 days ago',
    rewardCoins: 1000,
    status: 'CLAIMED',
  },
  {
    id: 'ref-4',
    name: 'Siddharth Rao',
    username: 'sid_ludoking',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    joinedDate: '1 week ago',
    rewardCoins: 1000,
    status: 'CLAIMED',
  },
];

class ReferralService {
  private friends: ReferredFriend[];
  private redeemedCode: string | null;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.friends = this.loadFriends();
    this.redeemedCode = this.loadRedeemedCode();
  }

  private loadFriends(): ReferredFriend[] {
    try {
      const saved = localStorage.getItem(REFERRAL_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return INITIAL_FRIENDS;
  }

  private saveFriends() {
    try {
      localStorage.setItem(REFERRAL_STORAGE_KEY, JSON.stringify(this.friends));
    } catch {
      // Fallback
    }
  }

  private loadRedeemedCode(): string | null {
    try {
      return localStorage.getItem(REDEEMED_STORAGE_KEY);
    } catch {
      return null;
    }
  }

  private saveRedeemedCode(code: string) {
    try {
      localStorage.setItem(REDEEMED_STORAGE_KEY, code);
      this.redeemedCode = code;
    } catch {
      // Fallback
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public getCode(): string {
    return USER_REFERRAL_CODE;
  }

  public getShareMessage(): string {
    return `Hey! Join me on KhelMitra to play Call Break, Teen Patti, Ludo & Indian Rummy completely FREE! 🎮🔥 Use my code *${USER_REFERRAL_CODE}* to get 500 Free Welcome Coins: https://khelmitra.app/join?ref=${USER_REFERRAL_CODE}`;
  }

  public getShareUrl(): string {
    return `https://khelmitra.app/join?ref=${USER_REFERRAL_CODE}`;
  }

  public getFriends(): ReferredFriend[] {
    return [...this.friends];
  }

  public getStats(): ReferralStats {
    const totalCoins = this.friends.reduce((sum, f) => (f.status === 'CLAIMED' ? sum + f.rewardCoins : sum), 0);
    return {
      userCode: USER_REFERRAL_CODE,
      totalInvited: this.friends.length,
      totalCoinsEarned: totalCoins,
      redeemedCode: this.redeemedCode,
      hasRedeemedBonus: !!this.redeemedCode,
    };
  }

  public redeemCode(code: string): { success: boolean; message: string; coinsAdded?: number } {
    const trimmed = code.trim().toUpperCase();
    if (!trimmed) {
      return { success: false, message: 'Please enter a valid referral code.' };
    }

    if (trimmed === USER_REFERRAL_CODE) {
      return { success: false, message: 'You cannot use your own referral code!' };
    }

    if (this.redeemedCode) {
      return {
        success: false,
        message: `You have already redeemed referral code "${this.redeemedCode}". Only 1 redemption allowed per account.`,
      };
    }

    // Accept valid format e.g. KHELM-XXXX or any referral code
    const bonus = 500;
    this.saveRedeemedCode(trimmed);
    demoPointsService.addPoints(bonus, 'Referral Bonus', `Friend invite code bonus (${trimmed})`);
    this.notify();

    return {
      success: true,
      message: `Success! Code "${trimmed}" redeemed. 500 Free Coins added to your wallet!`,
      coinsAdded: bonus,
    };
  }

  public simulateNewFriendJoin(friendName?: string): { friend: ReferredFriend; coinsEarned: number } {
    const names = ['Karan Mehta', 'Ananya Roy', 'Deepak Singh', 'Sneha Joshi', 'Manish Gupta', 'Rohit Verma'];
    const chosenName = friendName || names[Math.floor(Math.random() * names.length)];
    const username = chosenName.toLowerCase().replace(/\s+/g, '_') + Math.floor(Math.random() * 90 + 10);
    
    const newFriend: ReferredFriend = {
      id: `ref-${Date.now()}`,
      name: chosenName,
      username,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`,
      joinedDate: 'Just now',
      rewardCoins: 1000,
      status: 'CLAIMED',
    };

    this.friends.unshift(newFriend);
    this.saveFriends();

    // Reward user with 1,000 Coins
    demoPointsService.addPoints(1000, 'Referral Reward', `Bonus for inviting ${chosenName}`);
    this.notify();

    return { friend: newFriend, coinsEarned: 1000 };
  }
}

export const referralService = new ReferralService();
