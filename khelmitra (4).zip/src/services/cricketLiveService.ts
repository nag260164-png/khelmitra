import { LiveMatch, BallCommentary } from '../types';
import { COMPREHENSIVE_MATCHES } from '../data/cricketData';

type MatchChangeListener = (matches: LiveMatch[], isSimulatedError: boolean) => void;

class CricketLiveService {
  private matches: LiveMatch[] = JSON.parse(JSON.stringify(COMPREHENSIVE_MATCHES));
  private listeners: Set<MatchChangeListener> = new Set();
  private isError: boolean = false;
  private autoRefreshEnabled: boolean = true;
  private refreshIntervalSeconds: number = 10;
  private countdown: number = 10;
  private timerId: any = null;
  private lastUpdated: Date = new Date();

  constructor() {
    this.startAutoRefreshLoop();
  }

  public getMatches(): LiveMatch[] {
    return this.matches;
  }

  public getMatchById(id: string): LiveMatch | undefined {
    return this.matches.find((m) => m.id === id);
  }

  public getLiveMatches(): LiveMatch[] {
    return this.matches.filter((m) => m.status === 'LIVE');
  }

  public getUpcomingMatches(): LiveMatch[] {
    return this.matches.filter((m) => m.status === 'UPCOMING');
  }

  public getCompletedMatches(): LiveMatch[] {
    return this.matches.filter((m) => m.status === 'COMPLETED');
  }

  public isAutoRefreshActive(): boolean {
    return this.autoRefreshEnabled;
  }

  public toggleAutoRefresh(): boolean {
    this.autoRefreshEnabled = !this.autoRefreshEnabled;
    this.countdown = this.refreshIntervalSeconds;
    this.notify();
    return this.autoRefreshEnabled;
  }

  public setAutoRefresh(enabled: boolean) {
    this.autoRefreshEnabled = enabled;
    this.countdown = this.refreshIntervalSeconds;
    this.notify();
  }

  public getCountdown(): number {
    return this.countdown;
  }

  public getLastUpdatedText(): string {
    const diffSeconds = Math.floor((new Date().getTime() - this.lastUpdated.getTime()) / 1000);
    if (diffSeconds < 5) return 'Just now';
    if (diffSeconds < 60) return `${diffSeconds}s ago`;
    return this.lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  public isErrorState(): boolean {
    return this.isError;
  }

  public triggerErrorSimulation(): void {
    this.isError = true;
    this.notify();
  }

  public clearErrorState(): void {
    this.isError = false;
    this.lastUpdated = new Date();
    this.notify();
  }

  public refreshMatchesNow(): Promise<LiveMatch[]> {
    return new Promise((resolve) => {
      this.isError = false;
      this.simulateNextBallEvent();
      this.lastUpdated = new Date();
      this.countdown = this.refreshIntervalSeconds;
      this.notify();
      resolve(this.matches);
    });
  }

  public subscribe(listener: MatchChangeListener): () => void {
    this.listeners.add(listener);
    listener(this.matches, this.isError);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    for (const listener of this.listeners) {
      listener(this.matches, this.isError);
    }
  }

  private startAutoRefreshLoop() {
    if (this.timerId) clearInterval(this.timerId);
    this.timerId = setInterval(() => {
      if (!this.autoRefreshEnabled || this.isError) return;

      this.countdown -= 1;
      if (this.countdown <= 0) {
        this.countdown = this.refreshIntervalSeconds;
        this.simulateNextBallEvent();
        this.lastUpdated = new Date();
        this.notify();
      } else {
        // notify countdown change
        this.notify();
      }
    }, 1000);
  }

  /**
   * Simulates real-time live match telemetry progression
   */
  private simulateNextBallEvent() {
    const liveMatch = this.matches.find((m) => m.id === 'match-live-1');
    if (!liveMatch || liveMatch.status !== 'LIVE') return;

    const currentOverStr = liveMatch.team2.overs || "17.2";
    const parts = currentOverStr.split('.');
    const overPart = parseInt(parts[0], 10) || 0;
    const ballPart = parseInt(parts[1] || '0', 10) || 0;
    let newOver = overPart;
    let newBall = ballPart + 1;

    if (newBall >= 6) {
      newOver += 1;
      newBall = 0;
    }

    // Determine random outcome for this ball
    const outcomes: Array<{ runs: number; type: 'dot' | 'run' | 'four' | 'six'; label: string; text: string }> = [
      { runs: 1, type: 'run', label: '1', text: 'Pushed into the gap at deep cover, good running brings an easy single.' },
      { runs: 2, type: 'run', label: '2', text: 'Clips it off the hips between deep square leg and fine leg, sprint back for two.' },
      { runs: 4, type: 'four', label: '4', text: 'FOUR! Dispatched with authority! Pierces the point boundary with sublime bat speed!' },
      { runs: 1, type: 'run', label: '1', text: 'Length ball tucked neatly to mid-on, quick rotation of strike.' },
      { runs: 0, type: 'dot', label: '0', text: 'Fiery back of a length delivery, defended solidly on the back foot.' },
      { runs: 6, type: 'six', label: '6', text: 'SIX! Maximum power into the second tier! Clean strike straight down the ground!' },
    ];

    const outcome = outcomes[Math.floor(Math.random() * outcomes.length)];
    const newTeamRuns = (liveMatch.team2.runs || 165) + outcome.runs;
    const newOversStr = `${newOver}.${newBall}`;

    // Update match state
    liveMatch.team2.runs = newTeamRuns;
    liveMatch.team2.overs = newOversStr;
    liveMatch.team2.score = `${newTeamRuns}/${liveMatch.team2.wickets || 4}`;

    // Update batsman
    if (liveMatch.currentBatsman) {
      liveMatch.currentBatsman.runs = (liveMatch.currentBatsman.runs || 0) + outcome.runs;
      liveMatch.currentBatsman.balls = (liveMatch.currentBatsman.balls || 0) + 1;
      if (outcome.type === 'four') liveMatch.currentBatsman.fours = (liveMatch.currentBatsman.fours || 0) + 1;
      if (outcome.type === 'six') liveMatch.currentBatsman.sixes = (liveMatch.currentBatsman.sixes || 0) + 1;
    }

    // Update bowler
    if (liveMatch.currentBowler) {
      liveMatch.currentBowler.runs = (liveMatch.currentBowler.runs || 0) + outcome.runs;
      liveMatch.currentBowler.overs = newOversStr;
    }

    // Update recent balls
    const currentRecent = Array.isArray(liveMatch.recentBalls) ? liveMatch.recentBalls : [];
    const updatedBalls = [...currentRecent.slice(-5), outcome.label];
    liveMatch.recentBalls = updatedBalls;

    // Calculate remaining runs
    const target = liveMatch.target || 193;
    const runsNeeded = Math.max(0, target - newTeamRuns);
    const totalBallsBowled = newOver * 6 + newBall;
    const ballsRemaining = Math.max(0, 120 - totalBallsBowled);

    if (runsNeeded === 0) {
      liveMatch.status = 'COMPLETED';
      liveMatch.statusText = 'India won by 6 wickets!';
      liveMatch.result = 'India won by 6 wickets to lift the World Cup Trophy!';
    } else {
      liveMatch.requiredRuns = `${runsNeeded} off ${ballsRemaining}`;
      liveMatch.statusText = `India need ${runsNeeded} runs in ${ballsRemaining} balls to win`;
      // Update win prob
      if (liveMatch.winProbability) {
        liveMatch.winProbability.team2 = Math.min(95, Math.max(10, Math.round(55 + (newTeamRuns - 165) * 1.5)));
        liveMatch.winProbability.team1 = 100 - liveMatch.winProbability.team2;
      }
    }

    // Add commentary
    if (liveMatch.commentary) {
      const newCommentary: BallCommentary = {
        id: `auto-${Date.now()}`,
        over: newOversStr,
        ballNumber: newBall || 6,
        runs: outcome.runs,
        ballType: outcome.type,
        text: outcome.text,
        bowler: liveMatch.currentBowler.name,
        batsman: liveMatch.currentBatsman.name,
        scoreSnapshot: liveMatch.team2.score,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      liveMatch.commentary = [newCommentary, ...liveMatch.commentary.slice(0, 20)];
    }

    // Also update Innings 2 batting entry
    if (liveMatch.innings2 && liveMatch.innings2.batting) {
      const striker = liveMatch.innings2.batting.find((b) => b.isStriker);
      if (striker) {
        striker.runs = liveMatch.currentBatsman.runs;
        striker.balls = liveMatch.currentBatsman.balls;
        striker.fours = liveMatch.currentBatsman.fours;
        striker.sixes = liveMatch.currentBatsman.sixes;
        striker.strikeRate = Number(((striker.runs / striker.balls) * 100).toFixed(2));
      }
      liveMatch.innings2.runs = newTeamRuns;
      liveMatch.innings2.overs = newOversStr;
      liveMatch.innings2.runRate = (newTeamRuns / (newOver + newBall / 6)).toFixed(2);
    }
  }
}

export const cricketLiveService = new CricketLiveService();
