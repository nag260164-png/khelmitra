import { demoPointsService } from './demoPointsService';

export interface FAQItem {
  id: string;
  category: 'Games & Rules' | 'Virtual Coins' | 'Referrals & Social' | 'Android APK & Tech';
  question: string;
  answer: string;
}

export interface SupportTicket {
  id: string;
  category: 'Gameplay Issue' | 'Virtual Coins' | 'App Crash / Bug' | 'Account / Profile' | 'Feature Suggestion' | 'Other';
  severity: 'Low' | 'Medium' | 'High';
  description: string;
  contactEmail: string;
  timestamp: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  resolutionNotes?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

const TICKETS_STORAGE_KEY = 'khelmitra_support_tickets_v1';

export const FAQ_LIST: FAQItem[] = [
  {
    id: 'faq-1',
    category: 'Games & Rules',
    question: 'How do Trump cards work in Call Break?',
    answer: 'In Call Break, Spades (♠) are always the permanent Trump suit. When you do not possess a card in the leading suit, you can cut with any Spade card. The highest Spade played wins the trick unless someone plays a higher Spade.',
  },
  {
    id: 'faq-2',
    category: 'Games & Rules',
    question: 'What is the highest hand in Teen Patti?',
    answer: 'The highest hand is Trail/Trio (Three cards of the same rank, with A-A-A being the supreme trail), followed by Pure Sequence (Straight Flush), Normal Sequence (Straight), Color (Flush), Pair, and High Card.',
  },
  {
    id: 'faq-3',
    category: 'Games & Rules',
    question: 'Are there safe spots on the Ludo board?',
    answer: 'Yes! All cells marked with a golden Star (⭐) are protected Safe Zones. Tokens sitting on these cells cannot be eliminated or captured by opposing players.',
  },
  {
    id: 'faq-4',
    category: 'Games & Rules',
    question: 'What is required for a valid Rummy declaration?',
    answer: 'A valid Rummy declaration requires 13 arranged cards with at least TWO sequences, where at least ONE sequence must be a Pure Sequence (consecutive cards of the identical suit without any Joker).',
  },
  {
    id: 'faq-5',
    category: 'Virtual Coins',
    question: 'Is KhelMitra 100% free? Is there any real-money gambling?',
    answer: 'KhelMitra is strictly 100% FREE-TO-PLAY for recreational and casual gaming entertainment. All coins and prizes are virtual and hold zero cash or monetary value. No deposit, betting, or real-money wagering is permitted.',
  },
  {
    id: 'faq-6',
    category: 'Virtual Coins',
    question: 'How can I get more free virtual coins?',
    answer: 'You have unlimited free ways to get coins! Claim 1,000 Coins anytime in Settings, spin the Lucky Reward Wheel daily, complete Daily Missions, maintain daily login streaks, or invite friends using your unique referral code.',
  },
  {
    id: 'faq-7',
    category: 'Referrals & Social',
    question: 'How do referral rewards work?',
    answer: 'Share your personal referral code (found in the Invite Friends tab). When a friend joins and enters your code, you receive 1,000 Free Coins, and your friend gets 500 Welcome Bonus Coins instantly!',
  },
  {
    id: 'faq-8',
    category: 'Android APK & Tech',
    question: 'How do I download and install the Android APK?',
    answer: 'Tap the APK button in the top navigation bar to open the APK Center. You can download the complete Android Studio project ZIP or install the app directly on your Android phone via Chrome PWA (Add to Home screen).',
  },
];

const INITIAL_TICKETS: SupportTicket[] = [
  {
    id: 'KM-TKT-8291',
    category: 'Gameplay Issue',
    severity: 'Medium',
    description: 'Question regarding card auto-sorting in Rummy hand.',
    contactEmail: 'user@khelmitra.com',
    timestamp: '2 days ago',
    status: 'Resolved',
    resolutionNotes: 'Auto-sort preference can be toggled on or off in Game Settings menu.',
  },
];

class CustomerSupportService {
  private tickets: SupportTicket[];

  constructor() {
    this.tickets = this.loadTickets();
  }

  private loadTickets(): SupportTicket[] {
    try {
      const saved = localStorage.getItem(TICKETS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return INITIAL_TICKETS;
  }

  private saveTickets() {
    try {
      localStorage.setItem(TICKETS_STORAGE_KEY, JSON.stringify(this.tickets));
    } catch {
      // Fallback
    }
  }

  public getTickets(): SupportTicket[] {
    return [...this.tickets];
  }

  public createTicket(
    category: SupportTicket['category'],
    severity: SupportTicket['severity'],
    description: string,
    contactEmail: string
  ): { ticket: SupportTicket; rewardCoins: number } {
    const randomId = Math.floor(1000 + Math.random() * 9000);
    const ticketId = `KM-TKT-${randomId}`;

    const newTicket: SupportTicket = {
      id: ticketId,
      category,
      severity,
      description,
      contactEmail: contactEmail || 'gamer@khelmitra.com',
      timestamp: 'Just now',
      status: 'Open',
    };

    this.tickets.unshift(newTicket);
    this.saveTickets();

    // Reward 50 coins as a courtesy for reporting / contacting support
    demoPointsService.addPoints(50, 'Support Bonus', `Feedback token reward (${ticketId})`);

    return { ticket: newTicket, rewardCoins: 50 };
  }

  public getBotResponse(userQuery: string): string {
    const q = userQuery.toLowerCase();
    if (q.includes('coin') || q.includes('money') || q.includes('cash') || q.includes('balance') || q.includes('refill')) {
      return 'KhelMitra is 100% free-to-play with virtual demo coins! You can refill 1,000 free coins anytime from the Settings menu or claim daily mission streak rewards.';
    }
    if (q.includes('call break') || q.includes('spade') || q.includes('trick')) {
      return 'In Call Break, Spades are permanent trumps. You must follow the led suit if you have cards of that suit; otherwise you can cut with Spades!';
    }
    if (q.includes('teen patti') || q.includes('trail') || q.includes('blind')) {
      return 'In Teen Patti, Trio/Trail (3 of a kind) is the strongest hand, followed by Pure Sequence. Blind players bet half of the Seen player amount!';
    }
    if (q.includes('ludo') || q.includes('dice') || q.includes('safe')) {
      return 'In Ludo, roll a 6 to release tokens from base. All star-marked squares (⭐) are safe zones where tokens cannot be captured.';
    }
    if (q.includes('rummy') || q.includes('pure sequence') || q.includes('declare')) {
      return 'To declare in Indian Rummy, you need 13 valid cards with at least two sequences, one of which MUST be a Pure Sequence (no Jokers).';
    }
    if (q.includes('apk') || q.includes('install') || q.includes('android') || q.includes('download')) {
      return 'You can install KhelMitra on Android either via the Chrome "Add to Home Screen" PWA prompt or by building the native project in the APK Center!';
    }
    if (q.includes('invite') || q.includes('friend') || q.includes('referral') || q.includes('code')) {
      return 'Share your referral code from the Invite Friends screen to earn 1,000 Free Coins for every friend that joins! Your friend gets 500 Coins too.';
    }
    return 'Thank you for messaging KhelMitra 24/7 Support. Our team typically responds within 5 minutes. You can also contact us directly via WhatsApp or submit a formal ticket!';
  }
}

export const customerSupportService = new CustomerSupportService();
