import { ActiveSheetType } from '../types';

export type NotificationCategory = 
  | 'cricket' 
  | 'missions' 
  | 'rewards' 
  | 'games' 
  | 'support' 
  | 'referral';

export interface AppNotification {
  id: string;
  category: NotificationCategory;
  title: string;
  message: string;
  timeAgo: string;
  timestamp: number;
  read: boolean;
  priority: 'high' | 'normal';
  actionSheet?: ActiveSheetType;
  actionLabel?: string;
  iconType: 'cricket' | 'target' | 'gift' | 'game' | 'support' | 'user';
}

const DEFAULT_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'notif-cricket-1',
    category: 'cricket',
    title: '🏏 Live Cricket: IND vs AUS Death Overs!',
    message: 'IND 198/4 (18.2 ov) • RR: 10.8. Virat Kohli 82* (44) powering towards a 200+ total. Real-time ball-by-ball score active!',
    timeAgo: 'Just now',
    timestamp: Date.now() - 30000,
    read: false,
    priority: 'high',
    actionSheet: 'live-cricket',
    actionLabel: 'View Live Scorecard',
    iconType: 'cricket',
  },
  {
    id: 'notif-missions-1',
    category: 'missions',
    title: '🎯 Daily Missions Unlocked',
    message: 'Play 1 round of Call Break and roll a 6 in Ludo to claim 550 Free Coins & keep your daily streak alive.',
    timeAgo: '12m ago',
    timestamp: Date.now() - 720000,
    read: false,
    priority: 'high',
    actionSheet: 'daily-missions',
    actionLabel: 'Open Missions',
    iconType: 'target',
  },
  {
    id: 'notif-rewards-1',
    category: 'rewards',
    title: '🎡 Free Lucky Wheel Spin Available',
    message: 'Your 24-hour lucky wheel spin is ready! Spin now to win up to 5,000 Coins, badges, and multipliers.',
    timeAgo: '45m ago',
    timestamp: Date.now() - 2700000,
    read: false,
    priority: 'normal',
    actionSheet: 'rewards',
    actionLabel: 'Spin Wheel',
    iconType: 'gift',
  },
  {
    id: 'notif-games-1',
    category: 'games',
    title: '🎮 4 Real Skill Games Fully Operational',
    message: 'Call Break Master, Teen Patti Royal, Khel Ludo Classic & Indian Rummy are online with smart AI & room codes.',
    timeAgo: '2h ago',
    timestamp: Date.now() - 7200000,
    read: false,
    priority: 'normal',
    actionSheet: 'call-break',
    actionLabel: 'Play Call Break',
    iconType: 'game',
  },
  {
    id: 'notif-referral-1',
    category: 'referral',
    title: '🎁 Invite Friends: +1,000 Coins Reward',
    message: 'Share your code KHELM-ARJUN77 on WhatsApp. Friends get 500 Coins welcome bonus, and you earn 1,000 Coins on signup.',
    timeAgo: '3h ago',
    timestamp: Date.now() - 10800000,
    read: false,
    priority: 'normal',
    actionSheet: 'invite-friends',
    actionLabel: 'Share Invite Code',
    iconType: 'user',
  },
  {
    id: 'notif-support-1',
    category: 'support',
    title: '🎧 24/7 Customer Care Desk Ready',
    message: 'Have questions about game rules, virtual coin refills, or Android APK installation? WhatsApp support replies in < 3 mins.',
    timeAgo: '5h ago',
    timestamp: Date.now() - 18000000,
    read: false,
    priority: 'normal',
    actionSheet: 'customer-care',
    actionLabel: 'Contact Support',
    iconType: 'support',
  },
];

const STORAGE_KEY = 'khelmitra_notifications_v1';

class NotificationService {
  private notifications: AppNotification[] = [];
  private listeners: Array<(items: AppNotification[]) => void> = [];

  constructor() {
    this.loadNotifications();
  }

  private loadNotifications() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.notifications = JSON.parse(stored);
      } else {
        this.notifications = [...DEFAULT_NOTIFICATIONS];
        this.save();
      }
    } catch {
      this.notifications = [...DEFAULT_NOTIFICATIONS];
    }
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.notifications));
    } catch {
      // ignore
    }
    this.notify();
  }

  private notify() {
    this.listeners.forEach((fn) => fn([...this.notifications]));
  }

  public subscribe(listener: (items: AppNotification[]) => void): () => void {
    this.listeners.push(listener);
    listener([...this.notifications]);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  public getNotifications(): AppNotification[] {
    return [...this.notifications];
  }

  public getUnreadCount(): number {
    return this.notifications.filter((n) => !n.read).length;
  }

  public markAsRead(id: string) {
    this.notifications = this.notifications.map((n) =>
      n.id === id ? { ...n, read: true } : n
    );
    this.save();
  }

  public markAllAsRead() {
    this.notifications = this.notifications.map((n) => ({ ...n, read: true }));
    this.save();
  }

  public removeNotification(id: string) {
    this.notifications = this.notifications.filter((n) => n.id !== id);
    this.save();
  }

  public clearAll() {
    this.notifications = [];
    this.save();
  }

  public resetToDefault() {
    this.notifications = [...DEFAULT_NOTIFICATIONS];
    this.save();
  }

  public addNotification(notif: Omit<AppNotification, 'id' | 'timestamp' | 'read' | 'timeAgo'>) {
    const newNotif: AppNotification = {
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: Date.now(),
      timeAgo: 'Just now',
      read: false,
    };
    this.notifications = [newNotif, ...this.notifications];
    this.save();
    return newNotif;
  }

  // Helper to trigger realistic live notifications
  public triggerSimulatedNotification(type: 'cricket' | 'reward' | 'mission' | 'referral') {
    if (type === 'cricket') {
      return this.addNotification({
        category: 'cricket',
        title: '🏏 WICKET! AUS 194/7 (17.5 ov)',
        message: 'Bumrah strikes! Yorker shatters the stumps. India tightening their grip in the death overs.',
        priority: 'high',
        actionSheet: 'live-cricket',
        actionLabel: 'View Match Ball-by-Ball',
        iconType: 'cricket',
      });
    } else if (type === 'reward') {
      return this.addNotification({
        category: 'rewards',
        title: '💰 Coin Bonus Deposited!',
        message: '+500 Free Coins credited to your wallet balance for continuous play.',
        priority: 'normal',
        actionSheet: 'rewards',
        actionLabel: 'View Wallet & Rewards',
        iconType: 'gift',
      });
    } else if (type === 'mission') {
      return this.addNotification({
        category: 'missions',
        title: '🏆 Mission Complete: Card Master!',
        message: 'You won your Call Break trick! Claim your +250 Coins reward now.',
        priority: 'high',
        actionSheet: 'daily-missions',
        actionLabel: 'Claim Reward',
        iconType: 'target',
      });
    } else {
      return this.addNotification({
        category: 'referral',
        title: '🎉 Referral Joined: Rohit Sharma',
        message: 'Your friend entered referral code KHELM-ARJUN77. +1,000 Coins credited to your account!',
        priority: 'high',
        actionSheet: 'invite-friends',
        actionLabel: 'Check Referral Hub',
        iconType: 'user',
      });
    }
  }
}

export const notificationService = new NotificationService();
