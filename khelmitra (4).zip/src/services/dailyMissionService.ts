import { DailyMission, DailyMissionState } from '../types';
import { demoPointsService } from './demoPointsService';

const STORAGE_KEY = 'khelmitra_daily_missions_v2';

export const DAILY_LOGIN_REWARDS = [
  { day: 1, coins: 100, label: 'Day 1' },
  { day: 2, coins: 150, label: 'Day 2' },
  { day: 3, coins: 200, label: 'Day 3' },
  { day: 4, coins: 250, label: 'Day 4' },
  { day: 5, coins: 300, label: 'Day 5' },
  { day: 6, coins: 400, label: 'Day 6' },
  { day: 7, coins: 600, label: 'Day 7 🏆', isMega: true },
];

export const DEFAULT_MISSIONS_DEF: Omit<DailyMission, 'currentProgress' | 'isCompleted' | 'isClaimed'>[] = [
  {
    id: 'mission-login',
    title: 'Daily Check-in',
    description: 'Launch KhelMitra and check in for your daily streak reward',
    rewardCoins: 100,
    category: 'login',
    targetProgress: 1,
    iconName: 'CalendarCheck',
  },
  {
    id: 'mission-watch-ad',
    title: 'Watch Sponsor Clips',
    description: 'Watch 2 short sponsor clips to earn instant demo coins',
    rewardCoins: 100,
    category: 'ad',
    targetProgress: 2,
    iconName: 'PlayCircle',
  },
  {
    id: 'mission-cricket-quiz',
    title: 'Cricket IQ Challenge',
    description: 'Play 1 round of Cricket Master Quiz or General Knowledge IQ',
    rewardCoins: 120,
    category: 'quiz',
    targetProgress: 1,
    actionSheet: 'games',
    actionLabel: 'Play Quiz',
    iconName: 'HelpCircle',
  },
  {
    id: 'mission-fantasy-draft',
    title: 'Fantasy Team Strategist',
    description: 'Draft or edit your fantasy 11 cricket team squad',
    rewardCoins: 150,
    category: 'fantasy',
    targetProgress: 1,
    actionSheet: 'create-team',
    actionLabel: 'Draft Team',
    iconName: 'Trophy',
  },
  {
    id: 'mission-puzzle-match',
    title: 'Cricket Brain Teaser',
    description: 'Solve 1 cricket anagram puzzle or complete memory match',
    rewardCoins: 120,
    category: 'puzzle',
    targetProgress: 1,
    actionSheet: 'games',
    actionLabel: 'Solve Puzzle',
    iconName: 'Gamepad2',
  },
];

class DailyMissionService {
  private state: DailyMissionState;
  private listeners: Set<(state: DailyMissionState) => void> = new Set();

  constructor() {
    this.state = this.loadState();
    // Daily login check-in: automatic progress for login mission
    this.recordLoginProgress();
  }

  private getTodayString(): string {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  private getYesterdayString(): string {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  private loadState(): DailyMissionState {
    const today = this.getTodayString();
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          // Ensure missions dictionary exists
          const missionsMap: DailyMissionState['missions'] = parsed.missions && typeof parsed.missions === 'object' 
            ? { ...parsed.missions } 
            : {};

          // Backfill any missing default mission keys
          DEFAULT_MISSIONS_DEF.forEach((m) => {
            if (!missionsMap[m.id]) {
              missionsMap[m.id] = {
                progress: m.id === 'mission-login' ? 1 : 0,
                isClaimed: false,
              };
            }
          });

          const streak = Math.max(1, Number(parsed.dailyStreak) || 1);

          if (parsed.date === today) {
            return {
              date: today,
              dailyStreak: streak,
              loginClaimed: Boolean(parsed.loginClaimed),
              adsWatchedToday: Math.min(3, Math.max(0, Number(parsed.adsWatchedToday) || 0)),
              maxDailyAds: 3,
              missions: missionsMap,
              totalMissionsCompleted: Number(parsed.totalMissionsCompleted) || 1,
              megaBonusClaimed: Boolean(parsed.megaBonusClaimed),
            };
          }

          // New day! Calculate streak
          const yesterday = this.getYesterdayString();
          const continueStreak = parsed.date === yesterday && Boolean(parsed.loginClaimed);
          const newStreak = continueStreak ? (streak % 7) + 1 : 1;

          return this.createFreshState(today, newStreak);
        }
      }
    } catch {
      // Fallback on corrupt JSON or storage access error
    }

    return this.createFreshState(today, 1);
  }

  private createFreshState(date: string, streak: number): DailyMissionState {
    const missionsMap: DailyMissionState['missions'] = {};
    DEFAULT_MISSIONS_DEF.forEach((m) => {
      missionsMap[m.id] = {
        progress: m.id === 'mission-login' ? 1 : 0, // Login mission automatically progressed
        isClaimed: false,
      };
    });

    return {
      date,
      dailyStreak: Math.max(1, streak || 1),
      loginClaimed: false,
      adsWatchedToday: 0,
      maxDailyAds: 3,
      missions: missionsMap,
      totalMissionsCompleted: 1, // Login mission is ready
      megaBonusClaimed: false,
    };
  }

  private recordLoginProgress() {
    if (!this.state.missions) {
      this.state.missions = {};
    }
    if (!this.state.missions['mission-login']) {
      this.state.missions['mission-login'] = { progress: 1, isClaimed: false };
    } else {
      this.state.missions['mission-login'].progress = 1;
    }
    this.save();
  }

  public getState(): DailyMissionState {
    if (!this.state || !this.state.missions) {
      this.state = this.loadState();
    }
    return { ...this.state };
  }

  public getMissionsList(): DailyMission[] {
    if (!this.state || !this.state.missions) {
      this.state = this.loadState();
    }
    return DEFAULT_MISSIONS_DEF.map((def) => {
      const saved = this.state.missions?.[def.id] || { progress: 0, isClaimed: false };
      const isCompleted = (saved.progress || 0) >= def.targetProgress;
      return {
        ...def,
        currentProgress: saved.progress || 0,
        isCompleted,
        isClaimed: Boolean(saved.isClaimed),
      };
    });
  }

  public getLoginRewardForToday(): { day: number; coins: number; isMega?: boolean } {
    const streak = Math.max(1, Number(this.state?.dailyStreak) || 1);
    const dayIndex = ((streak - 1) % 7);
    return DAILY_LOGIN_REWARDS[dayIndex] || DAILY_LOGIN_REWARDS[0];
  }

  // Feature 1 & 5: Claim Daily Login Reward (strictly prevents multiple claims per day)
  public claimDailyLoginReward(): { success: boolean; coins: number; message: string } {
    const today = this.getTodayString();
    if (this.state.date !== today) {
      // Refresh to today if day rolled over
      this.state = this.loadState();
    }

    if (this.state.loginClaimed) {
      return {
        success: false,
        coins: 0,
        message: 'Daily login reward has already been claimed today. Please return tomorrow!',
      };
    }

    const reward = this.getLoginRewardForToday();
    this.state.loginClaimed = true;
    
    // Also mark the login mission as claimed if not yet
    if (this.state.missions && this.state.missions['mission-login']) {
      this.state.missions['mission-login'].isClaimed = true;
      this.state.missions['mission-login'].claimedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    this.save();

    // Credit shared demo points
    demoPointsService.addPoints(
      reward.coins,
      'Daily Login Reward',
      `Day ${reward.day} check-in bonus streak (${this.state.dailyStreak} days)`
    );

    this.notify();
    return {
      success: true,
      coins: reward.coins,
      message: `Congratulations! Claimed +${reward.coins} Demo Coins for Day ${reward.day} login.`,
    };
  }

  // Feature 2: Watch Ad and earn demo coins
  public recordAdWatched(): { success: boolean; coins: number; message: string; adsRemaining: number } {
    const rewardCoins = 50;
    if (this.state.adsWatchedToday >= this.state.maxDailyAds) {
      return {
        success: false,
        coins: 0,
        message: `Daily video ad limit reached (${this.state.maxDailyAds}/${this.state.maxDailyAds}). Resets tomorrow!`,
        adsRemaining: 0,
      };
    }

    this.state.adsWatchedToday = (this.state.adsWatchedToday || 0) + 1;

    // Advance 'mission-watch-ad'
    if (this.state.missions && this.state.missions['mission-watch-ad']) {
      const mission = this.state.missions['mission-watch-ad'];
      mission.progress = Math.min(2, (mission.progress || 0) + 1);
    }

    this.save();

    // Credit immediate coins for watching
    demoPointsService.addPoints(
      rewardCoins,
      'Sponsor Clip Demo Reward',
      `Watched sponsor clip (${this.state.adsWatchedToday}/${this.state.maxDailyAds} today)`
    );

    this.notify();

    const remaining = this.state.maxDailyAds - this.state.adsWatchedToday;
    return {
      success: true,
      coins: rewardCoins,
      message: `+${rewardCoins} Demo Coins credited! (${remaining} ad bonuses remaining today)`,
      adsRemaining: remaining,
    };
  }

  // Feature 3: Increment arbitrary mission progress (e.g. when user plays quiz, drafts team, or plays puzzle)
  public incrementProgress(missionId: string, amount: number = 1): boolean {
    if (!this.state?.missions) {
      this.state = this.loadState();
    }
    const mission = this.state.missions?.[missionId];
    if (!mission) return false;

    const def = DEFAULT_MISSIONS_DEF.find((d) => d.id === missionId);
    if (!def) return false;

    if (mission.progress < def.targetProgress) {
      mission.progress = Math.min(def.targetProgress, (mission.progress || 0) + amount);
      this.save();
      this.notify();
      return true;
    }
    return false;
  }

  // Feature 4 & 5: Claim reward button for a specific mission (prevents multiple claims)
  public claimMissionReward(missionId: string): { success: boolean; coins: number; message: string } {
    if (!this.state?.missions) {
      this.state = this.loadState();
    }
    const mission = this.state.missions?.[missionId];
    const def = DEFAULT_MISSIONS_DEF.find((d) => d.id === missionId);

    if (!mission || !def) {
      return { success: false, coins: 0, message: 'Mission not found.' };
    }

    if (mission.progress < def.targetProgress) {
      return { success: false, coins: 0, message: 'Mission requirements not yet completed!' };
    }

    if (mission.isClaimed) {
      return { success: false, coins: 0, message: 'This mission reward has already been claimed today.' };
    }

    mission.isClaimed = true;
    mission.claimedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // If it's the login mission, ensure loginClaimed is marked
    if (missionId === 'mission-login') {
      this.state.loginClaimed = true;
    }

    this.save();

    // Credit demo points
    demoPointsService.addPoints(
      def.rewardCoins,
      `Daily Mission: ${def.title}`,
      `Completed task "${def.title}"`
    );

    this.notify();
    return {
      success: true,
      coins: def.rewardCoins,
      message: `Claimed +${def.rewardCoins} Demo Coins for "${def.title}"!`,
    };
  }

  // Claim Mega Chest Bonus (e.g. complete 4 or more missions)
  public claimMegaBonus(): { success: boolean; coins: number; message: string } {
    if (this.state.megaBonusClaimed) {
      return { success: false, coins: 0, message: 'Mega Chest bonus already claimed today.' };
    }

    const missionsList = this.getMissionsList();
    const completedCount = missionsList.filter((m) => m.isCompleted).length;

    if (completedCount < 4) {
      return {
        success: false,
        coins: 0,
        message: `Complete at least 4 daily missions to open the Mega Chest (${completedCount}/4 ready).`,
      };
    }

    const megaCoins = 250;
    this.state.megaBonusClaimed = true;
    this.save();

    demoPointsService.addPoints(
      megaCoins,
      'Mega Daily Chest Bonus',
      'Completed 4+ daily missions master reward'
    );

    this.notify();
    return {
      success: true,
      coins: megaCoins,
      message: `🎉 Mega Chest Unlocked! +${megaCoins} Demo Coins awarded!`,
    };
  }

  // Calculate Time remaining until midnight reset
  public getTimeUntilMidnight(): string {
    const now = new Date();
    const midnight = new Date();
    midnight.setHours(24, 0, 0, 0);
    const diff = midnight.getTime() - now.getTime();

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    return `${hours}h ${minutes}m ${seconds}s`;
  }

  // Convenient tester method to simulate next day (for demo/evaluation)
  public simulateNextDay() {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    const fakeDate = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    
    const newStreak = (this.state.dailyStreak % 7) + 1;
    this.state = this.createFreshState(fakeDate, newStreak);
    this.save();
    this.notify();
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch {
      // Ignore
    }
  }

  public subscribe(listener: (state: DailyMissionState) => void): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const copy = { ...this.state };
    this.listeners.forEach((l) => l(copy));
  }
}

export const dailyMissionService = new DailyMissionService();
