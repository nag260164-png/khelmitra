// Shared Free Demo Points Service for KhelMitra Games
// strictly 100% Free Demo Points / Virtual Coins - No Real Money, No Cash, No Gambling

export interface DemoPointTransaction {
  id: string;
  amount: number;
  game: string;
  timestamp: string;
  description: string;
  type?: 'credit' | 'debit';
}

export interface GameMatchRecord {
  id: string;
  gameName: 'Call Break' | 'Teen Patti' | 'Ludo' | 'Rummy' | 'Cricket Quiz' | 'Word Puzzle' | 'Fantasy 11';
  gameKey: string;
  result: 'WON' | 'LOST' | 'DRAW';
  coinsWon: number;
  coinsSpent: number;
  timestamp: string;
  details: string;
}

export interface GameSettings {
  soundEffects: boolean;
  hapticFeedback: boolean;
  fastAnimations: boolean;
  autoSortCards: boolean;
}

const STORAGE_KEY = 'khelmitra_demo_points_v1';
const HISTORY_KEY = 'khelmitra_demo_points_history_v1';
const MATCH_HISTORY_KEY = 'khelmitra_game_matches_v1';
const SETTINGS_KEY = 'khelmitra_game_settings_v1';
const INITIAL_POINTS = 2500;

class DemoPointsService {
  private points: number;
  private history: DemoPointTransaction[];
  private matchHistory: GameMatchRecord[];
  private settings: GameSettings;
  private listeners: Set<(points: number) => void> = new Set();

  constructor() {
    this.points = this.loadPoints();
    this.history = this.loadHistory();
    this.matchHistory = this.loadMatchHistory();
    this.settings = this.loadSettings();
  }

  private loadPoints(): number {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved !== null) {
        const parsed = parseInt(saved, 10);
        return isNaN(parsed) ? INITIAL_POINTS : parsed;
      }
    } catch {
      // Fallback
    }
    return INITIAL_POINTS;
  }

  private loadHistory(): DemoPointTransaction[] {
    try {
      const saved = localStorage.getItem(HISTORY_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return [
      {
        id: 'tx-welcome',
        amount: 1000,
        game: 'Welcome Bonus',
        timestamp: 'Just now',
        description: 'New gamer free virtual coins gift',
        type: 'credit',
      },
      {
        id: 'tx-daily',
        amount: 1500,
        game: 'Daily Streak Bonus',
        timestamp: 'Today',
        description: 'Free daily virtual coins reward',
        type: 'credit',
      },
    ];
  }

  private loadMatchHistory(): GameMatchRecord[] {
    try {
      const saved = localStorage.getItem(MATCH_HISTORY_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return [
      {
        id: 'm-01',
        gameName: 'Call Break',
        gameKey: 'call-break',
        result: 'WON',
        coinsWon: 350,
        coinsSpent: 100,
        timestamp: '15 mins ago',
        details: '4 Bid Completed • 1st Position with 5 Tricks',
      },
      {
        id: 'm-02',
        gameName: 'Teen Patti',
        gameKey: 'teen-patti',
        result: 'WON',
        coinsWon: 420,
        coinsSpent: 80,
        timestamp: '1 hour ago',
        details: 'Pure Sequence (K♠ Q♠ J♠) Showdown win',
      },
      {
        id: 'm-03',
        gameName: 'Ludo',
        gameKey: 'ludo',
        result: 'WON',
        coinsWon: 300,
        coinsSpent: 100,
        timestamp: 'Yesterday',
        details: '4 Tokens in Home • Red Player Victory',
      },
    ];
  }

  private loadSettings(): GameSettings {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return {
      soundEffects: true,
      hapticFeedback: true,
      fastAnimations: false,
      autoSortCards: true,
    };
  }

  public getPoints(): number {
    return this.points;
  }

  public getHistory(): DemoPointTransaction[] {
    return [...this.history];
  }

  public getMatchHistory(): GameMatchRecord[] {
    return [...this.matchHistory];
  }

  public getSettings(): GameSettings {
    return { ...this.settings };
  }

  public updateSettings(newSettings: Partial<GameSettings>): GameSettings {
    this.settings = { ...this.settings, ...newSettings };
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(this.settings));
    } catch {
      // ignore
    }
    return { ...this.settings };
  }

  public addPoints(amount: number, game: string, description: string = 'Game victory virtual coins'): number {
    // 1. Strict Input Validation & Range Guard
    if (typeof amount !== 'number' || isNaN(amount) || amount <= 0 || !isFinite(amount)) {
      console.warn('[Security Guard] Rejected invalid credit coin amount:', amount);
      return this.points;
    }
    // Cap single transaction credit to prevent overflow/injection
    const safeAmount = Math.min(Math.floor(amount), 50000);

    this.points += safeAmount;
    const tx: DemoPointTransaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      amount: safeAmount,
      game: String(game).slice(0, 50),
      timestamp: 'Just now',
      description: String(description).slice(0, 100),
      type: 'credit',
    };
    this.history = [tx, ...this.history.slice(0, 24)];
    this.save();
    this.notify();
    return this.points;
  }

  public deductPoints(amount: number, game: string, description: string = 'Game table entry coins'): boolean {
    // 1. Strict Input Validation & Range Guard
    if (typeof amount !== 'number' || isNaN(amount) || amount <= 0 || !isFinite(amount)) {
      console.warn('[Security Guard] Rejected invalid debit coin amount:', amount);
      return false;
    }
    const safeAmount = Math.floor(amount);

    if (this.points < safeAmount) {
      return false; // Insufficient coins
    }
    this.points -= safeAmount;
    const tx: DemoPointTransaction = {
      id: `tx-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      amount: -safeAmount,
      game: String(game).slice(0, 50),
      timestamp: 'Just now',
      description: String(description).slice(0, 100),
      type: 'debit',
    };
    this.history = [tx, ...this.history.slice(0, 24)];
    this.save();
    this.notify();
    return true;
  }

  // 2. Server-side Reward Validation Endpoint Integration
  public async claimServerReward(
    userId: string,
    type: 'daily_login' | 'mission' | 'streak',
    amount: number,
    day?: number
  ): Promise<{ success: boolean; message: string; newBalance?: number }> {
    try {
      const res = await fetch('/api/rewards/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, type, amount, day })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        this.addPoints(amount, type.toUpperCase(), data.message || 'Server verified reward');
        return { success: true, message: data.message, newBalance: this.points };
      } else {
        return { success: false, message: data.error || 'Reward claim rejected by server' };
      }
    } catch {
      // Offline fallback with client validation
      this.addPoints(amount, type.toUpperCase(), 'Free Daily Virtual Reward (Local)');
      return { success: true, message: 'Claimed free demo reward', newBalance: this.points };
    }
  }

  public refillFreeCoins(amount: number = 1000): number {
    return this.addPoints(amount, 'Free Coin Refill', 'Free daily virtual coins top-up (No cash required)');
  }

  public recordMatch(record: Omit<GameMatchRecord, 'id' | 'timestamp'>): void {
    const newRecord: GameMatchRecord = {
      ...record,
      id: `match-${Date.now()}`,
      timestamp: 'Just now',
    };
    this.matchHistory = [newRecord, ...this.matchHistory.slice(0, 29)];
    try {
      localStorage.setItem(MATCH_HISTORY_KEY, JSON.stringify(this.matchHistory));
    } catch {
      // ignore
    }
  }

  private save() {
    try {
      localStorage.setItem(STORAGE_KEY, this.points.toString());
      localStorage.setItem(HISTORY_KEY, JSON.stringify(this.history));
      localStorage.setItem(MATCH_HISTORY_KEY, JSON.stringify(this.matchHistory));
    } catch {
      // Ignore storage errors
    }
  }

  public subscribe(listener: (points: number) => void): () => void {
    this.listeners.add(listener);
    listener(this.points);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => fn(this.points));
  }
}

export const demoPointsService = new DemoPointsService();

