import { 
  ResellerProduct, ResellerOrder, SupplierProfile, ResellerEarnings, 
  ResellerCategory, MarketplaceConfig, OrderStatus 
} from '../types';
import { 
  INITIAL_PRODUCTS, INITIAL_ORDERS, INITIAL_SUPPLIERS, 
  INITIAL_EARNINGS, DEFAULT_MARKETPLACE_CONFIG 
} from '../data/resellingData';
import { notificationService } from './notificationService';

type ResellerListener = () => void;

class ResellingService {
  private products: ResellerProduct[] = [];
  private orders: ResellerOrder[] = [];
  private suppliers: SupplierProfile[] = [];
  private earnings: ResellerEarnings = INITIAL_EARNINGS;
  private config: MarketplaceConfig = DEFAULT_MARKETPLACE_CONFIG;
  private listeners: Set<ResellerListener> = new Set();
  private selectedCategory: ResellerCategory | 'All' = 'All';
  private searchQuery: string = '';
  private activeProduct: ResellerProduct | null = null;
  private currentSupplierId: string = 'sup-101'; // Default logged-in supplier demo

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const storedProds = localStorage.getItem('km_reseller_products');
      this.products = storedProds ? JSON.parse(storedProds) : INITIAL_PRODUCTS;

      const storedOrders = localStorage.getItem('km_reseller_orders');
      this.orders = storedOrders ? JSON.parse(storedOrders) : INITIAL_ORDERS;

      const storedSuppliers = localStorage.getItem('km_reseller_suppliers');
      this.suppliers = storedSuppliers ? JSON.parse(storedSuppliers) : INITIAL_SUPPLIERS;

      const storedEarnings = localStorage.getItem('km_reseller_earnings');
      this.earnings = storedEarnings ? JSON.parse(storedEarnings) : INITIAL_EARNINGS;

      const storedConfig = localStorage.getItem('km_marketplace_config');
      this.config = storedConfig ? JSON.parse(storedConfig) : DEFAULT_MARKETPLACE_CONFIG;
    } catch {
      this.products = INITIAL_PRODUCTS;
      this.orders = INITIAL_ORDERS;
      this.suppliers = INITIAL_SUPPLIERS;
      this.earnings = INITIAL_EARNINGS;
      this.config = DEFAULT_MARKETPLACE_CONFIG;
    }
  }

  private saveToStorage() {
    try {
      localStorage.setItem('km_reseller_products', JSON.stringify(this.products));
      localStorage.setItem('km_reseller_orders', JSON.stringify(this.orders));
      localStorage.setItem('km_reseller_suppliers', JSON.stringify(this.suppliers));
      localStorage.setItem('km_reseller_earnings', JSON.stringify(this.earnings));
      localStorage.setItem('km_marketplace_config', JSON.stringify(this.config));
    } catch (e) {
      console.warn('Storage save failed', e);
    }
    this.notify();
  }

  public subscribe(listener: ResellerListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(fn => fn());
  }

  // --------------------------------------------------
  // PRODUCT CATALOGUE & FILTERING
  // --------------------------------------------------
  public getProducts(): ResellerProduct[] {
    return this.products;
  }

  public getFilteredProducts(): ResellerProduct[] {
    return this.products.filter(p => {
      const matchesCat = this.selectedCategory === 'All' || p.category === this.selectedCategory;
      const q = this.searchQuery.toLowerCase().trim();
      const matchesSearch = !q || 
        p.title.toLowerCase().includes(q) || 
        p.category.toLowerCase().includes(q) ||
        (p.fabric && p.fabric.toLowerCase().includes(q)) ||
        p.tags.some(t => t.toLowerCase().includes(q));
      return matchesCat && matchesSearch;
    });
  }

  public getProductById(id: string): ResellerProduct | undefined {
    return this.products.find(p => p.id === id);
  }

  public setSelectedCategory(cat: ResellerCategory | 'All') {
    this.selectedCategory = cat;
    this.notify();
  }

  public getSelectedCategory(): ResellerCategory | 'All' {
    return this.selectedCategory;
  }

  public setSearchQuery(q: string) {
    this.searchQuery = q;
    this.notify();
  }

  public getSearchQuery(): string {
    return this.searchQuery;
  }

  public setActiveProduct(product: ResellerProduct | null) {
    this.activeProduct = product;
    this.notify();
  }

  public getActiveProduct(): ResellerProduct | null {
    return this.activeProduct;
  }

  // --------------------------------------------------
  // MARGIN CALCULATOR & WHATSAPP SHARING
  // --------------------------------------------------
  public calculateFinalPrice(supplierPrice: number, margin: number): {
    finalCustomerPrice: number;
    resellerProfit: number;
    profitPercent: number;
  } {
    const profit = Math.max(0, margin);
    const finalPrice = supplierPrice + profit;
    const profitPercent = supplierPrice > 0 ? Math.round((profit / supplierPrice) * 100) : 0;
    return {
      finalCustomerPrice: finalPrice,
      resellerProfit: profit,
      profitPercent
    };
  }

  public generateWhatsAppShareText(product: ResellerProduct, resellerMargin: number): string {
    const { finalCustomerPrice } = this.calculateFinalPrice(product.supplierPrice, resellerMargin);
    const sizesList = product.sizes.join(', ');
    
    return `🛍️ *SPECIAL OFFER: ${product.title}*\n\n` +
      `✨ *Price:* ₹${finalCustomerPrice} Only (Free Home Delivery)\n` +
      `🏷️ *Fabric/Material:* ${product.fabric || 'Premium Quality Guaranteed'}\n` +
      `📏 *Available Sizes:* ${sizesList}\n` +
      `⭐ *Customer Rating:* ${product.rating}★ (${product.reviewsCount}+ verified reviews)\n\n` +
      `🚚 *Key Benefits:*\n` +
      `• Cash on Delivery (COD) Available All Over India\n` +
      `• 100% Quality Checked & Inspected\n` +
      `• Easy 7-Days Exchange & Return Window\n\n` +
      `💬 *Reply to this message with your size and address to order now!*`;
  }

  public shareProductOnWhatsApp(product: ResellerProduct, resellerMargin: number) {
    const text = this.generateWhatsAppShareText(product, resellerMargin);
    const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');

    notificationService.addNotification({
      title: 'Catalogue Shared on WhatsApp! 🛍️',
      message: `"${product.title.slice(0, 32)}..." shared with ₹${resellerMargin} margin. When customer orders, you earn directly!`,
      category: 'rewards',
      priority: 'normal',
      iconType: 'gift'
    });
  }

  // --------------------------------------------------
  // ORDER MANAGEMENT & CUSTOMER ORDER PLACEMENT
  // --------------------------------------------------
  public getOrders(): ResellerOrder[] {
    return this.orders;
  }

  public placeCustomerOrder(params: {
    product: ResellerProduct;
    size: string;
    quantity: number;
    resellerMargin: number;
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    pincode: string;
    city: string;
    state: string;
    paymentMethod: 'COD' | 'Online';
  }): { success: boolean; order?: ResellerOrder; message: string } {
    // 1. Validation
    if (!params.customerName.trim() || params.customerName.length < 2) {
      return { success: false, message: 'Please enter a valid customer name' };
    }
    const cleanPhone = params.customerPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      return { success: false, message: 'Please enter a valid 10-digit customer mobile number' };
    }
    if (!params.customerAddress.trim() || params.customerAddress.length < 8) {
      return { success: false, message: 'Please enter complete house/street address for reliable delivery' };
    }
    if (!params.pincode.trim() || params.pincode.length !== 6) {
      return { success: false, message: 'Please enter valid 6-digit delivery pincode' };
    }

    const { finalCustomerPrice, resellerProfit } = this.calculateFinalPrice(
      params.product.supplierPrice * params.quantity,
      params.resellerMargin
    );

    const orderNum = `KM-RES-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: ResellerOrder = {
      id: `ord-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      orderNumber: orderNum,
      productId: params.product.id,
      productTitle: params.product.title,
      productImage: params.product.images[0] || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=400',
      category: params.product.category,
      size: params.size,
      quantity: params.quantity,
      supplierPrice: params.product.supplierPrice * params.quantity,
      resellerMargin: resellerProfit,
      finalCustomerPrice,
      customerName: params.customerName.trim(),
      customerPhone: params.customerPhone.trim(),
      customerAddress: params.customerAddress.trim(),
      pincode: params.pincode.trim(),
      city: params.city.trim() || 'New Delhi',
      state: params.state.trim() || 'Delhi',
      paymentMethod: params.paymentMethod,
      status: 'Placed',
      trackingNumber: `TRK-${Math.floor(100000 + Math.random() * 900000)}`,
      courierName: 'Delhivery Surface Pro',
      createdAt: 'Just now',
      estimatedDelivery: '3-5 Business Days',
      resellerId: 'usr-current',
      resellerName: 'Arjun Verma (You)',
      supplierId: params.product.supplierId,
      supplierName: params.product.supplierName
    };

    this.orders = [newOrder, ...this.orders];
    this.earnings.totalOrdersCount += 1;
    this.earnings.pendingPayout += resellerProfit;

    // Deduct stock safely
    const prod = this.products.find(p => p.id === params.product.id);
    if (prod && prod.stock > 0) {
      prod.stock = Math.max(0, prod.stock - params.quantity);
    }

    this.saveToStorage();

    // Notify user
    notificationService.addNotification({
      title: `Order Placed! #${orderNum} 📦`,
      message: `Customer order for ${params.product.title.slice(0, 24)}... recorded. ₹${resellerProfit} margin will be paid on delivery!`,
      category: 'rewards',
      priority: 'high',
      iconType: 'gift'
    });

    // Try posting to backend
    fetch('/api/marketplace/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newOrder)
    }).catch(err => console.warn('Order sync to backend deferred:', err));

    return { success: true, order: newOrder, message: `Order #${orderNum} placed successfully!` };
  }

  public updateOrderStatus(orderId: string, status: OrderStatus, trackingNumber?: string): boolean {
    const order = this.orders.find(o => o.id === orderId);
    if (!order) return false;

    const prevStatus = order.status;
    order.status = status;
    if (trackingNumber) order.trackingNumber = trackingNumber;

    // If order transitioned to Delivered, move margin from pending to earned
    if (status === 'Delivered' && prevStatus !== 'Delivered') {
      this.earnings.totalMarginEarned += order.resellerMargin;
      this.earnings.pendingPayout = Math.max(0, this.earnings.pendingPayout - order.resellerMargin);
      this.earnings.deliveredOrdersCount += 1;

      notificationService.addNotification({
        title: `Margin Credited! +₹${order.resellerMargin} 💰`,
        message: `Order #${order.orderNumber} delivered to ${order.customerName}. ₹${order.resellerMargin} is ready for UPI withdrawal!`,
        category: 'rewards',
        priority: 'high',
        iconType: 'gift'
      });
    }

    this.saveToStorage();

    // Backend sync
    fetch(`/api/marketplace/orders/${orderId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, trackingNumber })
    }).catch(e => console.warn('Order status sync error:', e));

    return true;
  }

  // --------------------------------------------------
  // EARNINGS & WITHDRAWAL
  // --------------------------------------------------
  public getEarnings(): ResellerEarnings {
    return this.earnings;
  }

  public updateBankDetails(details: {
    upiId?: string;
    bankAccountHolder?: string;
    bankAccountNumber?: string;
    bankIfsc?: string;
  }) {
    if (details.upiId !== undefined) this.earnings.upiId = details.upiId;
    if (details.bankAccountHolder !== undefined) this.earnings.bankAccountHolder = details.bankAccountHolder;
    if (details.bankAccountNumber !== undefined) this.earnings.bankAccountNumber = details.bankAccountNumber;
    if (details.bankIfsc !== undefined) this.earnings.bankIfsc = details.bankIfsc;
    this.saveToStorage();
  }

  public requestPayoutWithdrawal(amount: number): { success: boolean; message: string } {
    if (amount <= 0 || amount > this.earnings.totalMarginEarned) {
      return { success: false, message: 'Invalid payout withdrawal amount' };
    }
    if (!this.earnings.upiId && !this.earnings.bankAccountNumber) {
      return { success: false, message: 'Please enter your UPI ID or Bank Details to receive margin payout' };
    }

    this.earnings.totalMarginEarned -= amount;
    this.earnings.withdrawnAmount += amount;
    this.saveToStorage();

    notificationService.addNotification({
      title: `Payout Transferred: ₹${amount} 💸`,
      message: `Your reseller earnings of ₹${amount} were successfully initiated to ${this.earnings.upiId || 'your bank account'}.`,
      category: 'rewards',
      priority: 'high',
      iconType: 'gift'
    });

    return { success: true, message: `₹${amount} margin payout transferred successfully to ${this.earnings.upiId || 'Bank'}` };
  }

  // --------------------------------------------------
  // SUPPLIER SYSTEM
  // --------------------------------------------------
  public getSuppliers(): SupplierProfile[] {
    return this.suppliers;
  }

  public registerSupplier(data: {
    businessName: string;
    ownerName: string;
    phone: string;
    email: string;
    city: string;
    state: string;
    categories: ResellerCategory[];
    gstOrPan?: string;
  }): { success: boolean; message: string; supplierId?: string } {
    if (!data.businessName.trim() || !data.ownerName.trim() || !data.phone.trim()) {
      return { success: false, message: 'Please complete required business details' };
    }

    const newSupplier: SupplierProfile = {
      id: `sup-${Date.now().toString().slice(-4)}`,
      businessName: data.businessName.trim(),
      ownerName: data.ownerName.trim(),
      phone: data.phone.trim(),
      email: data.email.trim() || 'supplier@khelmitra.in',
      city: data.city.trim() || 'Surat',
      state: data.state.trim() || 'Gujarat',
      categories: data.categories.length > 0 ? data.categories : ['Ladies Kurti'],
      status: this.config.supplierAutoApproval ? 'approved' : 'pending',
      totalProducts: 0,
      totalOrders: 0,
      rating: 5.0,
      createdAt: 'Today',
      gstOrPan: data.gstOrPan
    };

    this.suppliers = [newSupplier, ...this.suppliers];
    this.saveToStorage();

    notificationService.addNotification({
      title: 'Supplier Application Submitted 🏭',
      message: `Your wholesale application for "${data.businessName}" is under verification by KhelMitra Master Owner.`,
      category: 'support',
      priority: 'normal',
      iconType: 'support'
    });

    return { 
      success: true, 
      supplierId: newSupplier.id, 
      message: this.config.supplierAutoApproval 
        ? 'Supplier account approved automatically!' 
        : 'Application submitted! Awaiting Master Owner review.' 
    };
  }

  public updateSupplierStatus(supplierId: string, status: 'approved' | 'rejected' | 'pending'): boolean {
    const sup = this.suppliers.find(s => s.id === supplierId);
    if (!sup) return false;
    sup.status = status;
    this.saveToStorage();
    return true;
  }

  public uploadSupplierProduct(data: {
    title: string;
    category: ResellerCategory;
    description: string;
    supplierPrice: number;
    suggestedMrp: number;
    stock: number;
    fabric: string;
    sizes: string[];
    imageUrl: string;
    supplierId?: string;
  }): { success: boolean; product?: ResellerProduct; message: string } {
    if (!data.title.trim() || data.supplierPrice <= 0) {
      return { success: false, message: 'Please provide valid product title and wholesale price' };
    }

    const supplier = this.suppliers.find(s => s.id === (data.supplierId || this.currentSupplierId)) || this.suppliers[0];

    const newProd: ResellerProduct = {
      id: `prod-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: data.title.trim(),
      category: data.category,
      description: data.description.trim() || 'Direct from wholesale factory. Premium quality guaranteed.',
      images: [
        data.imageUrl.trim() || 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=800',
      ],
      supplierPrice: Math.floor(data.supplierPrice),
      suggestedMrp: Math.max(data.suggestedMrp || Math.floor(data.supplierPrice * 2.5), data.supplierPrice + 100),
      minMargin: 50,
      maxMargin: Math.floor(data.supplierPrice * 1.5),
      stock: data.stock || 50,
      fabric: data.fabric || '100% Quality Inspected',
      sizes: data.sizes.length > 0 ? data.sizes : ['Free Size'],
      rating: 5.0,
      reviewsCount: 1,
      supplierId: supplier.id,
      supplierName: supplier.businessName,
      inStock: true,
      tags: ['New Arrival', 'Factory Direct'],
      featured: false
    };

    this.products = [newProd, ...this.products];
    supplier.totalProducts += 1;
    this.saveToStorage();

    return { success: true, product: newProd, message: 'Product listed on KhelMitra Reseller Marketplace!' };
  }

  public toggleProductStock(productId: string): boolean {
    const prod = this.products.find(p => p.id === productId);
    if (!prod) return false;
    prod.inStock = !prod.inStock;
    this.saveToStorage();
    return true;
  }

  // --------------------------------------------------
  // MASTER OWNER CONFIGURATION
  // --------------------------------------------------
  public getMarketplaceConfig(): MarketplaceConfig {
    return this.config;
  }

  public updateMarketplaceConfig(patch: Partial<MarketplaceConfig>) {
    this.config = { ...this.config, ...patch };
    this.saveToStorage();
  }

  public getMarketplaceStats() {
    const totalOrders = this.orders.length;
    const deliveredOrders = this.orders.filter(o => o.status === 'Delivered').length;
    const gmv = this.orders.reduce((sum, o) => sum + o.finalCustomerPrice, 0);
    const totalMarginsPaid = this.earnings.withdrawnAmount;
    const activeSuppliers = this.suppliers.filter(s => s.status === 'approved').length;
    const totalProducts = this.products.length;

    return {
      totalOrders,
      deliveredOrders,
      gmv,
      totalMarginsPaid,
      activeSuppliers,
      totalProducts,
      resellerSatisfaction: '99.4%'
    };
  }
}

export const resellingService = new ResellingService();
