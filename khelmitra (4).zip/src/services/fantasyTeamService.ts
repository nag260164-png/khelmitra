import { UserTeam, FantasyPlayer, LiveMatch } from '../types';
import { COMPREHENSIVE_MATCHES } from '../data/cricketData';

const STORAGE_KEY = 'khelmitra_fantasy_user_teams_v1';

// Standard demo points calculation rules
export interface ScoringRuleCategory {
  category: string;
  items: { action: string; points: string; description: string }[];
}

export const DEMO_SCORING_SYSTEM: ScoringRuleCategory[] = [
  {
    category: 'Batting Demo Points',
    items: [
      { action: 'Run Scored', points: '+1 pt', description: 'Every run scored off the bat' },
      { action: 'Boundary Bonus (4s)', points: '+1 bonus pt', description: 'Bonus for every four hit' },
      { action: 'Six Bonus (6s)', points: '+2 bonus pts', description: 'Bonus for every six hit' },
      { action: 'Half-Century (50)', points: '+8 bonus pts', description: 'Score of 50 or more runs in innings' },
      { action: 'Century (100)', points: '+16 bonus pts', description: 'Score of 100 or more runs (replaces 50-run bonus)' },
      { action: 'Duck Dismissal Penalty', points: '-2 pts', description: 'Dismissal for 0 runs (BAT, WK, AR)' },
    ],
  },
  {
    category: 'Bowling Demo Points',
    items: [
      { action: 'Wicket Taken', points: '+25 pts', description: 'Bowled, Caught, LBW, Stumped, Hit Wicket' },
      { action: 'Maiden Over', points: '+8 pts', description: 'Over with 0 runs conceded' },
      { action: '3-Wicket Haul', points: '+8 bonus pts', description: 'Bonus for claiming 3 or 4 wickets in match' },
      { action: '5-Wicket Haul', points: '+16 bonus pts', description: 'Bonus for claiming 5 or more wickets (replaces 3-wkt bonus)' },
    ],
  },
  {
    category: 'Fielding Demo Points',
    items: [
      { action: 'Catch Taken', points: '+8 pts', description: 'Fielding catch resulting in dismissal' },
      { action: 'Stumping', points: '+12 pts', description: 'Wicketkeeper stumping dismissal' },
      { action: 'Run-Out Dismissal', points: '+6 pts', description: 'Credited to thrower/catcher in run-out' },
    ],
  },
  {
    category: 'Captain & Vice-Captain Multipliers',
    items: [
      { action: 'Captain (C)', points: '2.0x Multiplier', description: 'Captain earns 2x total demo points (Doubled)' },
      { action: 'Vice-Captain (VC)', points: '1.5x Multiplier', description: 'Vice-Captain earns 1.5x total demo points' },
      { action: 'Role Diversity', points: 'Required', description: 'Captain and Vice-Captain must be different players' },
      { action: 'Fair Play Policy', points: '100% Free Demo', description: 'Demo points simulation only. No real money or betting.' },
    ],
  },
];

// Helper to get all available players for a given match
export function getAvailablePlayersForMatch(matchId: string): FantasyPlayer[] {
  const match = COMPREHENSIVE_MATCHES.find((m) => m.id === matchId) || COMPREHENSIVE_MATCHES[0];
  const players: FantasyPlayer[] = [];

  const mapRole = (roleStr: string, isWk?: boolean): 'WK' | 'BAT' | 'AR' | 'BOWL' => {
    if (isWk || roleStr.toLowerCase().includes('keeper') || roleStr.toLowerCase().includes('wk')) return 'WK';
    if (roleStr.toLowerCase().includes('all-round')) return 'AR';
    if (roleStr.toLowerCase().includes('bowl')) return 'BOWL';
    return 'BAT';
  };

  // Base credits generator based on role and prominence
  const getCredits = (name: string, role: string): number => {
    const starNames = ['Kohli', 'Rohit', 'Bumrah', 'Maxwell', 'Head', 'Starc', 'Buttler', 'Babar', 'Afridi', 'Dhoni', 'Jadeja', 'Pant', 'Gill'];
    const isStar = starNames.some((s) => name.includes(s));
    if (isStar) return 9.5 + (name.charCodeAt(0) % 3) * 0.5; // 9.5 - 10.5
    if (role === 'AR') return 8.5 + (name.charCodeAt(1) % 3) * 0.5;
    if (role === 'BOWL') return 8.0 + (name.charCodeAt(2) % 3) * 0.5;
    if (role === 'BAT') return 8.5 + (name.charCodeAt(1) % 2) * 0.5;
    return 8.5;
  };

  // Base points generator
  const getBasePoints = (name: string): number => {
    return 30 + ((name.charCodeAt(0) * 7 + name.charCodeAt(1) * 3) % 85);
  };

  const getSelectedPercent = (name: string): number => {
    return 40 + ((name.charCodeAt(0) * 11) % 55);
  };

  // Add Team 1 players
  if (match.playingXI?.team1) {
    match.playingXI.team1.forEach((p) => {
      const role = mapRole(p.role, p.isWk);
      players.push({
        id: p.id,
        name: p.name,
        teamName: match.team1.name,
        teamShortName: match.team1.shortName,
        role,
        credits: getCredits(p.name, role),
        points: getBasePoints(p.name),
        selectedByPercent: getSelectedPercent(p.name),
        battingStyle: p.battingStyle || 'Right Handed',
        bowlingStyle: p.bowlingStyle || 'Right-arm Fast',
        flagColor: match.team1.flagColor,
        recentScores: [34, 52, 18, 76, 29],
      });
    });
  }

  // Add Team 2 players
  if (match.playingXI?.team2) {
    match.playingXI.team2.forEach((p) => {
      const role = mapRole(p.role, p.isWk);
      players.push({
        id: p.id,
        name: p.name,
        teamName: match.team2.name,
        teamShortName: match.team2.shortName,
        role,
        credits: getCredits(p.name, role),
        points: getBasePoints(p.name),
        selectedByPercent: getSelectedPercent(p.name),
        battingStyle: p.battingStyle || 'Right Handed',
        bowlingStyle: p.bowlingStyle || 'Right-arm Spin',
        flagColor: match.team2.flagColor,
        recentScores: [48, 64, 12, 85, 41],
      });
    });
  }

  return players;
}

// Initial default teams for first load
const createInitialSeedTeams = (): UserTeam[] => {
  const match1Players = getAvailablePlayersForMatch('match-live-1');
  
  // Pick a valid 11 from match 1 (IND vs AUS):
  // 1 WK (Pant), 4 BAT (Kohli, Rohit, Head, Warner), 3 AR (Pandya, Jadeja, Maxwell), 3 BOWL (Bumrah, Starc, Cummins)
  const selectedMatch1 = [
    match1Players.find((p) => p.name.includes('Pant')) || match1Players[6], // WK
    match1Players.find((p) => p.name.includes('Kohli')) || match1Players[0], // BAT
    match1Players.find((p) => p.name.includes('Rohit')) || match1Players[1], // BAT
    match1Players.find((p) => p.name.includes('Head')) || match1Players[2], // BAT
    match1Players.find((p) => p.name.includes('Warner')) || match1Players[3], // BAT
    match1Players.find((p) => p.name.includes('Pandya')) || match1Players[4], // AR
    match1Players.find((p) => p.name.includes('Jadeja')) || match1Players[5], // AR
    match1Players.find((p) => p.name.includes('Maxwell')) || match1Players[7], // AR
    match1Players.find((p) => p.name.includes('Bumrah')) || match1Players[8], // BOWL
    match1Players.find((p) => p.name.includes('Starc')) || match1Players[9], // BOWL
    match1Players.find((p) => p.name.includes('Cummins')) || match1Players[10], // BOWL
  ].filter(Boolean) as FantasyPlayer[];

  const cap1 = selectedMatch1.find((p) => p.name.includes('Kohli')) || selectedMatch1[0];
  const vc1 = selectedMatch1.find((p) => p.name.includes('Bumrah')) || selectedMatch1[1];

  const team1: UserTeam = {
    id: 'team-1',
    name: 'India Champions (T1)',
    match: 'IND vs AUS • ICC T20 Final',
    matchId: 'match-live-1',
    captain: `${cap1?.name || 'Captain'} (2x Pts)`,
    captainId: cap1?.id || 'ind-1',
    viceCaptain: `${vc1?.name || 'Vice Captain'} (1.5x Pts)`,
    viceCaptainId: vc1?.id || 'ind-2',
    wicketKeepers: 1,
    batsmen: 4,
    allRounders: 3,
    bowlers: 3,
    totalPoints: 642.5,
    rank: 1840,
    status: 'In Contest',
    players: selectedMatch1,
    team1Count: 4,
    team2Count: 7,
    team1ShortName: 'AUS',
    team2ShortName: 'IND',
    totalCreditsUsed: 98.0,
    updatedAt: 'Just now',
  };

  // Match 2: ENG vs SA
  const match2Players = getAvailablePlayersForMatch('match-live-2');
  const selectedMatch2 = [
    match2Players.find((p) => p.name.includes('Buttler')) || match2Players[0],
    match2Players.find((p) => p.name.includes('Root')) || match2Players[1],
    match2Players.find((p) => p.name.includes('Brook')) || match2Players[2],
    match2Players.find((p) => p.name.includes('Bavuma')) || match2Players[3],
    match2Players.find((p) => p.name.includes('Markram')) || match2Players[4],
    match2Players.find((p) => p.name.includes('Livingstone')) || match2Players[5],
    match2Players.find((p) => p.name.includes('Jansen')) || match2Players[6],
    match2Players.find((p) => p.name.includes('Rabada')) || match2Players[7],
    match2Players.find((p) => p.name.includes('Archer')) || match2Players[8],
    match2Players.find((p) => p.name.includes('Nortje')) || match2Players[9],
    match2Players.find((p) => p.name.includes('Wood')) || match2Players[10],
  ].filter(Boolean) as FantasyPlayer[];

  const cap2 = selectedMatch2.find((p) => p.name.includes('Buttler')) || selectedMatch2[0];
  const vc2 = selectedMatch2.find((p) => p.name.includes('Rabada')) || selectedMatch2[1];

  const team2: UserTeam = {
    id: 'team-2',
    name: 'Lords Strikers (T2)',
    match: 'ENG vs SA • ODI Match 14',
    matchId: 'match-live-2',
    captain: `${cap2?.name || 'Captain'} (2x Pts)`,
    captainId: cap2?.id || 'sa-1',
    viceCaptain: `${vc2?.name || 'Vice Captain'} (1.5x Pts)`,
    viceCaptainId: vc2?.id || 'eng-1',
    wicketKeepers: 1,
    batsmen: 4,
    allRounders: 2,
    bowlers: 4,
    totalPoints: 510.0,
    rank: 3190,
    status: 'In Contest',
    players: selectedMatch2,
    team1Count: 5,
    team2Count: 6,
    team1ShortName: 'SA',
    team2ShortName: 'ENG',
    totalCreditsUsed: 96.5,
    updatedAt: '1 hour ago',
  };

  return [team1, team2];
};

type FantasyTeamListener = (teams: UserTeam[]) => void;

class FantasyTeamService {
  private teams: UserTeam[] = [];
  private listeners: Set<FantasyTeamListener> = new Set();

  constructor() {
    this.loadTeamsFromStorage();
  }

  private loadTeamsFromStorage() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          this.teams = parsed;
          return;
        }
      }
    } catch (e) {
      console.warn('Could not read fantasy teams from local storage', e);
    }
    this.teams = createInitialSeedTeams();
    this.saveToStorage();
  }

  private saveToStorage() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.teams));
    } catch (e) {
      console.warn('Could not save fantasy teams to local storage', e);
    }
  }

  private notify() {
    this.saveToStorage();
    this.listeners.forEach((listener) => listener([...this.teams]));
  }

  public subscribe(listener: FantasyTeamListener): () => void {
    this.listeners.add(listener);
    listener([...this.teams]);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getTeams(): UserTeam[] {
    return [...this.teams];
  }

  public getTeamById(id: string): UserTeam | undefined {
    return this.teams.find((t) => t.id === id);
  }

  public saveTeam(team: UserTeam): { success: boolean; message: string; team?: UserTeam } {
    const existingIndex = this.teams.findIndex((t) => t.id === team.id);
    if (existingIndex >= 0) {
      this.teams[existingIndex] = { ...team, updatedAt: 'Updated just now' };
    } else {
      this.teams.unshift({
        ...team,
        updatedAt: 'Created just now',
      });
    }
    this.notify();
    return { success: true, message: 'Fantasy Team saved successfully!', team };
  }

  public deleteTeam(id: string): boolean {
    const initialLen = this.teams.length;
    this.teams = this.teams.filter((t) => t.id !== id);
    if (this.teams.length !== initialLen) {
      this.notify();
      return true;
    }
    return false;
  }

  // Live Team Composition Validation
  public validateTeamComposition(
    selectedPlayers: FantasyPlayer[],
    captainId?: string | null,
    viceCaptainId?: string | null
  ): {
    isValid: boolean;
    errors: string[];
    roleCounts: { wk: number; bat: number; ar: number; bowl: number };
    teamCounts: { [team: string]: number };
    totalCredits: number;
    creditsLeft: number;
  } {
    const errors: string[] = [];
    const roleCounts = { wk: 0, bat: 0, ar: 0, bowl: 0 };
    const teamCounts: { [team: string]: number } = {};
    let totalCredits = 0;

    selectedPlayers.forEach((p) => {
      totalCredits += p.credits;
      teamCounts[p.teamShortName] = (teamCounts[p.teamShortName] || 0) + 1;

      if (p.role === 'WK') roleCounts.wk++;
      else if (p.role === 'BAT') roleCounts.bat++;
      else if (p.role === 'AR') roleCounts.ar++;
      else if (p.role === 'BOWL') roleCounts.bowl++;
    });

    // 1. Total players rule
    if (selectedPlayers.length !== 11) {
      errors.push(`Select exactly 11 players (${selectedPlayers.length}/11 selected)`);
    }

    // 2. Minimum 1 Wicketkeeper
    if (roleCounts.wk < 1) {
      errors.push('Must select at least 1 Wicketkeeper (WK)');
    }

    // 3. Minimum 1 Batter
    if (roleCounts.bat < 1) {
      errors.push('Must select at least 1 Batter (BAT)');
    }

    // 4. Minimum 1 All-Rounder
    if (roleCounts.ar < 1) {
      errors.push('Must select at least 1 All-Rounder (AR)');
    }

    // 5. Minimum 1 Bowler
    if (roleCounts.bowl < 1) {
      errors.push('Must select at least 1 Bowler (BOWL)');
    }

    // 6. Max 7 players from any single team
    Object.entries(teamCounts).forEach(([team, count]) => {
      if (count > 7) {
        errors.push(`Maximum 7 players allowed from a single team (${team} has ${count})`);
      }
    });

    // 7. Maximum 100 Credits budget
    const roundedCredits = Math.round(totalCredits * 10) / 10;
    if (roundedCredits > 100) {
      errors.push(`Credits exceeded limit: ${roundedCredits}/100.0`);
    }

    // 8. Captain and Vice Captain checks
    if (selectedPlayers.length === 11) {
      if (!captainId) {
        errors.push('Select a Captain (C) for 2x demo points');
      }
      if (!viceCaptainId) {
        errors.push('Select a Vice-Captain (VC) for 1.5x demo points');
      }
      if (captainId && viceCaptainId && captainId === viceCaptainId) {
        errors.push('Captain (C) and Vice-Captain (VC) must be different players');
      }
    }

    return {
      isValid: errors.length === 0,
      errors,
      roleCounts,
      teamCounts,
      totalCredits: roundedCredits,
      creditsLeft: Math.round((100 - roundedCredits) * 10) / 10,
    };
  }

  public getMatchesList(): LiveMatch[] {
    return COMPREHENSIVE_MATCHES;
  }
}

export const fantasyTeamService = new FantasyTeamService();
