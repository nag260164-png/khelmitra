// Multiplayer-ready architecture service for KhelMitra mobile gaming
// Supports Room Creation, Room Joining with Code, Quick Matchmaking,
// Real-time simulated player presence, in-game floating emotes, and tactical chat.

export type SupportedGameId = 'call-break' | 'teen-patti' | 'ludo' | 'rummy';

export interface MultiplayerPlayer {
  id: string;
  name: string;
  avatar: string;
  location: string;
  level: number;
  tier: string;
  isReady: boolean;
  isHost: boolean;
  pingMs: number;
}

export interface MultiplayerEmoteEvent {
  id: string;
  playerId: string;
  playerName: string;
  emote: string; // '👍' | '🔥' | '🏆' | '😂' | '👏' | '💥' | '😎' | '🎯'
  timestamp: number;
}

export interface MultiplayerChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
}

export interface GameRoom {
  roomId: string;
  gameId: SupportedGameId;
  gameTitle: string;
  entryCoins: number;
  prizeCoins: number;
  maxPlayers: number;
  status: 'waiting' | 'ready' | 'playing';
  players: MultiplayerPlayer[];
  createdAt: number;
}

const BOT_ROSTER: Array<{ name: string; avatar: string; location: string; tier: string }> = [
  { name: 'Aarav Sharma', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150', location: 'Mumbai', tier: 'Master' },
  { name: 'Priya Patel', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', location: 'Ahmedabad', tier: 'Diamond' },
  { name: 'Vikram Rajput', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150', location: 'Jaipur', tier: 'Grandmaster' },
  { name: 'Ananya Roy', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', location: 'Kolkata', tier: 'Platinum' },
  { name: 'Rohan Verma', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', location: 'Delhi', tier: 'Gold' },
  { name: 'Neha Joshi', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150', location: 'Pune', tier: 'Diamond' },
];

class MultiplayerService {
  private currentRoom: GameRoom | null = null;
  private roomListeners: Array<(room: GameRoom | null) => void> = [];
  private emoteListeners: Array<(event: MultiplayerEmoteEvent) => void> = [];
  private chatListeners: Array<(msg: MultiplayerChatMessage) => void> = [];

  public getRoom(): GameRoom | null {
    return this.currentRoom;
  }

  public subscribeRoom(callback: (room: GameRoom | null) => void) {
    this.roomListeners.push(callback);
    callback(this.currentRoom);
    return () => {
      this.roomListeners = this.roomListeners.filter(cb => cb !== callback);
    };
  }

  public subscribeEmotes(callback: (event: MultiplayerEmoteEvent) => void) {
    this.emoteListeners.push(callback);
    return () => {
      this.emoteListeners = this.emoteListeners.filter(cb => cb !== callback);
    };
  }

  public subscribeChat(callback: (msg: MultiplayerChatMessage) => void) {
    this.chatListeners.push(callback);
    return () => {
      this.chatListeners = this.chatListeners.filter(cb => cb !== callback);
    };
  }

  private notifyRoom() {
    this.roomListeners.forEach(cb => cb(this.currentRoom));
  }

  // Create Private Room with custom Code
  public createPrivateRoom(gameId: SupportedGameId, gameTitle: string, entryCoins: number = 500, maxPlayers: number = 4): GameRoom {
    const codeDigits = Math.floor(1000 + Math.random() * 9000);
    const roomId = `KHEL-${codeDigits}`;

    const humanPlayer: MultiplayerPlayer = {
      id: 'human_player',
      name: 'You (Host)',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      location: 'India',
      level: 28,
      tier: 'Master',
      isReady: true,
      isHost: true,
      pingMs: 24,
    };

    // Add 2-3 matched online players to simulate lively multiplayer lobby
    const matchedBots = BOT_ROSTER.slice(0, maxPlayers - 1).map((bot, i) => ({
      id: `bot_seat_${i + 1}`,
      name: bot.name,
      avatar: bot.avatar,
      location: bot.location,
      level: 20 + i * 3,
      tier: bot.tier,
      isReady: true,
      isHost: false,
      pingMs: 28 + Math.floor(Math.random() * 20),
    }));

    this.currentRoom = {
      roomId,
      gameId,
      gameTitle,
      entryCoins,
      prizeCoins: entryCoins * maxPlayers * 0.9,
      maxPlayers,
      status: 'ready',
      players: [humanPlayer, ...matchedBots],
      createdAt: Date.now(),
    };

    this.notifyRoom();
    return this.currentRoom;
  }

  // Quick Matchmaking
  public quickMatchmake(gameId: SupportedGameId, gameTitle: string, entryCoins: number = 500, maxPlayers: number = 4): Promise<GameRoom> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const room = this.createPrivateRoom(gameId, gameTitle, entryCoins, maxPlayers);
        resolve(room);
      }, 1200);
    });
  }

  // Join Room by Code
  public joinRoomByCode(code: string, gameId: SupportedGameId, gameTitle: string): GameRoom {
    const sanitizedCode = code.toUpperCase().trim();
    const humanPlayer: MultiplayerPlayer = {
      id: 'human_player',
      name: 'You',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      location: 'India',
      level: 28,
      tier: 'Master',
      isReady: true,
      isHost: false,
      pingMs: 26,
    };

    const matchedBots = BOT_ROSTER.slice(0, 3).map((bot, i) => ({
      id: `bot_seat_${i + 1}`,
      name: bot.name,
      avatar: bot.avatar,
      location: bot.location,
      level: 22 + i * 2,
      tier: bot.tier,
      isReady: true,
      isHost: i === 0,
      pingMs: 30 + Math.floor(Math.random() * 15),
    }));

    this.currentRoom = {
      roomId: sanitizedCode.startsWith('KHEL-') ? sanitizedCode : `KHEL-${sanitizedCode}`,
      gameId,
      gameTitle,
      entryCoins: 500,
      prizeCoins: 1800,
      maxPlayers: 4,
      status: 'playing',
      players: [humanPlayer, ...matchedBots],
      createdAt: Date.now(),
    };

    this.notifyRoom();
    return this.currentRoom;
  }

  // Send In-Game Floating Emote
  public sendEmote(emote: string, playerId: string = 'human_player', playerName: string = 'You') {
    const event: MultiplayerEmoteEvent = {
      id: `emote_${Date.now()}_${Math.random()}`,
      playerId,
      playerName,
      emote,
      timestamp: Date.now(),
    };
    this.emoteListeners.forEach(cb => cb(event));

    // Occasionally have an opponent reply with an emote after 1.5s for authentic multiplayer banter
    if (playerId === 'human_player' && Math.random() > 0.4) {
      setTimeout(() => {
        const reactions = ['🔥', '👏', '😎', '🏆', '👍'];
        const randomEmote = reactions[Math.floor(Math.random() * reactions.length)];
        const randomBot = BOT_ROSTER[Math.floor(Math.random() * BOT_ROSTER.length)];
        const replyEvent: MultiplayerEmoteEvent = {
          id: `emote_bot_${Date.now()}`,
          playerId: 'bot_reply',
          playerName: randomBot.name,
          emote: randomEmote,
          timestamp: Date.now(),
        };
        this.emoteListeners.forEach(cb => cb(replyEvent));
      }, 1400);
    }
  }

  // Send In-Game Tactical Chat Message
  public sendChat(text: string, senderId: string = 'human_player', senderName: string = 'You') {
    const msg: MultiplayerChatMessage = {
      id: `chat_${Date.now()}_${Math.random()}`,
      senderId,
      senderName,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    this.chatListeners.forEach(cb => cb(msg));

    // Automated tactical responses from opponents
    if (senderId === 'human_player') {
      setTimeout(() => {
        const replies = ['Good game!', 'Well played bro!', 'Nice move!', 'Watch this!', 'GG 👑'];
        const randomReply = replies[Math.floor(Math.random() * replies.length)];
        const randomBot = BOT_ROSTER[Math.floor(Math.random() * BOT_ROSTER.length)];
        const replyMsg: MultiplayerChatMessage = {
          id: `chat_bot_${Date.now()}`,
          senderId: 'bot_reply',
          senderName: randomBot.name,
          text: randomReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        this.chatListeners.forEach(cb => cb(replyMsg));
      }, 1600);
    }
  }

  public leaveRoom() {
    this.currentRoom = null;
    this.notifyRoom();
  }
}

export const multiplayerService = new MultiplayerService();
