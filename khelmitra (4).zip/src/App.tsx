import { useState, useEffect } from 'react';
import AndroidStatusBar from './components/AndroidStatusBar';
import AppHeader from './components/AppHeader';
import MainActionCards from './components/MainActionCards';
import FeaturedLiveMatch from './components/FeaturedLiveMatch';
import FantasyMegaBanner from './components/FantasyMegaBanner';
import UpcomingMatches from './components/UpcomingMatches';
import MyTeamsWidget from './components/MyTeamsWidget';
import InstantGamesSection from './components/InstantGamesSection';
import HomeGamingDashboard from './components/games/HomeGamingDashboard';
import DailyMissionBanner from './components/DailyMissionBanner';
import AndroidBottomNav from './components/AndroidBottomNav';
import ActionModalSheet from './components/ActionModalSheet';
import SuperAppModeSwitcher from './components/reselling/SuperAppModeSwitcher';
import ResellingMarketplaceView from './components/reselling/ResellingMarketplaceView';
import { CURRENT_USER, LIVE_MATCHES, FANTASY_CONTESTS, USER_TEAMS, GAMES_LIST } from './data/mockData';
import { ActiveSheetType, SuperAppMode, ResellerProduct } from './types';
import { Flame, ShieldCheck, Sparkles, Bell, AlertOctagon, Lock } from 'lucide-react';
import { masterOwnerService } from './services/masterOwnerService';
import { resellingService } from './services/resellingService';

export default function App() {
  const [activeSheet, setActiveSheet] = useState<ActiveSheetType>('none');
  const [superAppMode, setSuperAppMode] = useState<SuperAppMode>('gaming');
  const [appConfig, setAppConfig] = useState(masterOwnerService.getAppConfig());
  const [isOwnerAuth, setIsOwnerAuth] = useState(masterOwnerService.isOwnerAuthenticated());
  const [resellerEarnings, setResellerEarnings] = useState(resellingService.getEarnings().totalMarginEarned);

  useEffect(() => {
    const unsubMaster = masterOwnerService.subscribe(() => {
      setAppConfig({ ...masterOwnerService.getAppConfig() });
      setIsOwnerAuth(masterOwnerService.isOwnerAuthenticated());
    });

    const unsubReseller = resellingService.subscribe(() => {
      setResellerEarnings(resellingService.getEarnings().totalMarginEarned);
    });

    return () => {
      unsubMaster();
      unsubReseller();
    };
  }, []);

  const handleOpenSheet = (sheet: ActiveSheetType) => {
    setActiveSheet(sheet);
  };

  const handleCloseSheet = () => {
    setActiveSheet('none');
  };

  const handleOpenProductDetail = (product: ResellerProduct) => {
    resellingService.setActiveProduct(product);
    setActiveSheet('product-detail');
  };

  const handleQuickOrder = (product: ResellerProduct) => {
    resellingService.setActiveProduct(product);
    setActiveSheet('cart-checkout');
  };

  return (
    <div className="min-h-screen w-full bg-[#04060a] flex justify-center text-slate-100 font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Mobile-first Android container frame */}
      <div 
        id="khelmitra-home-screen"
        className="w-full max-w-md min-h-screen bg-[#070b14] relative flex flex-col border-x border-slate-900/80 shadow-[0_0_60px_rgba(0,0,0,0.85)] pb-24"
      >
        {/* 1. Android Status Bar */}
        <AndroidStatusBar />

        {/* 2. Top Header with KhelMitra Logo, Wallet & Profile */}
        <AppHeader 
          user={CURRENT_USER} 
          onOpenSheet={handleOpenSheet} 
        />

        {/* 3. SUPER APP DUAL-MODE SWITCHER (Gaming vs Reselling) */}
        <SuperAppModeSwitcher
          mode={superAppMode}
          onSwitchMode={(newMode) => setSuperAppMode(newMode)}
          gamingCoins={CURRENT_USER.coins}
          resellerEarnings={resellerEarnings}
        />

        {/* Master Owner Broadcast Announcement */}
        {appConfig.announcement.active && (
          <div className="mx-4 mt-2 p-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-slate-900 to-amber-500/10 border border-amber-500/40 text-xs flex items-center justify-between shadow-sm animate-in fade-in">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                <Bell className="w-3.5 h-3.5" />
              </div>
              <div>
                <span className="font-bold text-amber-300 block leading-tight">{appConfig.announcement.title}</span>
                <span className="text-[11px] text-slate-300 line-clamp-1">{appConfig.announcement.message}</span>
              </div>
            </div>
            <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border font-mono ${
              appConfig.announcement.level === 'critical' 
                ? 'bg-red-500/20 text-red-300 border-red-500/40' 
                : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
            }`}>
              {appConfig.announcement.level}
            </span>
          </div>
        )}

        {/* Master Owner Maintenance Mode Indicator */}
        {appConfig.maintenanceMode && !isOwnerAuth && (
          <div className="mx-4 mt-2 p-3.5 rounded-2xl bg-red-950/40 border border-red-500/50 text-xs space-y-2 animate-in fade-in">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <AlertOctagon className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Scheduled Maintenance in Progress</h4>
                <span className="text-[11px] text-slate-300 leading-tight block">{appConfig.maintenanceMessage}</span>
              </div>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-red-900/60 text-[10px]">
              <span className="text-slate-400">Est. Return: {appConfig.maintenanceEstimatedReturn}</span>
              <button
                onClick={() => handleOpenSheet('master-owner')}
                className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 active:scale-95 transition-all"
              >
                <Lock className="w-3 h-3" /> Master Owner Login
              </button>
            </div>
          </div>
        )}

        {/* Home Screen Content: Conditional based on Super App Mode */}
        <main className="flex-1 space-y-2 pb-6">
          {superAppMode === 'gaming' ? (
            /* ==================================================== */
            /* 1. GAMING MODE: Fully Preserved Gaming Features      */
            /* ==================================================== */
            <>
              {/* Welcome User & Fair Play Gaming Banner Pill */}
              <div className="px-4 pt-2">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-gradient-to-r from-amber-500/10 via-slate-900/70 to-red-500/10 border border-amber-500/20 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400">
                      <Flame className="w-4 h-4 fill-amber-400/40 text-amber-400" />
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400">Welcome back,</span>
                      <span className="font-bold text-white ml-1">{CURRENT_USER.name}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      Fair Play 100%
                    </span>
                  </div>
                </div>
              </div>

              {/* Daily Missions & Streak Reward Banner */}
              <DailyMissionBanner onOpenMissions={handleOpenSheet} />

              {/* Quick Action Hub (Live Cricket, Fantasy Cricket, My Teams, Games, Profile) */}
              <MainActionCards 
                onSelectAction={handleOpenSheet}
                activeSheet={activeSheet}
              />

              {/* Live Cricket Score Card with Loading & Error States (PRESERVED) */}
              <FeaturedLiveMatch 
                match={LIVE_MATCHES[0]} 
                onOpenLiveCricket={handleOpenSheet} 
              />

              {/* Fantasy Cricket Card */}
              <FantasyMegaBanner 
                contest={FANTASY_CONTESTS[0]} 
                onOpenFantasy={handleOpenSheet} 
              />

              {/* Upcoming Matches Section */}
              <UpcomingMatches 
                onOpenSheet={handleOpenSheet} 
              />

              {/* My Teams Button & Squad Overview */}
              <MyTeamsWidget 
                teams={USER_TEAMS} 
                onOpenMyTeams={handleOpenSheet} 
              />

              {/* KhelMitra 4 Games Arena & Gaming Dashboard */}
              <HomeGamingDashboard 
                onOpenSheet={handleOpenSheet} 
              />

              {/* Additional Instant Skill Games & Quizzes */}
              <InstantGamesSection 
                games={GAMES_LIST} 
                onOpenGames={handleOpenSheet} 
              />

              {/* Fair Play & Trust Footer Badge */}
              <div className="px-4 pt-2 text-center">
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-900 text-[10px] text-slate-500 flex flex-col items-center gap-1">
                  <div className="flex items-center gap-1 text-slate-400 font-semibold">
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span>KhelMitra Sports Gaming Platform</span>
                  </div>
                  <p>Strict Fair Play Certified • 100% Free Virtual Coins • Skill Gaming Only</p>
                </div>
              </div>
            </>
          ) : (
            /* ==================================================== */
            /* 2. RESELLING MODE: Original Wholesale Marketplace    */
            /* ==================================================== */
            <>
              <ResellingMarketplaceView
                onOpenProductDetail={handleOpenProductDetail}
                onOpenDashboard={() => handleOpenSheet('reseller-dashboard')}
                onOpenSupplierPortal={() => handleOpenSheet('supplier-portal')}
                onPlaceQuickOrder={handleQuickOrder}
              />

              {/* Reseller Marketplace Trust Footer */}
              <div className="px-4 pt-1 text-center">
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-900 text-[10px] text-slate-500 flex flex-col items-center gap-1">
                  <div className="flex items-center gap-1 text-pink-400 font-semibold">
                    <Sparkles className="w-3 h-3 text-pink-400" />
                    <span>KhelMitra Direct Factory Reseller Network</span>
                  </div>
                  <p>Zero Capital Required • Surat & Jaipur Direct Rates • Cash on Delivery All-India</p>
                </div>
              </div>
            </>
          )}
        </main>

        {/* Android Bottom Navigation: Adapts to Gaming vs Reselling Mode */}
        <AndroidBottomNav 
          activeSheet={activeSheet} 
          onNavigate={handleOpenSheet} 
          mode={superAppMode}
        />

        {/* Interactive Action Modal Sheet (Supports Gaming, Admin & Reseller Sheets) */}
        <ActionModalSheet 
          sheetType={activeSheet} 
          user={CURRENT_USER} 
          onClose={handleCloseSheet} 
          onSwitchSheet={handleOpenSheet} 
        />
      </div>
    </div>
  );
}
